# Report: main.hero against spec.md

## verdict

Refused, on two lines:

- **Line 20** `step @ 2`: `step` is bound by `=` on line 10, and `=` binds once, forever. `@` may only re-bind a mutable cell (`@=`), so this re-binding is refused.
- **Line 22** `last @= words[0]`: `last` is a mutable cell that nothing re-binds. The spec makes a cell nothing re-binds a compile error. Line 25 only reads `last`, and a read is not a re-bind.

Everything else on the program is accepted by the rules I could check: `bump` writes its `@c` parameter, `counts` and `total` are re-bound in the loop, `c` is written through the `@c` arguments, and `words`, `step`, `counts`, `total` and `c` are all used.

Smallest change that is accepted and keeps the evident meaning: line 10 becomes `step @= 1` (so line 20 re-binds a cell), and line 22 becomes `last = words[0]` (an immutable binding of the same value, which needs no re-bind).

The submitted program prints:

```
5
5
a
```

Trace: `counts["a"]` ends at 3 (indices 0, 2, 4), so `total` ends at 5 and `c.hits` is 3 after the first `bump`. `step` is 2 at the second `bump`, so `c.hits` ends at 5. `last` is `words[0]`, which is `"a"`.

## lines

| line | source | new name or change | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (the parameter `c`, a mutable parameter) | "Param = "@" ident ":" Type"; "Mutable parameters are marked `@` in the signature and at the call site" |
| 6 | `c.hits @ c.hits + by` | *changes an existing name* (a field of the `@` parameter `c`) | "`@` re-binds it, or a field or element inside one"; "Place @ Expression" in Simple |
| 9 | `words = ["a", "b", "a", "c", "a"]` | *new name* | "`=` defines"; "`=` binds once, forever" |
| 10 | `step = 1` | *new name* | "`=` binds once, forever" (this is the reason line 20 fails) |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell" |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell" |
| 15 | `counts[w] @ counts[w].default(0) + step` | *changes an existing name* (an element of the cell `counts`) | "`@` re-binds it, or a field or element inside one" |
| 16 | `total @ total + step` | *changes an existing name* (the cell `total`) | "`@` re-binds it" |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell" |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (the `@` argument lets `bump` write the caller's `c`) | "the callee works on the caller's place itself"; "Mutable parameters are marked `@` in the signature and at the call site" |
| 20 | `step @ 2` | *changes an existing name* as written, but refused: `step` is an `=` name | "`=` binds once, forever"; "`@=` declares a mutable cell, and `@` re-binds it" |
| 21 | `bump(@c, step)` | *changes an existing name* (as line 19, through `c`) | as line 19 |
| 22 | `last @= words[0]` | *new name* (a cell that nothing re-binds, hence refused) | "`@=` declares a mutable cell"; "a cell nothing re-binds" in the error sentence of section 5 |

No other line holds `=` or `@`. The `Counter` record (lines 1 to 3) and the call `Counter(label: "a", hits: 0)` on line 18 use only `:` for field names and arguments, so they are not rows.

## sentences

Quoted from spec.md, grouped by the verdict they support. Section numbers and line numbers refer to spec.md.

Line 20 (`step @ 2`):

- Section 5, line 134: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
- Section 5, line 131: "v @= 0             # mutable cell, type inferred too"
- Section 5, line 132: "v @ v + 1          # re-binding"

Line 22 (`last @= words[0]`, never re-bound):

- Section 5, line 138: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."

Lines 6, 15, 16, 19, 21 (the `@` writes that are accepted):

- Section 5, line 135: "`@` re-binds it, or a field or element inside one."
- Section 9, line 271: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"
- Section 9, line 276: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."

Lines 5 and 10 (the declaration forms):

- Section 4, line 124: "Param = "@" ident ":" Type | ident ":" Type [ "lent" ] ."
- Section 5, line 136: "Signatures are always explicit; inference is local only."

Lines 19 and 21 (`bump(@c, ...)` in a call):

- Section 9, line 276 (quoted above).

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Prints `5`, `5`, `a`, one per line.

## choice_points

1. **Fix for line 20.** I made `step` a cell on line 10 (`step @= 1`). The other choice was to drop line 20 and write `bump(@c, 2)` on line 21. That also prints `5`, `5`, `a`, but it changes two lines and removes `step` as a variable, which is further from the program as written.
2. **Fix for line 22.** I made `last` an immutable binding (`last = words[0]`), which matches the code exactly. The other choice was to keep the cell and make the value meaningful as the name suggests: `last @ words[4]`, the actual last word. That also prints `a`, since `words[4]` is `"a"`, but it changes what the program computes, so I did not choose it.
3. **Classification of `@` argument lines (19, 21).** I put them under *changes an existing name*, because the callee writes the caller's `c` through the `@` argument. The other reading is *neither*, on the grounds that the line is a call and binds nothing at the call site. The spec's text ("the callee works on the caller's place itself") supports my reading, but it is a choice.
4. **Classification of the `@` parameter (line 5).** I put it under *new name*, because the parameter `c` is a name introduced in `bump`. The other reading is *neither*, since the parameter only names an existing place passed in by the caller.
5. **Classification of line 20.** I wrote *changes an existing name* because the line as written tries to re-bind `step`. The spec does not say whether a refused re-binding counts as a change, so this is a reading of the line, not of the checker.
6. **Literal type of `step`.** `step = 1` is inferred as `i64` (section 2, "otherwise `i64`"), and `2` on line 20 fits that type. Changing `step` to `@=` does not change its type.

## confidence

- **High** that the program as written is refused, and that line 20 and line 22 are the refused lines. Both follow from quoted sentences (section 5 on `=` and on cells nothing re-binds).
- **High** that the submitted program is accepted and prints `5`, `5`, `a`. I traced it by hand.
- **Medium** on the classification of the `@`-argument and `@`-parameter lines (5, 19, 21), since the spec does not name the categories directly.
- **Least sure** of: the exact error the checker would report on line 20, since the spec states the rule ("`=` binds once, forever") but not an error message, and I cannot run the checker. Also whether the file uses only spaces for indentation: the Read output shows four-space indents, but I cannot check bytes for tabs.

## context

Only the files in this directory reached my reasoning as input: `brief.md`, `spec.md` and `main.hero`. I also tried to read the directory path itself, which failed with EISDIR and gave me nothing.

Other material was present in my context but was not read as an input for this task: the session's environment block (working directory, platform, date, model) and a system reminder with git status and the user's account details. I did not use any of it in the analysis, and I did not read any file outside this directory.
