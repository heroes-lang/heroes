# verdict

Refused, on lines 20 and 22 of `main.hero`.

- **Line 20** `step @ 2`: `step` was bound on line 10 with `=`, and an `=` binding cannot be re-bound. The `@` form only re-binds a mutable cell, and `step` is not one.
- **Line 22** `last @= words[0]`: `last` is declared as a mutable cell, but nothing in the program re-binds it. A cell that nothing re-binds is a compile error.

The two errors are independent of each other, so both lines are refused whatever the other one says.

The smallest change that makes the program accepted and keeps its evident meaning is two single-token edits:

- Line 10: `step = 1` becomes `step @= 1`, so that `step` is a cell and line 20 may re-bind it.
- Line 22: `last @= words[0]` becomes `last = words[0]`, since `last` is never meant to change.

The fixed program prints:

```
5
5
a
```

Trace: `counts` ends with a:3, b:1, c:1. `total` ends at 5. `bump(@c, 3)` sets `c.hits` to 3, then `step` becomes 2 and `bump(@c, 2)` sets `c.hits` to 5. `last` is `"a"`.

# lines

Every line of `main.hero` that holds `=` or `@` (the original file's line numbers):

| line | source | classification | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (parameter `c`; the `@` marks it mutable) | Grammar: `Param = "@" ident ":" Type`. Section 9: "Mutable parameters are marked `@` in the signature and at the call site". |
| 6 | `c.hits @ c.hits + by` | *changes an existing name* (field `hits` of the `@` parameter `c`) | Section 5: "`@` re-binds it, or a field or element inside one." Grammar: `Place = ident { "." ident \| "[" Expression "]" } .` |
| 9 | `words = ["a", "b", "a", "c", "a"]` | *new name* | Section 5: "`=` binds once, forever." |
| 10 | `step = 1` | *new name* | Section 5: "`=` binds once, forever." Section 2: "A literal takes the type its context asks for ... otherwise `i64`." |
| 11 | `counts: {str: i64} @= {}` | *new name* | Section 5: "`@=` declares a mutable cell". Section 10: "an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`." |
| 12 | `total @= 0` | *new name* | Section 5: "`@=` declares a mutable cell". |
| 15 | `counts[w] @ counts[w].default(0) + step` | *changes an existing name* (element of cell `counts`) | Section 5: "`@` re-binds it, or a field or element inside one." Section 10: "`m[k] @ v` inserts or replaces;" |
| 16 | `total @ total + step` | *changes an existing name* (cell `total` from line 12) | Section 5: "`@` re-binds it, or a field or element inside one." |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | Section 5: "`@=` declares a mutable cell". Section 9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`". |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (the caller's cell `c`, through the `@` argument) | Section 9: "Mutable parameters are marked `@` in the signature and at the call site"; "Either way the callee works on the caller's place itself". Section 5: "an `@` argument counting". |
| 20 | `step @ 2` | *changes an existing name*. The attempt is refused: `step` already exists from line 10 as an `=` binding. | Section 5: "`=` binds once, forever." and "`@` re-binds it" (a cell only). |
| 21 | `bump(@c, step)` | *changes an existing name* (the caller's cell `c`) | Same as line 19. |
| 22 | `last @= words[0]` | *new name* | Section 5: "`@=` declares a mutable cell". |

Note on line 22: the cell `last` is brought into existence on this line, and it is refused only because nothing ever re-binds it. That refusal comes from section 5, where "a cell nothing re-binds" is a compile error.

# sentences

Every sentence of the specification the verdict rests on, quoted (section and line of `spec.md`):

1. Section 5, lines 134-135: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
2. Section 5, lines 137-138: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
3. Section 5, line 150 (grammar): "Binding = [ ":" Type ] ( "=" | "@=" ) Expression NEWLINE ."
4. Section 5, line 151 (grammar): "Simple = "_" Binding | Place "@" Expression NEWLINE"
5. Section 9, lines 271-272: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`;"
6. Section 9, lines 275-276: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
7. Section 10, line 311: "`m[k]` is a `V?` with code `missing_key`; `m[k] @ v` inserts or replaces;"
8. Section 10, line 297: "A container literal separates elements by newline across lines and by comma on one, and an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`."
9. Section 2, lines 43-44: "A literal takes the type its context asks for ... otherwise `i64`."
10. Section 11, lines 323-324: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
11. Section 9, line 258: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`, and a variant's case `.num(v: 7)` or `.plus`."

The first three sentences carry the refusals. Sentences 5 and 6 carry the classification of lines 19 and 21. Sentences 9 to 11 carry the types and the output.

# program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a`, one per line.

# choice_points

1. **How to make line 20 legal.** I made `step` a cell by changing line 10 to `step @= 1`. The other choice was to keep `step` immutable and bind the new value to a fresh name, such as `step2 = 2`, with line 21 changed to `bump(@c, step2)`. That also prints `5`, `5`, `a`, but it changes two lines and invents a name the author did not write. A third choice, dropping line 20 and passing `2` directly to `bump` on line 21, would also print `5`, `5`, `a`, but it throws away the step update the program evidently means to make.
2. **How to make line 22 legal.** I changed `@=` to `=`, since `last` is never meant to change. The other choice was to keep the cell and add a re-binding, for example `last @ words[1]` after line 22. That would print `b` on the last line, not `a`, so it changes what the program does. I rejected it because the program shows no sign of wanting a second value for `last`.
3. **Whether line 5 counts as a new name.** I treated the parameter `c` as a new name on line 5, since the line brings it into existence, and the `@` only marks it mutable. The other reading, that the `@` makes line 5 a write to an existing name, has no basis, because no name exists before the signature.
4. **Whether line 20 counts as a change.** The line tries to change `step`. The specification forbids that, so I classified it as "changes an existing name" and not "neither", because the `@` writes to an existing name. The other reading, "neither", would hold only if the checker were read as ignoring the refused line, which it is not.
5. **Whether the checker reports line 22 when line 20 is also wrong.** I assumed it does, since the two faults are independent. If the checker stops at the first error, only line 20 would be reported. This does not change the verdict.

# confidence

- **Most sure:** the program is refused as written (lines 20 and 22). Both faults follow directly from the quoted sentences 1 and 2.
- **Sure:** the fixed program prints `5`, `5`, `a`. I traced it by hand. I did not run it, and I could not run anything.
- **Less sure:** the classification of lines 5 and 19 to 21. These depend on how "new name" and "changes an existing name" are read for parameters and `@` arguments. My reading is reasoned from sentence 6 but is not stated outright by the specification.
- **Least sure:** whether the checker reports both lines 20 and 22, as opposed to stopping at the first. This is a point about the checker's behaviour, which the specification does not describe.

# context

Only this directory's files reached my context as program input: `brief.md`, `spec.md` and `main.hero`. I wrote `report.md` here and used no other file.

Other material also reached my context. The session's environment block (working directory, platform, shell, scratchpad path, model details) and a git status snapshot with recent commit subjects were supplied with the session, along with an account identifier. None of it bears on the language, and I did not use any of it for the verdict, the classifications, or the output. I did not read any file outside this directory.
