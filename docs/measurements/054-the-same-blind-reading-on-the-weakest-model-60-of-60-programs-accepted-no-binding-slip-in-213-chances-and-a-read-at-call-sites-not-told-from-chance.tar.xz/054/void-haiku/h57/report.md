# program

```
function sorted_desc(xs: [i64]) -> [i64]
    a @= xs
    n = len(a)
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if a[j] < a[j + 1]
                tmp = a[j]
                a[j] @ a[j + 1]
                a[j + 1] @ tmp
            j @ j + 1
        i @ i + 1
    return a

function runs(xs: [i64]) -> i64
    count @= 0
    seen @= false
    prev @= 0
    for x in xs
        if !seen || x != prev
            count @ count + 1
        seen @ true
        prev @ x
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

# sentences

Line numbers count from the top of the block above.

1. Spec section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses."
   Governs: every line (indentation), and lines 5, 7, 8, 21 (conditions without parentheses).

2. Spec section 1: "Syntax is ASCII-only"
   Governs: the whole program (it uses only ASCII, including `!`).

3. Spec section 4: "`function` ident [ Generics ] Params [ \"->\" Type ] Block"
   Governs: lines 1, 16 and 27 (the three function declarations, two with `->` and `main` with none).

4. Spec section 4: "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations."
   Governs: line 28 (calls `sorted_desc`, declared above it) and line 30 (calls `runs`, declared above it).

5. Spec section 1: "the file you compile holds `function main()`, which takes nothing and produces nothing."
   Governs: line 27.

6. Spec section 5: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
   Governs: lines 2, 4, 6, 17, 18, 19 (cells `@=`); lines 3, 9, 20 (`=` bindings `n`, `tmp` and loop variable `x`); lines 10, 11 (re-binding of elements `a[j]`, `a[j + 1]`); lines 12, 13, 22, 23, 24 (re-binding of cells).

7. Spec section 5: "Signatures are always explicit; inference is local only."
   Governs: lines 1, 16, 27 (explicit parameter and return types).

8. Spec section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds"
   Governs: `xs` (lines 2, 20), `a` (lines 3, 5, 7, 8, 10, 14), `n` (lines 5, 7), `i` (lines 4, 5, 7, 8, 13), `j` (lines 6, 7, 8, 12), `tmp` (lines 9, 11), `count` (lines 17, 22, 25), `seen` (lines 18, 21, 23), `prev` (lines 19, 21, 24), `x` (lines 20 to 24, 29), each re-bound or read.

9. Spec section 5: "Shadowing is a compile error"
   Governs: all names. None of `sorted_desc`, `runs`, `main`, `xs`, `a`, `n`, `i`, `j`, `tmp`, `count`, `seen`, `prev`, `x` is a built-in or a `use` name.

10. Spec section 2: "A literal takes the type its context asks for ... otherwise `i64`."
    Governs: lines 4, 6, 17, 19 (`0`), line 7 (`1` in `n - 1 - i`), lines 12, 13, 22 (`1`), line 8 (`1` in `a[j + 1]`), and `seen @= false` at line 18 (boolean literal).

11. Spec section 7: "arithmetic + - * / % ... (both sides one numeric type, never mixed)"
    Governs: lines 7 (`n - 1 - i`), 8 (`j + 1`), 12 (`j + 1`), 13 (`i + 1`), 22 (`count + 1`). Each side is `i64` (or a literal taking `i64`).

12. Spec section 7: "comparison == != < <= > >= (`< <= > >=`: a number only)"
    Governs: line 5 (`i < n`), line 7 (`j < n - 1 - i`), line 8 (`a[j] < a[j + 1]`), line 21 (`x != prev`).

13. Spec section 7: "boolean && || ! (bool only; && and || short-circuit)"
    Governs: line 21 (`!seen || x != prev`); `!seen` is `bool`, `x != prev` is `bool`.

14. Spec section 7 (precedence): "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -` → ... → comparisons → `&&` → `||`."
    Governs: line 21 (`!` binds to `seen` only, `!=` before `||`, so the condition is `(!seen) || (x != prev)`); line 7 (`n - 1 - i` is `(n - 1) - i`).

15. Spec section 8 (paraphrased, the spec's sentence has a dash): `if cond` / `else if` / `else` take only `bool`, and there is no truthiness.
    Governs: line 8 (`a[j] < a[j + 1]`, a `bool`), line 21 (`bool`).

16. Spec section 8: "`while cond` and `for x in xs`, over an array or a `range` (section 11)." with grammar "While = \"while\" Expression Block ." and "For = \"for\" ident \"in\" Expression Block ."
    Governs: lines 5 and 7 (`while`), lines 20 and 28 (`for x in`).

17. Spec section 8: "A function with a `->` must `return` on every path that reaches its end"
    Governs: line 14 (`return a` ends `sorted_desc`), line 25 (`return count` ends `runs`).

18. Spec section 8: "A statement after a jump, in its block, is a compile error."
    Governs: line 14 and line 25 are the last statements of their blocks; no statement follows a jump in any block.

19. Spec section 3 table: "`[T]` | dynamic array, indices from 0", and section 5: "`@` re-binds it, or a field or element inside one."
    Governs: lines 8, 9, 10, 11 (`a[j]` and `a[j + 1]` read and written as element places of the array cell `a`). The spec states the element write form `m[k] @ v` only for maps, so this is an inference; see choice_points 7.

20. Spec section 10: "`xs @ xs.push(4)` grows in place when `xs` is a plain name"
    Governs: not used (the program does not grow an array).

21. Spec section 10: "A container literal separates elements by newline across lines and by comma on one"
    Governs: lines 28 and 30 (`[3, 1, 4, 1, 5, 9, 2, 6]` and `[1, 1, 2, 2, 2, 3, 1]`, comma on one line).

22. Spec section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
    Governs: lines 29 and 30 (each prints one `i64`).

23. Spec section 11: "`len`" (built-in, listed without a stated result type).
    Governs: line 3 (`n = len(a)`), which then governs lines 5 and 7 through comparison with `i64`. See choice_points 4 and confidence.

# choice_points

1. Sorting algorithm. Choice: bubble sort in place on a mutable copy `a`, with an outer pass counter `i` and an inner pass counter `j`, swapping when `a[j] < a[j + 1]` (descending order). For the given input the output is `9 6 5 4 3 2 1 1`. Other choice: insertion sort or selection sort. The output would be the same, but the code, loop bounds and comparison count would differ. Insertion sort needs a shifting inner loop, which is more code and more places for the bounds to go wrong.

2. Direction of the swap. Choice: swap when `a[j] < a[j + 1]`, so larger values move left. Other choice: swap when `a[j] > a[j + 1]`, which gives ascending order, not what the brief asks for.

3. Swap form. Choice: a temporary `tmp = a[j]` followed by two element writes. The spec has no tuple or multiple-assignment form, so a temporary is the only swap available inline. Other choice: a helper function that swaps through `@` parameters. It would give the same output, but it would pass two element places as `@` arguments, which the spec restricts (no other `@` argument of the call may reach the same place). The inline form avoids that.

4. Length type. Choice: `n = len(a)`, compared with the counters `i @= 0` and `j @= 0`, which the spec defaults to `i64`. The spec does not state what `len` returns. Other choice: if `len` returned a different integer type, the comparisons at lines 5 and 7 would mix two types and be refused. The spec gives no conversion for that case, so the fix would be to change the counters' type to match, which I cannot verify from the spec. This is the main unverified point.

5. Runs algorithm. Choice: a single `for` pass over `xs` with a `seen` flag, a `prev` value and a `count`. Other choice: an index-based `while` loop comparing `xs[i]` with `xs[i - 1]`, starting at 1. Both give 4 for `[1, 1, 2, 2, 2, 3, 1]` and both give 0 for an empty array. The index version also depends on the `len` type (choice 4), so the flag version avoids one dependency.

6. Empty array in `runs`. Choice: the `seen` flag makes an empty array return 0 with no special case. Other choice: an explicit `if len(xs) == 0` guard returning 0, which reintroduces the `len` type question.

7. Element write on an array. Choice: `a[j] @ v`, the form `Place = ident { "[" Expression "]" }` allows, with `@` re-binding an element inside a cell. Other choice: rebuilding the array each pass with `push`, which is slower and quadratic. The spec's only worked element write is for maps (`m[k] @ v`), so the array form rests on the grammar and the `@` rule rather than on an example.

8. Loop form in `sorted_desc`. Choice: two `while` loops with explicit counters. Other choice: `for` over `range(from: 0, to: n)`, which the spec defines over `i64`. Both are valid if `n` is `i64`. The `while` form avoids a dependency on the `range` signature.

9. Comments. Choice: none, to keep the program minimal. Other choice: a `#` comment above each function, which the spec permits and which would document it. No effect on acceptance.

10. Printing. Choice: `print(x)` for each element in `main`, iterating the returned array with `for`. Other choice: indexing with a counter and `len`, which would repeat choice 4.

# confidence

I estimate about 85% that the checker accepts the program on the first try.

The line I am least sure of is line 3, `n = len(a)`, together with the comparisons that use `n` at lines 5 and 7 (`i < n`, `j < n - 1 - i`). The specification lists `len` among the built-ins without giving its result type. I assumed `i64`, because the spec's default integer type is `i64` and the counters are `i64` by default. If `len` returns another integer type, the checker would refuse those comparisons. This is the single most likely failure.

The second least certain line is line 8 (`if a[j] < a[j + 1]`). The spec says `s[i]` yields a `u8` for strings, but it gives no matching sentence for arrays of `[T]`; the element type is the natural reading and I expect it to hold.

Lines 10 and 11 (`a[j] @ a[j + 1]`, `a[j + 1] @ tmp`) rely on element re-binding through a `[T]` cell. The spec states that `@` re-binds "a field or element inside one", which covers this, but it has no array example. This is the third most uncertain point.

Line 21 (`if !seen || x != prev`) depends on the precedence of `!` and `!=` relative to `||`, which the spec gives explicitly, so I am confident in it.

# context

Only the two files in this directory reached my context: `brief.md` and `spec.md`. I also attempted to read the directory itself, which returned an error (EISDIR) and gave me nothing.

The session's system context also carried the user's git status, branch name and five recent commit subjects for the repository that contains this directory. I did not read those commits or any file outside this directory, and nothing from them went into the program or the reasoning above.
