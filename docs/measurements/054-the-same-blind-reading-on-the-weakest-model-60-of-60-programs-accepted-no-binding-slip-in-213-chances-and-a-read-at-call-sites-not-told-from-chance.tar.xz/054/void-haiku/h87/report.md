## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    found @= false
    out: [Item] @= []
    for it in items
        if it.name == name
            found @ true
            out @ out.push(Item(name: it.name, qty: it.qty + n))
        else
            out @ out.push(it)
    if !found
        out @ out.push(Item(name: name, qty: n))
    items @ out

function take(@items: [Item], name: str, n: i64) -> bool
    enough @= false
    for probe in items
        if probe.name == name && probe.qty >= n
            enough @ true
    if !enough
        return false
    out: [Item] @= []
    for it in items
        if it.name == name
            out @ out.push(Item(name: it.name, qty: it.qty - n))
        else
            out @ out.push(it)
    items @ out
    return true

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total @ total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4`, one per line. After the two takes, apple holds 2 and pear holds 2, so the sum is 4.

Line numbers below count from the first line of the program block above (`record Item` is line 1, blank lines count).

## sentences

1. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every line. Each `if` condition on lines 9, 14, 21 and 23 is written without parentheses.
2. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs the constructions on lines 11, 15, 28 and 30.
3. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`" Governs the signatures on lines 5 and 18, and the calls on lines 36 to 40.
4. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs `found @= false` (line 6), `out: [Item] @= []` (lines 7 and 25), `enough @= false` (line 19), `total @= 0` (line 41), and every `@` re-binding of those cells.
5. "`xs @ xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs `out @ out.push(...)` (lines 11, 13, 15, 28, 30) and `items @ out` (lines 16 and 31). `out` is a plain name and `items` is the `@` parameter itself.
6. "Built-ins: `print(...)` · `len` · `push` ·" Governs `out.push(...)` on lines 11, 13, 15, 28 and 30, and `print` on lines 39, 40 and 44.
7. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends" Governs `found` (read on line 14), `out`, `enough` (read on line 23), `total` (re-bound on line 43, read on line 44), and `items` in `restock` and `take`, which are written by `items @ out` on lines 16 and 31.
8. "an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`." Governs `out: [Item] @= []` (lines 7 and 25) and `items: [Item] @= []` (line 35).
9. "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness." Governs the conditions on lines 14, 21 and 23. Each is `bool`.
10. "boolean      && || !            (bool only; && and || short-circuit)" Governs `&&` on line 21 and `!` on lines 14 and 23.
11. "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -`" with "→ comparisons → `&&` → `||`." Governs line 21: `==` and `>=` bind tighter than `&&`, so the condition is `(probe.name == name) && (probe.qty >= n)`.
12. "`==` is structural equality on any two values of one type, recursively;" Governs the string comparisons on lines 9, 21 and 27.
13. "(`< <= > >=`: a number only)" Governs `probe.qty >= n` on line 21. Both operands are `i64`.
14. "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `3`, `2`, `4`, `5`, `9` and `0` (line 41), and `true` and `false` as `bool` values.
15. "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs `out @ out.push(it)` on lines 13 and 30. Each element is pushed as a copy, and the old array is replaced by `items @ out`.
16. "A function with a `->` must `return` on every path that reaches its end, and `exit(code:)`, `assert false` and a `while true` with no `break` of its own end a path." Governs `take` (lines 18 to 32). `return false` on line 24 and `return true` on line 32 end every path.
17. "A statement after a jump, in its block, is a compile error." Governs `return false` (line 24), which is the last statement of its `if` block, and `return true` (line 32), which is the last statement of `take`.
18. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs `print(take(...))` on lines 39 and 40 (`bool`) and `print(total)` on line 44 (`i64`).
19. "a `bool` prints `true` or `false`." Governs the expected output for lines 39 and 40.
20. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs `for it in items` (lines 8 and 26), `for probe in items` (line 20) and `for item in items` (line 42).

## choice_points

1. **Lookup by rebuilding the array, not by index.** The spec gives `len` with no stated result type, so an index loop such as `while i < len(items)` might not type-check against an `i64` counter. I walked the array with `for ... in` and built a new `out` array instead. The other choice, an indexed loop with `items[i].qty @ items[i].qty + n` (a field write through an index, which the grammar allows as a `Place`), would produce the same results but depends on `len`'s type, which the spec does not state.
2. **`restock` and `take` replace `items` as a whole, with `items @ out`.** The other choice, changing the matched element through `items[i].qty @ ...`, would touch one element and avoid copying the array. The results are the same. I used whole-array replacement because the rebuild is needed for the loop, and it reads the same way in both functions.
3. **`take` makes two passes.** The first pass (`enough`) checks the condition before anything is written, so a failed take changes nothing, as the brief requires. The other choice is one pass that rebuilds `out` and returns `false` partway through. That would also leave `items` untouched, since `items` is only rebound at the end, but the two-pass form makes "changes nothing" obvious on the page.
4. **`restock` finds the first matching name and rebuilds `out`.** The other choice is to append a second item whenever no match is found, without the `found` flag. That would also be correct as long as `found` is false in that case, so the choice matters only for code that is not written here. The brief says "the item called `name`", which implies one item per name, and the `found` flag keeps that true.
5. **Loop variable names.** I used `it` in `restock` and in the second loop of `take`, `probe` in the first loop of `take`, and `item` in `main`. Each loop is a separate scope, so reusing one name would be legal in principle. The spec does not say how its shadowing rule treats sibling scopes, so I used distinct names to avoid the question.
6. **`found` and `enough` are `bool` cells, tested with `!`.** The other choice is `found == false`, which gives the same result. `!found` is the shorter form and matches the operator table.
7. **Arguments are positional, with `@` marks and no names.** The spec requires names only where two parameters share a type. `restock` and `take` have `[Item]`, `str` and `i64`, so no two match and names are optional. The other choice, `restock(items: @items, name: "apple", n: 3)`, would also compile.
8. **The sum is a `for` loop, not `fold`.** The spec lists `fold` as a built-in, but using it would need a function argument. The other choice, `fold(items, 0, ...)`, gives the same total. The loop is the plainer form.
9. **`print(take(@items, ...))` passes an `@` argument inside another call.** The other choice is `r @= take(@items, "apple", 5)` followed by `print(r)`, which gives the same output. I used the nested form. The `@` belongs to `take`, and `print` takes no `@` argument, so the spec's rule about other `@` arguments of the same call does not apply.

## confidence

I am about 85 percent sure the checker accepts the program on the first try. I cannot run the checker, so this rests on reading `spec.md` only.

The line I am least sure of is line 31, `items @ out`, in `take`. It rebinds the `@` parameter as a whole, and the spec shows `@` on a parameter only in the signature and call form, not as a whole-value rebinding. Line 16 has the same form in `restock`. If the checker rejects whole-array rebinding of an `@` parameter, the fix is to write each element back by index, which would change lines 16 and 31 only.

The next least sure line is line 39, `print(take(@items, "apple", 5))`, where an `@` argument sits inside a builtin call. I expect this to be allowed, since the rule in the spec about other `@` arguments concerns arguments of the same call.

## context

Nothing outside this directory reached my context. I read `brief.md` and `spec.md` in this directory and nothing else. Before writing, I tried to read `report.md`, which did not yet exist, and then I wrote it. I ran no tools other than reading and writing files in this directory.
