## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    out: [Item] @= []
    found @= false
    for item in items
        if item.name == name
            out = out.push(Item(name: item.name, qty: item.qty + n))
            found = true
        else
            out = out.push(item)
    if !found
        out = out.push(Item(name: name, qty: n))
    items = out

function take(@items: [Item], name: str, n: i64) -> bool
    out: [Item] @= []
    ok_take @= false
    for item in items
        if item.name == name && item.qty >= n
            out = out.push(Item(name: item.name, qty: item.qty - n))
            ok_take = true
        else
            out = out.push(item)
    if !ok_take
        return false
    items = out
    return true

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple 7 - 5 = 2, pear 2, sum 4), one per line.

## sentences

Line numbers refer to the program above.

1. Lines 1-3 (`record Item` and its fields): "Every top-level line starts with its kind." (section 4). The field lines follow the record grammar `Fields = INDENT { ident ":" Type NEWLINE } DEDENT .` (section 4).
2. Lines 5, 18, 32 (`function` headers): "Signatures are always explicit; inference is local only." (section 5)
3. Line 32 (`function main()`): "the file you compile holds `function main()`, which takes nothing and produces nothing." (section 1)
4. Lines 5, 18 (`@items` in the signatures): "Mutable parameters are marked `@` in the signature and at the call site:" (section 9).
5. Lines 34-38 (`restock(@items, ...)`, `take(@items, ...)`): "Mutable parameters are marked `@` in the signature and at the call site:" (section 9), and "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach," (section 9). Each call has exactly one `@` argument.
6. Lines 6, 19 (`out: [Item] @= []`) and line 33 (`items: [Item] @= []`): "an empty one needs an annotation" (section 10, example `xs: [i64] $= []`). Also "`@=` declares a mutable cell," (section 5).
7. Line 33 (`items` passed as `@items`) and line 39 (`total @= 0`): "a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting;" (section 5). `items` is a cell passed as an `@` argument; `total` is re-bound on line 41.
8. Lines 10, 13, 15, 23, 26 (`out = out.push(...)`): "`xs = xs.push(4)` grows in place when `xs` is a plain name;" (section 10). `out` is a plain name.
9. Lines 16 and 29 (`items = out`): "`=` re-binds it, or a field or element inside one." (section 5). This is the one place the spec does not say outright that `=` may write an `@` parameter. See `confidence`.
10. Lines 11, 24 (`found = true`, `ok_take = true`) and line 41 (`total = total + item.qty`): "`=` re-binds it" (section 5).
11. Lines 6-7, 19-20, 33, 39 (every binding): "All bindings are initialised." (section 5)
12. Every binding and parameter is read: "An unused binding or parameter is a compile error," (section 5). `out`, `found`, `ok_take`, `total`, `item`, `items`, `name`, `n` are each read on some line. The loop variables (lines 8, 21, 40) are read on lines 9-13, 22-26 and 41.
13. Lines 8, 21, 40 (`for item in items`): "Loops: `while cond` and `for x in xs`, over an array or a `range`" (section 8).
14. Lines 9, 14, 22, 27 (`if` conditions): "`if cond` / `else if` / `else` take only `bool`; there is no truthiness." (section 8). The spec's own text uses an em dash here; I have replaced it with a semicolon in this quote.
15. Lines 9 and 22 (`item.name == name`): "`==` is structural equality on any two values of one type, recursively;" (section 7). Both sides are `str`.
16. Line 22 (`item.qty >= n`): "(`< <= > >=`: a number only)" (section 7).
17. Line 22 (`&&`): "(bool only; && and || short-circuit)" (section 7). Both operands are `bool`.
18. Lines 14 and 27 (`!found`, `!ok_take`): "(bool only; && and || short-circuit)" (section 7), which covers `!` as well, since the row reads `boolean && || !`.
19. Lines 10, 23, 41 (`item.qty + n`, `item.qty - n`, `total + item.qty`): "(both sides one numeric type, never mixed)" (section 7). The spec's own text uses an em dash here; I have replaced it with a comma in this quote. All operands are `i64`.
20. Line 41 (`total @= 0`): "A literal takes the type its context asks for ... otherwise `i64`." (section 2). With no other context, `total` is `i64`, matching `item.qty`.
21. Lines 28 and 30 and the function `take` as a whole: "A function with a `->` must `return` on every path that reaches its end," (section 8). The last statement is `return true`, and the one `return false` is inside an `if` block.
22. Line 28 (`return false` as the last statement of its block): "A statement after a jump, in its block, is a compile error." (section 8). Nothing follows the jump in its block.
23. Lines 34-38 and 40-42 (`print(...)`): "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (section 11)
24. Lines 37-38 (`print` of a `bool`): "a `bool` prints `true` or `false`." (section 11)
25. Lines 9-13 and 22-26 (`if ... else` inside `for`): "`if` and `match` are expressions and may stand as statements;" (section 8).
26. Lines 12-13 and 25-26 (`else` at the same column as its `if`): "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." (section 1). Every level is 4 spaces, with no tabs.
27. Every line (no semicolons, no parentheses on conditions): "No braces, no semicolons; a condition needs no parentheses." (section 1)
28. Lines 10, 15, 23 (`Item(name: ..., qty: ...)`): "Record construction is a call with field names, always mandatory:" (section 9). Each `Item(...)` names both fields.
29. Lines 10, 13, 15, 23, 26 (`out.push(...)`): "Built-ins: `print(...)` · `len` · `push`" (section 11).
30. Lines 5, 18 (parameters `name: str` and `n: i64`): "When two parameters in a signature share a type, named arguments are mandatory at the call site" (section 9). Not triggered here, because `str` and `i64` differ, so the positional calls on lines 34-38 are allowed.
31. Lines 5, 18 (`restock` and `take` called as plain `f(args)`): "UFCS does not apply when the first parameter is `@`." (section 9).
32. Each function binds each name once: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." (section 5). The loop variable `item` appears in three separate functions and is never nested inside itself. The field name `name` (line 2) is not a binding.

## choice_points

1. **How to find and update the matching item in `restock` and `take`.** The spec does not describe an in-place update by position, and it gives `len` with no stated return type.
   - Chose: rebuild a new array `out` with `push` in one `for` loop, then `items = out`.
   - Other choice: an index loop, `range(from: 0, to: len(items))` with `items[i].qty = items[i].qty + n`. This would produce the same output. The risk is that the spec never says what `len` returns, and `range` takes `i64`, so the index loop could fail to type-check if `len` is not `i64`. An element write through `items[i].qty` is also a nested `Place` assignment, which the spec does not illustrate.
2. **Whether `restock` and `take` stop at the first match.** Chose: iterate the whole array and rebuild it, which keeps every path to the end of the loop. Other choice: `return` (or `break`) at the first match. The output would be the same, but `take` would then have to return `true` after writing `items`, and `restock` would have to skip the append step, so the code would need two write paths instead of one.
3. **How `take` handles several items with the same name.** The spec is silent. `restock` never creates two items with one name, so at most one item can match. Chose: apply the subtraction to every item whose name matches and whose quantity is at least `n` (in practice one). Other choice: stop at the first match. The output here is identical.
4. **Whether `take` writes `items` on failure.** Chose: build `out` during the loop, and return `false` before `items = out` when no item was taken from, so `items` is unchanged on failure, as the brief requires. Other choice: always assign `items = out`. That is also correct here, because `out` then equals the old array when nothing matched, but it would rewrite the whole array on every call for no gain.
5. **Sum in `main`.** Chose: a `for` loop with a mutable `total`. Other choice: `items.fold(0, add)`. That needs a function value named `add`, which the spec does not define, so it was not used. The output is identical.
6. **Printing the take results.** Chose: `print(take(@items, "apple", 5))` directly. Other choice: bind each result first, for example `ok_apple = take(@items, "apple", 5)`. The output is identical; the direct form avoids a binding that would need a use.
7. **Type of `total`.** Chose: `total @= 0`, inferred as `i64` from the literal default and `item.qty`. Other choice: annotate `total: i64 @= 0`. The output is identical.
8. **Names** (`out`, `found`, `ok_take`, `item`, `total`). The spec constrains these only through the shadowing rule, which I checked (see `sentences` 32).
9. **Form of the branch inside `restock` and `take`.** Chose: `if` / `else` so that each item takes exactly one of two paths. Other choice: a bare `if` with `continue` on the matched path. I did not check the spec's `continue` rules against that form, so I kept the `if` / `else`, which the spec states directly.

## confidence

I am fairly confident (about 85%) that the checker accepts this program on the first try.

Least sure line: **line 16** (`items = out`), and its twin on line 29. The spec says `=` re-binds a cell, a field, or an element, and that an `@` parameter is worked on in the caller's place, but it never says outright that `=` on an `@` parameter is accepted. I expect it to be accepted, since the spec treats an `@` parameter that nothing writes as an error, which implies that writes through it are normal. If the checker rejects it, the fix is to write through `items` element by element, which needs the index rewrite described under choice point 1.

Next least sure: **lines 37-38** (`@items` nested inside `print(take(@items, ...))`). The spec allows `@` in nested calls and says only that no other `@` argument of the same call may reach the same place. Each call has one `@` argument, so I expect this to be accepted.

Lines I am most sure of: the record and function headers (lines 1-5, 18, 32), the `if` conditions (lines 9, 14, 22, 27), and the `print` lines (37-38, 42).

## context

Only this directory's files reached my context. I read `brief.md` and `spec.md` in full. I also tried to read `report.md`; it did not exist yet, so that read returned an error, and I wrote it fresh.

Other material also reached my context, but none of it is a file outside this directory. It came from the session wrapper, not from a file read: the working directory and platform details, the scratchpad path, the model and date information, the budget figures, and a snapshot of the git status and user account for the repository. I did not use any of it in the program or the report.

I used no tool except reading and writing files in this directory, as the brief requires. I did not run or compile anything.
