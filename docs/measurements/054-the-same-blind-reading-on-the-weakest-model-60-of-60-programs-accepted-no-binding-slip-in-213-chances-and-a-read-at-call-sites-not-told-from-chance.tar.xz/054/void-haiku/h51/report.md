# verdict

Refused. The checker would reject `main.hero` on two lines:

- **Line 20** `step = 2`: `step` is bound by `$=` on line 10, and a `$=` name is never re-bound. (`step` is a plain immutable binding.)
- **Line 22** `last @= words[0]`: `last` is a mutable cell that nothing re-binds, which is a compile error.

Smallest change that is accepted and still does what the program evidently means:

- Line 10: `step $= 1` becomes `step @= 1`, so the re-binding on line 20 is legal.
- Line 22: `last @= words[0]` becomes `last $= words[0]`, since `last` is never meant to change.

Both edits are needed; either one alone leaves the other line refused.

The accepted program prints:

```
5
5
a
```

Trace: `words` is `a b a c a`, so `counts` ends with `a` = 3, `b` = 1, `c` = 1, and `total` = 5 after five iterations. `bump(@c, 3)` makes `c.hits` 3; `step` becomes 2; `bump(@c, 2)` makes `c.hits` 5. `last` is `"a"`.

# lines

Every line of `main.hero` that contains `=` (including the `=` inside `$=` and `@=`) or `@`:

| line | kind | words of the specification relied on |
|---|---|---|
| 5 | *new name* (parameter `c`, and `by`) | Param = `"@" ident ":" Type`; "Mutable parameters are marked `@` in the signature" (section 9). The signature declares the parameter names; `@` only marks how the parameter is passed. |
| 6 | *changes an existing name* (`c`, its field `hits`) | "`=` re-binds it, or a field or element inside one" (section 5). `c` is the `@` parameter, which "the callee works on the caller's place itself" (section 9). |
| 9 | *new name* (`words`) | "`$=` binds once, forever." (section 5). |
| 10 | *new name* (`step`) | "`$=` binds once, forever." (section 5). |
| 11 | *new name* (`counts`) | "`@=` declares a mutable cell, and `=` re-binds it" (section 5). |
| 12 | *new name* (`total`) | "`@=` declares a mutable cell" (section 5). |
| 15 | *changes an existing name* (`counts`, one entry) | "`=` re-binds it, or a field or element inside one" (section 5); "`m[k] = v` inserts or replaces" (section 10). The name `counts` already exists; an insertion adds a key, not a name. |
| 16 | *changes an existing name* (`total`) | "`v = v + 1` / `=` re-binds it" (section 5, `@=` declares a mutable cell, and `=` re-binds it). |
| 18 | *new name* (`c`) | "`@=` declares a mutable cell" (section 5). The `label:` and `hits:` colons are record-construction syntax (section 9), not bindings. |
| 19 | *changes an existing name* (`c`, through `@`) | "Mutable parameters are marked `@` in the signature and at the call site" (section 9); "an `@` argument counting" as a write (section 5). The `@` on this line is what lets `bump` change `c`. |
| 20 | *changes an existing name* (`step`), refused | "`$=` binds once, forever." (section 5), so `step = 2` cannot re-bind it; "`=` re-binds it" applies only to a cell, as in "`@=` declares a mutable cell, and `=` re-binds it" (section 5). |
| 21 | *changes an existing name* (`c`, through `@`) | Same as line 19: "`@` argument counting" (section 5) and "marked `@` ... at the call site" (section 9). |
| 22 | *new name* (`last`), refused as a cell | "`@=` declares a mutable cell" (section 5); a cell nothing re-binds is an error: "a cell nothing re-binds ... is a compile error" (section 5). |

# sentences

Each sentence the verdict rests on, quoted from `spec.md`:

1. Section 5: "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
2. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
3. Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy: `function peek(l: Lex lent)` … `peek(l)`. Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
4. Section 2: "A literal takes the type its context asks for — `b: u8 $= 255`, and `b + 1` is a `u8` — otherwise `i64`."
5. Section 10: "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces; `keys(m) -> [K]` gives the keys in no order."
6. Section 6 (table row): "`.default(v)` | extract or fall back"
7. Section 10: "`s[i]` yields a `u8`; iterate characters with `s.chars()`, which yields single-character `str`." (Used only to confirm that `words[0]` on a `[str]` is a plain element and that the list is not a string.)
8. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
9. Section 9: "When two parameters in a signature share a type, named arguments are mandatory at the call site" (checked: `bump`'s parameters have different types, so positional arguments are fine).

# program

```hero
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

# choice_points

1. **How to fix line 20.** I made `step` a cell (`step @= 1`). Other choice: keep `step $= 1`, delete line 20, and call `bump(@c, 2)` on line 21. That prints the same `5`, `5`, `a`, but it drops the name `step` from the second phase, which the original seems to intend.
2. **How to fix line 22.** I made `last` immutable (`last $= words[0]`). Other choice: keep `last @= words[0]` and add a re-binding such as `last = words[4]` after the loop. That also prints `a` (since `words[4]` is `"a"`), but it adds an assignment the program does not otherwise need.
3. **Line 5 classification.** I read the parameter declaration as bringing new names (`c`, `by`). Other reading: the line is *neither*, because a signature declares a parameter without binding a value in the body. The spec words do not settle this on the line alone.
4. **Lines 19 and 21 classification.** I read the `@` at the call site as changing `c`, because "an `@` argument counting" is a write (section 5). Other reading: *neither*, if the `@` is treated as only a mark, not a write. The section 5 sentence favours my reading.
5. **Line 15 classification.** I read `counts[w] = ...` as changing the existing name `counts`, since the name is not created. Other reading: *new name* for each new key, since the map gains an entry. I chose the first, because a map key is not a name.
6. **Lines containing `$=` or `@=`.** The brief says lines "that hold `=`", and I counted the `=` inside `$=` and `@=` as holding `=`. Other choice: only plain `=`, which would drop lines 9-12, 18 and 22 from the table.
7. **Line 20 classification.** I placed the refused re-binding under *changes an existing name*, because the line attempts a change to `step`. Other choice: *neither*, if one treats a refused line as producing no name change. I think the attempt is what the classification asks about.
8. **Dropping the unused `label` field.** I left `label` in place; it is set but never read. The spec's unused-binding rule covers bindings and parameters, not record fields, so I did not treat it as an error.

# confidence

- **Most sure:** the verdict that line 20 and line 22 are refused, and the program output `5`, `5`, `a` after the two edits. Both follow directly from the quoted sentences and from a careful trace of the arithmetic.
- **Less sure:** the *new name* / *changes an existing name* / *neither* labels for lines 5, 15, 19 and 21. The spec uses those words, but on some lines the choice depends on how "brings a new name" and "a write" are read. Choice points 3 to 5 cover these.
- **Least sure:** whether the checker would reject line 6 or line 5 for some reason outside the quoted rules (for example, a rule on the unused field `label`). I found none in the specification.

# context

Nothing outside this directory's files reached my context as document content. I read `brief.md`, `spec.md` and `main.hero` in this directory, and wrote `report.md` here. The session also carried environment details (the working path, platform, and a git status snapshot for a repository) and an account note. I did not read any of that and did not use it for the analysis. I ran no tools other than reading and writing files here.
