## program

```
# Sorts a copy of xs from largest to smallest by adjacent swaps.
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n $= ys.len()
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if ys[j] < ys[j + 1]
                t $= ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
            j = j + 1
        i = i + 1
    return ys

# Counts the maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    n $= xs.len()
    if n == 0
        return 0
    count @= 1
    k @= 1
    while k < n
        if xs[k] != xs[k - 1]
            count = count + 1
        k = k + 1
    return count

function main()
    ordered $= sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
    for v in ordered
        print(v)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output: `9`, `6`, `5`, `4`, `3`, `2`, `1`, `1`, then `4`, one per line.

Line numbers below count from line 1 of the fenced block above (the comment line), with the blank lines counted.

## sentences

Quotations are from `spec.md`. Lines are program lines.

1. Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line (2 to 15, 18 to 28, 30 to 34). I used only spaces.
2. Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 30 to 34. `main` has no parameters and no `->`.
3. Section 1: "`#` comments to end of line, markdown inside." Governs lines 1 and 17.
4. Section 1: "Syntax is ASCII-only". Governs the whole program, which is ASCII.
5. Section 2: "A literal takes the type its context asks for" and "otherwise `i64`." Governs every literal, for example lines 5, 7, 13, 14, 20, 21, 22, 23, 26, 27, 31 and 34. Each one is `i64` by context or default.
6. Section 2: "A leading zero is an error, never octal." Governs the literal `0` on lines 5, 7, 20 and 21. See choice_points, C5.
7. Section 3: "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." Governs line 3: `ys` is a copy of `xs`, so the caller's array is untouched.
8. Section 3: "No implicit conversions, widths included". Governs all arithmetic and comparisons, which are all `i64` (lines 4, 6, 8, 9, 13, 14, 19, 20, 24, 25, 26, 27).
9. Section 4: "Every top-level line starts with its kind." Governs lines 2, 18 and 30.
10. Section 4: "Declaration order never matters but a group's (section 13)". Governs line 31, which calls `sorted_desc` and `runs`. Both are declared before `main` anyway.
11. Section 5: "`$=` binds once, forever." Governs lines 4, 19, 31, and the temporary `t` on line 10.
12. Section 5: "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 3, 5, 7, 11, 13, 14, 22, 23, 26 and 27. Lines 11 and 12 re-bind elements of `ys`, and that is legal under this sentence.
13. Section 5: "Signatures are always explicit; inference is local only." Governs lines 2 and 18. Each parameter and return type is written out.
14. Section 5: "An unused binding or parameter is a compile error, and so is a cell nothing re-binds". Governs lines 3, 4, 5, 7, 10, 19, 22, 23 and 31. Every binding is read, and every cell is re-bound (`i`, `j`, `count`, `k`, `ys`).
15. Section 5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs all names in the file. None repeats a name in its own function, and none uses a built-in name (`print`, `len`, `range`) or a function name (`runs`, `sorted_desc`, `main`).
16. Section 6 (example): "`if xs.len() == 0`" is written in the spec. It shows that `.len()` is valid on an array. Governs lines 4 and 19.
17. Section 7: "(`< <= > >=`: a number only)". Governs lines 6, 9 and 24, which compare `i64` values only.
18. Section 7: "`==` is structural equality on any two values of one type". Governs line 20 (`==`), and line 25 (`!=`, the negation of the same comparison).
19. Section 7 grammar: `Sum = Product { ( "+" | "-" ) Product } .` Governs line 8, `n - 1 - i`. Subtraction is left to right, so it is `(n - 1) - i`. Since `i < n`, the value is at least 0 on every pass.
20. Section 8: "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness." Governs lines 9, 20 and 25. Each condition is a comparison, so it is `bool`.
21. Section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range`". Governs the loops on lines 6, 8, 24 and 32.
22. Section 8: "A function with a `->` must `return` on every path that reaches its end". Governs `sorted_desc` (return on line 15) and `runs` (returns on lines 21 and 28).
23. Section 8: "A statement after a jump, in its block, is a compile error." Governs line 21: `return 0` is the last statement of its block. Line 15 and line 28 are also last in their blocks.
24. Section 9: "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs lines 4 and 19, `ys.len()` and `xs.len()`.
25. Section 9: "where one with neither mark would be a copy" (in the paragraph on `lent`). Governs line 2 and line 18: `xs` is a plain parameter, so the caller's array is copied in. Nothing is written back.
26. Section 9: "When two parameters in a signature share a type, named arguments are mandatory at the call site". Governs no line. Each call here has a single argument, so positional calls are correct. `range` and `slice` are not used.
27. Section 10: "An out-of-bounds index or slice aborts". Governs lines 9, 10, 11, 12 and 25. Every index is in range: `j + 1` is at most `n - 1` because `j < n - 1 - i`, and `k - 1` is at least 0 because `k` starts at 1.
28. Section 11: "`print` writes its values with no separator and exactly one trailing newline" Governs lines 33 and 34. Each output is one line.

## choice_points

- **C1, inner loop bound (line 8).** I used `j < n - 1 - i`, which shrinks each pass, because the largest unsorted element is then already in place. The other choice, `j < n - 1` on every pass, produces the same output. It only does more comparisons, and it also stays in bounds.
- **C2, copying the input (line 3).** I used `ys @= xs`, a mutable copy. The other choice is an `@xs` parameter, which the brief's signature `sorted_desc(xs: [i64])` rules out. An `@` parameter would also make the caller write `@` at the call site on line 31. A copy is the only choice that keeps the required signature and leaves the caller's array alone.
- **C3, the swap (lines 10 to 12).** I used a temporary `t`. The language has no tuples or multiple assignment, so a temporary is the only option.
- **C4, strict or non-strict comparison (line 9).** I swap only when `ys[j] < ys[j + 1]`, so equal neighbours are never swapped. The other choice, `<=`, would swap equal values too. The sorted output is the same, because equal values print the same.
- **C5, the literal `0` (lines 5, 7, 20, 21).** I read the rule "A leading zero is an error" as covering `01` or `007`, not a single `0`. Under the other reading, every `0` would be an error and the checker would reject the whole program. That reading is less likely, since the spec gives no way to write a zero otherwise and the grammar has no separate rule for it. This is the main reason for the confidence below.
- **C6, the type of `len` (lines 4 and 19).** The spec lists `len` as a built-in, but it does not give its return type. I assumed `i64`, the type the rest of the program uses. The other possibility, a different integer type, would make the comparisons on lines 6, 8, 20 and 24 mismatched. The checker would then reject the program.
- **C7, `ys.len()` versus `len(ys)` (lines 4 and 19).** I used the method form, as the spec's own example does. The function form gives the same value, so this choice does not change the checker's verdict if `len` returns `i64`.
- **C8, the empty array in `runs` (lines 20 and 21).** I return 0 for `[]`. Without the guard, `count` starts at 1 and `[]` would give 1. The brief never passes an empty array, so the output is the same either way.
- **C9, printing (lines 32 to 34).** I print each element in a `for` loop, then the count. The other choice, joining the values into one `str` with `join` and printing once, needs conversions and produces the same output.
- **C10, the file name.** The brief asks only for `report.md`, so I did not create a `.hero` file. The program appears only in the `program` section.
- **C11, comments (lines 1 and 17).** I added one comment above each function. The checker ignores them. The other choice is no comments, which has no effect on the checker.

## confidence

About 90% that the checker accepts the program as written. Most of the remaining doubt is about the spec's own wording, not the logic.

Least certain line: line 4 and line 19, `ys.len()` and `xs.len()`. The spec does not state the return type of `len`. If it is not `i64`, the comparisons on lines 6, 8, 20 and 24 fail. See C6.

Second least certain: line 20 and lines 5, 7 and 21, the literal `0`. This depends on reading "A leading zero is an error" as not covering a single `0`. See C5.

The logic was checked by hand. For `[3, 1, 4, 1, 5, 9, 2, 6]`, the bubble passes give `9, 6, 5, 4, 3, 2, 1, 1`. For `[1, 1, 2, 2, 2, 3, 1]`, the groups are `1 1`, `2 2 2`, `3`, `1`, so `runs` gives 4. I could not run the program, so these are hand traces, not test results.

## context

Only the files in this directory reached my context as input: `brief.md` and `spec.md`. I read both in full.

One read of this directory itself failed with EISDIR. It returned no content.

Some material supplied by the harness also reached my context: environment details, a git status snapshot, account metadata, and the scratchpad path. I did not use any of it as input to the program or to this report. I ran no tools other than reading and writing files here, and I read no file outside this directory.
