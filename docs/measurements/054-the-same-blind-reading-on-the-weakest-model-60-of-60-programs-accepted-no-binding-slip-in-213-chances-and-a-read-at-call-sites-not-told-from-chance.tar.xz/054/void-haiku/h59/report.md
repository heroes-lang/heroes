## program

```
# Bubble sort: swap adjacent out-of-order pairs until a pass swaps nothing.
function sorted_desc(xs: [i64]) -> [i64]
    ys: [i64] @= xs
    n := len(ys)
    swapped @= true
    while swapped
        swapped = false
        for i in range(from: 0, to: n - 1)
            if ys[i] < ys[i + 1]
                t := ys[i]
                ys[i] = ys[i + 1]
                ys[i + 1] = t
                swapped = true
    return ys

# Count the maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    for i in range(from: 1, to: len(xs))
        if xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

## sentences

Line numbers refer to the program above, counted from its first line.

1. Spec section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 26 to 29.
2. Spec section 4: "Every top-level line starts with its kind." Governs lines 2, 17, 26.
3. Spec section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs the layout of the whole program.
4. Spec section 1: "No braces, no semicolons; a condition needs no parentheses." Governs lines 6, 9, 18, 22.
5. Spec section 2: "A literal takes the type its context asks for" and "otherwise `i64`." Governs the integer literals `0`, `1`, `2` (lines 8, 19, 20, 21, 23) and the array literals on lines 27 and 29.
6. Spec section 3: "`[T]` | dynamic array, indices from 0". Governs every index expression: `ys[i]`, `ys[i + 1]` (lines 9 to 13), `xs[i]`, `xs[i - 1]` (line 22).
7. Spec section 3: "No implicit conversions, widths included: `1 + 2.0` is an error." Governs every arithmetic and comparison, which uses only `i64` operands, on lines 8, 9, 11, 12, 18, 21, 22, 23.
8. Spec section 3: "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs line 5, where `ys` is a copy of `xs`, and the swaps on lines 11 and 12, which change only `ys`.
9. Spec section 5: "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 5, 7, 10, 11, 12, 13, 20 and 23. Lines 11 and 12 re-bind elements inside the cell `ys`.
10. Spec section 5: "mutable cell, type inferred too" (from the example `v @= 0`). Governs lines 5, 7 and 20, which are untyped `@=` bindings, and the annotated binding on line 5 (`ys: [i64] @=`), whose type is written out.
11. Spec section 5: "All bindings are initialised." Governs lines 4, 5, 7, 10 and 20.
12. Spec section 5: "An unused binding or parameter is a compile error", and "a read is a use and a write is not". Governs `n` (read on line 8), `t` (read on line 12), `ys` (read on lines 4 and 14), `swapped` (read on line 6), `count` (read on line 24), both `xs` parameters, and the loop variables `i` and `x`.
13. Spec section 5: "Shadowing is a compile error". Governs the names in the program. Each name is bound once in its scope. `i` is used as a loop variable in two different functions, and neither use is nested in another.
14. Spec section 7: "`< <= > >=`: a number only" from the comparison row. Governs line 9.
15. Spec section 7: "`==` is structural equality on any two values of one type". Governs line 18. Spec section 7 also lists `!=` in the same row, which governs line 22.
16. Spec section 7: "arithmetic + - * / %" with the note "both sides one numeric type". Governs `n - 1` (line 8), `i + 1` (lines 9, 11, 12), `i - 1` (line 22) and `count + 1` (line 23).
17. Spec section 8: "A function with a `->` must `return` on every path that reaches its end". Governs line 14 (in `sorted_desc`) and line 24 (in `runs`).
18. Spec section 8: "`if cond` / `else if` / `else` take only `bool`", with the rest of the sentence saying there is no truthiness. Governs the three `if` conditions on lines 9, 18 and 22, each of which is a `bool` comparison.
19. Spec section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs the `while` on line 6 and the `for` loops on lines 8, 21 and 27.
20. Spec section 8: "A statement after a jump, in its block, is a compile error." Governs `return 0` on line 19. The `if` on line 18 is followed by `count @= 1` on line 20 in the function block, not in the `if` block, so the rule does not apply there.
21. Spec section 9: "When two parameters in a signature share a type, named arguments are mandatory at the call site". Governs the `range(from: ..., to: ...)` calls on lines 8 and 21. The built-in `range` takes two `i64` parameters, so the names are required.
22. Spec section 9: "Arg = [ ident ":" ] [ "@" ] Expression" from the grammar. Governs the single-argument calls on lines 27, 28 and 29, which are positional and need no names.
23. Spec section 10: "A container literal separates elements by newline across lines and by comma on one". Governs the array literals on lines 27 and 29, which are written on one line with commas.
24. Spec section 10: "An out-of-bounds index or slice aborts". Governs the loop bound `n - 1` on line 8. The body reads `ys[i + 1]`, so `i` must stop before `n - 1`, which the exclusive `to:` bound achieves.
25. Spec section 11: "`print` writes its values with no separator and exactly one trailing newline" and "takes the types this language renders as text: a number, `str` or `bool`". Governs lines 28 and 29.
26. Spec section 11: "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs both `range` calls: line 8 gives `i` from 0 to `n - 2`, and line 21 gives `i` from 1 to `len(xs) - 1`.
27. Spec section 11: "Built-ins: `print(...)` · `len` · `push`". Governs `len` on lines 6, 18 and 23. The spec names `len` without giving a signature, which is the basis of choice point 3.

## choice_points

1. Sorting method. I chose bubble sort, which swaps whenever the left element is smaller than its right neighbour, and repeats passes until one makes no swap. Insertion sort or selection sort would give the same output, `9 6 5 4 3 2 1 1`. Fixed `n - 1` passes with no flag would also give that output, and would drop the `while` and `swapped`.
2. Copy into a cell or build a new array. I chose one copy into the mutable cell `ys` on line 5, then in-place element swaps. The other choice is to build the result with `push` from an empty `[i64]` (`out: [i64] @= []`, then `out = out.push(...)`). That also gives the same output and avoids the swap temporary, but it does not sort anything by itself, so the swap logic would have to move into that loop. I took the swap approach because the brief asks for swaps.
3. The type of `len`. The spec lists `len` among the built-ins without a signature. I assumed `i64`, which is the language's default integer type, so the `range(from:, to:)` bounds on lines 8 and 21 type-check. The other choice is an explicit annotation, `n: i64 := len(ys)`. That states the same assumption. If `len` returns another integer width, both forms fail to compile, so the annotation would only move the error.
4. Loop bound in `sorted_desc`. I chose `to: n - 1`, which runs `i` from `0` to `n - 2`, so `ys[i + 1]` never goes out of bounds. The other choice is `to: n`, which reads `ys[n]` on the last pass. It would still compile, so the checker would accept it, but the program would abort at runtime.
5. Empty-array guard in `runs`. I added `if len(xs) == 0` with `return 0`. Without it, `runs([])` returns `1`, because `count` starts at `1` and the `range(from: 1, to: 0)` loop is empty. The program never calls `runs` with an empty array, so its output is the same either way. I kept the guard because the function is wrong for empty input without it.
6. Starting value of `count`. I chose `1`, because a non-empty array has at least one group. The other choice is `0`, with the loop starting at index 0 and counting a group whenever an element differs from the one before it. That needs a special case for index 0. `1` is simpler.
7. Argument style. Single-argument calls are positional, as in `sorted_desc([...])` and `runs([...])`. Named arguments, as in `sorted_desc(xs: [...])`, are also accepted, since the grammar allows a name on every argument. The output is the same either way.
8. Output loop versus `join`. I print each element with `print(x)` in a loop, as the brief asks. The other choice, `join(xs, sep)` with a newline separator, would print the same lines, but it needs a `str` conversion and a string literal the brief did not ask for.
9. Comments. I wrote one `#` comment above each function. Comments are allowed anywhere, so leaving them out does not change what the checker accepts.
10. Type of `swapped`. `swapped @= true` infers `bool`. The other choice, `swapped: bool @= true`, has the same meaning. I kept the inferred form, which matches the spec's example.

## confidence

I am fairly confident the checker accepts this program on the first try, roughly 80 to 85 percent. The main risk is that the spec does not give the signature of `len`.

The line I am least sure of is line 6, `n := len(ys)`, and its use on line 8 in `range(from: 0, to: n - 1)`. If `len` returns an integer type other than `i64`, line 8 fails to compile, and so do line 21 and the `range` call on line 23 if `len` is not `i64`. The rest of the program follows from explicit spec rules: the `@=` and `=` forms, the `while` and `for` syntax, the named-argument rule for `range`, and the four-space indentation.

Line 5, `ys: [i64] @= xs`, is the second least certain. The spec's Binding grammar allows an optional type before `@=`, and the example shows `v @= 0` without one. I read the grammar as allowing the annotated form, but I found no example of it in the spec.

Lines 11 and 12, the element re-bindings `ys[i] = ...`, rest on the Place grammar, `ident { "[" Expression "]" }`, and on the rule that `=` re-binds an element inside a cell. Both are covered explicitly by the spec.

## context

Only the two files in this directory were read: `brief.md` and `spec.md`. A read of the directory path itself returned an error, and nothing else was opened. I used no tool to run or compile anything, as the brief requires.

Some information outside those files reached my context from the session setup, not from any file I opened. It included the user's account identity, the git status and recent commit subjects of the repository, the working-directory and platform details, and the model and budget information. None of it was used in the program or in the reasoning about it. I did not read any file the brief excludes.
