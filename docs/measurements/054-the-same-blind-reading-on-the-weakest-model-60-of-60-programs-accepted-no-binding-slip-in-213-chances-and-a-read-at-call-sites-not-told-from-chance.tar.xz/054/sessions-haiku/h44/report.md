## program

```
# Sorts by adjacent swaps and counts runs of equal neighbours.

# Returns xs from largest to smallest, swapping adjacent out-of-order pairs.
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n = len(ys)
    outer @= 0
    while outer < n
        inner @= 0
        while inner < n - 1 - outer
            if ys[inner] < ys[inner + 1]
                a = ys[inner]
                b = ys[inner + 1]
                ys[inner] @ b
                ys[inner + 1] @ a
            inner @ inner + 1
        outer @ outer + 1
    return ys

# Counts the maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    count @= 0
    prev @= 0
    first @= true
    for x in xs
        if first
            count @ 1
            first @ false
        else if x != prev
            count @ count + 1
        prev @ x
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below refer to the program block, counting its first line as line 1.

## sentences

Spec sentences the program rests on, each with the program lines it governs.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 34-37 (`main`).
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs the whole file; every block is indented in multiples of 4 spaces.
3. "No braces, no semicolons; a condition needs no parentheses." Governs lines 8, 10, 11, 26, 29 (conditions written without parentheses).
4. "Signatures are always explicit; inference is local only." Governs lines 4, 21, 34 (all parameter and return types are written; `ys`, `n`, `a`, `b`, `count`, `prev`, `first` take types locally).
5. "A literal takes the type its context asks for ... otherwise `i64`." Governs lines 9, 22, 23, 35, 37 (`0`, `1` and the array literals default to `i64`) and line 24 (`true` is `bool`).
6. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs lines 5, 7, 9, 14, 15, 17, 22, 23, 24, 27, 28, 30, 31 (`=` for `n`, `a`, `b`; `@=` for cells; `@` for re-bindings, including element writes at lines 14-15).
7. "All bindings are initialised." Governs lines 5-7, 9, 22-24.
8. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds ... a read is a use and a write is not." Governs lines 5 (`ys` read at 6 and re-bound at 14-15), 7 (`outer` read at 8, re-bound at 17), 9 (`inner` read at 10, re-bound at 16), 22 and 23 (`count`, `prev` read, re-bound), 24 (`first` read at 26, re-bound at 28). Lines 4, 21 and 34 parameters `xs` are read at 5 and 22 and 25; `x` is read at 36 and 29, 30, 31.
9. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." The program has no `use`. Within each function, no name is bound twice; `x` appears in both `runs` and `main`, which are separate functions (lines 25, 35).
10. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs lines 4, 21, 34: `main` (line 34) calls `sorted_desc` and `runs`, which are declared earlier; order is not relied on.
11. "A function with a `->` must `return` on every path that reaches its end." Governs lines 18 (`sorted_desc`) and 32 (`runs`). Both end with a `return`, after loops with no early exit.
12. "Loops: `while cond` and `for x in xs`, over an array or a `range`." Governs lines 8, 10 (`while`), 25 and 35 (`for`).
13. "`if` and `match` are expressions and may stand as statements" and "`if cond` / `else if` / `else` take only `bool` - there is no truthiness." Governs lines 11 (`<` yields `bool`), 26 (`if first`, a `bool` cell), 29 (`else if x != prev`).
14. "`==` is structural equality on any two values of one type" and the comparison row "`!=`" in the operator table (`comparison   == != < <= > >=`). Governs line 29 (`x != prev`) and line 11 (`<`).
15. "`< <= > >=`: a number only" (section 7 table). Governs lines 8, 10, 11 (all `<` on `i64`).
16. "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -`" and the grammar `Sum = Product { ( "+" | "-" ) Product }`. Governs lines 10 (`n - 1 - outer`, parsed as `(n - 1) - outer`), 13, 15 (`inner + 1`), 30 (`count + 1`).
17. "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs line 5 (`ys @= xs` is a copy, so `xs` stays unchanged) and lines 12-15 (the swap works on a copy).
18. "`[T]` | dynamic array, indices from 0" (section 3 table). Governs lines 5-18 (`ys[inner]`, `ys[inner + 1]`) and line 31 onward indexing semantics.
19. "An out-of-bounds index or slice aborts" (section 10). Governs lines 11, 12, 13, 14, 15: every index used is in range, because `inner + 1` is at most `n - 1 - outer` plus one, which is at most `n - 1`.
20. "`len`" in the built-ins list: "Built-ins: `print(...)` · `len` · `push` ...". Governs lines 6, 8, 10 (`len(ys)`). The spec does not state the return type of `len` (see confidence).
21. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 36 and 37 (`print` of `i64` values, one per line).
22. "A container literal separates elements by newline across lines and by comma on one" (section 10). Governs lines 35 and 37 (single-line array literals with commas).
23. "Arg = [ ident ":" ] [ "@" ] Expression" (section 9 grammar). Governs lines 35, 37: arguments are positional. Named arguments are mandatory only "When two parameters in a signature share a type"; no function here has two such parameters.
24. "Comments: `#` comments to end of line." Governs lines 1, 3, 20.
25. "Syntax is ASCII-only" (section 1). The whole program is ASCII.

## choice_points

1. **How `runs` walks the array.** Chosen: `for x in xs` with a `first` flag, a `prev` cell and a `count` cell (lines 22-32). Other choice: index loop `i @= 1` with `while i < len(xs)` comparing `xs[i]` and `xs[i - 1]`. Both give 4 on `[1, 1, 2, 2, 2, 3, 1]`, and both give 0 on an empty array. The index form depends on the return type of `len` in one more place; the chosen form does not.
2. **The `first` flag and the `else if`.** Chosen: `if first ... else if x != prev`, so the first element counts once (lines 26-30). Other choice: two separate `if`s (`if first` then `if x != prev`). That counts the first element twice whenever it is not equal to the initial `prev` of 0, so the output would be 5 instead of 4 for the example. A third option, initialising `prev` to the first element, would also work but needs the first element read before the loop, which the for-loop form avoids.
3. **Empty input in `runs`.** Chosen: no special case; the loop does nothing and `count` stays 0. Other choice: an explicit `if len(xs) == 0` return. Same result. The spec gives no way to fail a plain `i64` result, so `fail` was not an option.
4. **Copying the input in `sorted_desc`.** Chosen: `ys @= xs` (line 5), then sort `ys` in place. Other choice: build a fresh array with `push` in a new cell. Same output, more code. An in-place sort of `xs` itself is not possible because parameters without `@` cannot be re-bound.
5. **The swap.** Chosen: read both elements into `a` and `b` (lines 12-13), then write (lines 14-15). Other choice: `ys[inner] @ ys[inner + 1]` followed by `ys[inner + 1] @ ys[inner]`. That second read sees the already-overwritten value, so both elements end up equal to the larger one. The temporaries are required.
6. **Number of passes.** Chosen: `outer < n`, always n passes (lines 8, 17). Other choice: a `swapped` flag that stops early. Same output, extra cells and lines.
7. **Inner bound.** Chosen: `inner < n - 1 - outer` (line 10). Other choice: `inner < n - 1`. Same output, extra comparisons on the sorted tail.
8. **Type of literals and cells.** Chosen: unannotated `@= 0`, `= 1`, `@= true`, which default to `i64` and `bool` (lines 7, 9, 22, 23, 24). Other choice: annotated, e.g. `count: i64 @= 0`. Same result. Literals in the two array arguments take `[i64]` from the parameter type of `sorted_desc` and `runs`.
9. **Argument style.** Chosen: positional arguments (lines 35, 37). Other choice: `sorted_desc(xs: [...])`. Both are accepted; named form is optional here because the function has one parameter.
10. **Output shape of `main`.** Chosen: loop over the sorted result and `print` each element (lines 35-36), then `print(runs(...))` directly (line 37). Other choice: bind the result to a name first, `r = runs(...)`, then `print(r)`. Same output. A binding for the sorted array would also be fine, since it would be used in the loop.
11. **Name choices.** `ys`, `outer`, `inner`, `a`, `b`, `count`, `prev`, `first` were chosen to avoid any reserved-looking word and any repeat within a function. Other names give the same program.
12. **Comparison direction.** Chosen: `ys[inner] < ys[inner + 1]` swaps when the left is smaller, giving descending order (line 11). Other choice: `>` would give ascending order, which is the wrong output for `sorted_desc`.

## confidence

About 80% that the checker accepts the program as written, on the first try.

Least confident line: **line 6**, `n = len(ys)`. The spec lists `len` among the built-ins but does not give its return type, and the spec's "No implicit conversions" rule means a non-`i64` result would make the comparisons on lines 8 and 10 (`outer < n`, `inner < n - 1 - outer`) errors. I assumed `len` returns `i64`, which fits the spec's default integer type, but the spec does not say so. The `runs` function avoids `len` entirely, for that reason.

Other lines I am less than fully sure about, in order:
- Line 10 (`inner < n - 1 - outer`): depends on line 6 as above.
- Line 29 (`else if x != prev`): the `else if` form with an `if` on the same line as `else` is per the grammar in section 8, but I have not seen an example of an `else if` whose body is a single-line `count @ ...` after a `first @ false` branch. It should parse.
- Lines 14-15 (`ys[inner] @ b`, element re-binding): the spec explicitly allows "`@` re-binds ... a field or element inside one", so I am confident in the syntax.

I cannot run the checker, so none of this is verified by a build.

## context

Only files in this directory reached my context: `brief.md`, `spec.md` (read in full), and `run.json` and `run.err`, which are both empty. I did not read anything outside this directory, and I used no tool other than reading and writing files here, as the brief requires. The session's system context also carried environment details (working directory, platform, date, model) and a git status snapshot. I did not use any of that to write the program or this report.
