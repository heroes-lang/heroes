# report

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    found @= false
    pos @= 0
    i @= 0
    for item in items
        if item.name == name
            found = true
            pos = i
        i = i + 1
    if found
        items[pos].qty = items[pos].qty + n
    else
        items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    found @= false
    pos @= 0
    i @= 0
    for item in items
        if item.name == name
            found = true
            pos = i
        i = i + 1
    if !found
        return false
    if items[pos].qty < n
        return false
    items[pos].qty = items[pos].qty - n
    return true

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    a $= take(@items, "apple", 5)
    b $= take(@items, "pear", 9)
    print(a)
    print(b)
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple 7 minus 5 leaves 2; pear holds 2, so taking 9 fails; 2 + 2 = 4).

Line numbers below count from the first line of the block above as line 1.

## sentences

1. "Every top-level line starts with its kind." (section 4). Governs lines 1, 5, 19, 35.
2. "`Fields = INDENT { ident ":" Type NEWLINE } DEDENT .`", with the example `record Point` / `x: i64` / `y: i64` (section 4). Governs lines 1-3.
3. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." (section 1). Governs the layout of every line, and the conditions on lines 10, 14, 24, 28, 30.
4. "`Param = "@" ident ":" Type | ident ":" Type [ "lent" ] .`" (section 4). Governs the parameter lists on lines 5 and 19.
5. "Mutable parameters are marked `@` in the signature and at the call site" (section 9). Governs `@items` on lines 5, 19, 37-41.
6. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." (section 5). Governs the cells `found`, `pos`, `i` (lines 6-8, 20-22), the re-bindings on lines 11-13, 25-27, the element writes on lines 15 and 32, and the `items = ...` re-binding on line 17.
7. "`$=` binds once, forever." (section 5). Governs `a` and `b` on lines 40-41.
8. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends." (section 5). Governs the cells on lines 6-8 and 20-22 (each re-bound and read), `@items` on lines 5 and 19 (written), and `a`, `b`, `total` on lines 40, 41, 44 (each read).
9. "`For = "for" ident "in" Expression Block .`" and "Loops: `while cond` and `for x in xs`, over an array" (section 8). Governs lines 9 and 45 (`for item in items`).
10. "`if cond` / `else if` / `else` take only `bool`; there is no truthiness." (section 8). Governs lines 10, 14, 24, 28, 30.
11. "`==` is structural equality on any two values of one type" (section 7). Governs lines 10 and 24 (`item.name == name`, both `str`).
12. "`boolean      && || !            (bool only; && and || short-circuit)`" (section 7). Governs line 28 (`!found`).
13. "`arithmetic   + - * / %          (both sides one numeric type, never mixed)`" (section 7). Governs lines 13, 15, 27, 32, 46 (`i + 1`, `items[pos].qty + n`, `i + 1`, `items[pos].qty - n`, `total + item.qty`; all `i64`).
14. "`< <= > >=`: a number only" (section 7). Governs line 30 (`items[pos].qty < n`).
15. "A function with a `->` must `return` on every path that reaches its end" (section 8). Governs lines 28-29, 30-31, 33 in `take`.
16. "`x.f(y)` is sugar for `f(x, y)` (UFCS)" (section 9), and "`xs = xs.push(4)` grows in place when `xs` is a plain name" (section 10). Governs line 17 (`items = items.push(...)`).
17. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" (section 9). Governs line 17 (`Item(name: name, qty: n)`).
18. "`[T]` dynamic array, indices from 0" (section 3). Governs the indexing on lines 15, 30, 32 (`items[pos]`), where `pos` is an `i64`.
19. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (section 11). Governs lines 42, 43, 47.
20. "`function main()`, which takes nothing and produces nothing" (section 1). Governs line 35.
21. "Declaration order never matters but a group's" (section 4). Governs `main` (line 35) calling `restock` and `take`, which are declared above it.
22. "A literal takes the type its context asks for ... otherwise `i64`." (section 2). Governs the literals `0` on lines 6, 7, 8, 20, 21, 22, 44, and the arguments `3`, `2`, `4`, `5`, `9` on lines 37-41.
23. "an empty one needs an annotation: `xs: [i64] $= []`" (section 10). Governs line 36 (`items: [Item] @= []`).
24. "A string is one line." (section 1) and the string literal form (section 2). Governs the string literals `"apple"` and `"pear"` on lines 37-41.

## choice_points

1. **Index search by hand instead of `find`.** The spec says `find` returns "the first it accepts, else `not_found`" but does not give its return type, so I did not use it. I walk the array with `for item in items` (lines 9, 23), keep a counter `i`, and record the match in `pos`. The other choice, `find`, would give a different result type and a different error code to match on.
2. **Index-based loop with `len` instead of a counter.** The spec never states the type `len` returns, and `i64` comparisons reject a mixed width ("No implicit conversions, widths included"). The other choice would be `while i < items.len()`, which compiles only if `len` returns `i64`.
3. **`i64` cells for `pos` and `i`.** Literals default to `i64` (section 2), so `pos @= 0` and `i @= 0` are `i64`. The other choice would be a `u64` or other index type, which needs an annotation such as `pos: u64 @= 0`. The spec does not say which integer types an index accepts.
4. **Positional `@` arguments.** I call `take(@items, "apple", 5)` with no names. The other choice, `take(@items, name: "apple", n: 5)`, is also valid, because named arguments are mandatory only when two parameters share a type, and here `str` and `i64` each appear once.
5. **`items = items.push(...)` rather than a bare `items.push(...)`.** A bare call would discard a non-`()` result, which "A line that computes a value must use it" forbids. The other choice, `_ $= items.push(...)`, would compile but never add the item.
6. **`found` flag rather than a `-1` sentinel for `pos`.** The spec has no sentinel convention. The other choice, `pos = -1` and a test `pos < 0`, would also work but needs a second comparison and a negative literal.
7. **No early `break` when the name matches.** Names are unique in `items`, so stopping early would give the same result. The other choice, `break` after line 11 or 25, would be valid under section 8 and would shorten each loop.
8. **Early `return false` statements in `take` (lines 29, 31) with a final `return true` (line 33).** The other choice, an `if`/`else` where both branches return, is equivalent and also passes the every-path rule.
9. **`print(a)` for a `bool`.** The spec says a `bool` prints `true` or `false`. The other choice, `print(to_str(a))`, prints the same text through an extra call.
10. **A plain loop for the sum (lines 44-46) instead of `fold`.** The spec's `fold` needs a top-level function value, which would be an extra declaration here. The other choice, `fold(0, add)` with a top-level `add`, prints the same sum.

## confidence

I am about 80% sure the checker accepts this program on the first try.

The least certain line is 15, `items[pos].qty = items[pos].qty + n`, and its twin on line 32 in `take`. They depend on an `i64` index into an `@` parameter array, and the spec never states the index type. Line 17 (`items = items.push(Item(name: name, qty: n))`) is next: it relies on UFCS `push` through an `@` parameter that is also re-bound with `=`. Lines 9 and 23 (`for item in items` over an `@` parameter) carry a small risk, since the spec does not say whether an `@` parameter can be iterated directly.

## context

Only the files in this directory reached my context: `brief.md`, `spec.md`, `run.json` and `run.err`. `run.json` and `run.err` were empty. I read no file outside the directory and used no tool other than reading and writing files here. The session's environment details (working directory, platform, git status and user identity) were also in my context from the session setup, not from any file in this directory. They did not affect the program.
