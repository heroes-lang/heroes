## program

```
# An item in stock: a name and a quantity.
record Item
    name: str
    qty: i64

# Adds n to the qty of the item called name, or appends a new item when none has that name.
function restock(@items: [Item], name: str, n: i64)
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
    items = items.push(Item(name: name, qty: n))

# Subtracts n from the qty of the item called name when it holds at least n; otherwise changes nothing.
function take(@items: [Item], name: str, n: i64) -> bool
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty = items[i].qty - n
                return true
            return false
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple 7 minus 5 leaves 2, pear 2 is untouched by the failed take, sum 2 + 2).

## sentences

Each sentence is quoted from `spec.md`; the line numbers refer to the program above.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 24.
2. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs the placement of `record Item` (line 2) before its use. The record is declared first only for readability; the order would not change the result.
3. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line, and the conditions on lines 9, 17 and 18, written without parentheses.
4. "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it" Governs lines 1, 6 and 14.
5. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs line 12.
6. "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs line 25 (`items` declared with `@=`), line 31 (`total @= 0`), line 33 (re-binding `total`), line 10 and line 19 (re-binding a field of an element), and line 12 (re-binding the `@` parameter `items`).
7. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends" Governs lines 7 and 15 (`@items` is written on lines 10, 12, 19), line 31 (`total` is re-bound on line 33), and every use of `i` and `item`.
8. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` ... `advance(@l)`" Governs lines 7 and 15 (signatures) and lines 26 to 30 (call sites).
9. "Signatures are always explicit; inference is local only." Governs lines 7, 15 and 24, which all state their parameter types, and the `-> bool` on line 15.
10. "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `0`, `3`, `2`, `4`, `5`, `9` and the `0` on line 31; each becomes `i64` from its context.
11. "No implicit conversions, widths included" Governs the arithmetic on lines 10, 19 and 33, where both sides are `i64`.
12. "`range(from: a, to: b) -> [i64]` exclude `to`." Governs lines 8 and 16.
13. "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs the `from:` and `to:` labels on lines 8 and 16, which name both `i64` arguments. The same sentence does not apply to lines 26 to 30, since the parameters of `restock` and `take` have different types.
14. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `items.len()` on lines 8 and 16 and `items.push(...)` on line 12.
15. "`xs = xs.push(4)` grows in place when `xs` is a plain name" Governs line 12.
16. "an empty one needs an annotation: `xs: [i64] := []` ... `m: {str: i64} @= {}`." Governs line 25, where `[]` is given the annotation `[Item]`.
17. "`for x in xs`, over an array or a `range` (section 11)." Governs lines 8, 16 and 32.
18. "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness." Govern lines 9, 17 and 18.
19. "`==` is structural equality on any two values of one type, recursively" Governs the string comparisons on lines 9 and 17.
20. "A function with a `->` must `return` on every path that reaches its end" Governs `take` (line 15): the `return true` on line 20, the `return false` on line 21, and the `return false` on line 22 that ends the path after the loop.
21. "A statement after a jump, in its block, is a compile error." Governs lines 11 and 20; each jump is the last statement of its block, and line 21 is not after a jump in its own block.
22. "Every value behaves as an independent copy" Governs the loop on lines 32 and 33, which reads `item.qty` from a copy of each element.
23. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 29, 30 and 34, which print a `bool` and then an `i64`.

## choice_points

1. **Iteration style for `restock` and `take`.** I used an index loop, `for i in range(from: 0, to: items.len())`, because I need to write `items[i].qty`. The other choice was `for item in items`. The loop variable is a copy of each element, so writing to it would not change `items`, and the program would either be refused or silently print wrong totals.
2. **Type of `len`.** The spec lists `len` among the built-ins but does not give its result type. I assumed `i64`, so that it can be compared with and passed to `range`, which takes `i64` bounds. If `len` returned another type, line 8 and line 16 would be refused. The other choice would be a `to:` expression converted explicitly, which the spec does not provide for `len`.
3. **Named labels on `range`.** I wrote `from:` and `to:`. Both are `i64`, so the spec makes the labels mandatory. Positional arguments would be refused at lines 8 and 16.
4. **Named labels on `restock` and `take` calls.** I wrote them positionally. The spec only requires labels when two parameters of one signature share a type, which is not the case here. Using `name:` and `n:` labels would be accepted and print the same output.
5. **Re-binding `items` inside `restock`.** I wrote `items = items.push(...)` (line 12). The other choice, `items.push(...)` on its own, would not compile, because `push` returns a new array and the result must be bound or re-bound. Re-binding the `@` parameter writes the caller's array as the spec's `@` rule requires.
6. **`take` on a name that exists but holds too little.** I return `false` and change nothing. The other choice would subtract anyway or return a `T?`, which the brief does not ask for.
7. **`take` on a name that does not exist.** I return `false` at line 22. The other choice would be to append an item with a negative quantity, which the brief does not ask for.
8. **Duplicate names.** I update the first matching item. The program never creates duplicates, so this choice does not change any output.
9. **Early `return` versus a flag in `take`.** I used early returns. A flag variable with a single `return` at the end would print the same output and use one more binding.
10. **Summing.** I used a mutable cell and a loop. `fold` with a named function would also work, and would print the same total of 4, but it needs a separate function declaration.
11. **Printing a `bool`.** I passed the `bool` directly to `print`. The other choice, `to_str(...)`, would print the same text.
12. **Inferred versus explicit types on the cell `total`.** I wrote `total @= 0`, with the type inferred as `i64`. The other choice, `total: i64 @= 0`, produces the same program.

## confidence

I am highly confident, about 90 percent, that the checker accepts the program on the first try. The rules it depends on are plain: records, `@` parameters, `@=` cells, index loops over `range`, early `return` in functions with and without `->`, and `print` of `bool` and `i64`.

The line I am least sure of is line 8, and line 16 with it. They depend on two things the spec does not state directly: that `items.len()` returns `i64`, and that a `for` over `range(from:, to:)` may contain a `return` and a write through `items[i].qty`. Line 12, which re-binds the `@` parameter `items`, is the next least certain.

## context

Only the files in this directory reached my context. I read `brief.md` and `spec.md` in full, as the brief requires. I also read `run.json` and `run.err`, which are in the same directory; both are empty and contributed nothing to the program. I did not open any file outside this directory and did not run any tool other than reading and writing files here.

My context also held the session's environment details: the working directory path, the platform, the shell, the date and the model name. These came from the environment, not from any file, and I did not use them in the program.
