## program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n @= 0
    for x in xs
        _ = x
        n @ n + 1
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if ys[j] < ys[j + 1]
                t = ys[j]
                ys[j] @ ys[j + 1]
                ys[j + 1] @ t
            j @ j + 1
        i @ i + 1
    return ys

function runs(xs: [i64]) -> i64
    groups @= 0
    prev @= 0
    first @= true
    for x in xs
        if first
            groups @ 1
            first @ false
        else if x != prev
            groups @ groups + 1
        prev @ x
    return groups

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below refer to this block. Line 1 is the `function sorted_desc` line, and blank lines count.

## sentences

1. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." (section 1). Governs the indentation of every line from 2 to 35.
2. "No braces, no semicolons; a condition needs no parentheses." (section 1). Governs lines 8, 10, 11, 24 and 27, whose conditions are written without parentheses.
3. "Outside brackets a line ends its statement: it may not end where the statement cannot, and the next line may not go on with it" (preamble). Governs every line. No statement is broken across lines, and no line continues another.
4. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." (section 4). Governs line 32, `main`, which calls `sorted_desc` and `runs`. Both are declared above it, though the order would not matter.
5. "Signatures are always explicit; inference is local only." (section 5). Governs lines 1, 19 and 32: each parameter and return type is written.
6. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." (section 5). Governs the `@=` declarations on lines 2, 3, 7, 9, 20, 21, 22, the `@` re-bindings of names on lines 6, 16, 25, 26, 28, 29, and the `=` bindings on lines 12 and 14 `t` and the loop variables.
7. `Simple = ... | Place "@" Expression NEWLINE ...` with `Place = ident { "." ident | "[" Expression "]" } .` (section 5). Governs lines 13 and 14, `ys[j] @ ys[j + 1]` and `ys[j + 1] @ t`, which re-bind elements of the cell `ys`.
8. "`[T]` | dynamic array, indices from 0" (section 3 table). Governs the indexing `ys[j]` and `ys[j + 1]` on lines 11 to 14, and the bounds that keep `j + 1` within the array.
9. "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." (section 3). Governs line 2: `ys @= xs` makes a copy, so the parameter `xs` is not changed by the sort, and `return ys` gives the sorted copy.
10. "All bindings are initialised." (section 5). Governs lines 2, 3, 7, 9, 12, 20, 21 and 22: each name is given a value where it is declared.
11. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds" (section 5). Governs the use of every name. `n` is read on lines 8 and 16. `ys` is read on line 17. `groups`, `prev` and `first` are each read (on lines 30, 27 and 24) and re-bound (on lines 28 and 25, 26, and 29). `t` is read on line 14. The loop variable `x` is read on line 5 and on line 27.
12. "`_` names anything you do not use: a payload (`.num _ => 0`), a parameter, a value. It binds nothing, so it is never unused and may repeat." (section 5). Governs the reason line 5 is needed: a `_` loop variable is not allowed by the `for` grammar, which takes a plain `ident`, so the loop variable is named `x`.
13. "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`, which a `()` line refuses: it stands alone." (section 5). Governs line 5, `_ = x`. The loop variable is discarded on purpose so that the loop can count the elements. `x` is an `i64`, not a `T?`, so the rule that a `_` never drops a `T?` does not apply.
14. "Shadowing is a compile error" (section 5). Governs the naming. Inside each function every name is introduced once: `xs`, `ys`, `n`, `x`, `i`, `j` and `t` in `sorted_desc`, and `xs`, `groups`, `prev`, `first` and `x` in `runs`. The loop variable `x` is used in two functions, which are separate scopes.
15. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." (section 8). Governs the `while` loops on lines 8 and 10 and the `for` loops over arrays on lines 4, 23 and 33.
16. `While = "while" Expression Block .` and `For = "for" ident "in" Expression Block .` (section 8). Governs the loop blocks on lines 4 to 6, 8 to 16, 23 to 29 and 33 to 34. The `for` variable must be an `ident`, which is why line 5 names the loop variable `x` and does not use `_`.
17. "`if` and `match` are expressions and may stand as statements" (section 8). Governs lines 11 and 24 to 29, which are `if` statements, one of them with `else if`.
18. "`if cond` / `else if` / `else` take only `bool`; there is no truthiness." (section 8). Governs the conditions on lines 11, 24 and 27. Line 11 is a `bool` comparison, line 24 reads the `bool` cell `first`, and line 27 is a `!=` comparison.
19. "`< <= > >=`: a number only" (section 7, comparison row). Governs the `<` comparisons on lines 8, 10 and 11, all on `i64` values.
20. "`!=` ... `==` is structural equality on any two values of one type" (section 7). Governs line 27, `x != prev`, which compares two `i64` values.
21. `Sum = Product { ( "+" | "-" ) Product } .` (section 7 grammar). Governs line 10, `n - 1 - i`, which is read as `(n - 1) - i`. With `i` below `n`, this bound is never negative inside the loop, and when `n` is 0 the loop does not run.
22. "A literal takes the type its context asks for ... otherwise `i64`." (section 2). Governs the literals `0`, `1`, `true` and `false`. The `0` on line 3 becomes `i64` because `n` is compared with `i`, and `i` takes `i64` from its literal. The `true` and `false` on lines 22 and 26 are `bool`.
23. "No implicit conversions, widths included" (section 3). Governs the arithmetic on lines 6, 9, 10, 16, 28: every operand is `i64`, so no conversion is needed.
24. "A container literal separates elements by newline across lines and by comma on one" (section 10). Governs the array literals on lines 33 and 35, which are on one line with commas.
25. "A function with a `->` must `return` on every path that reaches its end" (section 8). Governs line 17, `return ys`, and line 30, `return groups`. Each is the last statement of a function with a `->`, and no path reaches the end without it.
26. `Declaration = "function" ident [ Generics ] Params [ "->" Type ] Block .` and `Param = ident ":" Type [ "lent" ] .` (section 4). Governs the headers on lines 1, 19 and 32. All parameters are plain by-value parameters, with no `@` and no `lent`.
27. "the file you compile holds `function main()`, which takes nothing and produces nothing." (section 1). Governs line 32.
28. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (section 11). Governs lines 34 and 35: each `print` gets one `i64`, so each output is one number on its own line.

## choice_points

1. **Length of the input.** The specification lists `len` as a built-in but does not give its result type. I count the elements with a `for` loop (lines 3 to 6) instead of calling `xs.len()`. Other choice: `n @= xs.len()`. That would probably give an `i64` and the same output. If `len` returned another integer type, `i < n` would be a type error, since there are no implicit conversions, so the first try would fail.
2. **Sorting algorithm.** I used bubble sort: an outer `while i < n` and an inner `while j < n - 1 - i`. Other choice: a `for` over a `range`, or selection sort. Each gives the same descending order. The bound `n - 1 - i` only shrinks the inner pass, which is safe because the largest remaining element has already moved to the end.
3. **Swap.** Heroes has no tuples, so the swap uses a temporary `t` (line 12). Other choice: an insertion sort, which needs more index bookkeeping and gives the same output.
4. **Comparison for "out of order".** For descending order I swap when `ys[j] < ys[j + 1]`, which is strict. Other choice: `<=`. That would also swap equal neighbours. The output is the same, because equal `i64` values look the same, but it does extra work.
5. **Empty input to `runs`.** The `first` flag (lines 22, 24 to 26) makes `runs([])` return 0, since there are no groups. Other choice: read `xs[0]` first with an early `return 0` when the array is empty. That gives the same result but needs an explicit length check. Reading `xs[0]` without the check would abort on empty input, because an out-of-bounds index aborts.
6. **How `runs` counts groups.** A new group starts whenever an element differs from the one before it. The first element always starts a group, which the `first` flag handles. Other choice: count the changes between neighbours and add 1 at the end, which needs the same empty-input check. Using `fold`, which the specification names but does not give a signature for, was not chosen because its exact form is not stated.
7. **Loop variable in `sorted_desc`.** The counting loop does not need `x`, so line 5 discards it with `_ = x`. Other choice: a `while` loop with an index, which needs a length (see choice 1). The `_ = x` form is allowed by section 5, but it is an unusual idiom, which is why it is the least certain line (see confidence).
8. **Output format.** `print` is called once per element (line 34), so each number is on its own line with the built-in trailing newline. Other choice: build one string with `join` and `to_str`, then print it once. The output would be the same, but the program would need more conversions.
9. **Where `runs` is called.** `main` calls `runs` directly with the array from the task. Other choice: a `test` block with an `assert`. That was not chosen, because the task asks for `main` to print the value, and `test` blocks run only when asked for.
10. **Index type.** The specification gives indices from 0 but does not name the type of an index. I used `j @= 0`, which is `i64` by the literal rule, so the index is `i64`. Other choice: an index of another integer type, which would be a type error if the checker requires `i64` indices. The specification does not say which, so this is an assumption.

## confidence

I am about 85 percent sure the checker accepts this program on the first try.

The lines I am least sure of, most doubtful first:
1. **Line 5, `_ = x`.** Section 5 allows `_ = f(x)` as a deliberate discard, and `x` is an `i64`, so I expect it to be accepted. But the example in the specification is a call, not a bare name, and I could not confirm that a bare name is treated the same way.
2. **Lines 13 and 14, `ys[j] @ ys[j + 1]`.** The grammar allows a `Place` with `[ Expression ]`, and section 10 shows `m[k] @ v` for maps. The specification shows no example of an array element being re-bound, so I expect it to work but am not certain.
3. **Line 10, `n - 1 - i`.** Both operands are `i64` and the grammar makes `-` left-associative, so I expect it to be accepted.
4. **Index type on lines 8 to 14.** The specification does not state the type of an index. With `j` an `i64` by the literal rule, I expect it to be accepted.

Lines 17, 30, 32 and 35 use only the simplest forms, and I do not expect a problem there.

## context

Nothing other than this directory's files reached my context as file content. I read `brief.md`, `spec.md`, `run.json` and `run.err`, all in this directory. `run.json` and `run.err` are empty. I used no tool other than reading and writing files here, read no file outside this directory, and did not run anything.

Other things were in my context: harness environment details (working directory, platform, shell, date, model name and scratchpad path) and account and git metadata supplied by the harness. None of it was used in the program or in this report.
