# Report

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    while i < items.len()
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
        i = i + 1
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    while i < items.len()
        if items[i].name == name
            if items[i].qty < n
                return false
            items[i].qty = items[i].qty - n
            return true
        i = i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output, traced by hand from the program: `true`, `false`, `4`, each on its own line.

Line numbers used below count the fenced block from its first line, blank lines included. So L1 is `record Item`, L5 is `function restock`, L14 is `function take`, L25 is `function main()`, and L35 is `print(total)`.

## sentences

Each sentence is quoted from `spec.md` with its section and line. Where a spec line contains a dash, I quote only the part without it.

1. Section 1, lines 22-23: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs L25-L35, the entry point and its empty signature.
2. Section 1, lines 33-34: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line, and the `while` conditions at L7 and L16, which are written without parentheses.
3. Section 1, line 35: "Syntax is ASCII-only" (first clause of the sentence). Governs the whole program, which uses only ASCII.
4. Section 4, line 113: "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs the order of `record Item` (L1) and the functions, which are written in an order I chose.
5. Section 4, line 119: `"record" ident Fields`. Governs L1-L3.
6. Section 4, line 125: `Fields = INDENT { ident ":" Type NEWLINE } DEDENT .`. Governs L2-L3, the two fields of `Item`.
7. Section 3, table row, line 66: "`bool` | `true` / `false`". Governs the `-> bool` of `take` (L14), the `return false` and `return true` (L19, L21, L23), and the bool results printed at L30-L31.
8. Section 3, table row, line 67: "`str` | immutable UTF-8 string, indexed and measured in bytes". Governs the `str` type of `name` and of `Item.name` (L2, L5, L14). Equality on `str` is covered by sentence 20.
9. Section 3, table row, line 68: "`[T]` | dynamic array, indices from 0". Governs `items[i]` with `i` starting at 0 (L6, L15).
10. Section 3, table row, line 71: "`()` | nothing: what a function with no `->` returns". Governs `restock` (L5), `main` (L25), and the bare `return` at L10.
11. Section 2, line 45: "One `i64` is `0x1f` `0o37` `0b11111` or `31`, with `_` between any two digits." Governs the integer literals `0`, `1`, `2`, `3`, `4`, `5` and `9` (L6, L11, L15, L22, L27-L32, L34). Their type is `i64`, because no other type is asked for in context.
12. Section 2, line 44 (tail of a sentence): "otherwise `i64`." Governs the same literals as sentence 11, which are typed `i64` where no context asks for another type.
13. Section 5, lines 134-135: "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs `i @= 0` (L6, L15), `items: [Item] @= []` (L26) and `total @= 0` (L32), which are the mutable cells. It governs `i = i + 1` (L11, L22) and `total = total + item.qty` (L34), which are re-bindings of a cell. It governs `items[i].qty = ...` (L9, L20), which is a re-binding of a field inside one.
14. Section 5, lines 136-138: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." Governs every binding and parameter. `items` (L26) is re-bound by the `@` arguments at L27-L31. The `@items` parameters (L5, L14) are written at L9, L12 and L20. `total` (L32) is re-bound at L34. `i` is read at L7 and L16. `item` is read at L34.
15. Section 5, line 146: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs the reuse of `items`, `i`, `name` and `total` across functions. None of them is nested inside another binding of the same name, and the program has no `use`. My reading is that separate function scopes do not shadow each other. This is an interpretation, not a stated rule.
16. Section 5, line 156: `Place = ident { "." ident | "[" Expression "]" } .`. Governs L9 and L20, where `items[i].qty` is the assignment target.
17. Section 6 is not used. The program uses no `T?`.
18. Section 7, line 75: "No implicit conversions, widths included: `1 + 2.0` is an error." Governs every arithmetic and comparison operand, all `i64`: L9, L11, L18, L20, L22, L34.
19. Section 7, line 187: "`< <= > >=`: a number only" (within the comparison row of the operator table). Governs `i < items.len()` (L7, L16) and `items[i].qty < n` (L18).
20. Section 7, line 194: "`==` is structural equality on any two values of one type, recursively". Governs `items[i].name == name` (L8, L17).
21. Section 7, line 199: "Overflow aborts at every width." Governs the arithmetic at L9, L11, L20, L22, L34. The program does not overflow for these values.
22. Section 7, line 191 (precedence): "Precedence, strongest first: call, `.` and `::` → unary". Governs `items[i].qty + n` (L9) and `items[i].qty - n` (L20), where the postfix chain binds before `+` and `-`.
23. Section 8, lines 239-241: "A function with a `->` must `return` on every path that reaches its end, and `exit(code:)`, `assert false` and a `while true` with no `break` of its own end a path." Governs `take` (L14-L23). Its `return` statements at L19 and L21 end their paths, and the final `return false` at L23 covers the path that falls out of the loop.
24. Section 8, line 239: "A statement after a jump, in its block, is a compile error." Governs L10, L19 and L21, where each `return` is the last statement in its block. The `i = i + 1` at L11 and L22 sits in the enclosing `while` block, after an `if` that does not always leave, so it is not after a jump.
25. Section 8, line 248: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs the `while` loops (L7, L16) and the `for` loop over the array `items` (L33).
26. Section 9, line 258: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`". Governs `Item(name: name, qty: n)` (L12).
27. Section 9, line 268: "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `items.len()` (L7, L16) and `items.push(...)` (L12).
28. Section 9, line 271: "Mutable parameters are marked `@` in the signature and at the call site:". Governs the `@items` parameters in the signatures (L5, L14) and the `@items` arguments at every call (L27-L31).
29. Section 9, lines 273-276: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach". Governs the calls at L27-L31, each of which has exactly one `@` argument.
30. Section 10, line 297: "an empty one needs an annotation: `xs: [i64] := []`". Governs `items: [Item] @= []` (L26). I used `@=` rather than `:=` because the array is passed as an `@` argument.
31. Section 10, lines 307-309: "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs `items = items.push(...)` (L12). The receiver is the plain name `items`, so the push grows in place.
32. Section 10, line 313: "An out-of-bounds index or slice aborts". Governs `items[i]` at L8-L9 and L17-L20. Each index is taken only while `i < items.len()` holds (L7, L16).
33. Section 11, line 316: "Built-ins: `print(...)` · `len` · `push`". Governs `len` (via `items.len()`, L7, L16), `push` (L12) and `print` (L30, L31, L35).
34. Section 11, lines 323-325: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs L30, L31 and L35. Each call prints one value, and each output is on its own line.
35. Section 11, lines 326-327: "a `bool` prints `true` or `false`." Governs the two bool prints at L30 and L31.

## choice_points

1. **Loop shape for finding an item.** I used a `while` loop over an index `i @= 0`. The other choice was `for i in range(from: 0, to: items.len())` with a `return` inside. That would also be accepted, if `range` takes `i64` bounds, and it would print the same output. I chose `while` because `range`'s argument types are stated only indirectly.
2. **Early `return` in `restock`.** I return as soon as the name is found. The other choice was a `found @= false` flag and a final `if not found` append. That would compile with the same behaviour, but would use one more mutable cell.
3. **Append form.** I wrote `items = items.push(Item(...))`. The other choice was `push(items, Item(...))`. The spec describes both as the same operation, and the plain-name form grows in place (sentence 31).
4. **Updating a found item.** I wrote `items[i].qty = ...` directly. The other choice was to rebuild the array with a copied record, which the spec describes as copying the whole array and is slower. The direct form is what sentence 13 describes for a field inside a cell.
5. **Empty array declaration.** `items: [Item] @= []`. The other choice, `items: [Item] := []`, would be an error here, because `items` is passed as an `@` argument and an `:=` binding is never a mutable cell (sentence 13).
6. **Mutable cell or `:=` for `i` and `total`.** Both must be `@=` because they are re-bound. The other choice, `:=`, would be a compile error on the first `=`.
7. **Sum method.** I used a `for` loop with a `total` cell. The other choice, `fold` with a top-level function taking `acc` and `item`, is also valid, but the spec does not state its exact signature in a form I could check, so I did not use it.
8. **`len` written as `items.len()` (UFCS) or `len(items)`.** I used UFCS, which sentence 27 defines. The other form should be accepted too, and gives the same type.
9. **Named arguments at the call sites.** I wrote the arguments by position: `restock(@items, "apple", 3)`. The other choice is `restock(@items, name: "apple", n: 3)`. Names are required only where two parameters share a type (section 9), and no two non-`@` parameters here share one, so both forms are accepted and give the same result.
10. **Binding the result of `take` before printing.** I nested the call inside `print`. The other choice is `ok_apple := take(@items, "apple", 5)` and then `print(ok_apple)`. Both are valid; I did not split it because the nested `@` argument is an ordinary expression by the grammar.
11. **Comments.** I put none in the program. The other choice would add `#` comments (section 1), which the checker accepts and which change nothing.
12. **Integer type of `i`, `total` and the literals.** I left them to the default `i64` (sentence 12). The other choice, an explicit `i: i64 @= 0`, would also be accepted. A narrower type such as `i32` would be a mixed-width error against `items.len()` and `Item.qty`.
13. **Blank lines between declarations.** I used one blank line. The grammar does not require one, and the other choice is none.

## confidence

I am about 85% sure the checker accepts the program on the first try, and that it prints `true`, `false`, `4`.

The least sure line is L7 and L16, `while i < items.len()`. The spec does not state the return type of the built-in `len`. I assumed `i64`, so that it matches the `i64` cell `i`. If `len` returns another integer type, the comparison is a mixed-width error under section 7 (sentence 18). This is the one point I could not settle from the spec.

The next least sure line is L12, `items = items.push(Item(name: name, qty: n))`. I am fairly sure the `@` parameter can be re-bound this way, since sentence 31 covers a plain name, but the spec does not say explicitly how `push` behaves on an `@` parameter.

The lines I am most sure of are L1-L3 (record declaration), L9 and L20 (field assignment through an index, sentence 16), and L14-L23 (the `->` path rules, sentence 23).

## context

Only the files in this directory reached my context: `brief.md`, `spec.md`, and two files, `run.json` and `run.err`, which are both empty. I read all four. I used only `brief.md` and `spec.md` as inputs. The empty files had no content for me to use.

I did not read any file outside this directory, and I used no tool except reading and writing files here. I did not run the program or any checker, since I was not able to.

My session environment information (the working directory path, platform, git status, and similar context) was present in my context. It is not part of the program's inputs and did not affect the program's design.
