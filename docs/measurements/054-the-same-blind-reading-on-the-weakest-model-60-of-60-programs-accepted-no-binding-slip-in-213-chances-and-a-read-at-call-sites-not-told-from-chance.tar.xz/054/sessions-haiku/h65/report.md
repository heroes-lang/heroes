# program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n = len(ys)
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if ys[j] < ys[j + 1]
                a = ys[j]
                b = ys[j + 1]
                ys[j] @ b
                ys[j + 1] @ a
            j @ j + 1
        i @ i + 1
    return ys

function runs(xs: [i64]) -> i64
    count @= 0
    started @= false
    prev @= 0
    for x in xs
        if !started
            count @ 1
            started @ true
        else if x != prev
            count @ count + 1
        prev @ x
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output: `9 6 5 4 3 2 1 1` on separate lines, then `4`.

# sentences

Each quote is from `spec.md`. Where a quoted sentence contains a dash in the original, the dash is left out and the quote is split at that point.

1. Layout (Section 1): "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line, in both functions and in `main`.
2. Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()`.
3. Section 1: "Outside brackets a line ends its statement." Governs every single-line statement; no line continues another.
4. Section 4: "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs the order of the three functions, which is `sorted_desc`, `runs`, `main`.
5. Section 5: "`=` binds once, forever." Governs `a = ys[j]`, `b = ys[j + 1]`, `n = len(ys)`, and the `for x in ...` loop variables.
6. Section 5: "`@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs `ys @= xs`, `i @= 0`, `j @= 0`, `count @= 0`, `started @= false`, `prev @= 0` (declarations), and `ys[j] @ b`, `ys[j + 1] @ a`, `j @ j + 1`, `i @ i + 1`, `count @ 1`, `count @ count + 1`, `started @ true`, `prev @ x` (re-bindings).
7. Section 5: "All bindings are initialised." Governs every declaration line; each has an initial value.
8. Section 5: "An unused binding or parameter is a compile error, and so is a cell nothing re-binds." Governs `xs`, `n`, `i`, `j`, `a`, `b`, `ys`, `count`, `started`, `prev`, `x`: each is read somewhere, and each cell is re-bound (`ys` and `prev` through element/plain re-binding, `count`, `started`, `i`, `j`).
9. Section 5: "Signatures are always explicit; inference is local only." Governs the headers `sorted_desc(xs: [i64]) -> [i64]`, `runs(xs: [i64]) -> i64`, `function main()`.
10. Section 5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." The program has no `use`, so this does not apply. The name `x` appears in both `runs` and `main`, and each use sits in its own function.
11. Section 2: "A literal takes the type its context asks for" and "otherwise `i64`." Governs the literals `0`, `1`, `2`, `5`, `3`, `4`, `6`, `9`, `7` and the list elements: `i @= 0` and `count @= 0` take `i64`, and the list literals take `[i64]` from their parameter.
12. Section 3 (table): "`[T]` | dynamic array, indices from 0". Governs `ys[j]`, `ys[j + 1]`, and the zero-based walk in `sorted_desc`.
13. Section 3: "No implicit conversions, widths included: `1 + 2.0` is an error." Governs `n - 1 - i`, `i < n`, `j < n - 1 - i`, `x != prev`, `count + 1`: all operands are `i64`, given that `len` returns `i64` (see choice points).
14. Section 7 (table): "`< <= > >=`: a number only" and "`bool` only" for `!`. Governs `ys[j] < ys[j + 1]`, `i < n`, `j < n - 1 - i` (comparisons), and `!started`.
15. Section 7 (precedence): "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -`" followed by "`<<` `>>`" ... "comparisons". Governs `n - 1 - i` (left-associative subtraction, grouped as `(n - 1) - i`), `ys[j + 1]`, `count + 1`, and the `!started` unary.
16. Section 8: "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness." Governs `if ys[j] < ys[j + 1]`, `if !started`, `else if x != prev`. Each condition is a `bool`.
17. Section 8: "`if` and `match` are expressions and may stand as statements." Governs the `if` blocks inside both loops.
18. Section 8: "`while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs the two `while` loops in `sorted_desc`, and the `for x in xs` loops in `runs` and `main`.
19. Section 8: "A function with a `->` must `return` on every path that reaches its end." Governs `return ys` (end of `sorted_desc`) and `return count` (end of `runs`). No path reaches the end without a `return`.
20. Section 8: "A statement after a jump, in its block, is a compile error." No statement follows a `return` in any block.
21. Section 10: "A container literal separates elements by newline across lines and by comma on one" Governs `[3, 1, 4, 1, 5, 9, 2, 6]` and `[1, 1, 2, 2, 2, 3, 1]`, written on one line with commas.
22. Section 11: "Built-ins: `print(...)` · `len` · `push`" (the list gives `len` with no stated result type). Governs `n = len(ys)`.
23. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs `print(x)` in `main` (one `i64` per line) and `print(runs(...))` (prints `4`).
24. Section 5: "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`." Governs the calls to `print`, which return `()`, and the `for` loop over `sorted_desc(...)`, whose value is used by the loop.
25. Section 3: "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs `ys @= xs`: `xs` is not changed by the bubble sort.

# choice_points

1. `len` result type. The spec lists `len` as a built-in and never gives its result type. I took `i64`, so that `n` can be compared with `i` and combined with `1` and `i` without conversion. The other choice (an unsigned width such as `u64`, which the spec uses for `repeat`'s count) would make `i < n`, `n - 1 - i`, and `n = len(ys)` into "no implicit conversions" errors, and the checker would refuse the program.
2. Swap temporaries. I used two immutable bindings `a` and `b` inside the swap branch, which re-run on each loop iteration. The other choice, mutable cells `tmp @= ys[j]`, would be refused because a cell nothing re-binds is a compile error. A third choice, binding once outside the loops, is not possible because the values change. The `=` binding is also read as a fresh binding per block entry; if the checker read "binds once, forever" as once per function call, these two lines would be refused and the swap would need cells.
3. Inner bound of the bubble sort. I used `j < n - 1 - i`, which stops each pass earlier as the largest remaining elements settle. The other choice, `j < n - 1` on every pass, produces the same output; it does more comparisons and never reads outside the array, since `j + 1 <= n - 1`.
4. Shape of `runs`. I streamed with `for x in xs` and a `started` flag plus a `prev` cell, so it needs no `len` and no index. The other choice, an index loop `i` from 1 to `len(xs)` comparing `xs[i]` with `xs[i - 1]`, produces the same results but depends on choice point 1 and on the index type.
5. Empty input in `runs`. `runs([])` returns `0`, since no groups exist and `count` starts at `0`. The other choice, starting at `1` or returning `1` for an empty list, would give the wrong answer for an empty list. The program never calls `runs` on an empty list, so this does not change the output.
6. The first element in `runs`. I handle it with the `started` flag instead of comparing it with a sentinel such as `prev @= -1`. A sentinel would fail for inputs that contain the sentinel value. The flag works for any `i64`.
7. Sorting direction. "Largest to smallest" is done by swapping when `ys[j] < ys[j + 1]`. The other choice, swapping when `ys[j] > ys[j + 1]`, would give ascending order, which is the wrong result.
8. Where the call result goes. In `main`, I looped over `sorted_desc(...)` directly and printed `runs(...)` inline. The other choice, binding each to a name first (`r = runs(...)`), is equally valid and changes nothing in the output.
9. Use of `for x` in `main` and `runs`. Each `x` is in a different function and each `for` is not nested in another binding named `x`. The other choice, a different name, is equally valid.
10. Declaration order. I placed `sorted_desc` and `runs` before `main`. The spec says order does not matter, so the other order is equally valid.

Output effect: none of the choices above change the printed output. Choices 1 and 2 affect whether the checker accepts the program; choice 1 is the largest risk.

# confidence

I am about 75 percent sure the checker accepts the program as written.

The least certain line is `n = len(ys)` (in `sorted_desc`). The spec does not give `len`'s result type, and the comparisons `i < n` and `j < n - 1 - i` depend on it being `i64`. The line `i @= 0` and the comparison `while i < n` next to it are equally tied to that assumption.

The swap lines `a = ys[j]` and `b = ys[j + 1]` inside a loop are the second-least certain, because they depend on `=` being read as a fresh binding each time the block runs (choice point 2).

Every other line follows a sentence I can quote directly from the spec. The output is correct for the given inputs: `9 6 5 4 3 2 1 1` and `4`.

# context

Only the files in this directory were read: `brief.md` (read in full), `spec.md` (read in full), and `run.json` and `run.err`, which are both empty. I did not open any file outside this directory and used no other tool than reading and writing files here.

Two items of system-supplied material also reached my context and are not files I read: the working directory and platform details, and a git status snapshot listing `run.err` and `run.json` as untracked. Neither contains any part of the language specification or any other content for the program. The git status snapshot also includes the user's account email, which I did not use or write into this report.
