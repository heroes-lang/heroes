## program

```
# A record of one item: its name and how many are held.
record Item
    name: str
    qty: i64

# Adds n to the qty of the item called name, or appends a new item when none has that name.
function restock(@items: [Item], name: str, n: i64)
    rebuilt: [Item] @= []
    seen @= false
    for row in items
        if row.name == name
            rebuilt @ rebuilt.push(Item(name: row.name, qty: row.qty + n))
            seen @ true
        else
            rebuilt @ rebuilt.push(row)
    if !seen
        rebuilt @ rebuilt.push(Item(name: name, qty: n))
    items @ rebuilt

# Subtracts n from the qty of the item called name when it holds at least n; changes nothing otherwise.
function take(@items: [Item], name: str, n: i64) -> bool
    enough @= false
    for probe in items
        if probe.name == name && probe.qty >= n
            enough @ true
    if !enough
        return false
    rebuilt: [Item] @= []
    for row in items
        if row.name == name
            rebuilt @ rebuilt.push(Item(name: row.name, qty: row.qty - n))
        else
            rebuilt @ rebuilt.push(row)
    items @ rebuilt
    return true

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    took_apple = take(@items, "apple", 5)
    print(took_apple)
    took_pear = take(@items, "pear", 9)
    print(took_pear)
    total @= 0
    for row in items
        total @ total + row.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple is 7 after the restocks, taking 5 leaves 2; pear is 2, so taking 9 fails; the sum is 2 + 2).

## sentences

Each sentence is quoted from `spec.md`, with the program lines it governs.

1. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`, and a variant's case `.num(v: 7)` or `.plus`." Governs every `Item(name: ..., qty: ...)` line in `restock` and `take`, and the `Item(...)` pushes in `restock`.
2. "Mutable parameters are marked `@` in the signature and at the call site" Governs the signatures `restock(@items: [Item], ...)` and `take(@items: [Item], ...)`, and the calls `restock(@items, ...)` and `take(@items, ...)` in `main`.
3. "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach," Governs each call in `main`, each of which has exactly one `@` argument.
4. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs the `=` bindings (`took_apple`, `took_pear`) and every `@=` and `@` line (`rebuilt`, `seen`, `enough`, `total`, `items @ rebuilt`).
5. "Signatures are always explicit; inference is local only." Governs every `function` line, including `-> bool` on `take` and no return type on `restock` and `main`.
6. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting;" Governs `items` in `main` (re-bound by each `@` argument), the `@` parameter `items` in `restock` and `take` (written by `items @ rebuilt`), and the cells `seen`, `enough`, `total` (each re-bound and read).
7. "and an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`." Governs `items: [Item] @= []` in `main` and `rebuilt: [Item] @= []` in `restock` and `take`.
8. "`xs @ xs.push(4)` grows in place when `xs` is a plain name" Governs `rebuilt @ rebuilt.push(...)` and the write-backs `items @ rebuilt`, where the target is a plain name.
9. "Built-ins: `print(...)` · `len` · `push`" Governs every `rebuilt.push(...)` line (`push` is a built-in, called through `.`).
10. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `rebuilt.push(row)` and the other `.push` calls, which mean `push(rebuilt, ...)`.
11. "Loops: `while cond` and `for x in xs`, over an array or a `range`" Governs the `for row in items` loops in `restock`, `take`, and `main`, and `for probe in items` in `take`.
12. "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs the copies `row` in each loop and the `rebuilt` array built from them, which is written back into `items` only at the end.
13. "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness." Governs `if row.name == name`, `if probe.name == name && probe.qty >= n`, `if !seen`, `if !enough`, and the `else` arms. Every condition is a `bool`.
14. "(bool only; && and || short-circuit)" from the boolean row of the operator table. Governs `probe.name == name && probe.qty >= n` (both sides are `bool`), and `!seen` and `!enough` (`!` on a `bool`).
15. "`==` is structural equality on any two values of one type, recursively;" Governs `row.name == name` and `probe.name == name`, which compare `str` with `str`.
16. "(`< <= > >=`: a number only)" from the comparison row of the operator table. Governs `probe.qty >= n`, which compares two `i64` values.
17. "A literal takes the type its context asks for" and "otherwise `i64`." Governs `0` in `total @= 0`, `3`, `2`, `4`, `5`, `9` in `main`, which are all `i64` as the parameters require.
18. "A function with a `->` must `return` on every path that reaches its end," Governs `take`, whose `return false` (inside `if !enough`) and final `return true` cover every path.
19. "A statement after a jump, in its block, is a compile error." Governs the `if !enough` block and the `if row.name == name` / `else` blocks: each jump is the last statement of its block.
20. "`if` and `match` are expressions and may stand as statements;" Governs every `if` and `if ... else` used as a statement inside the loops and in the function bodies.
21. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs `print(took_apple)`, `print(took_pear)` (bool) and `print(total)` (i64).
22. "a `bool` prints `true` or `false`." Governs `print(took_apple)` and `print(took_pear)`, which print `true` and `false`.
23. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs the layout of the whole file (4 spaces per level, no tabs).
24. "No braces, no semicolons; a condition needs no parentheses." Governs every `if`, `for`, and `function` line, none of which uses braces, semicolons, or parentheses around the condition.
25. "Syntax is ASCII-only;" Governs the whole file: all identifiers, operators, and strings are ASCII. The comments are ASCII too.
26. "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it;" Governs the three `#` comment lines above `record Item`, `restock`, and `take`.
27. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs the loop variables `row` and `probe` and the parameter `name`. The sentence is worded for `use` names, so the distinct loop names are a precaution, not a rule the program depends on.
28. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs the record `Item`, which is placed before the functions that use it. The program does not depend on this order; it is a precaution.

The program uses no `T?`, `match`, `_`, `test`, `extern`, `use`, `?`, or generics, so no sentence about those governs a line.

## choice_points

1. **Array rebuild versus index loop.** I rebuild a new array (`rebuilt`) and write it back to `items`, instead of walking indices with `while k < len(items)` and writing `items[k].qty @ ...`.
   - Other choice: an index loop. The spec does not state what type `len` returns. `k @= 0` is `i64`, so `k < len(items)` is only accepted if `len` returns `i64`. If `len` returns another integer type, the checker rejects it, since there are no implicit conversions. The rebuild avoids `len` and indices altogether. Output is the same either way.
2. **`take` as two passes (check, then rebuild) versus one early-return loop.** I first set `enough`, return `false` if it is not set, and only then rebuild.
   - Other choice: `for row in items` with `if row.name == name && row.qty >= n` followed by `return true` inside the loop, then `return false` after it. The output is the same. It avoids the `enough` cell, but it needs a second write path into `items` inside the loop, which is less obviously correct under the copy rules. Both are accepted by my reading.
3. **Append inside `restock` through `rebuilt` versus direct `items @ items.push(...)`.** I push the new item onto `rebuilt` after the loop when `seen` is still `false`.
   - Other choice: `items @ items.push(Item(name: name, qty: n))` when `!seen`. That is simpler and also valid under the spec's `xs @ xs.push(4)` example. Output is the same.
4. **Positional arguments versus named arguments at the call site.** I write `restock(@items, "apple", 3)` and `take(@items, "apple", 5)` positionally.
   - Other choice: `restock(@items, name: "apple", n: 3)`. The spec makes names mandatory only when two parameters share a type. Here `name: str` and `n: i64` differ, so both forms are accepted. Output is the same.
5. **Printing `bool` directly versus through an `if`.** I call `print(took_apple)`, which prints `true` or `false` as the spec says.
   - Other choice: `if took_apple` with `print("true")` and `print("false")` in each branch. Output is the same. The direct form is shorter and depends only on the `print` rule for `bool`.
6. **Loop variable names.** I use `row` in two sibling loops and `probe` in one loop in `take`, and `row` again in `main`.
   - Other choice: one name everywhere. The spec's shadowing sentence is worded for `use` names, so reusing `row` across sibling loops is probably fine, but I used distinct names within each function to avoid relying on that reading.
7. **Integer type of `total` and of the literals.** Literals take `i64` because no context asks for another type. `total @= 0` is `i64`, which matches `row.qty`.
   - Other choice: an annotated type such as `total: i64 @= 0`. Same result.
8. **Flag `seen` versus a helper that returns a match.** I used a flag set inside the loop. Other choice: a helper returning the matching index, which would need an index type or a `T?` I did not want to depend on. Output is the same.

## confidence

About 90% that the checker accepts the program as written.

Least certain line: `items @ rebuilt`, the write-back of the `@` parameter `items` at the end of `restock` and before `return true` in `take`. The spec says an `@` parameter must be written or ended, and that `@` re-binds a cell, but it does not spell out a whole-array re-binding of an `@` parameter that was read by a `for` loop earlier in the same function. I expect it is accepted, since the loop has ended before the write, but I cannot verify it.

Next least certain: `rebuilt: [Item] @= []`, the annotated empty array of a record type. The spec's example is `[i64]`, so `[Item]` follows the same rule, but this is an inference from the example.

## context

Only the files in this directory reached my context: `brief.md` and `spec.md` (both read in full), and `run.json` and `run.err`, both of which are empty. The brief's instruction to read files in this directory and use no other tool was followed; I ran no commands and read no other file.

The session also supplied some background to my context: the working directory path, the platform and shell, a git status snapshot listing `run.err` and `run.json` as untracked files, the user's email address, and the model and date information. I did not use any of it in the program or in this report.
