# Report: main.hero

## verdict

Refused, on lines 20 and 22.

- Line 20, `step = 2`: `step` is bound by `$=` on line 10. A `$=` name binds once and cannot be re-bound. `=` re-binds only a `@=` cell, or a field or element inside one.
- Line 22, `last @= words[0]`: `last` is a cell that nothing re-binds. Its only later mention is `print(last)` on line 25, which is a read, and a read is not a re-binding. The spec makes a cell nothing re-binds a compile error.

I found no other refusal. Everything else (the `@c` parameter and its writes, `counts[w] = ...`, `total = total + step`, `counts["a"].default(0)`, the `bump(@c, ...)` calls, the `for` loop) is accepted as written.

As written, the program is not accepted, so it prints nothing. The smallest accepted change that keeps the evident meaning (`step` goes from 1 to 2, `last` is the first word) is in `program` below. That version prints:

```
5
5
a
```

## lines

| line | new name / changes an existing name / neither | words of the specification relied on |
|---|---|---|
| 5 | *new name* (the parameter `c`) | "Mutable parameters are marked `@` in the signature and at the call site"; the grammar `Param = "@" ident ":" Type` |
| 6 | *changes an existing name* (`c.hits`, a field inside the `@` parameter `c`) | "`=` re-binds it, or a field or element inside one." |
| 9 | *new name* (`words`) | "`$=` binds once, forever." |
| 10 | *new name* (`step`) | "`$=` binds once, forever." |
| 11 | *new name* (`counts`) | "`@=` declares a mutable cell, and `=` re-binds it" |
| 12 | *new name* (`total`) | "`@=` declares a mutable cell, and `=` re-binds it" |
| 15 | *changes an existing name* (an element of `counts`, `counts[w]`) | "`=` re-binds it, or a field or element inside one."; `m[k] = v` inserts or replaces |
| 16 | *changes an existing name* (`total`, a cell) | "`=` re-binds it, or a field or element inside one." |
| 18 | *new name* (`c`) | "`@=` declares a mutable cell, and `=` re-binds it" |
| 19 | *neither* (`@` at the call site only marks `c`; the write happens in line 6) | "Mutable parameters are marked `@` in the signature and at the call site"; "Either way the callee works on the caller's place itself" |
| 20 | *changes an existing name* (attempted on `step`, which is a `$=` name, so refused) | "`$=` binds once, forever." together with "`=` re-binds it" applying only to a `@=` cell |
| 21 | *neither* (same reasoning as line 19) | same as line 19 |
| 22 | *new name* (`last`) | "`@=` declares a mutable cell, and `=` re-binds it"; and, for the refusal, "a cell nothing re-binds ... is a compile error" |

Note: on line 19 and line 21 the line alone shows only the mark, not the write. The write is visible only in line 6, through the `@` parameter.

## sentences

From section 5 (Bindings):

- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."

From section 9 (Functions and calls):

- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy: `function peek(l: Lex lent)` … `peek(l)`. Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."

From section 2 (Literals):

- "A literal takes the type its context asks for [...] otherwise `i64`."

From section 6 (Failure), table row:

- "`.default(v)` | extract or fall back"

From section 10 (Strings, arrays, maps):

- "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"

From section 1 (Files and layout):

- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."

From section 8 (Control flow):

- "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)."

From section 11 (Built-ins):

- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

Changes from `main.hero`: line 10 `step $= 1` becomes `step @= 1`, and line 22 `last @= words[0]` becomes `last $= words[0]`.

Output of this program, worked by hand:

- `counts["a"]` is 3 after the loop (`a` occurs three times, each adding `step` = 1), so `total` is 5.
- `bump(@c, 3)` sets `c.hits` to 3. `step` becomes 2, and `bump(@c, 2)` sets `c.hits` to 5.
- `last` is `"a"`.

So it prints `5`, `5`, `a`, one per line.

## choice_points

1. **How to make `step` change (line 10 and line 20).** I chose `step @= 1`, so that the re-binding on line 20 is legal and `step` reaches 2 as the program evidently intends. Other choices:
   - Keep `step $= 1` and rename the new value: `step2 $= 2` on line 20 and `bump(@c, step2)` on line 21. Output is unchanged: `5`, `5`, `a`.
   - Keep `step $= 1` and delete line 20. Then `bump(@c, step)` adds 1, `c.hits` is 4, and the output is `4`, `5`, `a`. This drops the evident intent that `step` becomes 2, so I rejected it.
2. **How to fix `last` (line 22).** I chose `last $= words[0]`, a plain binding, because the program never re-binds `last`. Other choice: keep `@=` and add a re-binding such as `last = words[4]`. Output is unchanged (`a`), but that adds code the author did not write, so I rejected it.
3. **Classification of the `@` parameter on line 5.** I classed the parameter `c` as *new name*, since it brings `c` into the function's scope. The other reading is *neither*, since a parameter is not a binding statement. I chose *new name*.
4. **Classification of the `@` at call sites (lines 19 and 21).** I classed these as *neither*, because the line itself only marks the argument and the write is in `bump` (line 6). The other reading, *changes an existing name*, would apply because `c` does change. I chose *neither* as the line-local reading.
5. **Whether `@c` on lines 19 and 21 counts as re-binding `c`.** The spec says "an `@` argument counting" in the cell rule, so I treated it as a re-binding. If it did not count, `c` on line 18 would be a cell nothing re-binds, and the program would be refused on line 18 as well. I did not take that reading.
6. **Whether `counts[w] = ...` counts as re-binding `counts`.** The spec says `=` re-binds "a field or element inside one", so I treated it as a re-binding. This does not change the verdict.

## confidence

- **High** that the program is refused, and that it is refused on lines 20 and 22 (not on other lines).
- **High** that the corrected program is accepted and prints `5`, `5`, `a`, subject to the caveats below.
- **Least sure of:**
  - Whether the file has tab characters or invisible bytes. I read it through a viewer that shows spaces; I cannot check the bytes. A tab anywhere would be a compile error.
  - Whether the `@` argument counting as a re-binding of `c` is the intended reading (choice 5).
  - The classification of lines 5, 19 and 21 (choices 3 and 4), which depends on how the brief's "new name" and "changes an existing name" are read.
- I did not run anything. The verdict and the output are reasoned from the spec and the file text, not from the checker.

## context

Only this directory's files were read: `brief.md`, `spec.md`, `main.hero`, `run.json` and `run.err`. `run.json` and `run.err` are empty, and I did not use their contents. No other file or tool was used.

Other material in my context: the session's environment block (working directory, platform, shell, date, model information), a git status snapshot listing `run.err` and `run.json` as untracked, and the account metadata attached to the session. None of it came from outside this directory's files, and none of it bears on the verdict.
