## verdict

Refused, on two lines:

- **Line 20** (`step @ 2`): re-binds `step`, which was bound with `=` on line 10. An `=` binding can never be re-bound.
- **Line 22** (`last @= words[0]`): declares a mutable cell that nothing ever re-binds.

Smallest change that makes it accepted, keeping its evident meaning:

- Line 10: `step = 1` becomes `step @= 1`, so that the `@` on line 20 has a cell to re-bind.
- Line 22: `last @= words[0]` becomes `last = words[0]`, since it is never written again.

The fixed program is accepted and prints:

```
5
5
a
```

Hand trace of the fixed program: the loop gives `total` = 5 and `counts["a"]` = 3. `bump(@c, 3)` sets `c.hits` to 3. `step` becomes 2, and `bump(@c, 2)` sets `c.hits` to 5. So `print(c.hits)` gives 5, `print(total)` gives 5, and `print(last)` gives `a`.

## lines

| Line | Kind | Words of the specification relied on |
|---|---|---|
| 5 | *new name* (parameter `c` of `bump`) | "Mutable parameters are marked `@` in the signature and at the call site"; `Param = "@" ident ":" Type` |
| 6 | *changes an existing name* (`c.hits`) | "`@` re-binds it, or a field or element inside one."; "the callee works on the caller's place itself" |
| 9 | *new name* (`words`) | "`=` binds once, forever."; "`x = 5` # immutable binding" |
| 10 | *new name* (`step`) | "`=` binds once, forever." |
| 11 | *new name* (`counts`) | "`@=` declares a mutable cell"; `m: {str: i64} @= {}` |
| 12 | *new name* (`total`) | "`@=` declares a mutable cell" |
| 15 | *changes an existing name* (`counts[w]`) | "`@` re-binds it, or a field or element inside one." |
| 16 | *changes an existing name* (`total`) | "`@` re-binds it" |
| 18 | *new name* (`c`) | "`@=` declares a mutable cell" |
| 19 | *changes an existing name* (`c`, through the `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site" |
| 20 | *changes an existing name* (`step`), refused | "`=` binds once, forever."; "`@=` declares a mutable cell, and `@` re-binds it" (so `@` needs a cell) |
| 21 | *changes an existing name* (`c`, through the `@` argument) | as line 19 |
| 22 | *new name* (`last`), refused as written | "`@=` declares a mutable cell"; "a cell nothing re-binds ... is a compile error" |

## sentences

From section 5 (Bindings):

- "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it."

From section 9 (Functions and calls):

- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy"
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."

From section 11 (Built-ins):

- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

From section 2 (Literals):

- "A literal takes the type its context asks for ... otherwise `i64`."

From section 1 (Files and layout):

- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."

From section 4 (Top-level declarations):

- "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a`, one per line.

## choice_points

1. **Fixing line 20.** I made `step` a cell (`step @= 1` on line 10), so that the re-binding on line 20 is legal. The other choice is to delete line 20 and write `bump(@c, 2)` on line 21 (or to make line 21 read `2`). That also prints `5`, `5`, `a`, but it removes the step change from the program, so the program no longer shows the intent of changing `step` between the two calls. I preferred keeping the program's shape.
2. **Fixing line 22.** I changed `@=` to `=`, because the cell is never written again. The other choice is to keep a cell and add a re-binding (for example `last @ words[1]` after the loop). That would change the program's behaviour and print something other than `a` unless the new value is the same as the old, so I did not take it.
3. **Line 5 classification.** I counted the parameter `c` as *new name*, since the signature brings it into existence in `bump`. The other reading treats `@` on a parameter as a marker that changes nothing, so the line would be *neither*. The specification does not settle this.
4. **Call-site `@` (lines 19 and 21).** I counted `bump(@c, ...)` as *changes an existing name*, because "the callee works on the caller's place itself". The other reading would call it *neither*, since the line contains no `=`, but the specification says the callee writes the caller's place, so I did not take it.
5. **Whether an `@` argument re-binds `c` (line 18).** I followed the sentence "an `@` argument counting", so `c` is re-bound by `bump(@c, ...)` and is not refused as a cell nothing re-binds. The other reading would refuse line 18 as well, but the specification names the `@` argument case explicitly, so I did not take it.
6. **Classification of line 20.** The line is refused, so I categorised it by what it tries to do: change `step`, which is an existing name. The other reading would be *neither*, since the line fails rather than changing anything. This only affects the table, not the verdict.

## confidence

High on the verdict: lines 20 and 22 are refused, and the fixed program prints `5`, `5`, `a`. The hand trace is simple and the checks rest on explicit sentences of section 5. I have not run anything, so this is reasoning from the specification only.

Least sure of: the line 5 and call-site (lines 19 and 21) classifications, because the specification does not use the words *new name*, *changes an existing name* or *neither* for parameters or for call-site `@`. The verdict does not depend on them.

## context

Only the three files in this directory were read: `brief.md`, `spec.md` and `main.hero`. Nothing else was read, and no tool was used beyond reading and writing files here. The session's environment details (working directory, platform, git status, the user's account context) were present in my context but are not used in this report.
