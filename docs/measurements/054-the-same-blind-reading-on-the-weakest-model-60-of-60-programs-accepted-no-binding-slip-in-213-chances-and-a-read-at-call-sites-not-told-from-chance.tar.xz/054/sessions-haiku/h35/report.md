# program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n = len(xs)
    p @= 0
    while p < n
        j @= 0
        while j < n - 1 - p
            if ys[j] < ys[j + 1]
                a = ys[j]
                ys[j] @ ys[j + 1]
                ys[j + 1] @ a
            j @ j + 1
        p @ p + 1
    return ys

function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    i @= 1
    while i < len(xs)
        if xs[i] != xs[i - 1]
            count @ count + 1
        i @ i + 1
    return count

function main()
    ys = sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
    for y in ys
        print(y)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers used below: 1 `function sorted_desc`, 2 `ys @= xs`, 3 `n = len(xs)`, 4 `p @= 0`, 5 `while p < n`, 6 `j @= 0`, 7 `while j < n - 1 - p`, 8 `if ys[j] < ys[j + 1]`, 9 `a = ys[j]`, 10 `ys[j] @ ys[j + 1]`, 11 `ys[j + 1] @ a`, 12 `j @ j + 1`, 13 `p @ p + 1`, 14 `return ys`, 16 `function runs`, 17 `if len(xs) == 0`, 18 `return 0`, 19 `count @= 1`, 20 `i @= 1`, 21 `while i < len(xs)`, 22 `if xs[i] != xs[i - 1]`, 23 `count @ count + 1`, 24 `i @ i + 1`, 25 `return count`, 27 `function main()`, 28 `ys = sorted_desc(...)`, 29 `for y in ys`, 30 `print(y)`, 31 `print(runs(...))`.

# sentences

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 27 (`main` takes nothing, produces nothing, and no `->`).
2. "Signatures are always explicit; inference is local only." Governs lines 1, 16, 27 (all signatures are written out; `-> [i64]`, `-> i64`).
3. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every line. Conditions on lines 5, 7, 8, 17, 21, 22 have no parentheses.
4. "Outside brackets a line ends its statement: it may not end where the statement cannot, and the next line may not go on with it" Governs every line. Each statement is one line, and no line continues another.
5. "Syntax is ASCII-only" Governs the whole file. Every character is ASCII.
6. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs lines 2, 4, 6, 19, 20 (`@=` cells), 3, 9, 28 (`=` bindings), 10, 11 (element re-binding with `@`), 12, 13, 23, 24 (`@` re-binding of a cell).
7. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds" Governs lines 2 (`ys` re-bound on 10), 4 (`p` on 13), 6 (`j` on 12), 19 (`count` on 23), 20 (`i` on 24). Every binding is read: `n` on 7 and 5, `a` on 10 and 11, `count` on 25, `ys` on 14, 28-30, `xs` on 2, 3, 17, 21, 22.
8. "Shadowing is a compile error" Governs the whole program: no name is bound twice in one scope (`ys` in `sorted_desc` and `main` are in different functions; `y` and `a` are bound once).
9. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs lines 28 and 31, which call `sorted_desc` and `runs`, defined above `main`.
10. "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs line 2 (`ys` is a copy of `xs`, so `xs` is not changed) and line 28 (`ys` in `main` is an independent value).
11. "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `0` (17), `1` (19, 20), `0` (4, 6), `1` (12, 13, 23, 24) and `[3, 1, 4, 1, 5, 9, 2, 6]` and `[1, 1, 2, 2, 2, 3, 1]` (28, 31), which are `i64` by the parameter type.
12. "Built-ins: ... `len` ..." and "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs `len` on lines 3, 17, 21, and `print` on lines 30, 31. Each `print` writes one `i64` and one newline, so each element is on its own line.
13. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 5, 7, 21 (`while`) and 29 (`for y in ys`).
14. "`[T]` | dynamic array, indices from 0" (the type table, section 3). Governs the indices `ys[j]`, `ys[j + 1]` (8-11) and `xs[i]`, `xs[i - 1]` (22). Indices start at 0, and `i - 1` is at least 0 because `i` starts at 1.
15. "An out-of-bounds index or slice aborts" Governs lines 8-11 and 22. In the inner loop `j + 1` is at most `n - 1` because `j < n - 1 - p`. In `runs` `i` stays in `[1, len(xs) - 1]`.
16. "Overflow aborts at every width." Governs lines 7 and 13 (`n - 1 - p`, `p + 1`). With the given inputs nothing overflows.
17. "Precedence, strongest first" is not quoted; the grammar rule `Sum = Product { ( "+" | "-" ) Product } .` governs line 7 (`n - 1 - p` is left-associative subtraction) and lines 12, 13, 23, 24, 25 and 22 (`i - 1`, `j + 1`, `count + 1`).
18. "`< <= > >=`: a number only" Governs lines 5, 7, 8, 21 (`<` on `i64`).
19. "`==` is structural equality on any two values of one type, recursively" Governs lines 17 (`len(xs) == 0`), with the literal `0` taking the type of `len`.
20. "`!=`" is in the comparison row of section 7. Governs line 22 (`xs[i] != xs[i - 1]`), both sides `i64`.
21. "A function with a `->` must `return` on every path that reaches its end" Governs `sorted_desc` (line 14 is its final statement) and `runs` (line 25 is its final statement; the path through line 18 returns early).
22. "A statement after a jump, in its block, is a compile error." Governs line 18: `return 0` is the last statement of its `if` block. Line 19 is in the outer block, so it does not follow a jump there.
23. "`if cond` / `else if` / `else` take only `bool`" Governs lines 8, 17, 22. Each condition is a `bool` comparison.
24. "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs lines 28 and 31, which are positional calls. Each function has one parameter, so the rule does not apply.
25. "`_` names anything you do not use" is not used; no `_` appears in the program.
26. "Recursion too deep aborts." Not relevant: no recursion is used.

# choice_points

1. **Sorting by bubble passes with `while` loops (lines 4-13)** versus a `for` loop over a range. I used `while` with cells, because `range` is `[i64]` and `for` over it would need a second loop variable anyway. Other choice: `for` over `range(from: 0, to: n)` nested in another; the output would be identical.
2. **Swap through a temporary `a` (line 9)**. The spec has no tuple or swap operator, so a temporary is needed. Other choice: `ys[j] @ ys[j + 1]` without a temporary would lose the value of `ys[j]`, so the program would be wrong.
3. **Fixed `n` passes (line 5) versus early exit with a `swapped` flag**. I chose `n` passes for simplicity. The early exit would give the same output and fewer iterations on sorted input.
4. **Inner bound `n - 1 - p` (line 7)** versus `n - 1`. The shrinking bound skips the already-placed largest elements. The other choice is still correct and gives the same result, but does more comparisons.
5. **Descending order by swapping when `ys[j] < ys[j + 1]` (line 8)**. The other choice, `>`, would sort ascending, which is wrong for this task.
6. **`ys @= xs` (line 2)** versus `ys: [i64] @= xs`. I left the type to inference; the parameter already fixes it. The annotated form is also valid. The copy is needed because `xs` is immutable.
7. **`runs` starts with `count @= 1` (line 19) and checks from index 1 (line 20)**, with an early `return 0` for an empty array (lines 17-18). The other choice, starting `count` at 0 and comparing each element to the previous one, would need an extra guard for index `-1`. The empty-array guard is needed in my version because `xs[0]` would abort on an empty array.
8. **`while` loop in `runs` (lines 21-24)** versus `for x in xs` with a `prev` cell. The `prev` version would need a sentinel for the first element, so I used indices.
9. **`for y in ys` in `main` (line 29)** versus a `while` with an index. The `for` loop is shorter and yields each element.
10. **`print(y)` per element (line 30)** versus `print(join(...))`. The spec requires each element on its own line; a single `print` of a joined string would also work but needs a `str` conversion.
11. **Typing of `len` (lines 3, 17, 21)**. The spec lists `len` as a built-in but does not state its result type. I assumed `i64`, which matches the other integers here. The other possibility, an unsigned type such as `u64`, would make `p < n` (line 5), `j < n - 1 - p` (line 7) and `i < len(xs)` (line 21) compare mismatched types, which is an error under "No implicit conversions, widths included."
12. **`len(xs)` written as a call** versus `xs.len()`. The spec shows both forms (`xs.len()` in section 6, `len` in section 11). I used the function form, which is the one listed as a built-in.
13. **Helper names and comments**. No comments were written. The names `sorted_desc`, `runs`, `main` are required by the brief. Other local names are my choice.

# confidence

I am about 85% sure the checker accepts this program on the first try.

The least certain line is line 3 (`n = len(xs)`), together with line 5 (`while p < n`), line 7 (`while j < n - 1 - p`) and line 21 (`while i < len(xs)`). All depend on `len` returning `i64`, which the spec does not state. If it returns another integer type, these lines will be refused as mixed types.

The next least certain line is line 10 (`ys[j] @ ys[j + 1]`). The spec defines `Place` as `ident { "." ident | "[" Expression "]" }` and a Simple statement as `Place "@" Expression`, so I believe it is valid, but I have not seen an example of an element write.

Lines 2, 4, 6, 19, 20 and the `if`/`return` structure in lines 17-18 follow the spec's examples closely, and I am highly confident in them.

I cannot run the checker here, so this is a reading of the spec only.

# context

Only files in this directory reached my working context as program inputs: `brief.md` and `spec.md` were read in full. I also read `run.json` and `run.err`, which are in this directory; both are empty, and they did not inform the program.

Non-file context: the session environment (working directory path, platform, shell, date, and model name), and an account and git status snapshot (branch `main`, untracked `run.err` and `run.json`, one recent commit). None of this was used for the program or the report. No file outside this directory was read, and no tool other than reading and writing files in this directory was used.
