## program

```
# Bubble sort: swap adjacent out-of-order elements until none remain.
function sorted_desc(xs: [i64]) -> [i64]
    a @= xs
    n $= a.len()
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if a[j] < a[j + 1]
                t $= a[j]
                a[j] = a[j + 1]
                a[j + 1] = t
    return a

# Count maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    if xs.len() == 0
        return 0
    count @= 1
    for i in range(from: 1, to: xs.len())
        if xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers used below: 1 comment, 2 `function sorted_desc`, 3 `a @= xs`, 4 `n $= a.len()`, 5 outer `for`, 6 inner `for`, 7 `if a[j] < a[j + 1]`, 8 `t $= a[j]`, 9 `a[j] = a[j + 1]`, 10 `a[j + 1] = t`, 11 `return a`, 13 comment, 14 `function runs`, 15 `if xs.len() == 0`, 16 `return 0`, 17 `count @= 1`, 18 `for i in range(from: 1, to: xs.len())`, 19 `if xs[i] != xs[i - 1]`, 20 `count = count + 1`, 21 `return count`, 23 `function main()`, 24 `for x in sorted_desc(...)`, 25 `print(x)`, 26 `print(runs(...))`.

## sentences

Spec sentences the program rests on, with the lines they govern.

1. Section 1: "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 23.
2. Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs the whole program; the conditions on lines 7, 15 and 19 are written without parentheses.
3. Section 1: "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it; `##` is a section heading." Governs lines 1 and 13.
4. Section 4: "Declaration = ... | \"function\" ident [ Generics ] Params [ \"->\" Type ] Block" and "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs lines 2, 14 and 23; `main` calls `sorted_desc` and `runs`, which are declared above it.
5. Section 5: "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 3, 4, 8, 17 (`@=`), 9, 10 and 20 (`=`).
6. Section 5: "Signatures are always explicit; inference is local only." Governs lines 2, 14 and 23.
7. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds ... a read is a use and a write is not, except through an `@` parameter." Governs lines 3 and 17: `a` is read (line 4 onward) and re-bound through element writes (lines 9, 10); `count` is read on line 20 and returned on line 21. Every parameter and binding in the program is read.
8. Section 5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs the reused loop names `i` (lines 5, 18) and `j` (line 6), which are in different functions, and that no name is bound twice in one function.
9. Section 2: "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `0` (line 5, 15, 16), `1` (lines 17, 18, 20), `2` and `6` (line 24 list) and the array literals on lines 24 and 26, which take `[i64]` from the parameter.
10. Section 3: "`[T]` | dynamic array, indices from 0" and section 10: "An out-of-bounds index or slice aborts". Governs `a[j]`, `a[j + 1]`, `xs[i]`, `xs[i - 1]` (lines 7, 9, 10, 19). The indices stay in range: `j + 1 <= n - 1 - i + 1 <= n - 1` on line 9, and `i - 1 >= 0` on line 19 because `i` starts at 1.
11. Section 3: "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." Governs line 3, where `a @= xs` copies the parameter so the cell can be mutated without a `@` parameter.
12. Section 5 and section 3 Place grammar: "Place = ident { \".\" ident | \"[\" Expression \"]\" } ." Governs lines 9 and 10, which assign to elements of the cell `a`.
13. Section 7: "`< <= > >=`: a number only" and "bool only" for `&& ||`; comparison operators are listed as `== != < <= > >=`. Governs lines 7, 15 and 19, which compare `i64` values.
14. Section 7: "Overflow aborts at every width." Governs line 20 (`count + 1`) and line 6 (`n - 1 - i`); neither can overflow for an array of realistic length.
15. Section 9: "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `a.len()` (line 4), `xs.len()` (lines 15, 18). The spec example in section 6 also writes `if xs.len() == 0`.
16. Section 8: "`if cond` / `else if` / `else` take only `bool` ... `if` and `match` ... may stand as statements." Governs the `if` statements on lines 7, 15 and 19.
17. Section 8: "A function with a `->` must `return` on every path that reaches its end." Governs `sorted_desc` (line 11), and `runs`, where the `return 0` on line 16 is the early path and line 21 is the final path.
18. Section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs the `for` loops on lines 5, 6, 18, 24.
19. Section 11: "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs the bounds on lines 5, 6 and 18. `range(from: 0, to: n)` yields `0..n-1`; `range(from: 0, to: n - 1 - i)` yields the comparison pairs for the inner pass.
20. Section 9: "When two parameters in a signature share a type, named arguments are mandatory at the call site." `range` takes two `i64` parameters, so the calls on lines 5, 6 and 18 name `from:` and `to:`.
21. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 25 and 26; each `print` writes one `i64` and one line.
22. Section 11: "`len`" is listed among built-ins, with no stated return type. Governs lines 4, 15 and 18. See choice point 8 and confidence.
23. Section 11: "`print(...)`" and "`range`" are listed built-ins, and "`range(from: a, to: b) -> [i64]`" is given. Governs lines 5, 6, 18 and 25, 26.
24. Section 4: "a comment directly above" applies to function declarations at lines 2 and 14. Used only for documentation; no effect on the checker.

## choice_points

1. **Copy the input into a cell (`a @= xs`) and sort the cell.** Alternative: declare `xs` as an `@` parameter. That would require the caller to pass a place (`sorted_desc(@xs)`), and the call in `main` passes a literal, which is not a place, so it would be refused. Alternative two: sort `xs` in place with `@xs: [i64]` and a named variable in `main`, which changes the caller's array; not what the task describes.
2. **Swap via temporary `t` (lines 8 to 10).** Alternative: none. The spec has no tuple assignment or multi-target swap. A `t` name is used, so it is not unused.
3. **`for` over `range` for both passes.** Alternative: `while` loops with a counter cell. Same output, same checker rules; `for` is shorter.
4. **Inner bound `n - 1 - i` (line 6).** Alternative: `n - i - 1`, same value. Alternative: `n - 1` for every pass, which is also correct (adjacent comparisons on already-sorted tails do nothing) but does more work. The output is identical.
5. **Strict `<` on line 7, so equal elements are not swapped.** Alternative: `<=`, which would also swap equal elements. The printed output for these inputs is the same, only the number of swaps changes.
6. **Descending order comes from testing `a[j] < a[j + 1]` (line 7).** Alternative: `a[j] > a[j + 1]` produces ascending order, which the task does not want.
7. **`runs` returns 0 for an empty array (guard on lines 15 and 16).** Alternative: no guard. Then an empty array would return 1, because `count` starts at 1. The task's examples are non-empty, so the output is the same for them.
8. **Type of `len` (line 4 `n $= a.len()`, line 15, line 18).** The spec lists `len` as a built-in and does not give its return type. I assumed `i64`, because the spec makes `i64` the default and `range` takes `i64` arguments. Alternative: if `len` returned `u64`, `range(from: 0, to: n)` on line 5 would be a type error (no implicit conversion), and the comparisons `== 0` and `range(to: xs.len())` would fail on line 18. The program would then need `to_i64(...)` (which returns `i64?`, so `.must()`) or a different form.
9. **UFCS `xs.len()` versus `len(xs)`.** Both forms are allowed by the built-in list and UFCS. I used `xs.len()`, which the spec uses in its own example. Alternative `len(xs)` would give the same output.
10. **Named arguments on `range` (`from:`, `to:`).** Mandatory here (both `i64`), so I used them. Alternative positional form is refused by the checker.
11. **Comments included.** Alternative: omit them. No effect on the checker or on output.
12. **Element writes as re-binding.** I read "`=` re-binds it, or a field or element inside one" as meaning `a[j] = ...` satisfies "a cell nothing re-binds" for `a`. Alternative reading: element writes do not count, and `a` would then be an unused-cell error. I think the first reading is the one the spec states.
13. **Use of `main` without a return type and with a `for` over a call.** Alternative: bind the array first (`xs $= sorted_desc(...)`). Same output; I did not bind it because the loop variable is then the only use.

## confidence

About 85 percent that the checker accepts the program as written. Nothing here was compiled or run, because I was limited to reading and writing files.

Least certain line: line 4, `n $= a.len()`, together with the uses of `len` on lines 15 and 18. The spec does not state `len`'s return type (choice point 8), and the `range` calls on lines 5, 6 and 18 need `i64`. If `len` is not `i64`, the program is refused at those lines.

Second least certain: line 9 and 10 (element writes to a cell, sentence 5 and 12). I am fairly sure element assignment on a cell counts as re-binding, but the spec's wording is brief.

Line 7 and 19, comparing `i64` values with `<` and `!=`, I consider certain.

## context

Only the files in this directory were used as input for the task: `brief.md`, `spec.md`, `run.json` and `run.err`. I read `brief.md` and `spec.md` in full. `run.json` and `run.err` exist but were empty when read, so they contributed nothing.

Beyond those files, my context also held the session environment (the working directory path, platform and shell details, the scratchpad path, the model identifier and the current date) and some account and git metadata supplied by the harness: the user's email address and a git status snapshot listing `run.err` and `run.json` as untracked files. I did not use any of that to write the program or this report. I read no file outside this directory, and I used no tool other than reading and writing files here.
