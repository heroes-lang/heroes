# Report

## program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n := len(xs)
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - (i + 1))
            if ys[j] < ys[j + 1]
                t := ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
    return ys

function runs(xs: [i64]) -> i64
    n := len(xs)
    if n == 0
        return 0
    count @= 1
    for i in range(from: 1, to: n)
        if xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

## sentences

Line numbers refer to the program above, counting blank lines.

1. "Syntax is ASCII-only" (section 1). Governs the whole program: every character is ASCII.
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." (section 1). Governs every indented line, lines 2-10, 13-20, 23-25.
3. "No braces, no semicolons; a condition needs no parentheses." (section 1). Governs lines 6, 14, 18: the `if` conditions are bare.
4. "Signatures are always explicit; inference is local only." (section 5). Governs lines 1, 12, 22 (explicit parameter and return types).
5. "A literal takes the type its context asks for ... otherwise `i64`." (section 2). Governs the array literals on lines 23 and 25, `count @= 1` on line 16, and `return 0` on line 15 as `i64`.
6. "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." (section 3). Governs line 2: `ys` is a copy of `xs`, so the parameter is unchanged while the sort works on `ys`.
7. "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." (section 5). Governs lines 2, 16 (cells declared with `@=`), 8, 9 (element re-binding of `ys`), and 19 (re-binding `count`).
8. "All bindings are initialised. An unused binding or parameter is a compile error" (section 5). Governs every binding: `n` is used on lines 4, 5, 17; `t` on line 9; `count` on lines 19, 20; `i` and `j` on lines 5, 6, 8, 9, 18; `x` on line 24; `xs` on lines 2, 3, 13, 17; `ys` on line 10.
9. "A function with a `->` must `return` on every path that reaches its end" (section 8). Governs lines 10 and 20 (every path of `sorted_desc` and `runs` returns) and line 15 (the early return that covers the empty array).
10. "A statement after a jump, in its block, is a compile error." (section 8). Governs lines 14-15: `return 0` is the last statement of its block, and line 16 sits outside that block.
11. "`if cond` / `else if` / `else` take only `bool`" (section 8). Governs lines 6, 14, 18: each condition is a `bool` comparison.
12. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." (section 8). Governs lines 4, 5, 17 (`range` loops) and 23 (a `for` over the array returned by `sorted_desc`).
13. "`range(from: a, to: b) -> [i64]` exclude `to`." (section 11). Governs lines 4, 5, 17: `range(from: 0, to: n)` is `0..n-1`, `range(from: 1, to: n)` starts at index 1, and `range(from: 0, to: n - (i + 1))` stops before the last unsorted index.
14. "When two parameters in a signature share a type, named arguments are mandatory at the call site" (section 9). Governs lines 4, 5, 17: `range` takes two `i64` parameters, so `from:` and `to:` are written.
15. "Arithmetic `+ - * / %` (both sides one numeric type — never mixed)" (section 7). Governs lines 3, 5, 6, 8, 9, 13, 17, 18, 19: every operand is `i64`, and no `f` literals or other widths appear.
16. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (section 11). Governs lines 24 and 25: each prints one `i64` on its own line.
17. "Built-ins: `print(...)` · `len` · `push` · ..." (section 11). Governs lines 3 and 13: `len(xs)` is the built-in length.
18. "Recursion too deep aborts." is not relied on. The program uses no recursion.

## choice_points

1. **Sorting algorithm.** Chose bubble sort with two nested `range` loops, since the task requires adjacent swaps. Other choice: a `while` loop with cells for the indices. It produces the same output. I chose `range` because each loop's bounds are never negative (`n - (i + 1)` is at least 0 for `i` in `0..n-1`), so the empty-range edge case does not come up.
2. **Inner loop bound written as `n - (i + 1)`.** The spec's `Sum` production does not state associativity. `n - 1 - i` could be read as `(n - 1) - i` or `n - (1 - i)`, and these differ. Chose `n - (i + 1)`, which means the same thing under either reading. Other choice: `n - 1 - i`. It would produce the same output if the checker groups left to right, and a different loop bound if it groups right to left.
3. **`len(xs)` versus `xs.len()`.** Chose `len(xs)`, because section 11 lists `len` as a built-in. Other choice: `xs.len()`, which the section 6 example uses. Both would produce the same output, and the UFCS form is also allowed by section 9.
4. **Copy-then-swap versus building a new array with `push`.** Chose `ys @= xs` and swap in place on the cell. Other choice: build a fresh array with `push`. Output is identical. `push` on a plain name also works, but it is not needed here.
5. **Swap through a temporary `t`.** The spec has no tuples or multiple assignment, so a temporary is the only swap form. The other choice, a second array, would produce the same output.
6. **Descending comparison `<` (swap when the left is smaller).** Other choice: `<=`. For `i64` values that are equal, the output is the same, since swapping equal values changes nothing visible. I used `<` to avoid unneeded swaps.
7. **Empty input in `runs`.** Chose an early `return 0` for `n == 0`. Other choice: start `count` at 0 and compare each element with its predecessor. That would need an index guard, and reading `xs[0]` on an empty array aborts. The given input is non-empty, so the output is 4 either way.
8. **Parameter and loop names.** Kept `xs` for both parameters as the task names it. Used `i` and `j` for loop indices and `n` for the length. Other names would produce the same output. None of the local names is `use`-bound or a built-in or function name, which keeps clear of the shadowing rule.
9. **`main` prints element by element with a `for` loop.** Other choice: `join` with a separator, but `join` takes strings, so it would need conversions. The `for` loop with `print(x)` matches the task's "on its own line" wording directly.
10. **No `test` block.** Chose not to add one. The task does not ask for it, and it adds surface to check. Other choice: adding `test` blocks with `assert`. Ordinary builds ignore them, so the output would be unchanged.

## confidence

I am about 90% sure the checker accepts this program on the first try.

The line I am least sure of is line 4 and 5 (and 17), the `range(from: ..., to: ...)` calls. The labels are taken from the one-line signature in section 11, and I am relying on the named-argument rule of section 9 being applied to a built-in written in Heroes. If the checker rejects these labels, the cause is most likely there.

The next least certain point is the cell re-binding on lines 8 and 9 (`ys[j] = ...`). Section 5 says `=` re-binds "a field or element inside one", so I believe `ys` counts as re-bound and is not an unused cell, but the checker's treatment of element writes is the thing I have read from the spec only.

## context

Only files in this directory reached my context through tools: `brief.md`, `spec.md`, `run.json`, and `run.err`. I read all four with the Read tool. `run.json` and `run.err` are empty.

Two other things are in my context but did not come from files I read. First, the session's environment block: the working directory path, platform, shell, OS version, the scratchpad path, the model name and ID, the date, and a git status snapshot that lists `run.err` and `run.json` as untracked files along with the user's account email and git identity. Second, my general knowledge of programming languages, which I used for ordinary loop and swap idioms. I did not look at anything outside this directory, and I did not run anything. The brief permits reading and writing only.
