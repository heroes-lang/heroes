
# Report: main.hero

## verdict

Refused. The checker would reject two lines of `main.hero`:

- **Line 20** `step @ 2`: `step` is an immutable `=` binding (line 10), and only a cell declared with `@=` can be re-bound with `@`.
- **Line 22** `last @= words[0]`: `last` is a mutable cell that nothing re-binds, which is a compile error.

Smallest fix that keeps the evident meaning: line 10 becomes `step @= 1` and line 22 becomes `last = words[0]`. The fixed program is accepted and prints:

```
5
5
a
```

## lines

Every line holding `=` or `@` (the `@` in `@c` counts as well):

| line | name | classification | words of the specification relied on |
|---|---|---|---|
| 5 | `c` (parameter) | *new name* | `Param = "@" ident ":" Type` (section 4); "Mutable parameters are marked `@` in the signature and at the call site" (section 9) |
| 6 | `c.hits` | *changes an existing name* | `Simple = Place "@" Expression`, "`@` re-binds it, or a field or element inside one" (section 5) |
| 9 | `words` | *new name* | "`=` binds once, forever" (section 5) |
| 10 | `step` | *new name* | "`=` binds once, forever" (section 5) |
| 11 | `counts` | *new name* | "`@=` declares a mutable cell" (section 5); "`m: {str: i64} @= {}`" (section 10) |
| 12 | `total` | *new name* | "`@=` declares a mutable cell" (section 5) |
| 15 | `counts[w]` | *changes an existing name* | "`m[k] @ v` inserts or replaces" (section 10); "`@` re-binds it, or a field or element inside one" (section 5) |
| 16 | `total` | *changes an existing name* | "`@` re-binds it" (section 5) |
| 18 | `c` | *new name* | "`@=` declares a mutable cell" (section 5) |
| 19 | `c` (argument `@c`) | *changes an existing name* | "an `@` argument counting" as a write (section 5); "the callee works on the caller's place itself" (section 9) |
| 20 | `step` | *changes an existing name* in intent, refused | "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it" (section 5) |
| 21 | `c` (argument `@c`) | *changes an existing name* | as line 19 |
| 22 | `last` | *new name* | "`@=` declares a mutable cell" (section 5); refused as written because "a cell nothing re-binds" is a compile error (section 5) |

## sentences

Sentences of the specification the verdict rests on:

- Section 5: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
- Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- Section 5: "Signatures are always explicit; inference is local only."
- Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy"
- Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- Section 10: "`m[k] @ v` inserts or replaces;"
- Section 6 (table): "`.default(v)` | extract or fall back"
- Section 2: "A literal takes the type its context asks for … otherwise `i64`."
- Section 3: "No implicit conversions, widths included"
- Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Trace: the loop runs five times over `a b a c a`, so `counts["a"]` is 3 and `total` is 5. `bump` adds 3, then `step` is 2 and `bump` adds 2, so `c.hits` is 5. `last` is `"a"`. Output: `5`, `5`, `a`.

## choice_points

1. **Line 10 and line 20 (the `step` re-bind).** I made `step` a cell (`step @= 1`), because the author plainly writes `step @ 2` and means a changing value. The other choice is a new immutable name: `step2 = 2` and `bump(@c, step2)`, since `=` cannot be re-bound. That program prints the same `5`, `5`, `a`, so the output does not depend on this choice.
2. **Line 22 (the `last` cell).** I made `last` immutable (`last = words[0]`), because nothing in the program re-binds it. The other choice keeps `last @= words[0]` and adds a re-bind somewhere later, which the program does not have and the author did not write. Any such re-bind would be an invented assignment. The printed output would change only if the invented value differs from `"a"`, so I did not invent one.
3. **Line 5 classification.** I called the `@c` parameter a *new name*, since the signature brings `c` into the callee's scope. The other choice is *neither*, since a signature does not bind a value. I went with *new name*.
4. **Lines 19 and 21 classification.** I called the `@c` arguments *changes an existing name*, because an `@` argument is a write to the caller's place. The other choice is *neither*, since a call is not a binding. This affects only the table.
5. **Line 20 classification.** I recorded it as *changes an existing name* in intent, although the checker refuses it. The other reading is *neither*, because a refused line changes nothing.
6. **Type of the literal `1` on line 10.** I took it as `i64`, the default in section 2, since `step` has no other context and every use of `step` is with `i64` values. Had the literal been read as another integer type, the expression on line 15 would have mixed types and been refused, so this choice is tied to the verdict.

## confidence

- High that line 20 is refused, because "`=` binds once, forever" and "`@` re-binds" a cell are explicit.
- High that line 22 is refused, because "a cell nothing re-binds" is named as a compile error.
- High on the trace of the fixed program's output, given the spec's stated semantics for `+`, `.default`, `m[k] @ v`, and `print`.
- Lower on the classification of lines 5, 19 and 21, which the spec does not state in one sentence and which I inferred from section 5 and section 9.
- I could not compile or run anything in this session, so the verdict is a reading of the specification, not a checker run.

## context

I read only the three files in this directory: `brief.md`, `spec.md`, and `main.hero`. I did not open `run.err`, `run.json`, or any file outside this directory.

The harness supplied environment information that reached my context: the working directory path, the platform, the date, and a git status snapshot listing `run.err` and `run.json` as untracked files. The account identity from the session also reached my context. None of this was used in the verdict, the classifications, or the program.
