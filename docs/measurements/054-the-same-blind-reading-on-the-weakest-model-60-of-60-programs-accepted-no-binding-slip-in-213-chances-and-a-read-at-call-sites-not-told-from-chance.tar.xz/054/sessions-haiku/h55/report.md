# report

## program

```
# Sorts a copy of xs from largest to smallest by swapping adjacent
# out-of-order pairs (bubble sort).
function sorted_desc(xs: [i64]) -> [i64]
    a @= xs
    n = len(a)
    swapped @= true
    while swapped
        swapped @ false
        i @= 0
        while i < n - 1
            if a[i] < a[i + 1]
                t = a[i]
                a[i] @ a[i + 1]
                a[i + 1] @ t
                swapped @ true
            i @ i + 1
    return a

# Counts the maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    i @= 1
    while i < len(xs)
        if xs[i] != xs[i - 1]
            count @ count + 1
        i @ i + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output, if the program runs as written: `9 6 5 4 3 2 1 1`, one per line, then `4`.

## sentences

Line numbers count from the first line of the fenced block above.

- Lines 1 and 2 (comment above `function sorted_desc`): "A comment directly above a declaration documents it" (section 1). Comments are ASCII and use `#`.
- Line 3 (`function sorted_desc(xs: [i64]) -> [i64]`): "Signatures are always explicit; inference is local only." (section 5). Both the parameter and the result type are written.
- Line 3: "`[T]` | dynamic array, indices from 0" (section 3 table). Used for `xs` and the result.
- Line 4 (`a @= xs`): "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." (section 3). This copy is needed because `xs` is a read-only parameter and cannot be written.
- Line 4: "`@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." (section 5).
- Line 5 (`n = len(a)`): "`=` binds once, forever." (section 5). The built-in `len` is listed in section 11 ("Built-ins: `print(...)` · `len` · ...").
- Line 5: "A literal takes the type its context asks for ... otherwise `i64`." (section 2). Not directly used here, but it covers the `0`, `1` and `i64` literals in `sorted_desc` and `runs`.
- Lines 6, 8, 15: "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness" (section 8). `swapped` is `bool` (line 6, `true`) and `i < n - 1` is `bool`.
- Lines 7, 10, 25 (`while swapped`, `while i < n - 1`, `while i < len(xs)`): "Loops: `while cond` and `for x in xs`, over an array or a `range`" (section 8). Each condition is a `bool` expression.
- Line 6 (`swapped @= true`), line 8 (`swapped @ false`): "`@` re-binds it" (section 5). `swapped` is read at line 7, so it is used.
- Lines 9 and 16 (`i @= 0`, `i @ i + 1`): "`@` re-binds it" (section 5). `i` is read at lines 10, 11 and 13, so it is used.
- Line 11 (`if a[i] < a[i + 1]`): "`< <= > >=`: a number only" (section 7). The operands are `i64` (element type of `a`).
- Line 11: "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -` → ... → comparisons → `&&` → `||`." (section 7). Makes `a[i + 1]` and `n - 1` bind before the comparison, with no parentheses needed.
- Lines 10, 11, 13, 14 (index expressions): "An out-of-bounds index or slice aborts" (section 10). The loop bound `i < n - 1` keeps `i + 1` at most `n - 1`, so every index is in bounds when `n` is `len(a)`.
- Lines 13 and 14 (`a[i] @ a[i + 1]`, `a[i + 1] @ t`): "Place = ident { "." ident | "[" Expression "]" }" (section 5 grammar). `Simple = Place "@" Expression NEWLINE` accepts the element write.
- Line 12 (`t = a[i]`): "`=` binds once, forever." (section 5). `t` is a fresh immutable name, used at line 14. It is declared once in the whole file.
- Lines 4 to 17: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds" (section 5). `a`, `n`, `swapped`, `i`, `t` are read; `xs` is read at line 4; `a` is re-bound at lines 13 and 14.
- Lines 17 and 29: "A function with a `->` must `return` on every path that reaches its end" (section 8). `sorted_desc` ends with `return a` (line 17). `runs` returns on line 22 (empty input) and on line 29.
- Line 22: "A statement after a jump, in its block, is a compile error." (section 8). `return 0` is the last statement of its `if` block, so nothing follows it in that block.
- Line 20 (`function runs(xs: [i64]) -> i64`): the signature matches the task. `count` and `i` are `i64` by their literals and by `len`'s result (see choice points).
- Line 21 (`if len(xs) == 0`): "Literals take the type its context asks for ... otherwise `i64`" (section 2). `0` is compared with `len(xs)`, so `len` must give `i64` for the comparison to type-check.
- Line 25 (`while i < len(xs)`): "`< <= > >=`: a number only" (section 7). Relies on `len` giving a number of the same type as `i`.
- Line 26 (`if xs[i] != xs[i - 1]`): "`==` is structural equality on any two values of one type" (section 7). `!=` is the negation, applied to two `i64` values.
- Line 26: "An out-of-bounds index or slice aborts" (section 10). `i` starts at 1 and stays below `len(xs)`, so `xs[i - 1]` is in bounds.
- Line 27 (`count @ count + 1`): "`+`" arithmetic on one numeric type, "both sides one numeric type" (section 7).
- Line 31 (`function main()`): "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." (section 1). `main` has no `->` and no `return`.
- Line 32 (`for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])`): "`while cond` and `for x in xs`, over an array" (section 8). The array literal is one line, so commas separate it: "by comma on one" (section 10). The literal takes `[i64]` from the parameter's type, which is the context (section 2).
- Line 33 (`print(x)`): "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (section 11). Each `x` is an `i64`, so one number per line.
- Line 34 (`print(runs([1, 1, 2, 2, 2, 3, 1]))`): same `print` rule. `runs` returns `i64`.
- Whole file: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." (section 1). Every level in the program uses 4 spaces, and no tab appears.
- Whole file: "No braces, no semicolons; a condition needs no parentheses." (section 1). The program uses no braces or semicolons. The `if` and `while` conditions have no parentheses.
- Whole file: "Shadowing is a compile error" (section 5). No name is bound twice in one function. `i`, `t`, `a`, `n`, `count` and `swapped` each appear in one binding.
- Whole file: "Syntax is ASCII-only" (section 1). All characters are ASCII.

## choice_points

1. **Sorting algorithm.** I used bubble sort with a `swapped` flag. The spec allows any sequence of adjacent swaps. The other choice, a fixed number of passes (`n - 1` passes with no flag), gives the same output, with more work on sorted input.
2. **Temporary for the swap.** The language has no tuple assignment, so the swap uses `t = a[i]`. The other choice, an arithmetic swap (`a[i] @ a[i] + a[i + 1]`, then two subtractions), gives the same result but can overflow and abort for large values, so I avoided it.
3. **Copy of the input.** `xs` is a plain parameter, so it cannot be written. I copy it with `a @= xs`. The other choice, `@xs: [i64]`, would write the caller's place, but then `sorted_desc` would need an `@` at its call site, and `main` passes a literal, which cannot be marked `@`. So the copy is the only choice that fits `main`.
4. **Type of `len`.** The spec lists `len` as a built-in but gives no signature. I assumed it returns `i64`, so that `n - 1`, `i < len(xs)` and `len(xs) == 0` type-check against `i64` literals. The other choice, an unsigned or otherwise narrower type, would make these comparisons and the subtraction in `n - 1` fail with a mixed-type error, since the spec forbids implicit conversions.
5. **Empty input to `runs`.** The task does not say what `runs([])` returns. I return `0`, which is the number of groups. The other choice, leaving out the guard, makes `runs([])` return `1`, because `count` starts at 1 and the loop does not run. Neither choice is exercised by `main`.
6. **Loop form in `runs`.** I used an index loop with `while` and `xs[i - 1]`. The other choice, a `for x in xs` loop with a `prev` cell and a first-element flag, gives the same count, but needs an extra flag and a `prev` initial value that has no natural value.
7. **Descending order rule.** The task says "from the largest to the smallest", so I swap when `a[i] < a[i + 1]`, which moves larger values left. The other choice, `>`, gives ascending order, which the task does not ask for.
8. **Output form.** `main` prints each element with its own `print(x)` call, one per line, as the task asks. The other choice, `join` with a newline, would print one string, which is a different output shape with the same text.
9. **Comments.** I added a short `#` comment above each function. The other choice, no comments, is equally valid. The comments do not affect the checker.

## confidence

I am fairly confident that the checker accepts the program on the first try, roughly 80 percent. I could not run the checker, so this rests on reading the spec.

The line I am least sure of is line 5, `n = len(a)`, with the matching `len` calls on lines 21 and 25. The reason is that the spec gives no signature for `len`, so its result type is an assumption (choice point 4). If `len` does not return `i64`, lines 5, 10, 21 and 25 fail. The second least sure line is line 9, `i @= 0`, inside the outer `while` block. Each pass declares a fresh `i`. The spec does not say explicitly that a binding inside a loop body is fresh each time, though the block rules imply it.

## context

Nothing other than the files in this directory reached my context. I read `brief.md`, `spec.md`, `run.json` and `run.err`. The last two are empty and contributed nothing. I used general knowledge of bubble sort to choose the algorithm, and that is the only input from outside the spec. I did not run anything.
