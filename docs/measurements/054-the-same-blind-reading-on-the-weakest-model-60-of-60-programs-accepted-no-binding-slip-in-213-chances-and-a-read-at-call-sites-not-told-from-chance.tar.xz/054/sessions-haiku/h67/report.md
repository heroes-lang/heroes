# program

```
function sorted_desc(xs: [i64]) -> [i64]
    a @= xs
    n $= xs.len()
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if a[j] < a[j + 1]
                tmp $= a[j]
                a[j] = a[j + 1]
                a[j + 1] = tmp
            j = j + 1
        i = i + 1
    return a

function runs(xs: [i64]) -> i64
    count @= 0
    seen @= false
    last @= 0
    for x in xs
        if !seen || x != last
            count = count + 1
        seen = true
        last = x
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below count the lines of this block from 1, blank lines included: `sorted_desc` is lines 1 to 14, `runs` lines 16 to 25, `main` lines 27 to 30.

# sentences

Quotes are from `spec.md`. Where a quote contains an em dash, the part quoted is cut at the dash.

1. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every line; the program is indented with 4 spaces only.
2. "Outside brackets a line ends its statement: it may not end where the statement cannot, and the next line may not go on with it" Governs every line; each statement is one line.
3. "Every top-level line starts with its kind." Governs lines 1, 16, 27 (`function`).
4. "Signatures are always explicit; inference is local only." Governs lines 1, 16, 27 (explicit `->` types and `[i64]`, `i64`, `()`-less `main`).
5. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 27 to 30.
6. "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 2, 3, 4, 6 (`@=` cells and `$=` bindings); lines 10, 11 (element re-binding `a[j] = ...`); lines 12, 13, 17 to 19, 22 to 24 (cell re-binding).
7. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds" Governs lines 2, 3, 4, 6, 9, 17, 18, 19 (each binding is written and later used; `tmp` on line 9 is read on line 11).
8. "a read is a use and a write is not, except through an `@` parameter." Governs lines 2 to 4, 17 to 19: `count`, `seen`, `last` are read after every write.
9. "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." Governs line 2: `a @= xs` gives a mutable copy, so the array's sorting does not touch `xs`.
10. Section 3 table row: "`[T]` | dynamic array, indices from 0". Governs lines 8 to 11 (`a[j]`, `a[j + 1]`).
11. Section 6 example: "`if xs.len() == 0`" is shown with `xs.len()` returning a value compared to `0`. Governs line 3 (`xs.len()` used as a count), together with the next sentence.
12. Section 11: "Built-ins: `print(...)` · `len` · `push`" Governs line 3 (built-in `len`, called as `xs.len()`).
13. Section 9: "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs line 3 (`xs.len()` is `len(xs)`).
14. Section 2: "A literal takes the type its context asks for" and "otherwise `i64`." Governs the literals `0`, `1`, `2`, `3`, `4`, `5`, `6`, `9`, `8`, `7` on lines 4, 6, 8, 12, 13, 17, 19, 22 and 28 to 30 (`i64` by default; `0` is `i64`, which the `i64` cells need).
15. Section 2: "A leading zero is an error, never octal." Governs the literal `0` on lines 4, 6, 17, 19; a lone `0` has no leading zero.
16. Section 7: "both sides one numeric type" (arithmetic `+ - * / %`). Governs lines 3 (`n - 1 - i`), 7, 12, 13, 22 (`j + 1`, `i + 1`, `count + 1`) and 10, 11 (`a[j + 1]`), where both sides are `i64`.
17. Section 7: "`< <= > >=`: a number only" Governs lines 5, 7, 8 (`i < n`, `j < n - 1 - i`, `a[j] < a[j + 1]`).
18. Section 7: "`==` is structural equality on any two values of one type" Governs line 21 (`x != last`, both `i64`).
19. Section 7: "(bool only; && and || short-circuit)" Governs line 21 (`!seen || x != last`: `!` and `||` on a `bool` and a `bool`).
20. Section 7 precedence: "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -`" Governs lines 7, 8, 21 (`!seen` binds tighter than `||`; `n - 1 - i` and `a[j + 1]` group as written).
21. Section 8: "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness." Governs lines 8 and 21 (both conditions are `bool`).
22. Section 8: "`while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 5, 7 (`while`) and 20, 28 (`for ... in` over `[i64]`).
23. Section 8: "A function with a `->` must `return` on every path that reaches its end" Governs lines 14 (`sorted_desc`) and 25 (`runs`).
24. Section 8: "A statement after a jump, in its block, is a compile error." Governs lines 14 and 25 (each `return` is the last statement of its block).
25. Section 7 grammar, `Place`: "`Place     = ident { "." ident | "[" Expression "]" } .`" Governs lines 10, 11 (`a[j] = ...`, `a[j + 1] = ...`), 12 (`j = ...`), 13 (`i = ...`), 22 to 24 (`count`, `seen`, `last` re-bound).
26. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 29, 30: one `i64` per line.

# choice_points

1. **Sorting algorithm.** Chose bubble sort with adjacent swaps, as the brief requires. Any other algorithm that does not use `sort` and does not swap adjacent elements would also match the brief's wording, but would not meet its "swapping two adjacent elements" rule.
2. **Where the sort works.** Chose `a @= xs` (a copy, then in-place swaps). The other choice, a parameter marked `@` on `xs`, would be a mutable place in the caller, so the caller's array would change, and it would fail the brief's signature `sorted_desc(xs: [i64]) -> [i64]`.
3. **Inner loop bound.** Chose `j < n - 1 - i`, which shrinks each pass. The other choice, `j < n - 1`, is also correct and gives the same output, with extra comparisons.
4. **Type of `xs.len()`.** Chose `i64` (so `n`, `i`, `j` are `i64`). The spec does not state the type of `len`. The other choice (for example `u64`) would make `i < n` a mixed-type comparison, which is an error. `repeat` is the only built-in the spec marks `u64`, which is why I took `i64`.
5. **Type of array indices.** The spec does not say what type a `[T]` index must have. Chose `i64` because `i` and `j` are `i64`. The other choice (an index of another width) would be an error.
6. **`runs` method.** Chose a `seen` flag plus `last` (`for x in xs`, no index). The other choice, an index loop from 1 guarded by `xs.len() == 0`, gives the same counts but depends on the index type from choice 5 and on `xs[0]`-style reads.
7. **Initial value of `last`.** Chose `0`. Its value is never used when `seen` is `false`. The other choice, `last @= xs[0]`, would abort on an empty array.
8. **`main` shape.** Chose `for x in sorted_desc([...])` printing each element. The other choice, binding the result to a name first, gives the same output.
9. **Swap test.** Chose `a[j] < a[j + 1]`, so larger values move left and the result is descending. The other choice, `>`, would give ascending order.
10. **`print` of `runs` result.** Chose to print the `i64` directly. The other choice, binding it to a name first, gives the same output.

# confidence

I am highly confident the checker accepts this program, roughly 90 percent. I cannot run the checker here, so this is a reading of the spec, not a test.

The line I am least sure of is line 3, `n $= xs.len()`. The spec never states the return type of `len`. It is almost certainly `i64`, since the spec's default integer type is `i64`, but if it were a different type, lines 3 to 7 and 8 would fail. The next least sure is line 10 and 11 (`a[j] = a[j + 1]`), because the spec does not state the array index type (choice 5), and the element-write rule (sentence 6) is taken from the grammar and the `=` description rather than from an example.

# context

Only the files in this directory reached my task-relevant reading: `brief.md`, `spec.md`, `run.json` and `run.err`. `run.json` and `run.err` were both empty, and I used neither.

Other material also reached my context from outside this directory, because the session supplied it: a system prompt describing the environment, a working-directory path outside this directory, the current date, a git status snapshot of the repository, and the user's account email. None of it was used in the program or the report. I did not read any file outside this directory.
