## program

```
# Sorts a copy of xs from largest to smallest by adjacent swaps (bubble sort).
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n @= 0
    for x in ys
        _ = x
        n @ n + 1
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if ys[j] < ys[j + 1]
                tmp = ys[j]
                ys[j] @ ys[j + 1]
                ys[j + 1] @ tmp
            j @ j + 1
        i @ i + 1
    return ys

# Counts the maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    count @= 0
    prev @= 0
    started @= false
    for x in xs
        if !started || x != prev
            count @ count + 1
        prev @ x
        started @ true
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Program line numbers used below: line 1 is the first comment line of the block, so `function sorted_desc` is line 2, and `function main()` is line 32.

## sentences

Each quoted sentence is from `spec.md`. The line numbers after the arrow are lines of the program above.

1. Section 5: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs lines 3, 4, 8, 10, 22, 23, 24 (the `@=` declarations) and lines 7, 14, 15, 16, 17, 27, 28, 29 (the `@` re-bindings and element writes). Line 13 (`tmp = ys[j]`) is a plain `=` binding, which the same sentence says binds once.
2. Section 3: "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs line 3 (`ys @= xs` copies the parameter, so `xs` is not changed) and the `ys` element writes on lines 14 and 15.
3. Section 3 table: "`[T]` | dynamic array, indices from 0". Governs lines 12, 13, 14, 15 (`ys[j]`, `ys[j + 1]`) and the loop over `ys` on line 5.
4. Section 10: "An out-of-bounds index or slice aborts, and so does a slice that splits a character." Governs lines 12 to 15, which the loop bounds on lines 9 and 11 keep in range.
5. Section 5: "An unused binding or parameter is a compile error, and so is a cell nothing re-binds". Governs every binding in the program. Each `@=` cell is re-bound (lines 4, 8, 10, 16, 22, 23, 24, 27, 28, 29), and every name is read, including `x` on lines 5 and 25, which line 6 reads.
6. Section 5: "`_` names anything you do not use" and "It binds nothing, so it is never unused and may repeat." Governs line 6 (`_ = x`), which discards the loop variable on purpose.
7. Section 5: "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`". Governs line 6. The line does not compute a value, but this sentence is the reason a bare `x` would not be accepted as a statement.
8. Section 5: "Signatures are always explicit; inference is local only." Governs lines 2, 21, 32 (every signature is written in full, with `-> [i64]` and `-> i64`).
9. Section 2: "A literal takes the type its context asks for" and "otherwise `i64`." Governs lines 4, 8, 10, 22, 23 and 24 (`0` and `false` literals), and the `1` and the `[3, 1, ...]` literals on lines 7, 16, 27, 33 and 35.
10. Section 7: "No implicit conversions, widths included". Governs every comparison and arithmetic line: 7, 9, 11, 12, 16, 26, 27 (`n`, `i`, `j`, `x`, `prev`, and `count` are all `i64`).
11. Section 7: "Overflow aborts at every width." Governs line 11 (`n - 1 - i`, which is never below -1 and never overflows).
12. Section 7 precedence line: "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -`". Governs line 11 (`n - 1 - i` as `(n - 1) - i`) and line 26 (`!started` binds before `||`, and `x != prev` binds before `||`).
13. Section 7: "boolean && || ! (bool only; && and || short-circuit)". Governs line 26. `started` is a `bool`, and `||` short-circuits, so `prev` is only compared when `started` is already true.
14. Section 8: "`if cond` / `else if` / `else` take only `bool`". Governs lines 12 and 26, whose conditions are `bool` expressions.
15. Section 8 grammar: "While = "while" Expression Block ." and "For = "for" ident "in" Expression Block ." Govern lines 5, 9, 11, 25 and 33.
16. Section 8: "A function with a `->` must `return` on every path that reaches its end". Governs line 18 (`sorted_desc`) and line 30 (`runs`). Both functions have a single `return` as their last statement.
17. Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." and section 1: "No braces, no semicolons; a condition needs no parentheses." Govern the layout of every line of the program. The program uses four spaces per level and no parentheses around conditions.
18. Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 32 to 35.
19. Section 4: "Declaration order never matters but a group's (section 13)". Governs the call of `sorted_desc` and `runs` from `main` on lines 33 and 35, which come after the declarations of those functions anyway.
20. Section 10 literals: "A container literal separates elements by newline across lines and by comma on one". Governs the array literals `[3, 1, 4, 1, 5, 9, 2, 6]` on line 33 and `[1, 1, 2, 2, 2, 3, 1]` on line 35.
21. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 34 and 35. Each `print` gets one `i64`, so each output is one line.
22. Section 11 built-in list: "Built-ins: `print(...)` · `len`". The spec names `len` but gives no result type for it. The program does not call `len` (see choice 1), so no line relies on this.
23. Section 5 grammar: "Place     = ident { "." ident | "[" Expression "]" } ." and "Simple    = "_" Binding | Place "@" Expression NEWLINE". Govern the element writes on lines 14 and 15 and the statement `_ = x` on line 6.

## choice_points

1. **Counting `n` versus `len`.** The spec lists `len` as a built-in but does not give its result type. I count the elements with a loop (lines 4 to 7), which needs no type for `len`. The other choice is `n @= len(ys)`. That gives the same count, but if `len` returns anything other than `i64`, the comparison `i < n` on line 9 is a mixed-type error, because the spec forbids implicit conversions.
2. **Index type.** The spec says arrays index from 0, but it does not say which integer type an index must have. I index with `i64` cells, the default integer type. The other choice is an index of some other integer type, for example `u64`, which would make every `ys[...]` line (12 to 15) a type error with the `i64` cells here.
3. **Copying the parameter.** `ys @= xs` (line 3) makes a copy, which the spec says is independent. The other choice is an `@` parameter, `function sorted_desc(@xs: [i64])`, which changes the signature the brief fixes and makes the caller write `@xs`. I rejected it for that reason.
4. **Swap with a temporary.** The spec has no tuple or multi-assignment, so the swap uses `tmp` on lines 13 to 15. There is no other way to write a swap in this language as far as the spec shows.
5. **Empty-array handling in `runs`.** I use a `started` flag (lines 24, 26, 29). The other choice is `if len(xs) == 0` with `prev @= xs[0]`, which depends on the unknown result type of `len` (choice 1) and on the index type (choice 2). Both give the same results for every input.
6. **Inner-loop bound.** The inner loop runs to `n - 1 - i` (line 11), which skips the elements that the previous passes have already put in place. The other choice is `n - 1`, which gives the same output with more comparisons. The brief asks for swapping adjacent out-of-order elements, and both bounds do that.
7. **Equal elements.** The swap happens only on `ys[j] < ys[j + 1]` (line 12), so equal elements are never swapped and keep their order. The other choice is `<=`, which would also terminate because the pass count is bounded, and would give the same printed output for integers, since equal integers look the same.
8. **Using the loop variable.** `for x in ys` with `_ = x` (lines 5 and 6) avoids a variable that is unused. The other choice is an index loop with `while`, which needs a bound (choice 1 again). The `for` version is shorter and needs no bound.
9. **Printing.** `main` prints each element with its own `print` call (line 34). The other choice is `join` with a `str` conversion, which would print one line, not one line per element, so it does not match the brief.

## confidence

About 80% that the checker accepts the program as written, with no edits.

The parts I am surest of: the `runs` function (lines 21 to 30) and `main` (lines 32 to 35) use only literals, `bool` and `i64` values, `for`, `if` and `@` writes, and I checked each against the grammar. The `sorted_desc` loops (lines 8 to 17) use the same forms.

The line I am least sure of is line 12, `if ys[j] < ys[j + 1]`, and with it the index lines 13 to 15. The spec does not say which integer type an index must have (choice 2). If indices must be a type other than `i64`, these lines fail. The next least sure line is line 6, `_ = x`, which relies on the reading that a discard of a loop variable counts as a use.

## context

Only the files in this directory reached my context: `brief.md`, `spec.md`, `run.json` and `run.err`. `run.json` and `run.err` were empty, so they added nothing. I read no file outside this directory and used no tool other than reading and writing files here, as the brief requires.

Session metadata that the environment supplies also reached my context: the working directory path, a git status snapshot listing `run.err` and `run.json` as untracked files, the scratchpad path, the date, and an account email address. I did not use any of this metadata in the program or in this report, apart from the file names and the directory the files are in.
