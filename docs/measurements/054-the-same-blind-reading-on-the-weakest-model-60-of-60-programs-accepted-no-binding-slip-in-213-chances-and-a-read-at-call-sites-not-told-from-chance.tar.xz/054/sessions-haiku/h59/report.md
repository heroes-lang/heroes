# Report

## program

```
function sorted_desc(xs: [i64]) -> [i64]
    out @= xs
    n := to_i64(len(xs)).must()
    i @= 0
    j @= 0
    while i < n
        j = 0
        while j < n - 1 - i
            if out[j] < out[j + 1]
                t := out[j]
                out[j] = out[j + 1]
                out[j + 1] = t
            j = j + 1
        i = i + 1
    return out

function runs(xs: [i64]) -> i64
    n := to_i64(len(xs)).must()
    if n == 0
        return 0
    groups @= 1
    i @= 1
    while i < n
        if xs[i] != xs[i - 1]
            groups = groups + 1
        i = i + 1
    return groups

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

## sentences

Line numbers refer to the program above, counted from its first line.

1. "Signatures are always explicit; inference is local only." Governs lines 1 and 17 (the signatures of `sorted_desc` and `runs`, with their `-> [i64]` and `-> i64`).
2. "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 2, 3, 4, 5, 7, 13, 14, 18, 21, 22, 25, 26 (`:=` for `n` and `t`; `@=` for `out`, `i`, `j`, `groups`; `=` for `j`, `i`, `out[j]`, `out[j + 1]`, `groups`).
3. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds ... a read is a use and a write is not, except through an `@` parameter." Governs lines 2 to 5 and 21 to 22. Every cell is re-bound (`out` by lines 11 and 12, `j` by lines 7 and 13, `i` by lines 14 and 26, `groups` by line 25), and every binding is read (`n` by lines 6, 8, 19 and 23, `t` by line 12).
4. "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs line 2 (`out @= xs`). `xs` stays unchanged, so the parameter needs no `@` mark.
5. "Binding = [ ":" Type ] ( ":=" | "@=" ) Expression NEWLINE." Governs lines 2, 3, 4, 5, 10, 18, 21 and 22, all written as `name := expr` or `name @= expr` with no type annotation.
6. "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `0`, `1`, `2`, `9` and the array literals in lines 30 and 32. With no other context they are `i64`, and the arrays are `[i64]` from the parameter types.
7. "`[T]` | dynamic array, indices from 0." Governs the indexing in lines 9, 10, 11, 12, 24. Index values start at 0 and stay in bounds, so no index abort is reached.
8. "`to_i8` ... `to_u64` give a `T?`, because the number may not fit. `to_i64` takes a float too, truncating toward zero." Governs lines 3 and 18: `to_i64(len(xs))` is an `i64?`.
9. "`.must()` | extract or abort" (table row in section 6). Governs lines 3 and 18, where `.must()` takes the `i64` out of the `i64?`. The conversion cannot fail for a length.
10. "Built-ins: `print(...)` ... `len` ..." Governs `len(xs)` in lines 3 and 18.
11. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 31 and 32. Each `i64` prints on its own line.
12. "`while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs the three `while` loops (lines 6, 8, 23) and the `for` loop (line 30) over the array returned by `sorted_desc`.
13. "`if cond` / `else if` / `else` take only `bool`." Governs the conditions in lines 9, 19 and 24. Each is a comparison that yields `bool`.
14. "Comparison ... (`< <= > >=`: a number only)." Governs `<` in lines 6, 8, 9, 23 and `!=`, `==` in lines 19 and 24. All operands are `i64`.
15. "Precedence, strongest first: ... `* / %` → `+ -` ..." together with "Sum = Product { ( "+" | "-" ) Product } ." Governs `n - 1 - i` in line 8, which parses as `(n - 1) - i`, and `i - 1` in line 24. Both are left-associative and give the intended values.
16. "A function with a `->` must `return` on every path that reaches its end." Governs `sorted_desc` (line 15) and `runs` (lines 20 and 27). The early `return 0` in line 20 covers the empty-array path.
17. "A statement after a jump, in its block, is a compile error." Governs line 20: the `return 0` is the last statement of its `if` block, and line 21 sits in the function block after that `if`.
18. "Outside brackets a line ends its statement." Governs every line of the program. No statement spans lines, so no bracket continuation is used.
19. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs the whole program. Each level is indented by 4 spaces and no line has a tab, a brace, a semicolon or a parenthesised condition.
20. "Place = ident { "." ident | "[" Expression "]" } ." Governs the element writes in lines 11 and 12, which are `out[j] = ...` and `out[j + 1] = ...` on a mutable cell.
21. "`for x in xs`" and "Declaration order never matters but a group's (section 13)." Governs line 30 calling `sorted_desc` and line 32 calling `runs`. Each callee is declared above its use, and the program does not rely on order either way.
22. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 29.
23. "Param = "@" ident ":" Type | ident ":" Type [ "lent" ] ." Governs the parameters `xs` in lines 1 and 17. Each is a plain read-only parameter.

## choice_points

1. **Direction of the swap.** Chosen: swap when `out[j] < out[j + 1]` (line 9), which puts the larger element first. Other choice: swap when `out[j] > out[j + 1]`, which gives ascending order, the opposite of the brief.
2. **Copy versus in-place parameter.** Chosen: copy into the local cell `out` (line 2), so the caller's `xs` is untouched. Other choice: mark the parameter `@xs` and sort the caller's array in place. That would require the caller to pass a mutable place, and the brief's call `sorted_desc([...])` passes a literal, which would be refused.
3. **Type of `len`.** The spec does not state what `len` returns. Chosen: wrap it as `to_i64(len(xs)).must()` (lines 3 and 18), so the program compiles whether `len` returns `i64`, `u64` or another integer type. Other choice: use `len(xs)` directly. That is accepted only if `len` returns `i64`; otherwise `n` would not match the `i64` literals in `i < n`, which is a type error.
4. **Whether `to_i64` returns `T?`.** The spec's text ("`to_i8` ... `to_u64` give a `T?`") puts `to_i64` in that range, and separately says `to_i64` takes a float too, so I read it as `i64?`. Other reading: `to_i64` returns a plain `i64`. Then `.must()` on lines 3 and 18 is a type error. This is the main reason the confidence is not higher.
5. **Index type.** The spec does not say which integer type an index must have. Chosen: `i64`, since all indices are `i64` cells (`i`, `j`). Other choice: a `u64` or `len`-typed index would be needed only if the checker insisted on a particular index type, which the spec does not state.
6. **Loop form.** Chosen: `while` loops with `@=` counters (lines 4 to 14, 22 to 26). Other choice: `for i in range(from: 0, to: n)`. `range` takes two parameters of one type, so its arguments must be named (`from:`, `to:`), and that form would give the same output.
7. **Empty input in `runs`.** Chosen: return `0` when `n == 0` (lines 19 and 20). Other choice: start with `groups @= 1` regardless, which returns `1` for an empty array. That is wrong, because an empty array holds no groups.
8. **Bubble sort bounds.** Chosen: the inner loop runs to `n - 1 - i` (line 8), so each pass stops before the already-placed tail. Other choice: run to `n` every pass. That also sorts correctly, with extra comparisons, and it would read `out[j + 1]` past the end on the last pass and abort.
9. **Output shape of `main`.** Chosen: one `print(x)` per element (line 31), then one `print` of `runs` (line 32). Other choice: `join` the elements into one string first. The brief asks for one element per line, so the chosen form is the one required.
10. **Temporary for the swap.** Chosen: a block-local `t := out[j]` (line 10). Other choice: no tuple or multiple assignment exists in this spec, so a named temporary is the only route.
11. **Variable names.** Chosen: `n`, `i`, `j`, `t`, `out`, `groups`. None shadows another binding and none is a `use` name, since the file has no `use` lines.

## confidence

About 85 percent that the checker accepts the program unchanged on the first try.

The least certain line is line 3, and the same expression on line 18: `n := to_i64(len(xs)).must()`. It depends on two readings of the spec that the text does not state outright: what type `len` returns (answered by wrapping it in `to_i64`), and whether `to_i64` returns `i64?` (which `.must()` requires). If `to_i64` returns a plain `i64`, both lines fail. The remaining lines use only literal-typed `i64` arithmetic, plain `while` and `if`, array indexing and element assignment, and `print`, and I see no construct that the spec leaves open there. I did not run the checker, since I cannot run anything in this task.

## context

Only files in this directory reached my context: `brief.md`, `spec.md`, `run.json` and `run.err`. The last two are empty, and I read them only because they sit in this directory. Nothing outside this directory was read. My context also held the harness's environment notes and a git status snapshot, which came from the session setup, not from any file in this directory; I did not use them for the program.
