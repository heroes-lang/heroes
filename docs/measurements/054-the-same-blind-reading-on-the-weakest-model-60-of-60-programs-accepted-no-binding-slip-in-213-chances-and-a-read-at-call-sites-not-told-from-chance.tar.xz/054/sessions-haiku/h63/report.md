## verdict

Refused, on lines 20 and 22 of `main.hero`.

- Line 20, `step = 2`: `step` was bound with `$=` on line 10. A `$=` binding is fixed, and `=` only re-binds a mutable cell, so this line is refused.
- Line 22, `last @= words[0]`: `last` is a mutable cell that nothing re-binds. The spec refuses a cell nothing re-binds, and a read does not count as a re-binding.

Everything else is accepted as written. The rest of the program type-checks: the literals default to `i64`, the map reads return `V?` and are unwrapped with `.default(0)`, the record construction names all its fields, and every binding is used.

## lines

Lines holding `=` or `@` (the `@` in a signature or call counts, as does the `=` in a `Place = Expression` statement):

| line | source | new name, changes an existing name, or neither | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (`c`, `by`, parameters) | "Mutable parameters are marked `@` in the signature"; grammar `Param = "@" ident ":" Type` |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (`c`, its field `hits`) | "`=` re-binds it, or a field or element inside one" |
| 9 | `words $= ["a", "b", "a", "c", "a"]` | *new name* (`words`) | "`$=` binds once, forever."; "`x $= 5 # immutable binding, type inferred`" |
| 10 | `step $= 1` | *new name* (`step`) | "`$=` binds once, forever." |
| 11 | `counts: {str: i64} @= {}` | *new name* (`counts`) | "`@=` declares a mutable cell"; "an empty one needs an annotation: ... `m: {str: i64} @= {}`" |
| 12 | `total @= 0` | *new name* (`total`) | "`@=` declares a mutable cell" |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (`counts`, one element) | "`=` re-binds it, or a field or element inside one"; "`m[k] = v` inserts or replaces" |
| 16 | `total = total + step` | *changes an existing name* (`total`) | "`=` re-binds it"; "`v = v + 1 # re-binding`" |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* (`c`) | "`@=` declares a mutable cell"; "Record construction is a call with field names, always mandatory" |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, through the `@` argument) | "an `@` argument counting" (in the cell rule); "Either way the callee works on the caller's place itself" |
| 20 | `step = 2` | *changes an existing name* (`step`), which the checker refuses | "`$=` binds once, forever."; "`@=` declares a mutable cell, and `=` re-binds it" |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, through the `@` argument) | same as line 19 |
| 22 | `last @= words[0]` | *new name* (`last`), refused as a cell nothing re-binds | "`@=` declares a mutable cell"; "a cell nothing re-binds" is a compile error |

## sentences

Quoted from `spec.md`, in the order the verdict depends on them.

1. Section 5: "`$=` binds once, forever."
2. Section 5: "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
3. Section 5: "All bindings are initialised."
4. Section 5: "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
5. Section 5: "`x $= 5 # immutable binding, type inferred`" and "`v = v + 1 # re-binding`" (from the example block).
6. Section 9: "Mutable parameters are marked `@` in the signature and at the call site".
7. Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
8. Section 9: "Record construction is a call with field names, always mandatory:"
9. Section 10: "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"
10. Section 6, table row: "`.default(v)` | extract or fall back"
11. Section 3: "No implicit conversions, widths included: `1 + 2.0` is an error."
12. Section 2: "A literal takes the type its context asks for [...] otherwise `i64`." (the sentence has an example in between, omitted here)
13. Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing."
14. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
15. Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

Changes from `main.hero`: line 10 `step $= 1` becomes `step @= 1` (so line 20 re-binds a cell), and line 22 `last @= words[0]` becomes `last $= words[0]` (so it is not a cell that nothing re-binds).

This program prints:

```
5
5
a
```

Worked by hand: `counts` ends with `a` = 3, `c` (`hits`) = 0 + 3 = 3, then 3 + 2 = 5; `total` = 5 after five loop iterations; `last` = `words[0]` = `a`.

## choice_points

1. **Fixing line 20.** I made `step` a cell (`step @= 1`), which keeps the program's meaning. The other choice, removing or altering line 20, changes the output: removing line 20 leaves `step` at 1, so `c.hits` becomes 4 and the program prints `4`, `5`, `a`. Writing `step $= 2` on line 20 would be a second binding of `step` in the same file, which the spec refuses as shadowing.
2. **Fixing line 22.** I chose `last $=` (no cell needed). The other choice, keeping `@=` and adding a re-binding such as `last = words[0]`, is also accepted and prints the same output. "Last" might mean `words[words.len() - 1]` rather than `words[0]`. For this input both give `a`, so the output is the same either way. I kept `words[0]` because that is what the program as written does.
3. **Refusing `=` on a `$=` name (line 20).** I read `step = 2` as a re-binding of an immutable name and refused it. The other reading is that `=` may re-bind any existing name. Then the program is accepted as written, and it prints `5`, `5`, `a`, the same as the fixed program. The spec does not state this case in one sentence; I inferred it from sentences 1 and 2.
4. **Classifying line 5.** I counted the `@c` and `by` parameters as new names. The other choice, *neither*, would apply if the signature were read as introducing no binding. I took the parameters to be names in the callee's scope.
5. **Classifying lines 19 and 21.** I counted the `@` argument as changing the existing name `c`, because the spec counts an `@` argument as a write to a cell. The other choice, *neither*, reads the call as only lending the place, with the write done inside `bump`. Only the table changes, not the verdict.
6. **Treating line 20 as "changes an existing name".** This is the reading the line would have if it were accepted. Under the refusal it still names an existing name, so I report it that way.

## confidence

- **High** that line 22 is refused: sentence 4 names "a cell nothing re-binds" as a compile error, and no line in the program re-binds `last`.
- **High** that the fixed program prints `5`, `5`, `a` and that the checker accepts it. I checked each expression's type and each cell's re-binding by reading.
- **Fairly high** that line 20 is refused. The spec does not state in one sentence that `=` on a `$=` name is an error. The refusal follows from sentences 1 and 2 together.
- **Least sure**: the line classifications in the `lines` table where the spec leaves room (lines 5, 19, 21), see choice points 4 and 5. I have not run the checker; this is a reading of the spec only. I also did not check the bytes of the indentation for tabs; the file view shows four-space steps.

## context

I read only files in this directory: `brief.md`, `spec.md` (in full), `main.hero`, and `run.json` and `run.err`, which were both empty. I read no file outside the directory and ran no tool other than reading and writing files here.

Other things in my context: the session's environment preamble (working directory, platform, shell, model, date) and a session metadata block with a git status snapshot. I did not use any of it to reason about the program. Nothing else reached my context.
