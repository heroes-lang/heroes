## verdict

Refused. Two lines are refused:

- **Line 20** `step = 2`: `step` was bound with `$=` on line 10, and a `$=` name is never re-bound with `=`.
- **Line 22** `last @= words[0]`: `last` is a mutable cell, and nothing in `main` re-binds it, which the checker refuses as "a cell nothing re-binds".

Smallest change that is accepted and keeps the evident meaning:

- Line 10: `step $= 1` becomes `step @= 1` (so `step = 2` on line 20 is a re-binding of a cell).
- Line 22: `last @= words[0]` becomes `last $= words[0]` (so `last` is an immutable name that is only read).

With those two changes the program is accepted and prints:

```
5
5
a
```

Trace: the loop runs 5 times with `step` = 1, so `total` = 5 and `counts["a"]` = 3. `bump` adds 3 to `c.hits`, then `step` becomes 2 and `bump` adds 2, so `c.hits` = 5. `last` = `words[0]` = `"a"`.

Other lines checked and accepted: the `record`, `function bump` (its `@c` parameter is written on line 6), the map updates on line 15, the `.default(0)` calls, `total` (re-bound on line 16), `c` (its `@` argument on lines 19 and 21 counts as a write), and every `print`.

## lines

Lines with `=` or `@` (line numbers from `main.hero`):

| Line | Source | Category | Words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (parameter `c`) | "Param = "@" ident ":" Type" (section 4); "Mutable parameters are marked `@` in the signature and at the call site" (section 9) |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (field of cell `c`) | "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." (section 5) |
| 9 | `words $= [...]` | *new name* | "`$=` binds once, forever." (section 5) |
| 10 | `step $= 1` | *new name* (immutable) | "`$=` binds once, forever." (section 5); "A literal takes the type its context asks for ... otherwise `i64`." (section 2) |
| 11 | `counts: {str: i64} @= {}` | *new name* (mutable cell) | "`@=` declares a mutable cell, ..." (section 5); "an empty one needs an annotation: `xs: [i64] $= []` · `m: {str: i64} @= {}`" (section 10) |
| 12 | `total @= 0` | *new name* (mutable cell) | "`@=` declares a mutable cell, ..." (section 5) |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (element of `counts`) | "`=` re-binds it, or a field or element inside one." (section 5); "`m[k] = v` inserts or replaces;" (section 10) |
| 16 | `total = total + step` | *changes an existing name* (cell `total`) | "`=` re-binds it, or a field or element inside one." (section 5); code example `v = v + 1  # re-binding` (section 5) |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* (mutable cell) | "`@=` declares a mutable cell, ..." (section 5); "Record construction is a call with field names, always mandatory" (section 9) |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, through its `@` argument) | "Either way the callee works on the caller's place itself" (section 9); "a read is a use and a write is not, except through an `@` parameter" (section 5) |
| 20 | `step = 2` | *changes an existing name*, **refused** (`step` is `$=`) | "`$=` binds once, forever." and "`@=` declares a mutable cell, and `=` re-binds it, ..." (section 5) |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, through its `@` argument) | as line 19 |
| 22 | `last @= words[0]` | *new name*, **refused** (cell never re-bound) | "An unused binding or parameter is a compile error, and so is a cell nothing re-binds ..." (section 5) |

The `=` on lines 6, 15 and 16 and the `@` argument on lines 19 and 21 are the write forms. The `@` on line 5 is a parameter declaration.

## sentences

Every sentence of the specification the verdict rests on:

- "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." (section 1)
- "A literal takes the type its context asks for ... otherwise `i64`." (section 2, the middle of the sentence elided)
- "`[T]` | dynamic array, indices from 0" (section 3, table row)
- "`Param = "@" ident ":" Type | ident ":" Type [ "lent" ] .`" (section 4, grammar)
- "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." (section 8)
- "`$=` binds once, forever." (section 5)
- "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." (section 5)
- "`v = v + 1          # re-binding`" (section 5, code)
- "All bindings are initialised." (section 5)
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." (section 5)
- "`Place     = ident { "." ident | "[" Expression "]" } .`" (section 5, grammar)
- "A container literal separates elements by newline across lines and by comma on one, and an empty one needs an annotation: `xs: [i64] $= []` · `m: {str: i64} @= {}`." (section 10)
- "`m[k] = v` inserts or replaces;" (section 10)
- "| `.default(v)` | extract or fall back |" (section 6, table row)
- "arithmetic ... + - * / % ... (both sides one numeric type ... never mixed)" (section 7, operator table)
- "Mutable parameters are marked `@` in the signature and at the call site:" (section 9)
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument." (section 9)
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (section 11)

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a` (one per line).

## choice_points

1. **Fixing line 20.** I made `step` a cell (`step @= 1`). The other choice was to delete line 20 and write `bump(@c, 2)` on line 21. That prints the same output (5, 5, a), but it drops the name `step` from the second half of the program. Shadowing a `$=` name is not allowed, so a new binding for `step` on line 20 was not an option.
2. **Fixing line 22.** I made `last` immutable (`last $= words[0]`), since the program only reads it. The other choice was to keep `@=` and add a re-binding, which would be a larger change. The name `last` suggests the last word, but the code says `words[0]`. I kept `words[0]`. `words[4]` is also `"a"`, so the printed line would be the same either way.
3. **Classifying line 5** (`@c` in a signature) as *new name*. The specification does not say whether a parameter counts as a new name or as a change to the caller's place. I chose *new name*, because the parameter `c` is new inside `bump`. The other choice would make it *changes an existing name*, and would not change the verdict.
4. **Classifying lines 19 and 21** (`@` arguments) as *changes an existing name*. The specification says the callee "works on the caller's place itself" and that a write through an `@` parameter counts, but it does not use the word "changes" for a call. The other choice (*neither*) would contradict the "write" rule in section 5. The verdict does not depend on this.
5. **Literal types.** `step`, `hits` and `total` are `i64` because no other type is asked for. The other choice (a narrower type) would need an annotation and does not occur in the program.

## confidence

High on the verdict: lines 20 and 22 are refused by sentences that say so directly (`$=` binds once, forever; a cell nothing re-binds is an error). High on the printed output for the fixed program, which I traced by hand. Lower on the exact category of lines 5, 19 and 21, because the specification does not name the categories for `@` parameters and arguments. I could not run the checker, so the verdict rests on reading the specification, not on the checker's output.

## context

Only the files in this directory were used as inputs: `brief.md`, `spec.md` and `main.hero`. I also read `run.json` and `run.err`, which are in the same directory but are not named in the brief. Both were empty, and neither affected the verdict. Other things reached my context but were not used: the system and environment notes (the working-directory path, the scratchpad path, the platform details, the model description and the date), the git status snapshot, which lists `run.err` and `run.json` as untracked files and shows one recent commit, and the user's account email. I did not read any file outside this directory and did not run any tool other than reading and writing files here.
