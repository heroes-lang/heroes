## verdict

Refused, on two lines:

- **Line 20** (`step = 2`): `step` was bound with `$=` on line 10. The spec says `$=` binds once, forever, and that `=` re-binds only a cell (or a field or element inside one). Re-binding an immutable name is refused.
- **Line 22** (`last @= words[0]`): `last` is a mutable cell that nothing re-binds. The spec makes that a compile error. `last` is read on line 25, but a read is a use, not a re-binding.

Nothing else in the file is refused. Lines 15 and 16 re-bind existing cells, line 19 and line 21 pass `c` to an `@` parameter (which counts as a write), and line 6 writes through the `@` parameter `c`.

As written, the program would print nothing, because the checker refuses it.

Smallest accepted change: line 10 becomes `step @= 1` and line 22 becomes `last $= words[0]`. The fixed program prints:

```
5
5
a
```

Trace: `counts` ends as `a: 3, b: 1, c: 1`, and `total` ends at 5 (five loop iterations, each adding `step` = 1). `bump(@c, 3)` sets `c.hits` to 3, then `step` is 2 and `bump(@c, 2)` sets it to 5. `last` is `words[0]`, which is `"a"`.

## lines

| line | kind | category | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)`: parameter `c` | *new name* | "Mutable parameters are marked `@` in the signature and at the call site"; section 4 grammar `Param = "@" ident ":" Type`. The `@` introduces the parameter name `c` for the body. |
| 6 | `c.hits = c.hits + by` | *changes an existing name* | "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." The `@` parameter is written through, as "an `@` parameter nothing writes" requires. |
| 9 | `words $= [...]` | *new name* | "`$=` binds once, forever." |
| 10 | `step $= 1` | *new name* | "`$=` binds once, forever." (This binding is the cause of the refusal on line 20.) |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell, and `=` re-binds it". |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell". |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* | "`=` re-binds it, or a field or element inside one"; "`m[k] = v` inserts or replaces". |
| 16 | `total = total + step` | *changes an existing name* | "`=` re-binds it" (`total` is a cell declared with `@=` on line 12). |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell". |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* | "Mutable parameters are marked `@` ... at the call site"; "the callee works on the caller's place itself"; the `@` argument counts as a write for "a cell nothing re-binds". |
| 20 | `step = 2` | *changes an existing name* (attempted; refused) | "`$=` binds once, forever"; "`=` re-binds it" applies to a cell, and `step` is not one. |
| 21 | `bump(@c, step)` | *changes an existing name* | Same as line 19. The second argument `step` is a plain read and is not `@`. |
| 22 | `last @= words[0]` | *new name* (refused: a cell nothing re-binds) | "`@=` declares a mutable cell"; "so is a cell nothing re-binds"; "a read is a use and a write is not". |

## sentences

From section 5 (Bindings):

- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."

From section 9 (Functions and calls):

- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."

From section 2 (Literals):

- "A literal takes the type its context asks for … otherwise `i64`."

From section 6 (Failure):

- "`.default(v)` | extract or fall back"

From section 10 (Strings, arrays, maps):

- "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"

From section 11 (Built-ins):

- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

From section 1 (Files and layout):

- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output:

```
5
5
a
```

## choice_points

1. **Which fix for line 20.** I made `step` a cell (line 10 becomes `step @= 1`), because the program plainly intends `step` to change from 1 to 2. The other choice, removing line 20 and writing `bump(@c, 2)` on line 21, also yields an accepted program, and it prints the same output (5, 5, a), because `step` is then never used after the loop. It changes the program's shape more, so I did not take it.
2. **Which fix for line 22.** I made `last` immutable (`last $= words[0]`), because nothing re-binds it. The other choice, keeping `@=` and adding a re-binding later such as `last = words[4]`, would be accepted too, but it would print a different value (`"a"` here, but only by coincidence of the data) and would add a re-binding the source never states. I chose the form that adds no new behaviour.
3. **Classifying line 20.** The line as written tries to change `step`. I marked it *changes an existing name* (the attempt), not *neither*, because the attempt is what the author evidently means. The checker refuses the attempt, so no name changes in the program as submitted.
4. **Classifying line 5.** I marked the `@c` parameter as *new name*. The spec does not say a parameter counts as a binding, but section 5 lists "a parameter" alongside bindings for the unused-name rule, so I took it to introduce a name. The other reading, *neither*, would not change any verdict.
5. **Whether an `@` argument is a re-binding.** I read "an `@` argument counting" as meaning `bump(@c, ...)` counts as a write to `c`, so `c` is not "a cell nothing re-binds". If an `@` argument did not count, line 19 would be refused as well, and `c` would need a separate re-binding. I took the reading the sentence states.

## confidence

High (about 90 percent) that the checker refuses the program as written, on lines 20 and 22. Those two refusals follow from explicit sentences in section 5.

High that the fixed program is accepted and prints `5`, `5`, `a`, subject to the reading of "an `@` argument counting" in choice 5.

Less sure of: the category labels for lines 5, 19 and 21, which depend on how the spec's terms "parameter" and "`@` argument" should be classified. The spec does not define these categories directly. I also did not verify the indentation bytes of `main.hero`; it displayed with spaces and the spec forbids tabs, so a tab would be a further refusal I cannot rule out from the text view alone.

## context

Only the files in this directory were read: `brief.md`, `spec.md`, `main.hero`, and the two empty files `run.json` and `run.err`, which the brief does not mention but which are in this directory. No file outside this directory was read, and no tool other than file reads and this write was used.

Other material reached my context but is not a file from this directory: the session's environment description (working directory, platform, model identity, date, budget), and a system-supplied account and git status snapshot. None of it bears on the program's checking. I did not use any of it in the analysis.
