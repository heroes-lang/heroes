# Report: main.hero under the Heroes checker

## verdict

Refused, on lines 20 and 22.

- Line 20 `step = 2`: `step` is bound on line 10 with `$=`, which "binds once, forever". Only a cell (`@=`) can be re-bound with `=`, so the checker refuses the re-binding.
- Line 22 `last @= words[0]`: `last` is declared as a mutable cell and nothing ever re-binds it, and "a cell nothing re-binds ... is a compile error".

Smallest accepted change (two token edits, lines 10 and 22):

- Line 10: `step $= 1` becomes `step @= 1`, so that the re-binding on line 20 is legal.
- Line 22: `last @= words[0]` becomes `last $= words[0]`, since it is never re-bound.

The corrected program prints:

```
5
5
a
```

Trace: `words` is `a b a c a`, so the loop sets `counts` to a=3, b=1, c=1 and `total` to 5 (step is 1 in every pass). `bump(@c, 3)` makes `c.hits` 3. `step` becomes 2, and `bump(@c, 2)` makes `c.hits` 5. `last` is `"a"`.

The program as written would print nothing, because the checker refuses it.

## lines

Every line of `main.hero` that contains `=` or `@`. Lines 9 and 10 and the other `$=` lines count because `$=` contains `=`.

| line | new name | changes an existing name / neither | words of the specification relied on |
|---|---|---|---|
| 5 | `c` (the `@` parameter) | neither | "Mutable parameters are marked `@` in the signature and at the call site"; `Param = "@" ident ":" Type` |
| 6 | none | changes an existing name (`c.hits`, a field inside the cell `c`) | "`=` re-binds it, or a field or element inside one"; `Simple = Place "=" Expression` |
| 9 | `words` | new name | "`$=` binds once, forever."; `Binding = [ ":" Type ] ( "$=" | "@=" ) Expression` |
| 10 | `step` | new name | "`$=` binds once, forever." |
| 11 | `counts` | new name | "`@=` declares a mutable cell" |
| 12 | `total` | new name | "`@=` declares a mutable cell" |
| 15 | none | changes an existing name (an element of the cell `counts`) | "`=` re-binds it, or a field or element inside one"; `Place = ident { "." ident | "[" Expression "]" }` |
| 16 | none | changes an existing name (the cell `total`) | "`=` re-binds it" |
| 18 | `c` | new name | "`@=` declares a mutable cell" |
| 19 | none | changes an existing name (`c`, through the `@` argument) | "the callee works on the caller's place itself"; "an `@` argument counting" |
| 20 | none | neither, as written: `=` may only re-bind a cell, and `step` is `$=`, so the line changes nothing and is refused | "`$=` binds once, forever."; "`=` re-binds it" |
| 21 | none | changes an existing name (`c`, through the `@` argument) | as line 19 |
| 22 | `last` | new name | "`@=` declares a mutable cell" (and, by the same sentence, the refusal of a cell nothing re-binds) |

## sentences

Every sentence of the specification the verdict rests on, quoted (section and line numbers are those of `spec.md`):

- Section 5, line 134: "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- Section 5, line 137: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- Section 5, line 151 (grammar): "`Simple    = "_" Binding | Place "=" Expression NEWLINE`" ... "`Place     = ident { "." ident | "[" Expression "]" } .`"
- Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"
- Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- Section 2, line 44: "otherwise `i64`."
- Section 3 table, `[T]`: "dynamic array, indices from 0"
- Section 8, line 248: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)."
- Section 10, line 311: "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"
- Section 10, line 313: "An out-of-bounds index or slice aborts, and so does a slice that splits a character."
- Section 6, table row: "`.default(v)` | extract or fall back"
- Section 11, line 323: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

The program I would submit, whole:

```heroes
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

It prints `5`, `5`, `a`, one per line.

## choice_points

1. **Which fix for line 20.** I made `step` a cell (`step @= 1`). The other choice, keeping line 10 as `$=` and writing the second value under a new name (for example `step2 $= 2` on lines 20 and 21), also prints `5`, `5`, `a`, but it changes the program's names rather than its binding kind. I chose the one-token change that keeps the author's `step` throughout.
2. **Which fix for line 22.** I made `last` immutable (`last $= words[0]`). The other choice, `print(words[0])` with the `last` line removed, also prints `a` and keeps the program's output the same. I chose to keep the name.
3. **Whether a `@` parameter is a new name (line 5).** I treated `c` in `@c: Counter` as a new name, since a parameter binds a name in the callee. The other choice is "neither", because `@` only marks that the callee works on the caller's place. The verdict does not depend on this.
4. **Whether an `@` argument changes an existing name (lines 19 and 21).** I treated these as "changes an existing name", because the callee writes through `c`. The other choice is "neither", since the call line itself has no `=`. The specification's phrase "an `@` argument counting" supports the first choice. The verdict does not depend on it.
5. **Line 20 classification.** As written, `=` on a `$=` name is refused, so I classed it as "neither". The author evidently means "changes an existing name". The other choice would describe the intent rather than the accepted program. The verdict does not depend on it.
6. **Whether `$=` lines count as lines holding `=`.** I included them, since `$=` contains `=`. The other choice would drop lines 9 and 10 from the table, and the verdict would not change.
7. **Unused record fields.** `Counter.label` is never read. The specification makes unused bindings and parameters errors, and says nothing about unused fields, so I took them not to be errors. The other choice would refuse line 2, which the verdict does not change because the record's declaration line is not one of the lines the brief asks about.
8. **Literal typing.** `step`, `total`, `hits` and the map values are `i64` by the "otherwise `i64`" default. The other choice would be a narrower type named by the author; no line in the program forces one, so the output is unchanged.

## confidence

- **High** that the program as written is refused on lines 20 and 22. Both refusals follow from explicit sentences in section 5.
- **High** that the corrected program prints `5`, `5`, `a`. The trace is short and every operation is defined in the specification.
- **Moderate** on the line classifications in the `lines` table for lines 5, 19, 20 and 21, as listed under choice points 3 to 5.
- **Limit**: I read `main.hero` through the file viewer, which does not make tab characters or stray bytes visible. I did not verify that the indentation is exactly four spaces with no tabs. If it contains a tab, the checker would refuse the file for that reason as well, and the fix would include re-indenting.
- **Limit**: I cannot run the checker, so the verdict is by reading the specification, not by executing it.

## context

- The brief names `spec.md` and `main.hero` as the only inputs. I also opened `run.json` and `run.err`, which sit in this directory and appeared as untracked files in the session's git status. Both are empty, and they did not inform any part of this report. I read them in error, as the brief does not list them as inputs.
- Beyond this directory's files, my context holds the session's environment information: the working directory, platform, shell, scratchpad path, the model and date, a git status snapshot of the repository (branch `main`, one commit, the two untracked files above), and the user's account identifier. None of it was used for the verdict, the program, or the classifications.
- I did not read any file outside this directory and used no tool other than reading and writing files here. I did not run anything.
