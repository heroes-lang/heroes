# Report

## program

```
# One record for each named stock level.
record Item
    name: str
    qty: i64

# Adds n to the item called name, or appends it when there is none.
function restock(@items: [Item], name: str, n: i64)
    out: [Item] @= []
    found @= false
    for item in items
        if item.name == name
            found = true
            out = out.push(Item(name: item.name, qty: item.qty + n))
        else
            out = out.push(item)
    if !found
        out = out.push(Item(name: name, qty: n))
    items = out

# Subtracts n from the item called name when it holds at least n.
function take(@items: [Item], name: str, n: i64) -> bool
    out: [Item] @= []
    found @= false
    for item in items
        if item.name == name && item.qty >= n
            found = true
            out = out.push(Item(name: item.name, qty: item.qty - n))
        else
            out = out.push(item)
    if found
        items = out
    return found

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    apple_ok $= take(@items, "apple", 5)
    pear_ok $= take(@items, "pear", 9)
    print(apple_ok)
    print(pear_ok)
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output, one value per line: `true`, `false`, `4`.

Trace: restock apple 3 gives [apple 3]; restock pear 2 gives [apple 3, pear 2]; restock apple 4 gives [apple 7, pear 2]. take apple 5 gives true, leaving apple 2. take pear 9 gives false, leaving pear 2. The sum is 2 + 2 = 4.

## sentences

Line numbers refer to the program above, counted from its first line.

- §1: "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 34.
- §2: "A literal takes the type its context asks for" and "otherwise `i64`." Governs lines 43 (`total @= 0`, an `i64` cell) and 36 to 38 (the `i64` arguments, taking the parameter type).
- §3: "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." Governs lines 13, 15, 27 and 29, where each item is pushed as a fresh copy into `out`.
- §4: "`function ident [ Generics ] Params [ "->" Type ] Block`" (grammar of `Declaration`). Governs lines 7, 21 and 34, the three function headers.
- §5: "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 8, 9, 12, 18, 22, 23, 26, 31, 35, 39, 40, 43 and 45.
- §5: "Signatures are always explicit; inference is local only." Governs lines 7 and 21 (every parameter and return type is written).
- §5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends" Governs line 18 (`items` in `restock` is written), line 31 (`items` in `take` is written), lines 9 and 12 (`found` is re-bound), and lines 13 and 15 (`item` is used).
- §5: "Shadowing is a compile error" Governs lines 10, 24 and 44 (`item`), which are the only loop names, each in a different function scope, and line 7 (`name`), which no other binding in the file takes.
- §6 and §12 do not apply; the program uses no `T?` and no tests.
- §7: "boolean && || ! (bool only; && and || short-circuit)" Governs lines 16 (`!found`) and 25 (`&&`).
- §7: "`< <= > >=`: a number only" Governs line 25 (`item.qty >= n`).
- §7: "Precedence, strongest first: call, `.` and `::`" followed by "comparisons" and then "`&&`" in the same ordering list. Governs line 25: `&&` binds weaker than `==` and `>=`, so the condition is `(item.name == name) && (item.qty >= n)`.
- §7: "`==` is structural equality on any two values of one type" Governs lines 11 and 25 (string comparison).
- §8: "`if` and `match` are expressions and may stand as statements" and "`if cond` / `else if` / `else` take only `bool`", followed by "there is no truthiness." Governs lines 11, 16, 25 and 30.
- §8: "Loops: `while cond` and `for x in xs`, over an array or a `range`" Governs lines 10, 24 and 44 (`for ... in items`, where `items` is an array).
- §8: "A function with a `->` must `return` on every path that reaches its end" Governs line 32 (`return found`), the only path to the end of `take`.
- §9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs lines 13, 17, 27 and 29 (`Item(name: ..., qty: ...)`).
- §9: "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs lines 13, 15, 17, 27 and 29 (`out.push(...)`, which is `push(out, ...)`).
- §9: "UFCS does not apply when the first parameter is `@`." Governs lines 13 to 29: the program calls `push` only on `out`, which is a plain cell, and never on `items`.
- §9: "Mutable parameters are marked `@` in the signature and at the call site" Governs lines 7, 21, 36, 37, 38, 39 and 40.
- §9: "When two parameters in a signature share a type, named arguments are mandatory at the call site" Does not apply: `restock` has `str` and `i64`, and `take` has `str` and `i64`. Lines 36 to 40 are positional and need no names.
- §10: "an empty one needs an annotation: `xs: [i64] $= []`" Governs lines 8, 22 and 35 (`out: [Item] @= []` and `items: [Item] @= []`).
- §10: "`xs = xs.push(4)` grows in place when `xs` is a plain name" Governs lines 13, 15, 17, 27 and 29: `out` is a plain name, so the pushes do not copy the array.
- §11: "`push`" (listed as a built-in) Governs lines 13, 15, 17, 27 and 29.
- §11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 41, 42 and 46. "a `bool` prints `true` or `false`." Governs lines 41 and 42.
- §11: `len` is listed as a built-in with no stated return type. The program does not call it; see choice_points.
- §1: "Syntax is ASCII-only" Governs the whole program, which is ASCII.
- §1: "`#` comments to end of line" Governs lines 1, 6 and 20.

## choice_points

1. **Rebuild the list versus index loop.** I chose to build a new list `out` with a `for item in items` loop, then assign it back (lines 8 to 18 and 22 to 31). The spec gives no return type for `len`, so an index loop (`i @= 0`, `while i < items.len()`, `items[i].qty = ...`) would be a guess: if `len` returns `u64`, comparing it with an `i64` index is a type error. The index loop compiles only if `len` returns `i64`.
2. **Whether `take` writes the list on failure.** I assign `items = out` only when `found` is true (lines 30 and 31). The other choice, always assigning `items = out`, leaves the same contents on failure, so the observable output is the same. I chose the conditional so that the failure path visibly changes nothing.
3. **Where `restock` appends.** I append at the end (line 17). Inserting at the front would give a different list order. Output is unchanged because `take` and the sum do not depend on order.
4. **`take` updates every matching item.** Line 25 matches on name and quantity, and the rebuild updates every match. Only one item per name can exist, because `restock` never adds a duplicate. Stopping at the first match would need an index, which is choice 1.
5. **Sum by loop versus `fold`.** I used a `for` loop (lines 43 to 45). The alternative is `fold(0, add)` with a named two-parameter function `add`. Both give `4`; the loop needs no extra declaration.
6. **Binding each result before printing.** I wrote `apple_ok $= take(@items, ...)` (line 39) and printed the name. The other choice, `print(take(@items, "apple", 5))`, puts an `@` argument inside another call's arguments. The spec's rule about `@` arguments reaching one another concerns arguments of the same call, so the direct form likely also compiles, but the binding form avoids the question.
7. **`!found` versus `found == false`.** I used `!` (line 16). The other form compiles too and gives the same result.
8. **Type of the literal `0` in `total @= 0`.** It takes `i64` by default, since the context gives no other type (line 43). Choosing another width would need an annotation and would change the type of `total`.
9. **Comments.** I included short `#` comments above the declarations. Leaving them out gives the same program behaviour.
10. **Names.** `out`, `found`, `apple_ok`, `pear_ok`, `total`. I avoided `ok`, which may be reserved for `ok(...)`.

## confidence

I am fairly confident, about 85 percent, that the checker accepts this program on the first try. I could not run the checker, so this rests on reading the spec.

The line I am least sure of is line 18 (`items = out`), and line 31 (`items = out`, inside `take`). The spec says `=` re-binds "a mutable cell, or a field or element inside one", and it says an `@` parameter must be written or ended. It does not state in those words that `=` may re-bind a whole `@` parameter. I read the rule as allowing it, because a parameter marked `@` is the caller's cell and the spec counts writes to it. If the checker refuses a whole-name re-bind of an `@` parameter, the fix is an index loop, which depends on the unspecified return type of `len` (choice 1).

## context

I read only the files in this directory: `brief.md`, `spec.md`, `run.json` and `run.err`. `run.json` and `run.err` are both empty. Nothing outside this directory reached my context. I did not run any tool that executes code, and the brief does not allow one.

I also created a stray empty file, `report.md.tmp`, in this directory by mistake while trying to edit a line. I have no delete tool, so it remains and should be removed by hand.
