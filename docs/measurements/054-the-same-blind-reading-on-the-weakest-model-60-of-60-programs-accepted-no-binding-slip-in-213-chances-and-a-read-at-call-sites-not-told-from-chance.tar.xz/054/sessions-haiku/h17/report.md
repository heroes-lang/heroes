# program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n $= to_i64(len(ys)).must()
    swapped @= true
    while swapped
        swapped = false
        i @= 1
        while i < n
            if ys[i - 1] < ys[i]
                t $= ys[i - 1]
                ys[i - 1] = ys[i]
                ys[i] = t
                swapped = true
            i = i + 1
    return ys

function runs(xs: [i64]) -> i64
    count @= 0
    seen @= false
    prev @= 0
    for x in xs
        if !seen || x != prev
            count = count + 1
        seen = true
        prev = x
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below count from 1 at `function sorted_desc`. Line 16 and line 27 are blank.

# sentences

1. Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 28 to 31.
2. Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs the indentation of every line.
3. Section 1: "No braces, no semicolons; a condition needs no parentheses." Governs lines 5, 8, 9, 22.
4. Section 1: "Outside brackets a line ends its statement: it may not end where the statement cannot, and the next line may not go on with it, ..." Governs every statement line. Each one is a complete statement on its own line.
5. Section 4: "Every top-level line starts with its kind." Governs lines 1, 17, 28.
6. Section 4: "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs lines 29 and 31, which call functions defined above them.
7. Section 4: "Signatures are always explicit; inference is local only." Governs lines 1 and 17 (typed parameters and return types).
8. Section 5: "`$=` binds once, forever." Governs lines 3, 10 (`n`, `t`), which are never re-bound.
9. Section 5: "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 2, 4, 6, 7, 11, 12, 13, 14 (cells `ys`, `swapped`, `i`), and lines 18 to 20, 23 to 25 (cells `count`, `seen`, `prev`).
10. Section 5: "All bindings are initialised." Governs lines 2 to 4, 7, 18 to 20.
11. Section 5: "An unused binding or parameter is a compile error, and so is a cell nothing re-binds ..." Governs every binding. Each `@=` cell is re-bound, each binding is read, and both parameters (`xs`) are used.
12. Section 5: "Shadowing is a compile error" Governs the names `i`, `t`, `x`, `xs`, which are each bound once in the scope where they are used.
13. Section 3, table row `[T]`: "dynamic array, indices from 0" Governs indexing in lines 9, 11, 12 and 14.
14. Section 3: "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." Governs line 2, where `ys` is a copy of `xs`.
15. Section 2: "A literal takes the type its context asks for ... otherwise `i64`." Governs the integer literals on lines 7, 18, 20, 29 and 31, and the `0` and `1` in lines 7, 14, 18, 20, 23.
16. Section 7, table row comparison: "(`< <= > >=`: a number only)" Governs lines 8 and 9 (`<` on `i64`).
17. Section 7, table row boolean: "(bool only; && and || short-circuit)" Governs line 22.
18. Section 7, precedence: "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -` → `<<` `>>` → `&` → `^` → `|` → comparisons → `&&` → `||`." Governs line 22, which parses as `(!seen) || (x != prev)`, and lines 3, 9, 11, 12, 14 where `-` and indexing bind before `<`.
19. Section 8: "`if cond` / `else if` / `else` take only `bool`" Governs lines 9 and 22, whose conditions are `bool`.
20. Section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 5, 8, 21 and 29.
21. Section 8: "A function with a `->` must `return` on every path that reaches its end, ..." Governs lines 15 and 26, the last statement of each function with a `->`.
22. Section 6, table row: "`.must()` | extract or abort" Governs line 3.
23. Section 11: "Built-ins: `print(...)` · `len` ·" Governs lines 3 and 30 to 31 (`len` and `print` are built-ins).
24. Section 11: "`to_i8` … `to_u64` give a `T?`, because the number may not fit." Governs line 3. `to_i64` gives `i64?`, so `.must()` on line 3 is required.
25. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 30 and 31.
26. Section 10: "A container literal separates elements by newline across lines and by comma on one" Governs the one-line array literals on lines 29 and 31.
27. Section 11: "An out-of-bounds index or slice aborts, and so does a slice that splits a character." Governs the indices `i - 1` and `i` in lines 9 to 12, which stay in `0 .. n - 1` because `i` runs from 1 while `i < n`.
28. Section 9: "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs nothing in this program, since each function has one parameter. Recorded so that the omission is a deliberate choice.

# choice_points

1. **Type of `len`.** The spec lists `len` as a built-in but does not give its result type. I wrote `n $= to_i64(len(ys)).must()` (line 3), which compiles whether `len` returns `i64`, `u64` or another integer, because `to_i64` takes any integer and `.must()` cannot abort on the value it gets. The other choice, `n $= len(ys)`, gives the same result only if `len` returns `i64`. If `len` returns another type, the comparison `i < n` on line 8 fails with a type mismatch, since there are no implicit conversions.
2. **How to avoid `len` in `runs`.** I used a single pass over `for x in xs` with a `seen` flag (lines 19, 21 to 25), so `runs` does not depend on `len` at all. The other choice, an index loop with `len(xs)`, returns the same values, but it inherits the risk from choice 1.
3. **Sentinel for `prev`.** `prev @= 0` (line 20) is a placeholder. The `seen` flag (line 22) keeps the placeholder from ever counting as a run. The other choice, a sentinel value outside the input, would have a wrong answer for some input, so I rejected it.
4. **Copy of the parameter.** `xs` is an immutable parameter, and the signature `function sorted_desc(xs: [i64]) -> [i64]` is fixed by the brief, so `xs` cannot be sorted in place. I copy it with `ys @= xs` (line 2). The other choice, `@xs`, changes the signature and is not allowed here.
5. **Sort loop structure.** I used a bubble sort that repeats passes while any swap happened (lines 4 to 14). The other choice, a fixed number of `n - 1` passes, produces the same output and does more comparisons. I took the first because it stops early.
6. **Swap by temporary.** I swapped with a temporary `t $=` (lines 10 to 12). The spec gives no swap operator, so this is the only option.
7. **Comparison direction.** To sort descending I swap when the left element is smaller (`ys[i - 1] < ys[i]`, line 9). The other choice, `>`, sorts ascending.
8. **Printing.** I print each element with `print(x)` in a `for` loop (lines 29 and 30). The other choice, building one string with `join`, does not fit integers, since `join` takes strings.
9. **Naming.** Functions and variables use the names the brief gives, plus lower case words. `i`, `t`, `x` each appear in only one scope, so shadowing does not arise.

If choice 1 is resolved (`len` returns `i64`), line 3 could be simplified to `n $= len(ys)`. I kept the conversion because it is valid in either case.

# confidence

I am fairly sure the checker accepts the program on the first try, about 85 percent. The uncertain parts all come from points the spec leaves open:

- Line 3 is the least certain line. It depends on three things the spec does not settle: the result type of `len`, whether `to_i64` accepts an `i64` argument (the spec lists `to_i64` among the conversions that give `T?`, and says it takes a float too, but does not state its accepted input types in full), and whether `.must()` may follow a call directly.
- Line 8 (`while i < n`) depends on line 3 having type `i64`.
- Lines 9 to 12 depend on the index type. The spec says indices start at 0 but does not name the index type. `i` is an `i64` by default, so I expect this to be accepted.
- The remaining lines use only literal types, comparisons, `$=` and `@=` bindings, `while` and `for`, and `print`, all of which the spec describes directly.

# context

Only files in this directory reached my context: `brief.md`, `spec.md`, `run.json` and `run.err`. I read `run.json` and `run.err` as well, though the brief named only `spec.md`. Both files were empty, so they had no effect on the program. I used no tool other than reading these files and writing `report.md`. I did not run anything, as the brief requires. Nothing from outside the directory reached my context.
