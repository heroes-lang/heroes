## program

```
record Item
    name: str
    qty: i64

function index_of(items: [Item] lent, name: str) -> i64
    i @= 0
    for it in items
        if it.name == name
            return i
        i @ i + 1
    return -1

function restock(@items: [Item], name: str, n: i64)
    i = index_of(items, name)
    if i < 0
        items @ items.push(Item(name: name, qty: n))
    else
        items[i].qty @ items[i].qty + n

function take(@items: [Item], name: str, n: i64) -> bool
    i = index_of(items, name)
    if i < 0
        return false
    if items[i].qty < n
        return false
    items[i].qty @ items[i].qty - n
    return true

function qty_sum(items: [Item] lent) -> i64
    total @= 0
    for it in items
        total @ total + it.qty
    return total

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    print(qty_sum(items))
```

Expected output, one value per line:

```
true
false
4
```

(apple: 3 + 4 = 7, take 5 leaves 2; pear: 2, take 9 fails and leaves 2; sum 2 + 2 = 4.)

## sentences

Line numbers refer to the program above. Quotes are exact except where marked.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." (section 1). Governs lines 35-42.
2. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." (section 4). Governs the order of the declarations: `index_of`, `restock`, `take`, `qty_sum` and `main` use the names declared above them, and the sentence says the order does not matter either way.
3. "Indentation is significant and rigid: exactly 4 spaces per level" (section 1). Governs every indented line.
4. "No braces, no semicolons; a condition needs no parentheses." (section 1). Governs lines 8, 15, 22, 24.
5. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" (section 9). Governs line 16 (`Item(name: name, qty: n)`).
6. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." (section 5). Governs the `=` bindings at lines 14 and 21, the `@=` cells at lines 6, 30 and 36, and the re-binds at lines 10, 16, 18, 26 and 32 (lines 18 and 26 re-bind an element).
7. "Signatures are always explicit; inference is local only." (section 5). Governs every signature, lines 5, 13, 20, 29 and 35.
8. "an empty one needs an annotation: `xs: [i64] = []`" (section 10). Governs line 36 (`items: [Item] @= []`).
9. "Mutable parameters are marked `@` in the signature and at the call site" (section 9). Governs lines 13 and 20 (signatures) and lines 16, 37-41 (call sites, with `@items`).
10. "a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy" (section 9). Governs lines 5 and 29 (the `lent` marks), and the unmarked calls at lines 14, 21 and 42.
11. "`xs @ xs.push(4)` grows in place when `xs` is a plain name" (section 10). Governs line 16.
12. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." (section 9). Governs line 16 (`items.push(...)`).
13. "An out-of-bounds index or slice aborts" (section 10). Governs lines 18 and 26. The index `i` is only used after the `i < 0` tests at lines 15 and 22, and `index_of` only returns a position the loop has visited, or `-1`.
14. "`==` is structural equality on any two values of one type, recursively" (section 7). Governs line 8 (`it.name == name`).
15. "`if cond` / `else if` / `else` take only `bool`" (section 8, the sentence goes on to say there is no truthiness). Governs lines 15, 22 and 24.
16. "`< <= > >=`: a number only" (section 7). Governs lines 15, 22 and 24.
17. "No implicit conversions, widths included" (section 3). Governs lines 15, 18, 24, 26 and 32: every operand is `i64`, and the literals `0`, `1` and `-1` take `i64` from their context.
18. "A literal takes the type its context asks for ... otherwise `i64`." (section 2). Governs the literals at lines 6, 10, 11, 15, 22, 24, 30 and 36.
19. "A function with a `->` must `return` on every path that reaches its end" (section 8). Governs `index_of` (return at line 11), `take` (return at line 27) and `qty_sum` (return at line 33).
20. "A statement after a jump, in its block, is a compile error." (section 8). Governs lines 23 and 25 (each `return` is the only statement of its `if` block) and line 27 (last statement of `take`).
21. "`while cond` and `for x in xs`, over an array or a `range` (section 11)." (section 8). Governs the `for` loops at lines 7 and 31, which loop over an array.
22. "An unused binding or parameter is a compile error" (section 5). Governs every binding and parameter. Each is read at least once: `i` (6, 14, 21), `it` (7, 8, 31, 32), `total` (30, 33), and `items`, `name` and `n` in each function.
23. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (section 11). Governs lines 40, 41 (a `bool`) and 42 (an `i64`).
24. "a `bool` prints `true` or `false`." (section 11). Governs lines 40 and 41 (the expected output).
25. "`()` nothing: what a function with no `->` returns" (section 3). Governs `restock` (line 13) and `main` (line 35).
26. "Every value behaves as an independent copy" (section 3). Governs the `for it in items` loops at lines 7 and 31: `it` is a copy, and it is only read.
27. "Overflow aborts at every width." (section 7). Governs lines 18, 26 and 32. The program does not guard against overflow, and the stated values do not reach the limit.

## choice_points

1. **Read-only parameter mark.** `index_of` and `qty_sum` take `items: [Item] lent`. Other choice: no mark, which the spec says makes a copy of the array per call. The output would be the same, only slower. Plain `items: [Item]` would also compile, so the choice is about cost, not correctness.
2. **Finding the position.** I used a helper `index_of` that returns `-1` for "not found", with an `i64` return. Other choices: (a) `-> i64?` with `fail(...)` and `match` at each call site; the output would be the same, with more code. (b) The `find` built-in; it needs a named predicate, but it cannot see `name`, since there are no closures, so it cannot be used here.
3. **Loop style for the search.** I used `for it in items` with a manual counter `i @= 0`, rather than `while i < len(items)` with indexing. Other choice: `while` with `len(items)`. I avoided `len` because the spec does not say what type `len` returns. If it returns a type other than `i64`, `i < len(items)` would be a type error under "No implicit conversions". The output would be the same either way.
4. **Index type.** `items[i]` uses an `i64` index. The spec does not state which integer types an index may take. Other choice: an unsigned index (e.g. `u64`), which would need conversion via `to_u64`, which returns `T?`. That would not match the rest of the program and would complicate it.
5. **Argument style.** I used positional arguments everywhere. The types of the two `str`/`i64`/`[Item]` parameters are all distinct in each signature, so named arguments are not mandatory (section 9). Other choice: named arguments such as `restock(@items, name: "apple", n: 3)`; the output would be the same.
6. **Missing item in `take`.** When there is no such item, `take` returns `false` and changes nothing. Other choice: abort, which the spec does not ask for.
7. **Zero quantity after a successful take.** An item whose `qty` falls to 0 stays in the list (it is not removed). The sum counts it as 0. Other choice: removing items when `qty` reaches 0; the sum would be the same, since a 0 contributes nothing.
8. **Where `restock` appends.** A new item goes to the end of the list. The sum does not depend on order, so the output is the same for any order.
9. **Negative literal.** `return -1` uses unary minus on a literal (`Unary = ( "-" | "!" | "~" ) Unary`). Other choice: `return 0 - 1`, same value.
10. **Reading `@` as a re-bind of `items` in `main`.** `items` in `main` is `@=` and is only ever passed as `@items`. I read "an `@` argument counting" as meaning that passing a cell with `@` counts as a re-bind, so `items` is not a cell nothing re-binds. The other reading would make this an error. This is the largest reading risk in the program; see confidence.
11. **Passing `items` on.** `qty_sum` takes `items` with `lent`, so `main` passes it without a mark. Other choice: `qty_sum(items: items)`, which is the same program.

## confidence

About 80% that the checker accepts the program as written.

The line I am least sure of is line 18 (`items[i].qty @ items[i].qty + n`), and line 26 (`items[i].qty @ items[i].qty - n`), which are the same pattern. They rest on three points that the spec states without a worked example: that a `Place` may combine a field and an index (`Place = ident { "." ident | "[" Expression "]" }`), that the index type is `i64`, and that the write goes through an `@` parameter (`items`).

The next least sure point is line 36 and line 42, through the `@`-argument reading in choice 10. If "an `@` argument counting" means something else, `items` in `main` would be reported as a cell nothing re-binds.

Lines 14 and 21 (`index_of(items, name)` on an `@` parameter, passed unmarked to a `lent` parameter) and line 16 (`items @ items.push(...)`) are a smaller risk: the spec says `lent` is for reading the caller's place, but it does not say explicitly that an `@` parameter may be lent on to a `lent` parameter.

Nothing in the program uses a `T?`, a `test`, an extern, or a hole, so those sections do not add risk.

## context

Yes, but only metadata, not any file or tool output beyond the directory:

- The files I read are all in this directory: `brief.md`, `spec.md`, `run.json` and `run.err`. `run.json` and `run.err` are empty (the Read tool reported empty contents). I did not use them.
- My context also contained the system environment block: the working directory path, the platform and shell, the scratchpad directory, the model name and cutoff, and today's date. It also had a git status snapshot (branch `main`, untracked `run.err` and `run.json`, a recent commit titled "inputs"), the git user name, and a user email address. None of that is part of the spec or the brief. I did not use the email address, and I did not read any file outside this directory.
- I did not run or compile anything; I have only read the spec and written this report, as the brief requires.
