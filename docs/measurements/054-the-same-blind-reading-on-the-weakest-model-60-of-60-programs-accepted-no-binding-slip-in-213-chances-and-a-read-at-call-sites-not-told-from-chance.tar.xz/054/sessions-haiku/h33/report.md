# program

```
function sorted_desc(xs: [i64]) -> [i64]
    a @= xs
    n = len(a)
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if a[j] < a[j + 1]
                t = a[j]
                a[j] @ a[j + 1]
                a[j + 1] @ t
            j @ j + 1
        i @ i + 1
    return a

function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    k @= 1
    while k < len(xs)
        if xs[k] != xs[k - 1]
            count @ count + 1
        k @ k + 1
    return count

function main()
    desc = sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
    for x in desc
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

# sentences

Each sentence is quoted from `spec.md`. The line numbers refer to the program above.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 27-31.
2. "Declaration = ... | "function" ident [ Generics ] Params [ "->" Type ] Block" (section 4 grammar). Governs the headers on lines 1, 16 and 27.
3. "`()` nothing: what a function with no `->` returns" (section 3). Governs `main` on line 27, which has no `->`.
4. "No braces, no semicolons; a condition needs no parentheses." (section 1). Governs the layout of every line, and the conditions on lines 5, 7, 8, 17, 21 and 22.
5. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." (section 1). Governs the indentation of every line.
6. "A literal takes the type its context asks for ... otherwise `i64`." (section 2). Governs the literals `0` and `1` on lines 4, 6, 18, 19, 20 and 24, the array literals on line 31 and 28, and the element type of the array literal on line 28.
7. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." (section 5). Governs the cells `a` (line 2), `i` (line 4), `j` (line 6), `count` (line 19), `k` (line 20), and the re-bindings on lines 10, 11, 12, 13, 23 and 24. Also the bindings `n`, `t` and `desc`, which are immutable `=` bindings.
8. "Place = ident { "." ident | "[" Expression "]" }" (section 5 grammar), with "Simple = "_" Binding | Place "@" Expression NEWLINE". Governs the element writes on lines 10 and 11 (`a[j] @ ...`, `a[j + 1] @ ...`).
9. "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." (section 3). Governs line 2: `a @= xs` copies the parameter, so `xs` is never written.
10. "A line that computes a value must use it: bind it, or discard it on purpose" (section 5). Governs lines 3 and 28, whose values are bound and then used, and line 31, whose value is printed.
11. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds" (section 5). Governs every binding: `a`, `n`, `i`, `j`, `t` in `sorted_desc`; `count`, `k` in `runs`; `desc`, `x` in `main`. Each one is read, and each cell is re-bound (lines 10-13, 23-24).
12. "Sum = Product { ( "+" | "-" ) Product } ." and "Product = Unary { ( "*" | "/" | "%" ) Unary } ." (section 7 grammar). Governs `n - 1 - i` on line 7, `k - 1` on line 22 and `j + 1` on lines 8, 10, 11, and `count + 1` on line 23.
13. "Compare = BitOr { ( "==" | "!=" | "<" | "<=" | ">" | ">=" ) BitOr } ." (section 7 grammar). Governs the comparisons on lines 5, 7, 8, 17, 21 and 22.
14. "`if cond` / `else if` / `else` take only `bool`" (section 8). Governs the `if` on lines 8, 17 and 22, whose conditions are `bool`.
15. "Loops: `while cond` and `for x in xs`, over an array or a `range`". Governs the loops on lines 5, 7, 21 and 29.
16. "`return` ... A function with a `->` must `return` on every path that reaches its end" (section 8). Governs `return a` on line 14, and `return count` on line 25. Also the early `return 0` on line 18, which covers the path where `xs` is empty.
17. "A statement after a jump, in its block, is a compile error." (section 8). Line 18 is the only statement in its block. Line 19 is in the enclosing function block, not that `if` block, so it does not follow the jump in the same block.
18. "Built-ins: `print(...)` · `len` · `push` ..." (section 11). Governs `len` on lines 3, 17 and 21. The spec gives `len` no signature (see confidence).
19. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." (section 11). Governs the `print` calls on lines 30 and 31.
20. "An out-of-bounds index or slice aborts" (section 10). Lines 8, 10, 11 and 22 index only within bounds: `j` stays below `n - 1 - i`, so `j + 1` is at most `n - 1`, and `k` starts at 1 so `k - 1` is at least 0.
21. "Overflow aborts at every width." (section 7). Governs the arithmetic on lines 7, 13, 23, 24: all values stay far below the `i64` range.
22. "return ok(xs[0])" (the section 6 example). Shows that indexing an array gives the element type directly, not a `T?`. Governs `xs[k]` and `a[j]` on lines 8, 9, 10, 22.
23. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." This program has no `use`, so it does not apply. The name `xs` is a parameter of two functions and `i` is no longer reused across functions; each function's names are distinct from one another within the function.

# choice_points

1. **Loop form.** I used `while` with mutable cells (`i`, `j`, `k`). The other choice was `for x in range(from: 0, to: n)`. That form works, but `range` takes two parameters of the same type, so its call would need named arguments (`from:` and `to:`). The output is the same either way.
2. **Comparison direction.** I swap when `a[j] < a[j + 1]`, which moves larger values forward and gives descending order. The other choice, `>`, would produce ascending order, which the brief does not want.
3. **Strict vs. non-strict swap.** I used `<`, so equal neighbours are not swapped. The other choice, `<=`, would still produce the same printed output, since equal `i64` values are indistinguishable. It would only add unnecessary swaps.
4. **Copy of the input.** I wrote `a @= xs` and sorted the copy. The other choice was to mutate `xs` directly. The spec gives `xs` no `@` mark, so writes to it are not allowed. Mutation would need `@xs: [i64]`, which the brief does not ask for.
5. **Temporary for the swap.** The spec gives no tuples or multiple assignment, so the swap uses the immutable `t = a[j]` (line 9). Without a temporary, the first write would lose `a[j]`.
6. **Empty input in `runs`.** I return `0` early (lines 17-18). The other choice was to start `count` at 0 and skip the early return. That needs a separate first-element case, and it gives the same result.
7. **`len(xs)` vs. `xs.len()`.** The spec allows both, since `x.f(y)` is sugar for `f(x, y)`. I wrote the function form.
8. **Printing.** I print the sorted values with a `for` loop in `main` (lines 29-30). The other choice was to build a `str` with `join` and print it once. That is more code for the same output.
9. **Local names.** I avoided reusing a name across functions beyond the required `xs` parameter, and named `main`'s local `desc` and `runs`'s index `k`. The other choice (`i` everywhere) is also legal in principle, since scopes are per function, but I did not want to rely on that reading.
10. **Loop bound.** The inner bound is `n - 1 - i` (line 7). The other choice, `n - i - 1`, is the same value. I wrote this order so that each pass shrinks by one from the right.

# confidence

I am about 85% sure the checker accepts this program on the first try.

The least certain line is line 3, `n = len(a)`, together with the same call on lines 17 and 21. The spec lists `len` among the built-ins without giving its signature. I assumed it returns `i64`, so that the comparisons on lines 5, 7, 17 and 21 need no conversion. The spec forbids implicit conversions, so if `len` returns another width, the checker will reject these lines.

The next least certain lines are 10 and 11, the element writes `a[j] @ ...`. The grammar allows a `Place` with an index, but the spec does not show an element write in an example. I am fairly confident this is accepted.

The remaining lines use only constructs the spec shows directly (`while`, `if`, `return`, `for`, `print`, cells with `@=` and `@`).

# context

Only the files in this directory reached my context: `brief.md`, `spec.md`, `run.json` and `run.err`. The last two are empty (the reads reported empty contents). I read no file outside this directory and used no other tool than reading and writing files here.

Other material is also in my context from the session setup, not from any file I read here: the environment description (platform, shell, scratchpad path, model details), the current date, and a git status and user-account block. None of it informed the program or the report.
