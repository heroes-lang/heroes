## program

```
# Sorting and run counting, in the bubble style the brief asks for.

# Returns xs from largest to smallest, swapping adjacent out-of-order pairs.
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n := len(ys)
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if ys[j] < ys[j + 1]
                t := ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
    return ys

# Counts the maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    n := len(xs)
    if n == 0
        return 0
    groups @= 1
    for k in range(from: 1, to: n)
        if xs[k] != xs[k - 1]
            groups = groups + 1
    return groups

function main()
    for v in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(v)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below count the program above from its first line (the first `#` comment is line 1).

## sentences

Quotations are from spec.md; bracketed numbers are spec.md's line numbers.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." [spec.md 22-23] Governs `function main()` (line 26).
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." [spec.md 33-34] Governs the layout of every line; the conditions on lines 9, 18 and 22 have no parentheses.
3. "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it" [spec.md 31-32] Governs lines 1, 3 and 15, which are single-`#` comments; lines 3 and 15 sit directly above their functions.
4. "Syntax is ASCII-only" [spec.md 35] Governs the whole program: every character is ASCII.
5. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." [spec.md 134-135] Governs `ys @= xs` (line 5), `groups @= 1` (line 20), `ys[j] = ...` (lines 11 and 12, an element inside the cell `ys`), and `groups = groups + 1` (line 23).
6. "`:=` binds once, forever." [spec.md 134] Governs `n := len(ys)` (line 6), `t := ys[j]` (line 10), `n := len(xs)` (line 17).
7. "A literal takes the type its context asks for ... otherwise `i64`." [spec.md 43-44] Governs the literals `0` and `1` (lines 19, 20), the integers in the array arguments (line 27 and line 29), and the literals `1` and `2` in lines 7, 8, 9, 11, 12, 22, 23, which take `i64` from their `i64` operands.
8. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds" [spec.md 137-138] Governs `ys` (rebound on lines 11-12), `groups` (rebound on line 23), `t` (read on line 12), `n` (read on lines 7, 8, 18, 21 and the `n` on line 6), `k` (read on line 22), `i` and `j` (read on lines 8 and 9), `v` (read on line 28), and the parameters `xs` (lines 5 and 17).
9. "Shadowing is a compile error" [spec.md 146] Governs the names: each of `i`, `j`, `k`, `n`, `t`, `v`, `ys`, `groups` is bound once per function, and none equals a function name or a built-in.
10. "A function with a `->` must `return` on every path that reaches its end" [spec.md 240] Governs `sorted_desc` (line 13, `return ys`, reached on every path) and `runs` (line 24, `return groups`; the early `return 0` on line 19 ends its own path).
11. "A statement after a jump, in its block, is a compile error." [spec.md 239] Governs line 19: `return 0` is the last statement in its block.
12. "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness." [spec.md 247] Governs the `if` conditions on lines 9, 18 and 22: each is a comparison, so each is `bool`.
13. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." [spec.md 248] Governs the loops on lines 7, 8, 21 and 27.
14. "`range(from: a, to: b) -> [i64]` exclude `to`." [spec.md 322] Governs `range(from: 0, to: n)` (line 7): it yields 0 through n-1; `range(from: 0, to: n - 1 - i)` (line 8): it yields 0 through n-2-i, so `j + 1` reaches at most n-1-i; `range(from: 1, to: n)` (line 21): it yields 1 through n-1, so `k - 1` is never below 0.
15. "When two parameters in a signature share a type, named arguments are mandatory at the call site" [spec.md 263-264] Governs the `range(from: ..., to: ...)` calls on lines 7, 8 and 21: both parameters are `i64`, so the names are required.
16. "Built-ins: `print(...)` · `len` · ..." [spec.md 316] Governs `len(ys)` (line 6), `len(xs)` (line 17), and `print(v)` and `print(runs(...))` (lines 28 and 29). `len` is listed by name with no signature (see choice point 6).
17. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." [spec.md 323-325] Governs lines 28 and 29: each prints one `i64` on its own line.
18. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." [spec.md 268] Governs the choice of `len(ys)` over `ys.len()`: the two are the same call.
19. "Mutable parameters are marked `@` in the signature and at the call site" [spec.md 271-272] Governs the choice not to take `xs` as `@xs`: the program has no `@` parameter, and `xs` is copied into `ys` on line 5.
20. "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." [spec.md 76-77] Governs `ys @= xs` (line 5): writing `ys` on lines 11-12 leaves the caller's array unchanged.
21. "Precedence, strongest first: call, `.` and `::` ... unary `-` `!` `~` ... `* / %` ... `+ -`" [spec.md 191-192] Governs `n - 1 - i` (line 8) and `ys[j + 1]` (line 9): `-` groups left to right, and the index is a postfix that binds tighter than `<`.
22. "Place = ident { "." ident | "[" Expression "]" } ." [spec.md 156] Governs the element assignments `ys[j] = ys[j + 1]` (line 11) and `ys[j + 1] = t` (line 12).
23. "An out-of-bounds index or slice aborts" [spec.md 313] Governs every index on lines 9 to 12 and 22: the bounds are chosen so that no index leaves `0 .. n-1` (see choice point 4).

## choice_points

1. **Loop form.** Chosen: `for ... in range(...)` loops over immutable loop names `i`, `j`, `k`. Other: `while` loops over mutable index cells (`j @= 0`, `j = j + 1`). Same output; the `while` form needs extra cells and rebinding.
2. **Copying the input.** Chosen: `ys @= xs`, a copy, since values are independent copies (spec.md 76-77). Other: take `@xs: [i64]` and sort the caller's array in place. Then every caller must write `@` at the call site, and the literal argument in `main` is not a place, so that call would be refused.
3. **Direction of the swap test.** Chosen: `if ys[j] < ys[j + 1]` swaps when the left element is smaller, giving descending order. Other: `>` gives ascending order, which the brief does not ask for; `sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])` would then print 1 1 2 3 4 5 6 9.
4. **Inner loop bound.** Chosen: `to: n - 1 - i`, so `j + 1` never exceeds `n - 1 - i <= n - 1`. Other: `to: n - i` would reach `ys[n]` on the last pass and abort at run time (out of bounds); the checker may accept it, but it would be wrong.
5. **Call form for `len`.** Chosen: `len(ys)`. Other: `ys.len()`, which UFCS makes the same call (spec.md 268). Both are accepted if `len` is a built-in as listed.
6. **Result type of `len`.** The spec lists `len` without a signature. Chosen: `i64`, so that `n := len(ys)` combines with `range(to: n)`, `n - 1 - i` and `n == 0` without mixing widths (spec.md 185 forbids mixing). Other: a `u64` or `u32` result makes every `n` expression with an `i64` operand a type error. This is the largest single assumption in the program.
7. **Type of array indexing.** Chosen: `xs[k]` yields the element type `i64`, not `i64?`. Other: an optional result would make `ys[j] < ys[j + 1]` and `xs[k] != xs[k - 1]` type errors and require `.must()`. The spec gives the optional result only for maps (spec.md 311) and says only that an out-of-bounds index aborts (spec.md 313), so arrays are read as plain values.
8. **Named arguments to `range`.** Chosen: `range(from: a, to: b)`, the form the spec writes (spec.md 322). Other: positional `range(0, n)` is refused, because both parameters are `i64` and the names are mandatory (spec.md 263-264).
9. **Counting groups.** Chosen: start `groups` at 1 after the `n == 0` early return and increment at each change. Other: start at 0 and add one for the first element; same answer (4 for the test input), with an extra case.
10. **Empty input in `runs`.** Chosen: an explicit `if n == 0` early return of `0`, so `xs[0]` is never read. Other: loop from index 0 with a flag. The brief does not require empty input; the early return is the simpler form that the spec's `return` rule handles.
11. **Early return placement.** Chosen: `return 0` inside an `if` block. Other: an `if` / `else` whose `else` holds the loop. The spec allows either (spec.md 240, 244); the early return keeps the body flat.
12. **Comments.** Chosen: single `#` comment lines above each function, as spec.md 31-32 allows. Other: no comments; no effect on acceptance.
13. **Use of `_`.** Not used. Every binding is read, so no `_` is needed (spec.md 139-142).
14. **Printing.** Chosen: `print(v)` once per element in `main`, giving one line per element (spec.md 323-325). Other: build one string with `join` and print it once; same output, more code.

## confidence

About 85% that the checker accepts the program as written on the first try, given the spec and that it reads the way I have taken it.

The line I am least sure of is line 6, `n := len(ys)`, and the same form on line 17, `n := len(xs)`. The spec names `len` without a signature (spec.md 316). If `len` returns anything other than `i64`, these lines and every expression that uses `n` (lines 7, 8, 18, 21) are type errors. This is choice point 6.

Next least sure: lines 11 and 12, the element writes `ys[j] = ys[j + 1]` and `ys[j + 1] = t`. The spec says `=` re-binds an element inside a cell (spec.md 134-135) and gives the `Place` grammar with `[ ]` (spec.md 156), so I expect them to be accepted, but the spec gives no explicit example of an array element write.

Lines 7, 8 and 21 depend on `range` as a `for` source and on named arguments (spec.md 263-264, 316, 322). I am fairly sure of these.

## context

Yes, things other than the files in this directory reached my context:

- The brief (`brief.md`) and the specification (`spec.md`) in this directory. These are the intended inputs.
- `run.json` and `run.err`, which are also in this directory. I read them because they were there, although the brief names only `spec.md` as input. Both are empty and informed nothing in the program.
- Harness-provided material outside the directory's files: a system reminder with the user's account details and a snapshot of the git status (branch, one recent commit, two untracked files), and environment details (working directory path, platform, scratchpad path, model identity, and the current date). None of it informed the program or this report, and I have not sent any of it anywhere.

I read no file outside this directory and used no tool other than reading and writing files here, as the brief requires. I could not run the checker, so the confidence above is an estimate from reading the spec.
