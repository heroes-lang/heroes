# program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    out: [Item] @= []
    found @= false
    for item in items
        if item.name == name
            out = out.push(Item(name: item.name, qty: item.qty + n))
            found = true
        else
            out = out.push(item)
    if !found
        out = out.push(Item(name: name, qty: n))
    items = out

function take(@items: [Item], name: str, n: i64) -> bool
    out: [Item] @= []
    done @= false
    for item in items
        if !done && item.name == name && item.qty >= n
            out = out.push(Item(name: item.name, qty: item.qty - n))
            done = true
        else
            out = out.push(item)
    if done
        items = out
    return done

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output, traced by hand: `true`, `false`, `4` (apple 7 minus 5 leaves 2, pear stays 2, sum 4).

# sentences

Line numbers refer to the program above.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 31.
2. "Signatures are always explicit; inference is local only." Governs lines 5, 18, 31 (every signature is written in full).
3. "Declaration order never matters but a group's (section 13)." Governs the order of the record, the two functions and `main`.
4. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every block, and the `if` conditions on lines 9, 14, 22, 27.
5. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`." Governs lines 10, 15, 23.
6. "A literal takes the type its context asks for ... otherwise `i64`." Governs lines 7, 33 to 35, 38 (the `0`, `3`, `2`, `4`, `5`, `9` literals become `i64`).
7. "No implicit conversions, widths included." Governs lines 10, 23, 40 (all operands are `i64`).
8. "`+` ... (both sides one numeric type, never mixed)." and "`-`" in the arithmetic row of section 7. Governs lines 10, 23, 40.
9. "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 6, 7, 19, 20, 32, 38 (cells) and 11, 16, 24, 28, 40 (re-bindings).
10. "A container literal separates elements ... and an empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`." Governs lines 6, 19, 32 (`out: [Item] @= []` and `items: [Item] @= []`).
11. "`xs = xs.push(4)` grows in place when `xs` is a plain name." Governs lines 10, 13, 15, 23, 26 (`out = out.push(...)`).
12. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs the `out.push(...)` calls, since `out` is not an `@` parameter.
13. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`." Governs lines 5, 18 (signatures) and 33 to 37 (call sites).
14. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends ..., an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." Governs `items` (written at lines 16, 28), `out` and `found` (line 7 and 11, read at 9 and 14), `done` (lines 20, 24 and read at 22, 27), `total` (line 38, 40), `n` and `name` (used at lines 9, 10, 15, 22, 23).
15. "A function with a `->` must `return` on every path that reaches its end." Governs line 29 (the only `return` in `take`).
16. "`for x in xs`, over an array or a `range` (section 11)." Governs lines 8, 21, 39.
17. "`if cond` / `else if` / `else` take only `bool` — there is no truthiness." Governs lines 9, 14, 22, 27.
18. "`If = "if" Expression Block { "else" "if" Expression Block } [ "else" Block ]`", the `else` being optional. Governs line 14 and line 27 (`if` with no `else`).
19. "`==` is structural equality on any two values of one type, recursively." Governs lines 9 and 22 (`str` comparisons).
20. "`>=` ... (`< <= > >=`: a number only)." Governs line 22 (`item.qty >= n`).
21. "boolean `&& || !` (bool only; && and || short-circuit)." Governs `!done`, `&&` on line 22.
22. "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -` → ... → comparisons → `&&` → `||`." Governs line 22: `!done` binds to `done` alone, each comparison binds before `&&`.
23. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 36, 37 (bool results, each on its own line) and 41 (the sum).
24. "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs lines 10, 13, 23, 26 (the items pushed into `out`) and line 16 or 28 (the copy of `out` into `items`).
25. "`Place = ident { "." ident | "[" Expression "]" }`." Governs lines 16, 28, 40 (`items = out`, `total = ...`).

# choice_points

1. **Find the item: flag and rebuild, not an index loop.** I rebuild `out` element by element (lines 6 to 15, 19 to 28), so there is no index. The specification gives no return type for `len` and does not state the type of `range`'s result beyond `[i64]`, and `find` gives no type for its result. The other choice, `i @= 0` with `while i < len(items)` and `items[i].qty = items[i].qty + n`, would type-check only if `len` returns `i64`, and the spec does not say that. Output would be the same if it does.
2. **Iterate by value.** `for item in items` (lines 8, 21, 39) copies each item. The other choice, an index loop, would need `len` (see 1).
3. **`take` writes back only when it succeeds.** Line 27 to 28 assigns `items = out` only when `done` is true. The other choice, always assigning, would produce the same contents for `take`, since a failed take leaves each item as it was. I chose the conditional to match the brief literally ("changes nothing").
4. **Rebuild the whole array versus assign in place.** The other choice is to mutate one element by `items[i].qty = ...`. The specification allows that, but it needs an index (see 1).
5. **Literal types.** All numeric literals and `total @= 0` take `i64` by default. The other choice, `total: i64 @= 0` or `i8`, would change nothing in output but would be a type error with `item.qty` if it were narrower.
6. **Positional arguments at call sites.** `restock(@items, "apple", 3)` (lines 33 to 35). The parameters `name: str` and `n: i64` have different types, so named arguments are not mandatory. The other choice, `name: "apple", n: 3`, is also accepted by the `Arg` production and would give the same program behavior.
7. **Printing a `bool` directly.** `print(take(...))` (lines 36, 37) prints `true` or `false`, as section 11 specifies. The other choice, `if` then `print("yes")`, would print different text.
8. **Reusing `item` as the loop variable in three functions.** The rule "Shadowing is a compile error" applies to a `use` name in a file, and no `use` is written here. The other choice, distinct loop names, would avoid any doubt, at the cost of a less consistent program.
9. **Expressing `not found` with a flag rather than `find`.** `find` is listed as "the first it accepts, else `not_found`", but the result type is not stated, so I did not use it. The other choice, `find` with a `T?` result, is untested by the spec's examples.

# confidence

About 85% that the checker accepts the program on the first try, and high confidence that the program's output is `true`, `false`, `4`. I cannot compile here, so this estimate rests on reading the specification only.

The line I am least sure of is line 28 (`items = out`), with line 16 a close second. Both re-bind an `@` parameter as a whole from a local cell. The specification says `=` re-binds a cell, and that an `@` parameter counts as written when it is re-bound, but it never gives a whole-array re-binding of an `@` parameter as an example. Line 6 and line 19 (`out: [Item] @= []`) are close to the specification's own example `m: {str: i64} @= {}`, so I am confident in them.

# context

Only files in this directory reached my context: `brief.md`, `spec.md` (read in full), `run.json`, and `run.err`. Both `run.json` and `run.err` are empty. I used no file outside this directory and ran no tool other than reading and writing files here. The session also carries harness and environment metadata (platform, date, git status snapshot). None of it was used in the program or in this report.
