## program

```
# A named stock count.
record Item
    name: str
    qty: i64

# Adds n to the qty of the item called name, or appends a new item.
function restock(@items: [Item], name: str, n: i64)
    limit: i64 $= to_i64(len(items)).must()
    i @= 0
    while i < limit
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
        i = i + 1
    items = items.push(Item(name: name, qty: n))

# Subtracts n from the item called name when it holds at least n.
function take(@items: [Item], name: str, n: i64) -> bool
    limit: i64 $= to_i64(len(items)).must()
    i @= 0
    while i < limit
        if items[i].name == name
            if items[i].qty < n
                return false
            items[i].qty = items[i].qty - n
            return true
        i = i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    r1 $= take(@items, "apple", 5)
    print(r1)
    r2 $= take(@items, "pear", 9)
    print(r2)
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output, one value per line: `true`, `false`, `4`.

## sentences

Line numbers refer to the program above.

- "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 30-42, the entry point.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every line; all indentation is 4 spaces, and the `while` and `if` conditions have no parentheses (lines 10, 11, 21, 22, 23).
- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 8 and 19 (`limit $=`), lines 9, 20 (`i @=`), 31 (`items @=`), 39 (`total @=`), and the re-bindings at lines 12, 14, 15, 25, 27, 41.
- "Signatures are always explicit; inference is local only." Governs lines 7, 18, 30; all parameter and return types are written.
- "Mutable parameters are marked `@` in the signature and at the call site" Governs `@items` in lines 7 and 18, and `@items` in every call at lines 32-37.
- "the callee works on the caller's place itself, which no other `@` argument of the call may reach" Governs lines 32-37; each call has exactly one `@` argument.
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting" Governs `name` and `n` (lines 7, 18, used on lines 11, 12, 15, 23, 25), `items` (written at lines 12, 15, 25), `i` (re-bound at lines 14, 27), `total` (re-bound at line 41), and `r1`, `r2` (used at lines 36, 38).
- "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `0` (lines 9, 20, 39), `3`, `2`, `4`, `5`, `9` (lines 32-37), and `return false` / `return true` as `bool`.
- "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs `Item(name: name, qty: n)` at line 15.
- "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array" Governs line 15, `items = items.push(...)`, where `items` is a plain name.
- "an empty one needs an annotation: `xs: [i64] $= []`" Governs line 31, `items: [Item] @= []`.
- "`if cond` / `else if` / `else` take only `bool`; there is no truthiness." Governs lines 11, 22, 23, which each test a `bool` comparison.
- "`==` is structural equality on any two values of one type, recursively" Governs `items[i].name == name` at lines 11 and 22.
- "`< <= > >=`: a number only" Governs `i < limit` (lines 10, 21) and `items[i].qty < n` (line 23).
- "No implicit conversions, widths included" Governs `limit: i64` (lines 8, 19), `i < limit` (both `i64`), and `items[i].qty + n` (both `i64`).
- "Place     = ident { "." ident | "[" Expression "]" }." Governs the assignments `items[i].qty = ...` at lines 12, 25 and `total = ...` at line 41.
- "Loops: `while cond` and `for x in xs`, over an array" Governs lines 10, 21 (`while`) and line 40 (`for item in items`).
- "Every value behaves as an independent copy" Governs line 40: `item` is a copy of each element, so `total` is the sum of the stored quantities.
- "A statement after a jump, in its block, is a compile error. A function with a `->` must `return` on every path that reaches its end" Governs `take` (lines 18-28): line 28 `return false` ends the last path. Line 27 follows an `if` with no `else`, which does not leave, so it is not after a jump. Line 14 likewise follows an `if` with no `else` in `restock`.
- "a line that computes a value must use it: bind it, or discard it on purpose with `_ $= f(x)`, which a `()` line refuses: it stands alone." Governs lines 32-34 and 36, 38: the calls to `restock` and `print` return `()` and stand alone; `take` values are bound at lines 35 and 37.
- "`.must()` | extract or abort" Governs `.must()` at lines 8 and 19.
- "Convert with `to_<type>`" and "`to_i64` takes a float too, truncating toward zero." Governs `to_i64(len(items))` at lines 8 and 19: `to_i64` gives an `i64?`, extracted by `.must()`.
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 36, 38, 42, and the expected output.
- "a `bool` prints `true` or `false`." Governs lines 36 and 38.
- "Shadowing is a compile error" Governs the names: no two bindings in one function share a name, and `item` (line 40) does not clash with the type `Item`.
- "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it" Governs lines 1, 6, 17.
- "Syntax is ASCII-only" Governs the whole file; the program is pure ASCII.
- "Built-ins: `print(...)` · `len` · `push`" Governs the use of `len` (lines 8, 19), `push` (line 15), and `print` (lines 36, 38, 42).

## choice_points

1. **Search loop.** I used a `while` loop with an index cell (`i @= 0`) to find the item. The alternative is the built-in `find`, which the spec describes as "the first it accepts, else `not_found`". Its return type is not stated in the spec, so `find` would need `.must()` or `match` with an unclear result type. The alternative `for` loop cannot write the element in place, because each `item` is a copy (section 3), so the index loop is needed for the `@` write.

2. **Loop bound.** I bound the loop with `limit: i64 $= to_i64(len(items)).must()` (lines 8, 19) instead of `i < len(items)`. The spec does not state the type `len` returns. If it returns `i64`, both forms compile. If it returns an unsigned type, `i < len(items)` is an error because there is no implicit conversion between `i64` and that type. The `to_i64` form compiles either way, at the cost of one extra conversion. The `limit` is computed once; this is safe because `restock` appends only after its loop, and `take` never changes the length.

3. **Append form.** I wrote `items = items.push(Item(...))` (line 15). The spec's example `xs = xs.push(4)` grows in place when `xs` is a plain name, and `items` is one. The alternative `push(items, Item(...))` as a bare statement would compute a value that is unused, which the spec refuses. The alternative `items.push(...)` without the `=` is the same error. A rebind through `items[i] = Item(...)` at the found index would also compile but rebuilds the whole record; I did not use it.

4. **Argument form.** I passed arguments by position (`restock(@items, "apple", 3)`). Named arguments are not mandatory here, because no two parameters of one signature share a type (`[Item]`, `str`, `i64`). Named arguments such as `restock(@items, name: "apple", n: 3)` would also compile. The `@` marker is required in both the signature and the call.

5. **Return shape of `take`.** I put one `return false` after the loop (line 28) and returned `false` inside the loop when the stock is short (line 24). The alternative is a single exit through a `found` flag. Both compile; the flag version has one more cell that must be re-bound.

6. **Printing booleans.** I passed the `bool` directly to `print` (lines 36, 38). The alternative is `print(to_str(r1))`, which prints the same text. The spec states that `print` takes a `bool`, so the direct form is what the spec describes.

7. **Sum.** I summed with a `for` loop over `items` (lines 39-41). The alternative is `fold` (the spec says its function names its arguments `acc` and `item`), which would also compile; I did not need it.

8. **Mutation style.** Changes to an item's `qty` are made in place through the `@` parameter (`items[i].qty = ...`) and not by building a new array. The alternative, copying the array and reassigning, would be slower and is not needed.

9. **Loop variable name.** I named the loop variable `item`. The spec does not reserve it, and it does not collide with the type name `Item`, which differs by case. The alternative `entry` would also compile.

## confidence

I am about 85% sure the checker accepts the program on the first try.

The line I am least sure of is line 8 (and the identical line 19): `limit: i64 $= to_i64(len(items)).must()`. The spec does not state what type `len` returns, so I rely on `to_i64` accepting any integer type and on `.must()` extracting its `i64?`. If `len` returns a type `to_i64` does not accept, or if `to_i64` on an integer is rejected, this line fails. The rest of the program uses only constructs the spec states directly.

## context

Only this directory's files reached my context: `brief.md` and `spec.md`, which I read in full. I also tried to read the directory path itself, which returned an error (it is a directory), and I read nothing from it.

Other material also reached my context from the surrounding environment, not from the files: the working directory and platform, a git status snapshot that lists untracked `run.err` and `run.json` in the repository, the user's account email, and the model and date information. I did not open `run.err` or `run.json`, and I did not use any of that material in the program or this report.
