# Report

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    while i < to_i64(len(items)).must()
        if items[i].name == name
            items[i].qty @ items[i].qty + n
            return
        i @ i + 1
    items @ items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    while i < to_i64(len(items)).must()
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty @ items[i].qty - n
                return true
            return false
        i @ i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total @ total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple 7 minus 5 leaves 2; pear 2 cannot give 9; 2 + 2 = 4).

## sentences

Line numbers refer to the program above.

- "`@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs lines 6, 9, 11, 15, 19, 22, 26, 32, 34 (cells `i`, `total`, `items`, and element/field writes).
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`". Governs lines 5, 14 (signatures) and 27 to 31 (call sites).
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs line 12 (`items.push(...)`) and the spec's `xs @ xs.push(4)` form.
- "`xs @ xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs line 12: `items` is a plain name (an `@` parameter).
- "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`." Governs line 12 (`Item(name: name, qty: n)`).
- "Place     = ident { "." ident | "[" Expression "]" } ." Governs lines 9, 11, 19, 22, 34 (`items[i].qty @ ...`, `i @ ...`).
- "`[T]` | dynamic array, indices from 0" (section 3). Governs lines 6 and 15 (`i` starts at 0 and indexes `items`).
- "`s[i]` yields a `u8`" and "An out-of-bounds index or slice aborts" (section 10). Governs lines 8, 9, 17, 18, 19 (indexing never out of bounds, because `i < len` is checked first).
- "`.must()` | extract or abort" (section 6). Governs lines 7, 16.
- "`to_i64` takes a float too, truncating toward zero." and "`to_i8` … `to_u64` give a `T?`, because the number may not fit." (section 11). Governs lines 7, 16 (`to_i64(len(items))` gives `i64?`, then `.must()`).
- "No implicit conversions, widths included: `1 + 2.0` is an error." Governs lines 7, 9, 16, 18, 19, 34 (every number is `i64`; the `len` result is converted explicitly).
- "A literal takes the type its context asks for … otherwise `i64`." Governs lines 6, 15, 27 to 29 (`3`, `2`, `4`, `0`, `1`), and 30, 31 (`5`, `9`).
- "`+` … (both sides one numeric type, never mixed)" and "Overflow aborts at every width." (section 7). Governs lines 9, 11, 19, 22, 34.
- "`< <= > >=`: a number only" (section 7 comparison). Governs lines 7, 16, 18.
- "`==` is structural equality on any two values of one type, recursively." Governs lines 8, 17 (`str == str`).
- "`if cond` / `else if` / `else` take only `bool`, there is no truthiness." Governs lines 8, 17, 18.
- "a condition needs no parentheses." (section 1). Governs lines 7, 8, 16, 17, 18.
- "Indentation is significant and rigid: exactly 4 spaces per level." Governs every indented line.
- "A function with a `->` must `return` on every path that reaches its end." (section 8). Governs lines 14 to 23 (`take` ends with `return false` on line 23 and every `if` path returns).
- "A statement after a jump, in its block, is a compile error." Governs lines 10, 20 to 21 (no statement follows a `return` in the same block: line 11 is outside the `if` block, and line 22 is outside the inner `if` block).
- "`while cond` and `for x in xs`, over an array or a `range`" (section 8). Governs lines 7, 16 and 33.
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 30, 31, 35.
- "a `bool` prints `true` or `false`." Governs lines 30, 31 (`true`, `false` output).
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends …, an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." Governs lines 5, 14 (`@items` written), 6, 15, 26, 32 (cells re-bound), 27 to 31 (`@` arguments count as re-binding `items`), 33 (`item` read on line 34).
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`, which a `()` line refuses." Governs lines 27 to 29 (`restock` returns `()`, so no binding is needed) and 30, 31 (`take` result passed to `print`).
- "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Read as "no name is bound twice in one scope." Governs lines 5, 14 (`i` in two functions, separate scopes), 33 (`item` loop variable, no other `item` in scope).
- "`main` ... takes nothing and produces nothing" (section 1, "the file you compile holds `function main()`, which takes nothing and produces nothing."). Governs line 25.
- "Declaration order never matters but a group's." Governs the layout: `record Item` first, then functions.
- "Syntax is ASCII-only." Governs the whole program (all ASCII).
- "`Binding = [ ":" Type ] ( "=" | "@=" ) Expression NEWLINE`" (section 5). Governs line 26 (`items: [Item] @= []`).
- "`xs: [i64] = []` · `m: {str: i64} @= {}`" (section 10: an empty container needs an annotation). Governs line 26.
- "`print(...)`" and "`len`" are built-ins (section 11). Governs lines 7, 12, 16, 30, 31, 35.
- "`for`" line 33 loops over `items`, which is `[Item]`, binding each element as `item`.

## choice_points

1. **Search loop.** I used a `while` loop with a `@=` index cell (lines 6 to 11, 15 to 22). Other choice: `for i in range(from: 0, to: ...)` with the same body, or the built-in `find`. `find` returns `not_found` on failure and its exact type was not what I needed here, so I avoided it. Other choice with `range` gives the same output.
2. **Early exit in `restock`.** I used `return` inside the loop (line 10) rather than a `found` flag. Other choice: a `found @= false` flag and an `if not found` branch after the loop. Output is the same.
3. **Length type.** `len` returns a type the spec does not state. I wrapped it as `to_i64(len(items)).must()` (lines 7, 16). Other choice: bare `len(items)` in the comparison. That is correct only if `len` returns `i64`. If `len` returns `u64` or another width, the bare form is a type error under "no implicit conversions". The wrapper works in both cases, provided `to_i64` accepts an integer argument (the spec says it takes a float too, which implies integers are accepted).
4. **Index type.** I index with an `i64` cell (`items[i]`). The spec does not say which integer types an index may use. Other choice: a `u64` or `i32` index. That would need a conversion or would be refused. `i64` is the default literal type, so no conversion is needed.
5. **Append form.** `items @ items.push(...)` (line 12) uses the spec's `xs @ xs.push(4)` shape. Other choice: `push(items, ...)` as a bare statement. The spec does not show that the bare form returns the new array, so the assignment form is safer. Other choice would also compile if `push` mutates `items` in place, but that is not in the spec.
6. **Sum.** I used a `for` loop with a `total @=` cell (lines 32 to 35). Other choice: `items.fold(0, ...)`. `fold` needs a function value whose exact shape I did not want to rely on (the spec says its function names `acc` and `item`; the function would need to be a top-level function taking those). Output is the same.
7. **Named arguments.** None are used: no two parameters in `restock`, `take`, or the calls share a type (`items` is `[Item]`, `name` is `str`, `n` is `i64`). Other choice: naming the arguments anyway (for example `restock(@items, name: "apple", n: 3)`). The spec makes names mandatory only when two parameters share a type, so the program compiles either way.
8. **Printing the take results.** I passed `take(...)` directly to `print` (lines 30, 31). Other choice: bind `ok = take(...)` on its own line and then `print(ok)`. Output is the same, and this avoids any concern about a computed value being unused.
9. **Mutable cell declarations.** I used `i @= 0` (inferred `i64`). Other choice: `i: i64 @= 0`, which is equivalent. Declaring it with the type would make the choice explicit.
10. **Empty-array annotation.** `items: [Item] @= []` (line 26). Other choice: `items @= ([] : [Item])`, which the spec does not show. The annotated form matches the spec's own example.

## confidence

About 80% that the checker accepts this program on the first try.

Least sure of line 7 and line 16 (`while i < to_i64(len(items)).must()`). The spec does not state the result type of `len`, and does not state which integer types an index may use. The `to_i64` wrapper is my hedge against the first; if `to_i64` does not accept an integer argument, both lines fail.

Next least sure: line 12 (`items @ items.push(Item(name: name, qty: n))`). It relies on `items`, an `@` parameter, counting as a "plain name" for in-place growth, and on `push` returning the new array in the form `xs @ xs.push(4)` implies. If the checker treats `@` parameters differently, this line copies the array but still compiles and runs with the same output.

Lines 9, 19 (`items[i].qty @ ...`) depend on the `Place` production allowing an index followed by a field. The grammar (`Place = ident { "." ident | "[" Expression "]" }`) permits it, so I rate that as low risk.

## context

Nothing from outside this directory reached my context. I read only `brief.md`, `spec.md`, and the two files `run.json` and `run.err`. The last two are empty; I read them although the brief did not ask for them, and they contributed nothing. The session's environment details (working directory, model, date) were in my context from the harness, but none of them were used as input to the program.
