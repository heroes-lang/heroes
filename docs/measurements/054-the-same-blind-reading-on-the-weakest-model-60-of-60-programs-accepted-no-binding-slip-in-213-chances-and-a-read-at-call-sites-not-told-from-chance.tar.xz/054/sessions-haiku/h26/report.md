## verdict

Refused. The checker rejects two lines of `main.hero`:

- **Line 20**, `step = 2`. `step` is bound by `$=` on line 10, which binds once, forever. `=` re-binds only a mutable cell (`@=`) or a field or element inside one, and `step` is neither.
- **Line 22**, `last @= words[0]`. `last` is a cell that nothing re-binds. A cell nothing re-binds is a compile error.

Smallest change that keeps the evident meaning: line 10 becomes `step @= 1` (so `step = 2` re-binds a cell), and line 22 becomes `last $= words[0]` (an immutable binding, since nothing re-binds it). The program is in `program` below.

As written, the program prints nothing, because it is refused. The fixed program prints:

```
5
5
a
```

Trace: the loop over `["a", "b", "a", "c", "a"]` gives `counts` = `a`: 3, `b`: 1, `c`: 1 and `total` = 5. `bump(@c, counts["a"].default(0))` makes `c.hits` = 3. `step` is now 2, so `bump(@c, step)` makes `c.hits` = 5. `print(c.hits)` prints `5`, `print(total)` prints `5`, and `print(last)` prints `a`.

Other lines hold `=` or `@` and are accepted: lines 5, 6, 9, 11, 12, 15, 16, 18, 19, 21.

## lines

Every line of `main.hero` that holds `=` or `@` (the `$=` and `@=` forms count, since they contain `=`).

| line | effect | words of the specification relied on |
|---|---|---|
| 5 | *new name* (the parameter `c`) | "Mutable parameters are marked `@` in the signature and at the call site:"; the `@` is a parameter mark, so the line binds nothing with `=` (see `choice_points`) |
| 6 | *changes an existing name* (`c.hits`, a field of the `@` parameter `c`) | "`=` re-binds it, or a field or element inside one."; "Either way the callee works on the caller's place itself" |
| 9 | *new name* (`words`) | "`$=` binds once, forever." |
| 10 | *new name* (`step`) | "`$=` binds once, forever." |
| 11 | *new name* (`counts`) | "`@=` declares a mutable cell, and `=` re-binds it" |
| 12 | *new name* (`total`) | "`@=` declares a mutable cell" |
| 15 | *changes an existing name* (an element of `counts`) | "`=` re-binds it, or a field or element inside one."; "`m[k] = v` inserts or replaces;" |
| 16 | *changes an existing name* (`total`) | "`=` re-binds it" (`total` is a cell, from `@=` on line 12) |
| 18 | *new name* (`c`) | "`@=` declares a mutable cell" |
| 19 | *changes an existing name* (`c`, through the `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site"; "an `@` argument counting" as a write |
| 20 | *changes an existing name*, as written; refused, so nothing changes | "`$=` binds once, forever." against "`=` re-binds it, or a field or element inside one." (`step` is `$=`, neither a cell nor a field or element of one) |
| 21 | *changes an existing name* (`c`, through the `@` argument) | same as line 19 |
| 22 | *new name* (`last`), refused: a cell nothing re-binds | "`@=` declares a mutable cell"; "a cell nothing re-binds ... is a compile error" |

## sentences

From section 5 (Bindings):

- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."

From section 9 (Functions and calls):

- "Mutable parameters are marked `@` in the signature and at the call site:"
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."

From section 1 (Files and layout):

- "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing."

From section 2 (Literals):

- "A literal takes the type its context asks for — `b: u8 $= 255`, and `b + 1` is a `u8` — otherwise `i64`."

From section 3 (Types):

- "`[T]` | dynamic array, indices from 0"

From section 7 (Operators):

- "arithmetic   + - * / %          (both sides one numeric type — never mixed)"

From section 10 (Strings, arrays, maps):

- "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"

From section 6 (Failure), the table row:

- "`.default(v)` | extract or fall back"

From section 9 (Functions and calls):

- "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`"

From section 11 (Built-ins):

- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

This program prints `5`, `5`, `a`, one per line.

## choice_points

1. **Fixing line 20.** I made `step` a cell (line 10 becomes `step @= 1`). The other choice is to delete line 20 and write `bump(@c, 2)` on line 21. That also prints `5`, `5`, `a`, because `step` would stay 1 and the second bump passes 2 directly. I chose the cell because it keeps the name and changes only one token, so the fix is closest to what the author wrote.
2. **Fixing line 22.** I made `last` an immutable binding (`last $= words[0]`). The other choice is to keep the cell and add a re-binding, such as `last = words[4]`, which prints the same `a`. Or delete `last` and print `words[0]`, which also prints `a`. I chose `$=` because it is the smallest change and nothing in the program re-binds `last`.
3. **Line 5 classification.** I counted the `@c` parameter as *new name*. The other reading is *neither*, since the `@` mark in a signature changes no value and `=` does not appear on that line. I went with *new name* because the signature introduces `c` into the body's scope.
4. **Line 20 classification.** I counted it as *changes an existing name*, from the operator alone, which is the reading the brief asks for. The other reading is *neither*, since the checker refuses the line and nothing changes. The verdict is the same either way.
5. **Lines 19 and 21.** I counted the `@` arguments as *changes an existing name*, because the spec says an `@` argument counts as a write. The other reading would count them as *neither* if you consider only the call and not what the callee does. The spec's "an `@` argument counting" pushes me to the first reading.
6. **Reading "the smallest change".** I took it as the fewest edits that make the checker accept the program while keeping the printed output the author evidently intends. Other edits (for example, rewriting the loop) would also be accepted but are not minimal.

## confidence

- **Most sure:** line 22 is refused. The spec states that a cell nothing re-binds is a compile error, and nothing in `main.hero` re-binds `last`.
- **Also very sure:** line 20 is refused. `$=` binds once, forever, and `=` re-binds only cells or fields and elements inside them.
- **Sure:** the other lines are accepted, and the printed output of the fixed program is `5`, `5`, `a`. The arithmetic is simple and all types are `i64`, `str` or `{str: i64}`, which the spec covers directly.
- **Least sure:** the line-level classifications for lines 5, 19, 20 and 21 (see `choice_points`). These depend on how you read "new name", "changes an existing name" and "neither" for parameters and for a refused line. I am also relying on the reading that `c @= Counter(...)` (line 18) counts as a re-binding target for the `@` arguments on lines 19 and 21, which is the spec's "an `@` argument counting" rule.
- I cannot run the checker, so this is a reading of the specification, not a compile result.

## context

Only the files in this directory reached my context: `brief.md`, `spec.md` and `main.hero`. I read no other files and used no tools other than reading and writing files here.

Beyond those files, my context holds the system's environment notes (the working directory, platform, date and model) and a git status snapshot. The snapshot lists `run.err` and `run.json` as untracked files in the repository. I did not open either file, and they did not inform the verdict.
