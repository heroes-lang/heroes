## verdict

Refused, on lines 20 and 22 of `main.hero`.

- Line 20, `step @ 2`: `step` is bound by `=` on line 10, and an `=` name cannot be re-bound. The `@` on this line has no mutable cell to write to.
- Line 22, `last @= words[0]`: `last` is a mutable cell that nothing re-binds. The rule says a cell nothing re-binds is a compile error, and a read (`print(last)` on line 25) does not count as a re-binding.

Every other line is accepted by the rules I could check.

The smallest change that makes the program accepted and keeps its evident meaning is two edits:

- Line 10: `step = 1` becomes `step @= 1`, so that the later `step @ 2` re-binds a cell.
- Line 22: `last @= words[0]` becomes `last = words[0]`, since nothing needs to re-bind it.

The corrected program prints:

```
5
5
a
```

Trace: the loop runs five times with `step` = 1, so `total` = 5 and `counts["a"]` = 3. `bump(@c, 3)` gives `c.hits` = 3. `step` then becomes 2, and `bump(@c, step)` gives `c.hits` = 5. `last` is `"a"`.

## lines

| line | new name / changes an existing name / neither | the words of the specification relied on |
|---|---|---|
| 5 | *new name* (`c`, a parameter) | "Param = "@" ident ":" Type"; "Mutable parameters are marked `@` in the signature and at the call site" |
| 6 | *changes an existing name* (`c.hits`) | "`@` re-binds it, or a field or element inside one"; grammar `Simple = Place "@" Expression` |
| 9 | *new name* (`words`) | "`=` binds once, forever." (a plain `=` binding with no `@`); grammar `Binding = [ ":" Type ] ( "=" \| "@=" ) Expression` |
| 10 | *new name* (`step`) | "`=` binds once, forever." (it is the `=` form, so line 20 cannot re-bind it) |
| 11 | *new name* (`counts`) | "`@=` declares a mutable cell" |
| 12 | *new name* (`total`) | "`@=` declares a mutable cell" |
| 15 | *changes an existing name* (an element of `counts`) | "`@` re-binds it, or a field or element inside one" |
| 16 | *changes an existing name* (`total`) | "`@` re-binds it, or a field or element inside one" |
| 18 | *new name* (`c`) | "`@=` declares a mutable cell"; "Record construction is a call with field names, always mandatory:" |
| 19 | *changes an existing name* (`c`, through the `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site"; "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument." |
| 20 | *changes an existing name* (`step`), refused | "`=` binds once, forever." and "`@` re-binds it" (only for a cell declared with `@=`) |
| 21 | *changes an existing name* (`c`, through the `@` argument) | same as line 19 |
| 22 | *new name* (`last`) | "`@=` declares a mutable cell"; refused as written by "a cell nothing re-binds" |

Line 22 is refused because of this sentence: "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."

## sentences

Quoted from `spec.md`, each one the verdict or the line classifications rest on:

1. Section 5, line 134: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
2. Section 5, lines 137-138: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
3. Section 5, grammar: "Binding   = [ ":" Type ] ( "=" | "@=" ) Expression NEWLINE ."
4. Section 5, grammar: "Simple    = "_" Binding | Place "@" Expression NEWLINE"
5. Section 9, lines 271-272: "Mutable parameters are marked `@` in the signature and at the call site:"
6. Section 9, lines 274-276: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
7. Section 9, line 258: "Record construction is a call with field names, always mandatory:"
8. Section 3, table: "`[T]` | dynamic array, indices from 0"
9. Section 6, example: "function head(xs: [str]) -> str?" with "return ok(xs[0])" (shows that indexing a `[str]` yields a `str`)
10. Section 6, table: "`.default(v)` | extract or fall back"
11. Section 10: "`m[k]` is a `V?` with code `missing_key`;"
12. Section 2: "A literal takes the type its context asks for ... otherwise `i64`."
13. Section 11: "`print` writes its values with no separator and exactly one trailing newline"

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a` (one per line).

## choice_points

1. **Fixing line 20.** I changed line 10 to `step @= 1`, which keeps line 20 as written. The other choice was to delete line 20 or to change it. Deleting it gives `c.hits` = 4 after the first bump, so the output would be `4`, `5`, `a`. That changes the program's meaning, so I did not take it.
2. **Fixing line 22.** I changed `@=` to `=`. The other choices were `last @ w` inside the loop, or `last = words[4]`. Each gives `a`, so the printed output is the same. I chose the form that changes the least.
3. **Classifying the call-site `@` on lines 19 and 21.** I called these *changes an existing name*, because the callee works on the caller's place. The other choice is *neither*, since the line binds nothing. Acceptance and output do not depend on this choice.
4. **Classifying the parameter on line 5.** I called it *new name*, since `c` comes into existence in the function. The other choice would be to skip line 5 as a signature. Again, the verdict does not change.
5. **Type of `step`.** The literal `1` takes `i64` because no other context asks for a type, and `c.hits` is `i64`. Any other choice would be refused by the `i64` operations, so I took `i64`.

## confidence

- **Verdict (refused on lines 20 and 22):** high. Both rules are stated directly in the specification, and I checked the rest of the program against them.
- **Printed output of the corrected program (`5`, `5`, `a`):** high. I traced the loop and the two `bump` calls by hand.
- **Least sure of:** the line 19 and 21 classification (a judgment call, choice point 3) and the intent behind `last` (choice point 2). The output is the same under the alternatives I considered.

## context

Files read from this directory: `brief.md`, `spec.md`, `main.hero`, and `run.json` and `run.err`. The last two are empty and were not used. The brief named only `spec.md` and `main.hero` as inputs, so I note that I also opened the two empty files.

Other things in my context that did not come from this directory: the session's system instructions, the environment block (model identity, working paths, date), and a git status snapshot. None of these bore on the answer. I used no tool other than reading and writing files here, and I ran nothing.
