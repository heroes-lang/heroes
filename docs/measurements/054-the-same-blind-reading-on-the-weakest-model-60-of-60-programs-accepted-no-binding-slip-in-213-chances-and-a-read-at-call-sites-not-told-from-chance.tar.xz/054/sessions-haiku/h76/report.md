# Report

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty = items[i].qty - n
                return true
            return false
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for row in items
        total = total + row.qty
    print(total)
```

Expected output: `true`, `false`, `4`, each on its own line. (apple 3 + 4 = 7, take 5 leaves 2; pear 2 cannot give 9; sum 2 + 2 = 4.)

## sentences

Line numbers refer to the program above.

- "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 21-31.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every line; the program uses only spaces, and `if` conditions are bare (lines 7, 14, 15).
- "`record` ... `Fields = INDENT { ident ":" Type NEWLINE } DEDENT`" (section 4 grammar). Governs lines 1-3.
- "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`." Governs line 10 (`Item(name: name, qty: n)`).
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs lines 6, 10, 13 (`items.len()`, `items.push(...)`).
- "UFCS does not apply when the first parameter is `@`." Governs lines 5, 12: the user functions are called as `restock(@items, ...)` and `take(@items, ...)`, never as `items.restock(...)`.
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` ... `advance(@l)`." Governs lines 5, 12 (signatures) and 23-27 (call sites).
- "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 8 and 16 (element field re-binding through an `@` parameter), line 22 (`items` cell), lines 28 and 30 (`total` cell).
- "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs line 10. `items` is a plain name, so the push grows in place.
- "A container literal separates elements by newline across lines and by comma on one, and an empty one needs an annotation: `xs: [i64] $= []` · `m: {str: i64} @= {}`." Governs line 22 (`items: [Item] @= []`).
- "When two parameters in a signature share a type, named arguments are mandatory at the call site: `copy(from: a, to: b)`." Governs line 6 and line 13 (`range(from: 0, to: ...)`, both `i64`).
- "`range(from: a, to: b) -> [i64]` exclude `to`." Governs lines 6 and 13: indices run over `0 .. len - 1`, so every `items[i]` is in bounds.
- "`for x in xs`, over an array or a `range` (section 11)." Governs lines 6, 13, 29.
- "An out-of-bounds index or slice aborts." Governs lines 8, 14, 15, 16: the loop bound makes each index valid.
- "`==` is structural equality on any two values of one type, recursively." Governs lines 7 and 14 (`str == str`).
- "`< <= > >=`: a number only" and "`>=`" as a comparison. Governs line 15 (`items[i].qty >= n`, both `i64`).
- "`if cond` / `else if` / `else` take only `bool` - there is no truthiness." Governs lines 7, 14, 15 (each condition is a `bool` comparison). The spec's dash is rendered as a hyphen here.
- "Overflow aborts at every width." Governs lines 8, 16, 30; the values are small, so no overflow occurs.
- "A `@` parameter nothing writes or ends" and "an `@` argument counting" (section 5: a cell nothing re-binds is an error, and an `@` argument counts as a write). Governs line 22: `items` is never re-bound by name in `main`, but it is passed as `@items` to three calls, which counts.
- "All bindings are initialised." Governs lines 22 and 28.
- "An unused binding or parameter is a compile error ... a read is a use and a write is not, except through an `@` parameter." Governs all bindings: `name`, `n`, `items`, `i`, `row`, `total` each are read; `items` in `restock` and `take` is written through `@`.
- "A function with a `->` must `return` on every path that reaches its end." Governs lines 12-19 (`take`): the `for` may finish without a return, so line 19 `return false` covers that path.
- "A statement after a jump, in its block, is a compile error." Governs lines 9, 17, 18, 19: each `return` is the last statement in its block.
- "`return` [Expression] NEWLINE" (section 5 grammar). Governs line 9 (bare `return` in a function without `->`) and lines 17, 18, 19 (`return true`, `return false`).
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." and "a `bool` prints `true` or `false`." Governs lines 26, 27 (`bool`) and 31 (`i64`).
- "Built-ins: ... `len` · `push` ..." Governs lines 10 and 13 (`push`, `len` via `.len()`).
- "`function ... -> bool`" with "`returns true`" (brief) and the signature grammar `Declaration = "function" ident [ Generics ] Params [ "->" Type ] Block`. Governs line 12.

## choice_points

1. **Finding the item: index loop over `range` (chosen) vs. a built-in search.** The spec offers `find`, which returns the element, not its index, so an in-place write would need the index anyway. Other choice: `any`, then a second pass. Same results, more code.
2. **Early `return` inside the loop (chosen) vs. a flag variable.** With a flag, `restock` would set `found` and append after the loop when `found` is false. Same behavior; the flag form needs an extra cell that must be re-bound.
3. **Nested `if` in `take` (chosen) vs. a single condition `items[i].name == name && items[i].qty >= n`.** The single condition would skip a matching item with too little stock and keep searching, then reach `return false` at line 19. Since `restock` never creates duplicate names, both give the same result. The nested form states the "otherwise changes nothing" branch directly.
4. **`items.len()` (chosen) vs. `len(items)`.** The spec shows both forms for built-ins. Same result.
5. **Append as `items = items.push(...)` (chosen) vs. `push(items, ...)`.** The spec's sentence uses the UFCS form, so that is the form I chose. The function-call form would also be valid under the same rule.
6. **Mutable `items` cell in `main` (chosen) vs. building the list in a function returning `[Item]`.** A cell is needed because `@items` is passed in three calls. A returned list would have to be rebound and would not match the brief's `@items` signature.
7. **`print(take(...))` (chosen) vs. binding `ok $= take(...)` first.** `print` uses the value, so the "a line that computes a value must use it" rule is met with no `_ $=`.
8. **Sum with a `total` cell and a `for` loop (chosen) vs. `fold`.** `fold` needs a named function value for `add`, which the brief does not provide; the loop is shorter. A `fold` with a lambda is not possible here (no anonymous functions).
9. **Loop variable names `i` and `row` (chosen).** The spec forbids shadowing a `use` name and has no such names here; any other name gives the same result.
10. **`>=` in `take` (chosen) vs. `>` with `n - 1`.** The brief says "holds at least `n`", so `>=` is the exact reading.
11. **Element write `items[i].qty = ...` (chosen) vs. a copy-modify-write of the whole element `items[i] = Item(...)`.** The field write is shorter; the other form would produce the same stored value.
12. **Blank lines between declarations (chosen).** The grammar does not require them; they change nothing.

## confidence

I am fairly sure the checker accepts the program, roughly 80%. I cannot run it, so this rests on reading the spec.

Least sure line: **line 10** (`items = items.push(Item(name: name, qty: n))`). It re-binds an `@` parameter as a whole cell and relies on `push` growing in place for a plain name. The spec states both, but the combination (a mutable parameter reassigned with `push`) is the one I could not confirm by a direct example.

Next least sure: **lines 8 and 16** (`items[i].qty = ...` through an `@` parameter). The Place rule (`ident { "." ident | "[" Expression "]" }`) and "`=` re-binds ... a field or element inside one" cover it, but it is an indexed field write inside a mutable parameter.

## context

Only the files in this directory reached my context: `brief.md`, `spec.md`, and `run.json` and `run.err`, which are both empty. I used no file outside this directory and no external documentation. I wrote the program from `spec.md` alone; nothing else informed it.
