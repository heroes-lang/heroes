## program

```
function sorted_desc(xs: [i64]) -> [i64]
    arr @= xs
    n := arr.len()
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if arr[j] < arr[j + 1]
                t := arr[j]
                arr[j] = arr[j + 1]
                arr[j + 1] = t
    return arr

function runs(xs: [i64]) -> i64
    if xs.len() == 0
        return 0
    count @= 1
    for i in range(from: 1, to: xs.len())
        if xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output: `9`, `6`, `5`, `4`, `3`, `2`, `1`, `1` on eight lines, then `4`.

Line numbers below count from the first line of the fenced block. Line 1 is `function sorted_desc`, line 10 is `return arr`, line 12 is `function runs`, line 19 is `return count`, line 21 is `function main()`, line 24 is the last line.

## sentences

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 21.
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line.
3. "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs line 2 (`arr @= xs`). Sorting `arr` leaves `xs` unchanged.
4. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 2, 15 and 18 (`count = count + 1`), and the element writes on lines 8 and 9.
5. "Place     = ident { "." ident | "[" Expression "]" } ." Governs lines 8 and 9, which assign to `arr[...]` as a place.
6. "`:=` binds once, forever." Governs lines 3 (`n := arr.len()`) and 7 (`t := arr[j]`).
7. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." This is why each name is distinct within a function. The loop variables `i` and `j` are each bound once per loop, and `i` in `sorted_desc` (line 4) and in `runs` (line 16) belong to different functions. Governs the whole program.
8. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds." Governs line 2 (`arr` is written on lines 8 and 9), line 3 (`n` is read on lines 4 and 5), line 7 (`t` is read on line 9), line 15 (`count` is re-bound on line 18), and line 22 (`x` is read on line 23).
9. "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals on lines 13, 14, 15, 16, 22 and 24, and the list literals on lines 22 and 24.
10. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `arr.len()` (line 3), `xs.len()` (lines 13 and 16).
11. Section 11 lists `len` among the built-ins with no stated signature. The program takes `len` to return `i64`, see choice point 5. Governs lines 3, 5, 13 and 16.
12. "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs the loop ranges on lines 4, 5 and 16.
13. "When two parameters in a signature share a type, named arguments are mandatory at the call site: `copy(from: a, to: b)`." Governs lines 4, 5 and 16. Both parameters of `range` are `i64`, so each call names both.
14. "`for` ... over an array or a `range` (section 11)." The grammar is `For = "for" ident "in" Expression Block`. Governs lines 4, 5, 16 and 22. Line 22 iterates the array that `sorted_desc` returns.
15. "`if cond` / `else if` / `else` take only `bool`; there is no truthiness." Governs lines 6, 13, 17. Each condition is a `bool` comparison.
16. "comparison   == != < <= > >=    (`< <= > >=`: a number only)." Governs line 6 (`<`) and line 17 (`!=`), both on `i64`.
17. "An out-of-bounds index or slice aborts." The program avoids this. On line 5 the bound `n - 1 - i` keeps `j + 1` at most `n - 1` on line 6. On line 17, `i` starts at 1 on line 16, so `i - 1` is at least 0.
18. "A function with a `->` must `return` on every path that reaches its end." Governs `sorted_desc` (line 10) and `runs` (line 19). The `return 0` on line 14 is the last statement of its block, so nothing follows a jump in that block.
19. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 23 and 24, both on `i64`.

## choice_points

1. **Copy into a mutable cell.** The parameter `xs` is read-only and cannot be re-bound. I chose `arr @= xs` (line 2) and sort `arr`. The other choice, marking the parameter `@xs`, would change the signature the brief fixes and force `@` at every call site. The sorted output would be the same.
2. **Swap test `<` versus `<=`.** I chose `arr[j] < arr[j + 1]` (line 6), which swaps only strictly out-of-order pairs. The other choice, `<=`, would also swap equal neighbours. The printed output is identical, since swapping equal values changes nothing, but the program does more writes.
3. **Inner bound `n - 1 - i` versus `n - 1`.** I chose `n - 1 - i` (line 5), because after pass `i` the last `i` slots already hold their final values. The other choice, `n - 1`, is still correct, because `j + 1` stays within the array, but it makes extra comparisons. The output is the same.
4. **`for` over `range` versus `while`.** I chose `for ... in range(...)` (lines 4, 5, 16). The other choice, a `while` loop with a `@=` counter, gives the same result without relying on the `range` named arguments. I judged the `for` form simpler and in line with the spec's loop description.
5. **Type of `len`.** The spec does not state what `len` or `.len()` returns. I assumed `i64`, which the literals `0` and `1` and the arithmetic `n - 1 - i` need in order to type-check, since the spec forbids mixed widths. If `len` returned another integer width, lines 3, 5, 13 and 16 would fail. A fix would be `to_i64(...)` plus `.must()`. I did not add it.
6. **Empty input in `runs`.** The brief does not say what `runs([])` should return. I chose the guard on lines 13 and 14, which returns `0`. The other choice, starting `count @= 1` with no guard, returns `1` for an empty array. The brief's example does not exercise this case.
7. **Named arguments on `range`.** The spec makes them mandatory, because both parameters share `i64`. I wrote `range(from: ..., to: ...)`. A positional call would be refused, so this is a requirement and not a free choice.
8. **`sorted_desc` argument form.** I called `sorted_desc([...])` positionally (line 22). Naming the argument `xs:` is also valid, since the name is optional for a single parameter. Both forms compile to the same program.
9. **Swap in place versus a helper.** I wrote the swap inline with a temporary `t` (lines 7 to 9). The other choice, a helper that returns a new array for each swap, would copy the array on every swap and is slower. The spec has no tuple swap, so the temporary is the direct form.

## confidence

I am fairly confident the checker accepts the program on the first try, at roughly 80 to 85 percent. Every construct comes from a rule the spec states directly: `@=` cells, element assignment through `Place`, `for` over `range`, `if` on `bool`, `return` on every path, and `print`.

The line I am least sure of is line 3, `n := arr.len()`. The spec lists `len` with no signature, so `i64` is inferred from the literals and the mixed-width rule, not stated. If `len` does not return `i64`, lines 3, 5, 13 and 16 are refused.

Second least sure is line 8, `arr[j] = arr[j + 1]`. The `Place` production allows an index, and "`=` re-binds it, or a field or element inside one" covers it. The spec's own element-assignment example uses a map (`m["a"] = 1`), not an array.

## context

Nothing other than this directory's files reached my context. I read `brief.md`, `spec.md`, `run.json` and `run.err`. The last two are empty and contributed nothing. I read no file outside this directory and used no other tool. I did not run anything, and the checker was not available to me, so the confidence figure is an estimate from the spec alone.
