## verdict

Refused. The checker would reject `main.hero` as written, on two lines:

- **Line 20** `step @ 2`: `step` was bound with `=` on line 10, and `=` binds once, forever. `@` may only re-bind a cell (`@=`).
- **Line 22** `last @= words[0]`: `last` is a cell that nothing re-binds, which is a compile error.

Nothing else in the file is refused by the rules I checked (see `lines` and `choice_points`).

Because the program is refused, it produces no output as written. The smallest change that is accepted and keeps the evident meaning is in `program`, and that program prints:

```
5
5
a
```

## lines

| Line | Text | Kind | Words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (the parameter `c`) | "Param = "@" ident ":" Type" (section 4); "Mutable parameters are marked `@` in the signature" (section 9). The `@` marks the parameter as mutable; the line itself introduces `c`. |
| 6 | `c.hits @ c.hits + by` | *changes an existing name* | "`@` re-binds it, or a field or element inside one" (section 5). `c` is an `@` parameter, so this write is allowed. |
| 9 | `words = ["a", "b", "a", "c", "a"]` | *new name* | "`=` binds once, forever" (section 5). |
| 10 | `step = 1` | *new name* | "`=` binds once, forever" (section 5). A literal with no context takes `i64` (section 2). |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell" (section 5). |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell" (section 5). |
| 15 | `counts[w] @ counts[w].default(0) + step` | *changes an existing name* | "`@` re-binds it, or a field or element inside one" (section 5); "`m[k] @ v` inserts or replaces" (section 10). |
| 16 | `total @ total + step` | *changes an existing name* | "`@` re-binds it" (section 5). |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell" (section 5). |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, through its `@` argument) | "an `@` argument counting" as a write (section 5); "Mutable parameters are marked `@` ... at the call site" and "the callee works on the caller's place itself" (section 9). |
| 20 | `step @ 2` | *changes an existing name* in its form (`@` re-binds `step`), but **refused**: `step` is not a cell | "`=` binds once, forever" and "`@=` declares a mutable cell, and `@` re-binds it" (section 5). On this line alone the `@` re-binds `step`; that `step` is immutable is learned from line 10. |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, through its `@` argument) | Same as line 19. |
| 22 | `last @= words[0]` | *new name*, but **refused**: a cell nothing re-binds | "`@=` declares a mutable cell" (section 5); "so is a cell nothing re-binds" (section 5). |

## sentences

From section 5 (Bindings):

- "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."

From section 9 (Functions and calls):

- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy: `function peek(l: Lex lent)` … `peek(l)`. Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."

From section 10 (Strings, arrays, maps):

- "`m[k] @ v` inserts or replaces;"

From section 2 (Literals):

- "A literal takes the type its context asks for — `b: u8 = 255`, and `b + 1` is a `u8` — otherwise `i64`."

From section 11 (Built-ins):

- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output of this program:

```
5
5
a
```

Trace: `counts` ends with `a` = 3, `b` = 1, `c` = 1, so the first `bump` adds 3 and `c.hits` is 3. `total` counts the five words at `step` 1, so it is 5. Then `step` becomes 2 and the second `bump` adds 2, so `c.hits` is 5. `last` is `"a"`, the first word.

Changes made relative to `main.hero`: line 10 `step = 1` becomes `step @= 1`, and line 22 `last @= words[0]` becomes `last = words[0]`.

## choice_points

1. **How to make line 20 accepted.** I made `step` a cell by changing `=` to `@=` on line 10. This keeps lines 20 and 21 as written, which is the evident meaning. The other choice, giving the new value its own name (`step2 = 2` and `bump(@c, step2)`), also prints `5`, `5`, `a`, but it changes two lines and drops the re-binding the author wrote. Keeping `step` at `1` throughout would print `4` for `c.hits`, which contradicts the evident meaning.
2. **How to make line 22 accepted.** I changed `@=` to `=`, since `last` is never re-bound. The other choice, keeping the cell and adding a re-bind (for example `last @ words[0]`), is contrived and would print the same `a`.
3. **Whether line 5 counts as introducing a name.** I classified it as *new name*, since the parameter `c` comes into existence in the signature. A reader could say it changes nothing and is only a marker. The specification does not settle this word by word.
4. **Whether line 20 counts as changing or neither.** As written it is refused, so no value changes. I classified it as *changes an existing name* because the `@` re-binds `step`, and I noted the refusal.
5. **Unread record field.** `label` is never read. The specification makes unused bindings and parameters errors, and says nothing about fields, so I assumed it is accepted. The other reading would refuse line 2 as well.
6. **`by` as a parameter name.** `by` is not in the keyword list in the specification, so I assumed it is a valid identifier.

## confidence

- **Most sure:** line 20 is refused and line 22 is refused. Both follow directly from quoted sentences in section 5.
- **Sure:** the fixed program prints `5`, `5`, `a`. The arithmetic and the `@` argument rules are explicit.
- **Less sure:** the classification of line 5 (choice 3), the reading of line 20 as "changes an existing name" (choice 4), and the treatment of the unread field `label` (choice 5). These are judgments about the wording, not about the checker's output.
- **Least sure:** I have not checked the bytes of `main.hero` for tab characters. The file shows four-space indentation when read, and I did not run anything to confirm there are no tabs.

## context

Files read: `brief.md`, `spec.md` and `main.hero`, all in this directory, as the brief requires. I also read `run.json` and `run.err`, which are also in this directory but were not part of the brief's inputs. Both are empty, so they had no effect on this report.

Nothing outside this directory was read, and no tool was used other than reading and writing files here. The system context I was given, which includes the environment details, the git status and the user's account, reached my context. The git status lists `run.err` and `run.json` as untracked files, which is how I knew they existed. None of that context was used in the verdict.
