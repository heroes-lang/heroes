# Report

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    found @= false
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            items[i].qty @ items[i].qty + n
            found @ true
    if !found
        items @ items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty @ items[i].qty - n
                return true
            return false
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    first = take(@items, "apple", 5)
    print(first)
    second = take(@items, "pear", 9)
    print(second)
    total @= 0
    for item in items
        total @ total + item.qty
    print(total)
```

Expected output, traced by hand: `true`, `false`, `4` (apple 7 minus 5 leaves 2, pear 2 is unchanged, sum 4).

## sentences

Quotations are from `spec.md`. Line numbers refer to the program above, counted from its first line.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()` (line 23).
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs the whole layout, and the conditions with no parentheses, such as line 8 `if items[i].name == name`.
3. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs `found @= false` (line 6), `items: [Item] @= []` (line 24), `total @= 0` (line 32), and the re-bindings on lines 9, 10, 12, 18, 34.
4. "Signatures are always explicit; inference is local only." Governs every `function` line, including the `-> bool` in `take` (line 14).
5. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." Governs `found` (read on line 11), `first` and `second` (read by `print`, lines 29 and 31), `total` (read on lines 34 and 35), and the `@items` parameters of `restock` and `take` (written on lines 9 and 18).
6. "A container literal separates elements by newline across lines and by comma on one, and an empty one needs an annotation" Governs `items: [Item] @= []` (line 24).
7. "`xs: [i64] = []` · `m: {str: i64} @= {}`" Confirms the `name: Type @= []` form used on line 24.
8. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs `Item(name: name, qty: n)` (line 12).
9. "`xs @ xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs `items @ items.push(Item(name: name, qty: n))` (line 12). `items` is a plain name, so the array grows in place.
10. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `items.len()` (lines 7 and 15) and `items.push(...)` (line 12).
11. "Mutable parameters are marked `@` in the signature and at the call site" Governs `@items` in the signatures on lines 5 and 14, and `@items` at each call site on lines 25 to 27 and 30.
12. "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness." Govern the conditions on lines 8, 11, 16 and 17.
13. "boolean      && || !            (bool only; && and || short-circuit)" from the operator table of section 7. Governs `!found` (line 11): the operand is a `bool` cell.
14. "`==` is structural equality on any two values of one type, recursively" Governs `items[i].name == name` (lines 8 and 16), comparing two `str` values.
15. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs `for i in range(...)` (lines 7 and 15) and `for item in items` (line 33).
16. "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs `range(from: 0, to: items.len())` (lines 7 and 15), which yields indices `0` to `len - 1`.
17. "Built-ins: `print(...)` · `len` · `push`" and the rest of the built-in list in section 11. Governs the `print` calls (lines 29, 31, 35) and the use of `push` (line 12).
18. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs `print(first)`, `print(second)`, `print(total)`.
19. "A function with a `->` must `return` on every path that reaches its end" Governs `take`: the final `return false` (line 21) covers the path that leaves the loop.
20. "A statement after a jump, in its block, is a compile error." Governs `take`: `return false` on line 20 sits after an `if` with no `else`, not after a jump in the same block, so it is legal.
21. "Overflow aborts at every width." Relevant to `items[i].qty + n` (line 9) and `total + item.qty` (line 34). The values here are far from any limit.
22. "Declaration order never matters but a group's" Governs `restock` and `take` being declared before `main`; the order is irrelevant.
23. "Every top-level line starts with its kind." Governs `record Item` (line 1), `function restock` (line 5), `function take` (line 14), `function main()` (line 23).
24. "`"record" ident Fields`" from the `Declaration` production of section 4. Governs `record Item` with its indented fields (lines 1 to 3).
25. "`Arg = [ ident ":" ] [ "@" ] Expression .`" from section 9. Governs `@items` as an argument in `take(@items, ...)` (line 28) and `restock(@items, ...)` (lines 25 to 27).
26. "Syntax is ASCII-only" Governs the whole program, which is ASCII.

## choice_points

1. **Finding the item in `restock`:** a `found` flag set in a loop (chosen). The other choice, an early `return` on the match, would also work and produce the same items list, since names are unique.
2. **Finding the item in `take`:** an early `return` inside the loop (chosen). The other choice, a `found` flag and one final `return`, produces the same results.
3. **Loop form:** `for i in range(from: 0, to: items.len())` (chosen). The other choice is a `while` over a mutable index cell `i @= 0` with `i @ i + 1`. Same behaviour, more lines, more chances to slip.
4. **Appending:** `items @ items.push(Item(name: name, qty: n))` (chosen, following the spec's `xs @ xs.push(4)` pattern). The other choice, `push(@items, ...)`, would probably be rejected, because the spec never says `push` takes an `@` argument, and a bare `push(...)` call would leave a value unused unless it is bound. This is the riskiest choice.
5. **Sum:** a `for` loop over `items` with a `total` cell (chosen). The other choice, `items.fold(0, add)`, needs a top-level `add` function, which the spec permits but which adds a declaration. Both produce `4`.
6. **Printing the two results:** bound to `first` and `second` before `print` (chosen). The other choice, `print(take(@items, "apple", 5))`, relies on `@` being accepted inside a `print` argument. The grammar's `Arg` allows it, but the spec's rule about `@` arguments makes it less certain. The output would be the same if it compiled.
7. **Empty list annotation:** `items: [Item] @= []` (chosen). The other choice, `items @= []` with no annotation, is an error by the spec ("an empty one needs an annotation"), so the checker would refuse it.
8. **Length:** `items.len()` (chosen, UFCS sugar). The other choice, `len(items)`, is also a built-in call. The spec lists `len` among built-ins without a signature, so the method form follows the one example the spec gives (`xs.len()`).
9. **Printing the booleans:** `print(first)` directly (chosen). The other choice, `print(to_str(first))`, would print the same `true` or `false`.
10. **Named arguments to `range`:** `from:` and `to:` are both `i64`, so the spec makes names mandatory only where two parameters of a signature share a type; I wrote them anyway, since the spec's own form is `range(from: a, to: b)`. Dropping them would be the riskier option.
11. **Integer width:** all numbers are `i64` by default. The other choice, annotating `total: i64 @= 0` or using `u64`, would also work; `i64` matches `qty`.
12. **Names:** `i`, `item`, `found`, `first`, `second`, `total` do not clash with `items`, `name`, `n`, or each other. Shadowing is an error, so each name is bound once per scope.

## confidence

About 85% that the checker accepts the program on the first try.

Least sure line: line 12, `items @ items.push(Item(name: name, qty: n))`. The spec gives the pattern `xs @ xs.push(4)` and says it grows in place for a plain name, which matches. It does not give the signature of `push` for a record element, so I am relying on the pattern carrying over to a record, with a constructor as its argument.

Second least sure: lines 7 and 15, `range(from: 0, to: items.len())`. The named-argument form follows section 11, and `.len()` follows the spec's use of `xs.len()`, but the spec gives no explicit signature for `len`.

## context

Files read from this directory: `brief.md`, `spec.md`, `run.json`, `run.err`. Both `run.json` and `run.err` came back empty, so they added nothing to the program. No file outside this directory was read, and no tool was used except reading and writing files here, as the brief requires.

Other things in my context, not from this directory: the session's environment description (platform, shell, working directory, scratchpad path, model identity, date), a git status snapshot, and account metadata. None of these informed the program or the rules used in it.
