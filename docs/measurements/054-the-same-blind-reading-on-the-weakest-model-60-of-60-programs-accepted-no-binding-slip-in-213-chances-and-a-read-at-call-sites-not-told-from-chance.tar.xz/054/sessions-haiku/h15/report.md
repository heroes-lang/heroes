## verdict

Refused. The checker would reject two lines of `main.hero` as written:

- **Line 20** `step = 2`. `step` is bound by `:=` on line 10, and a `:=` name is never re-bound. `=` re-binds only a cell (`@=`) or a field or element inside one.
- **Line 22** `last @= words[0]`. `last` is a cell that nothing re-binds, which the spec makes a compile error. It is read by `print(last)`, but a read is a use and does not count as a write.

Nothing else on the file's `=` or `@` lines is refused on the spec's words. Line 19 and line 21 pass `@c`, and an `@` argument counts as a re-binding, so `c` on line 18 is accepted.

Smallest accepted program (see `program`): change `step := 1` to `step @= 1` on line 10, and change `last @= words[0]` to `last := words[0]` on line 22. The program then prints:

```
5
5
a
```

Trace: `counts["a"]` ends at 3 (indices 0, 2, 4), so `c.hits` is 3 after the first `bump`, then 5 after `bump(@c, step)` with `step` equal to 2. `total` is 5 because the loop runs five times with `step` still 1. `last` is `"a"`.

## lines

| line | source | class | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (parameter `c`) | "Param = "@" ident ":" Type"; "Mutable parameters are marked `@` in the signature and at the call site" |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (`c`, a field of it) | "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." |
| 9 | `words := ["a", "b", "a", "c", "a"]` | *new name* | ":= binds once, forever." |
| 10 | `step := 1` | *new name* | ":= binds once, forever."; "otherwise `i64`" (see `sentences`) |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell" |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell" |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (`counts`, an element) | "`=` re-binds it, or a field or element inside one."; "`m[k] = v` inserts or replaces;" |
| 16 | `total = total + step` | *changes an existing name* (`total`) | "`@=` declares a mutable cell, and `=` re-binds it" |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell"; "Record construction is a call with field names, always mandatory" |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, through the `@` argument) | "an `@` argument counting" (in the sentence on cells, see `sentences`); "the callee works on the caller's place itself" |
| 20 | `step = 2` | *changes an existing name* in form, and refused: `step` is a `:=` name | ":= binds once, forever."; "`=` re-binds it" (only a cell) |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, through the `@` argument) | same as line 19 |
| 22 | `last @= words[0]` | *new name*, but a cell nothing re-binds: refused | "`@=` declares a mutable cell"; "a cell nothing re-binds" is a compile error |

Note on line 22: the spec's cell rule makes the line refused even though its name is used by `print(last)`.

## sentences

From section 5 (Bindings):

> `:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one.

> All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter.

From section 2 (Literals), the type of `step` and `total`. The dash inside the sentence is the spec's own, shown here as "[dash]":

> A literal takes the type its context asks for [dash] `b: u8 := 255`, and `b + 1` is a `u8` [dash] otherwise `i64`.

From section 9 (Functions and calls):

> Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy:

> Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`, and a variant's case `.num(v: 7)` or `.plus`.

From section 10 (Strings, arrays, maps):

> `m[k] = v` inserts or replaces;

> `m[k]` is a `V?` with code `missing_key`;

From section 6 (Failure), the table row used by `.default(0)`:

> `.default(v)` | extract or fall back

From section 11 (Built-ins), the output of `print`:

> `print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`.

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a`, one per line.

## choice_points

1. **Line 20 (`step = 2`).** I made `step` a cell by changing line 10 to `step @= 1`. This keeps the line the author evidently meant. Other choices:
   - Delete line 20 and keep `step` at 1: `bump(@c, step)` then adds 1, and the program prints `4`, `5`, `a`.
   - Keep `step := 1` and write `step2 := 2`, then `bump(@c, step2)`: prints `5`, `5`, `a`, the same as my choice.
2. **Line 22 (`last @= words[0]`).** I changed `@=` to `:=`, because `last` is never re-bound. Other choices:
   - Keep the cell and add a later write, such as `last = words[1]`: the output's last line would change to `b`.
   - Delete `last` and its `print`: the output would be `5`, `5`.
3. **Reading of "an `@` argument counting".** I read it as meaning that `bump(@c, ...)` counts as a write to `c`, so `c` on line 18 is not refused. The other reading would refuse line 18 as a cell nothing re-binds. The smallest fix would then be a plain write to `c` in `main`, with output unchanged.
4. **Classification of line 5.** I called the `@c` parameter a *new name*, because a parameter brings its name into existence in `bump`. The other reading would count the `@` as marking an existing name, which would be *neither*.
5. **Classification of line 20.** I put it under *changes an existing name* because its form is a re-binding. The spec forbids it, so it is refused. Reading it as *neither* would reflect that no re-binding happens. Either way the verdict is the same.
6. **The unused record field `label`.** The spec's unused-binding rule covers bindings and parameters, not fields. I left `label` as it is and treated the program as accepted on that point.

## confidence

- **High** that the checker refuses line 20. The spec says `:=` binds once, forever, and `=` re-binds only a cell or a field or element inside one.
- **High** that the checker refuses line 22. The spec says a cell nothing re-binds is a compile error, and `print(last)` is a read, not a write.
- **Medium** on the rest of the file being accepted. This depends on the `@`-argument reading (choice 3). I think the sentence supports it, but it is the least certain point.
- **Medium-high** on the printed output of the fixed program. It depends on `print` rendering `i64` as plain decimal, which the spec states, and on my trace of the arithmetic.
- I could not run anything, so the verdict and output come from reading the spec and the program, not from a compiler run.

## context

Only the files in this directory reached my reasoning: `brief.md`, `spec.md` and `main.hero`. I read each in full and wrote this report here. Nothing outside this directory was read, and no other tool was used.

The session also gave me its environment metadata: the working directory, the platform, and a git status snapshot from the start of the session. That snapshot named two untracked files, `run.err` and `run.json`, which I did not open and which play no part in this report.
