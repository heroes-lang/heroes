## verdict

Refused, on lines 20 and 22 of `main.hero`.

- Line 20, `step = 2`: `step` was bound with `:=` on line 10, and a `:=` name binds once, forever. Only a `@=` cell can be re-bound with `=`.
- Line 22, `last @= words[0]`: `last` is a cell that nothing re-binds (its only later use, line 25, is a read). The spec refuses a cell nothing re-binds.

Everything else in the file is accepted by the rules quoted below.

If accepted, the program as written would print nothing, because it is refused. The smallest change that is accepted and does what it evidently means prints:

```
5
5
a
```

(Line 10 becomes `step @= 1`, line 22 becomes `last := words[0]`; see `program`.)

## lines

Every line of `main.hero` holding `=` or `@` (including `:=`, `@=`, and `@` at a call site or in a parameter list).

| Line | New name, changes an existing name, or neither | Words of the specification relied on |
|---|---|---|
| 5 `function bump(@c: Counter, by: i64)` | **new name** (parameters `c` and `by`) | §1 `Param = "@" ident ":" Type \| ident ":" Type [ "lent" ] .`; §9 "Mutable parameters are marked `@` in the signature and at the call site" |
| 6 `c.hits = c.hits + by` | **changes an existing name** (`c.hits`, a field inside the `@` parameter `c`) | §5 "`=` re-binds it, or a field or element inside one." |
| 9 `words := ["a", "b", "a", "c", "a"]` | **new name** (`words`) | §5 "`:=` binds once, forever." |
| 10 `step := 1` | **new name** (`step`) | §5 "`:=` binds once, forever."; §2 "otherwise `i64`" |
| 11 `counts: {str: i64} @= {}` | **new name** (`counts`) | §5 "`@=` declares a mutable cell, and `=` re-binds it"; §10 "an empty one needs an annotation: ... `m: {str: i64} @= {}`" |
| 12 `total @= 0` | **new name** (`total`) | §5 "`@=` declares a mutable cell" |
| 15 `counts[w] = counts[w].default(0) + step` | **changes an existing name** (an element of `counts`) | §5 "`=` re-binds it, or a field or element inside one."; §10 "`m[k] = v` inserts or replaces" |
| 16 `total = total + step` | **changes an existing name** (`total`) | §5 "`@=` declares a mutable cell, and `=` re-binds it" |
| 18 `c @= Counter(label: "a", hits: 0)` | **new name** (`c`) | §5 "`@=` declares a mutable cell"; §9 "Record construction is a call with field names, always mandatory" |
| 19 `bump(@c, counts["a"].default(0))` | **changes an existing name** (`c`, through the `@` argument; the write itself happens on line 6) | §9 "Mutable parameters are marked `@` ... at the call site"; §9 "the callee works on the caller's place itself"; §5 "an `@` argument counting" |
| 20 `step = 2` | **changes an existing name**, and refused (`step` is `:=`) | §5 "`:=` binds once, forever."; §5 "`@=` declares a mutable cell, and `=` re-binds it" |
| 21 `bump(@c, step)` | **changes an existing name** (`c`, as on line 19) | §9 "Mutable parameters are marked `@` ... at the call site"; §5 "an `@` argument counting" |
| 22 `last @= words[0]` | **new name** (`last`), and refused: nothing re-binds it | §5 "`@=` declares a mutable cell"; §5 "so is a cell nothing re-binds" |

No line is classed as *neither*. Line 19 and line 21 are the closest call; see `choice_points`.

## sentences

Every sentence of the specification the verdict rests on, quoted. Where a sentence contains an em dash in the source, I have elided that part with `...`.

From §1 (layout):
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."

From §2 (literals):
- "A literal takes the type its context asks for ... otherwise `i64`."

From §5 (bindings):
- "`:=` binds once, forever."
- "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "All bindings are initialised."
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."

From §9 (functions and calls):
- "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` ... `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy: `function peek(l: Lex lent)` ... `peek(l)`."
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`, and a variant's case `.num(v: 7)` or `.plus`."

From §10 (strings, arrays, maps):
- "A container literal separates elements by newline across lines and by comma on one, and an empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`."
- "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"

From §6 (failure), the `.default(v)` row of its table:
- "`.default(v)` | extract or fall back"

From §11 (built-ins):
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

The program I would submit, whole. Two changes from the original: line 10 `step := 1` becomes `step @= 1`, and line 22 `last @= words[0]` becomes `last := words[0]`.

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

What it prints, traced by hand:
- The loop runs over five words, each adding `step` (1) to `total` and to a count. After the loop `counts` is `a: 3, b: 1, c: 1` and `total` is `5`.
- `bump(@c, 3)` sets `c.hits` to `3`. `step` becomes `2`, and `bump(@c, 2)` sets `c.hits` to `5`.
- `last` is `"a"`.

Output:
```
5
5
a
```

## choice_points

1. **Fix for `step` (line 10 vs. line 20).** I made `step` a cell (`step @= 1`), which keeps line 20 and the program's shape. The other choice was to delete `step = 2` and pass the literal: `bump(@c, 2)` on line 21 (and deleting line 20). That also prints `5`, `5`, `a`, and changes two lines instead of one.
2. **Fix for `last` (line 22).** I changed `@=` to `:=`, since nothing is meant to change `last` later. The other choice was to keep `last @= words[0]` and add a re-binding, for example another `last = ...` line. That would invent behaviour the program does not have, and it would need a value I would be guessing. Its output would differ from `a` only if the added value differed.
3. **Lines 19 and 21 (`bump(@c, ...)`).** I classed these as *changes an existing name*, because the call may change `c` through the callee, and the spec says the callee "works on the caller's place itself". The other reading is *neither*: the `@` at the call site only marks the argument, and the write is on line 6. I chose the first reading because it matches the spec's use of "an `@` argument counting" as a use of the cell.
4. **Line 5 (`@c`, `by`).** I classed these parameters as *new names*. The other reading would not count parameters as bindings. It would not change any verdict, because no parameter is unused and both are used.
5. **Refusing line 20 (`step = 2`).** The spec has no sentence that says "re-binding a `:=` name is an error" in those words. I took it from "`:=` binds once, forever" together with "`=` re-binds it" applying to a `@=` cell. The other choice would be to accept line 20, but I think that departs from the spec.
6. **Unused record field.** `label` in `Counter` is never read. I did not treat this as an error, because the spec's unused rule covers bindings and parameters, and a record field is neither. The other choice would refuse line 3 or 18.

## confidence

- **Most sure:** that line 22 is refused, since the spec states "a cell nothing re-binds" is a compile error, and `last` has no re-binding. Also that the fixed program prints `5`, `5`, `a` (I traced the arithmetic twice).
- **Less sure:** that line 20 is refused as written. The spec does not say in one sentence that re-binding an `:=` name is an error, and I inferred it from §5. If the checker accepted it, the verdict would change to accepted on line 22 only.
- **Least sure:** the byte-level layout. I checked indentation by reading the file view, which shows four spaces per level, but I cannot see raw bytes here. A tab would be a compile error under §1. I also could not run the checker, so this is a reading, not a test.

## context

- Files read in this directory: `brief.md`, `spec.md` (in full), `main.hero` (in full). I also read `run.json` and `run.err`. The brief did not ask for them; both are empty and I did not use them.
- Nothing outside this directory was read, and no tool was used beyond reading and writing files here.
- Outside the files, the harness gave me the working directory, platform, scratchpad path, today's date, and my model identity. A session git-status snapshot listed `run.err` and `run.json` as untracked, plus one commit named `inputs`. None of this bears on the verdict.
