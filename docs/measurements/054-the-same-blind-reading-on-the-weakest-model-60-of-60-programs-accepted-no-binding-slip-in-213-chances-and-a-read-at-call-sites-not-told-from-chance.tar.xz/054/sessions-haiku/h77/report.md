## verdict

Refused, on lines 20 and 22 of `main.hero`.

- **Line 20** (`step @ 2`): `step` is bound by `=` on line 10, and `=` binds once, forever. Only a `@=` cell can be re-bound with `@`.
- **Line 22** (`last @= words[0]`): `last` is a cell that nothing re-binds, and the spec makes that a compile error.

Every other line is accepted as written. Line 5 and line 19 are fine on their own. The program is refused because of lines 20 and 22 only.

Smallest accepted program: two single-token edits, one for each refusal (see `program`). As written, the program is not accepted, so it prints nothing. If the two edits are made, it prints:

```
5
5
a
```

Hand trace of the fixed program: `words` is `a b a c a`, so `counts` ends with `a` = 3. `total` is incremented 5 times by `step` = 1, giving 5. `c.hits` goes 0, then +3 (`counts["a"]`), then +2 (`step` after line 20), giving 5. `last` is `"a"`.

## lines

| line | kind | classification | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (parameter `c`, in scope in `bump`) | "Mutable parameters are marked `@` in the signature and at the call site"; the `@` is a mark, it binds no value. See choice point 1. |
| 6 | `c.hits @ c.hits + by` | *changes an existing name* (field of the `@` parameter `c`) | "`@` re-binds it, or a field or element inside one." |
| 9 | `words = [...]` | *new name* | "`=` binds once, forever." |
| 10 | `step = 1` | *new name* | "`=` binds once, forever." |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell"; "an empty one needs an annotation: `m: {str: i64} @= {}`" |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell" |
| 15 | `counts[w] @ counts[w].default(0) + step` | *changes an existing name* (element of `counts`) | "`@` re-binds it, or a field or element inside one."; "`m[k] @ v` inserts or replaces" |
| 16 | `total @ total + step` | *changes an existing name* (`total`, a cell) | "`@=` declares a mutable cell, and `@` re-binds it" |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell" |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, passed as `@` argument) | "Mutable parameters are marked `@` in the signature and at the call site"; "an `@` argument counting" (as a write) |
| 20 | `step @ 2` | *changes an existing name* in intent; **refused**, because `step` is an `=` name | "`=` binds once, forever."; "`@=` declares a mutable cell, and `@` re-binds it" |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, `@` argument) | as line 19 |
| 22 | `last @= words[0]` | *new name* (cell `last`); **refused**, because no `@` re-binds it | "a cell nothing re-binds ... is a compile error" |

## sentences

Sentences the refusal of lines 20 and 22 rests on:

- Section 5: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
- Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- Section 5 (grammar): "Simple = ... | Place "@" Expression NEWLINE ..." (the grammar accepts `step @ 2` syntactically; the refusal comes from the semantic rules above).

Sentences the verdict on the other lines and the output rests on:

- Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."
- Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing."
- Section 2: "A literal takes the type its context asks for [...] otherwise `i64`."
- Section 3: "No implicit conversions, widths included: `1 + 2.0` is an error."
- Section 5: "Signatures are always explicit; inference is local only."
- Section 6 (table row): "`.default(v)` | extract or fall back"
- Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"
- Section 10: "`m[k]` is a `V?` with code `missing_key`; `m[k] @ v` inserts or replaces;"
- Section 10: "an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`."
- Section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)."
- Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Edits relative to `main.hero`: line 10 `step = 1` becomes `step @= 1`, and line 22 `last @= words[0]` becomes `last = words[0]`. Output: `5`, `5`, `a`, one per line.

## choice_points

1. **Line 5, new name or neither.** I chose *new name*, because the parameter `c` comes into existence in `bump`. The other choice, *neither*, reads the `@` as a mark that binds no value. The verdict is unaffected.
2. **Fix for line 20.** I chose to make `step` a cell on line 10 (`step @= 1`), so the existing `step @ 2` re-binds it. The other choice removes the re-binding and passes the literal: `bump(@c, 2)` in place of lines 20 and 21, with `step = 1` left as an `=` name. That also prints `5`, `5`, `a`, but changes more of the program.
3. **Fix for line 22.** I chose `last = words[0]` (drop the `@`). The other choice keeps `@=` and adds a re-binding such as `last @ words[0]` after line 22. That also prints `a`, but adds a line that does nothing new.
4. **Refusal reading of line 22.** I read "a cell nothing re-binds ... is a compile error" as applying to `last`, which has no `@` on any later line. The other reading, that an unused `@=` cell is fine, is ruled out by the sentence quoted.
5. **Literal types.** `step`, `total`, and the map values are `i64` by the default rule. The other choice would be a narrower type, but every value here fits in `i64`, so the output is the same.
6. **Map iteration order.** The program never prints map contents, so the order from `keys` does not affect the output. I did not use `keys`.

## confidence

- **High** that the program as written is refused. Line 22 follows from the "cell nothing re-binds" rule, and line 20 from "`=` binds once, forever" together with "`@` re-binds" a `@=` cell.
- **High** that the two-edit program is accepted and prints `5`, `5`, `a`. I checked the types (all `i64`, `str`, and `counts[w].default(0)`), the indentation, the single `@` argument per call, and the `@` parameter being written in `bump`.
- **Medium** on the exact wording of the checker's refusal for line 20. The spec has no single sentence saying "`@` on an `=` name is an error." That follows from the two sentences quoted in `sentences`.
- **Least sure** of the classification of line 5 (choice point 1).
- **Not verified:** I read the files as text. I could not check bytes for tabs or invisible control characters beyond what the reader shows. I could not run the checker.

## context

- Read in this directory: `brief.md`, `spec.md` (in full), `main.hero`.
- Also read, although the brief does not name them: `run.json` and `run.err`. Both are empty. I did not use their contents.
- Outside this directory, the harness supplied: the working-directory and platform description, a git status snapshot, a user identity note, and the current date. None of this bears on the program or the verdict. No other files were read, and no tools other than reading and writing files were used.
