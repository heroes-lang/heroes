## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    while i < items.len()
        if items[i].name == name
            items[i].qty @ items[i].qty + n
            return
        i @ i + 1
    items @ items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    while i < items.len()
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty @ items[i].qty - n
                return true
            return false
        i @ i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    taken_apple = take(@items, "apple", 5)
    taken_pear = take(@items, "pear", 9)
    print(taken_apple)
    print(taken_pear)
    total @= 0
    for item in items
        total @ total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4`.

## sentences

Line numbers are the program's own lines, counted from `record Item` as line 1 (so the program's line 1 is the file's line 4 in this report).

- "Every top-level line starts with its kind." Governs lines 1, 5, 14, 25.
- "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs lines 5, 14, 25: `restock` and `take` are used by `main`, which is declared last.
- "Signatures are always explicit; inference is local only." Governs lines 5, 14, 25.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line.
- "No braces, no semicolons; a condition needs no parentheses." Governs lines 7, 8, 16, 17, 18.
- "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 25.
- "Fields = INDENT { ident ":" Type NEWLINE } DEDENT ." Governs lines 1 to 3 (`record Item` with `name: str` and `qty: i64`).
- "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs line 12 (`Item(name: name, qty: n)`).
- "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs lines 6, 9, 11, 12, 15, 19, 22, 26, 34, 36.
- "Binding = [ ":" Type ] ( "=" | "@=" ) Expression NEWLINE ." Governs lines 6, 15, 26, 30, 31, 34.
- "an empty one needs an annotation: `xs: [i64] = []`" Governs line 26 (`items: [Item] @= []`).
- "Place = ident { "." ident | "[" Expression "]" } ." Governs line 9 and line 19 (`items[i].qty @`) and line 12 (`items @`).
- "Mutable parameters are marked `@` in the signature and at the call site" Governs lines 5, 14, 27 to 31.
- "an `@` parameter nothing writes or ends" Governs lines 5 and 14: `items` is written at lines 9 and 12 in `restock`, and at line 19 in `take`.
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds" Governs lines 6, 15, 26, 30, 31, 34: every name is used, and the cells `i` and `total` are re-bound.
- "Shadowing is a compile error" Governs every binding. The names `i`, `items`, `name`, `n`, `taken_apple`, `taken_pear`, `total` and `item` do not repeat within a function.
- "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`, which a `()` line refuses: it stands alone." Governs lines 27 to 29 (`restock` returns `()` and stands alone) and lines 32, 33, 37 (`print`).
- "`return` [ Expression ] NEWLINE" (grammar `Simple`) Governs the bare `return` at line 10 and `return true` / `return false` at lines 20, 21, 23.
- "A function with a `->` must `return` on every path that reaches its end" Governs lines 14 to 23 (`take`): the `while` loop can finish, and line 23 returns on that path.
- "A statement after a jump, in its block, is a compile error." Governs lines 10 to 11 and 20 to 22: no statement follows a jump in the same block.
- "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness." Govern lines 8, 17, 18.
- "While = "while" Expression Block ." Governs lines 7 and 16.
- "For = "for" ident "in" Expression Block ." Governs lines 35 and 36.
- "`<` `<=` `>` `>=`: a number only" Governs lines 7, 16 and 18 (`>=` on `i64`).
- "`==` is structural equality on any two values of one type, recursively" Governs lines 8 and 17 (`str == str`).
- "`[T]` dynamic array, indices from 0" Governs lines 8, 9, 17, 18, 19 (`items[i]`).
- "`xs @ xs.push(4)` grows in place when `xs` is a plain name" Governs line 12. `items` is a plain name.
- "Built-ins: `print(...)` · `len` · `push`" Governs `len` at lines 7 and 16, `push` at line 12, and `print` at lines 32, 33, 37.
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `items.len()` at lines 7 and 16 and `items.push(...)` at line 12.
- "UFCS does not apply when the first parameter is `@`." Does not block lines 7, 12, 16, since the first parameter of `len` and `push` is not `@`.
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 32, 33, 37.
- "a `bool` prints `true` or `false`." Governs lines 32 and 33.
- "A literal takes the type its context asks for" and "otherwise `i64`." Govern `i @= 0` (lines 6, 15 of the program's own count, i.e. the `i` cells) as `i64`, and the literals `3`, `2`, `4`, `5`, `9` at lines 27 to 31 as `i64`.
- "Overflow aborts at every width." Not triggered: the largest value is 9.
- "Arg = [ ident ":" ] [ "@" ] Expression ." Governs lines 27 to 31: the arguments are positional.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site." Does not apply: `restock` and `take` have the parameter types `[Item]`, `str`, `i64`, all different.

## choice_points

1. **Finding a name in `items`.** I used an index cell `i` with `while i < items.len()`. The other choice: a `for item in items` loop that builds a new array and writes it back through `items @ ...`. That avoids the index and the `len` type question, at the cost of more code. Output is the same.
2. **Type of `len` and of an index.** I assumed `items.len()` yields an `i64`, to match `i @= 0` (the default literal type). The spec does not state the return type of `len`, and it has no implicit conversions, so a mismatch would be an error at lines 7 and 16. If `len` returns `u64`, the fix is a typed cell such as `i: u64 @= 0`. I also assumed `items[i]` takes an `i64` index. The output is the same in every case; only the type check depends on this.
3. **Positional or named arguments.** I used positional arguments. The other choice, `restock(@items, name: "apple", n: 3)`, is also legal and gives the same output.
4. **Using the `take` results.** I bound each result to a name, then printed it. The other choice, `print(take(@items, "apple", 5))`, passes an `@` argument inside another call. The spec does not forbid it, but I did not want to rely on that reading. Output is the same.
5. **Early `return` in `restock`.** I return from inside the loop once the name is found. The other choice, an `else` branch around the append, gives the same output.
6. **Summing with a `for` loop, not `fold`.** The spec gives no example of `fold`'s signature. A `for` loop is certain to check; `fold` would be shorter but less certain.
7. **Appending with `items @ items.push(...)`.** The spec says a push reached through a field or an index copies the whole array. `items` is a plain name here, so it grows in place. Another choice, pushing through a field of a wrapper record, would copy and still give the same output.
8. **Missing name in `take`.** The spec says the call "changes nothing and returns `false`". The loop reaches line 23 and returns `false` when no item matches.

## confidence

I am fairly confident (about 80%) that the checker accepts this program as written. I checked every rule that applies to the constructs used: bindings, `@` parameters and their writes, return paths, statements after a jump, UFCS, `print` of `bool`, and the empty-array annotation. I found nothing in the spec that forbids any of them.

The line I am least sure of is line 7, and line 16 for the same reason: `i < items.len()`. It depends on `len` returning `i64`, which the spec does not state. Lines 8 and 18 rely on `items[i]` accepting an `i64` index. Lines 9 and 19 rely on a field write through an index (`items[i].qty @ ...`); the grammar allows it, but the spec gives no example of it.

## context

Only the files in this directory were read as file content: `brief.md`, `spec.md`, and `run.json` and `run.err`, which are both empty. No file outside this directory was read, and no tool other than reading and writing files here was used.

Other material did reach my context and is not from this directory's files: the system-provided environment description (working directory, platform, shell, scratchpad path, date, model details, a git status snapshot, and account metadata). None of it was used to write the program or this report; the program rests only on `spec.md`.
