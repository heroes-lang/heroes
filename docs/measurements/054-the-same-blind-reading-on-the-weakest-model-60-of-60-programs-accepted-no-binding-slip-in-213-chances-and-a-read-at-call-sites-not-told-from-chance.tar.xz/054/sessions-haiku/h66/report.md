# Report

## program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n: i64 = len(xs)
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if ys[j] < ys[j + 1]
                t = ys[j]
                ys[j] @ ys[j + 1]
                ys[j + 1] @ t
    return ys

function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    for i in range(from: 1, to: len(xs))
        if xs[i] != xs[i - 1]
            count @ count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output, by hand: `9`, `6`, `5`, `4`, `3`, `2`, `1`, `1`, then `4`. Nothing was run, so this is a trace, not a test.

Line numbers in the rest of this report count the lines of the block above, starting at 1 for `function sorted_desc`.

## sentences

1. Lines 2, 8, 9, 15, 18. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." This governs the cells `ys` and `count`, and the element re-bindings `ys[j] @` and `ys[j + 1] @` (Place and Simple in section 5: "Place = ident { "." ident | "[" Expression "]" }", and "Simple = "_" Binding | Place "@" Expression NEWLINE ...").
2. Line 2. "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Here `ys @= xs` copies the parameter, which is what lets `ys` be mutated while `xs` stays unchanged.
3. Lines 3, 4, 5, 6, 7, 8, 9, 13, 16, 17. The table row "`[T]` | dynamic array, indices from 0". It governs the array indexing `ys[j]`, `ys[j + 1]`, `xs[i]`, `xs[i - 1]`.
4. Lines 4, 5, 16. "`range(from: a, to: b) -> [i64]` exclude `to`." It governs the three loops. Their `to` bound is excluded, so `range(from: 0, to: n)` yields 0 through n - 1.
5. Lines 4, 5, 16. "When two parameters in a signature share a type, named arguments are mandatory at the call site". `range` has two `i64` parameters, so both calls use `from:` and `to:`.
6. Lines 6, 13, 17. "`if cond` / `else if` / `else` take only `bool`". Each `if` condition is a `bool` comparison.
7. Lines 6, 13, 17. "a condition needs no parentheses." Each condition is written bare.
8. Lines 4, 5, 16, 22. "`while cond` and `for x in xs`, over an array or a `range` (section 11)." It governs the `for` loops over `range` and over the array returned by `sorted_desc`.
9. Lines 1 to 10 (return on line 10), and lines 12 to 19 (return on lines 14 and 19). "A function with a `->` must `return` on every path that reaches its end". Both functions end in a `return`, and the early return in `runs` is a `return` inside an `if` that is itself a path.
10. Lines 3, 7, 15, and the loop variables on lines 4, 5, 16, 22. "An unused binding or parameter is a compile error". Every binding and parameter is read: `n` on lines 4 and 5, `t` on line 9, `count` on line 19, `i` on line 5 and line 17, `x` on line 23, `xs` on lines 2, 3, 13, 16.
11. Lines 13, 14, 15, 16, 18. "A literal takes the type its context asks for" and "otherwise `i64`." Each literal (`0`, `1`, `2`) sits in an `i64` context, so it is an `i64`.
12. Lines 5, 6, 8, 9, 17, 18. "arithmetic `+ - * / %`" and "both sides one numeric type". Every operation has `i64` on both sides, because `n`, `i`, `j`, `ys` elements and `count` are all `i64`.
13. Lines 6 and 17. "comparison `== != < <= > >=`" and "(`< <= > >=`: a number only)". Line 6 uses `<` on `i64` elements and line 17 uses `!=` on `i64` elements.
14. Line 21. "the file you compile holds `function main()`, which takes nothing and produces nothing." `main` takes no parameters and has no `->`.
15. Line 24. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Lines 23 and 24 print `i64` values.
16. Every line. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." The program uses 4 spaces per level and no tabs.
17. Lines 1, 12, 21 (the three declarations). "Declaration order never matters but a group's (section 13)". `main` on line 21 calls `sorted_desc` and `runs`, which are declared earlier. The order is also valid either way.
18. Every statement. "Outside brackets a line ends its statement". Every statement sits on one line, so no statement breaks across lines.
19. Line 3. "Signatures are always explicit; inference is local only." The parameter and return types are written out. The annotation on line 3 is written because the type of `len` is not given in the spec (see choice points).

## choice_points

1. **Algorithm.** I used nested `for ... in range` bubble sort with no swap flag. The other choice, a `while` loop with a flag that stops early, gives the same output and needs `@=` for the flag. Both are valid. The spec only forbids the built-in `sort`.
2. **Copy of the parameter (line 2).** I wrote `ys @= xs` and kept `xs` as a plain parameter. The other choice, `@xs` in the signature, would make the array mutable in place, but then every caller must pass `@xs`. `main` passes a literal, which is not a place, so that call would be refused.
3. **Length type (lines 3, 13, 16).** The spec names `len` as a built-in but never gives its return type. I assumed `i64`, so that `n: i64 = len(xs)` holds and `range(from: 0, to: len(xs))` accepts it. If `len` returned another integer type, line 3 would be a type error, and so would lines 13 and 16 through `range`.
4. **Index type (lines 7, 8, 9, 17).** The spec says arrays are indexed from 0 but does not give the index type. I used `i64` indices, which match `range`. Another integer type would need casts that the spec does not describe, so `i64` is the safe reading.
5. **Swap method (lines 7 to 9).** The spec has no tuple assignment. I used a temporary `t`. The other choices, such as building a new array, are longer and do not change the result.
6. **Strict versus non-strict swap (line 6).** I swap only when `ys[j] < ys[j + 1]`, so equal elements are left alone. The other choice, `<=`, would still sort correctly and print the same output, but it does extra work.
7. **Empty input in `runs` (lines 13 and 14).** I return `0` for an empty array. The other choice, dropping the guard, would give `1` for an empty array, because `count` starts at 1 and the loop range is empty. The guard matches the usual definition of runs.
8. **Named arguments on `range` (lines 4, 5, 16).** The spec makes named arguments mandatory there, so I wrote `from:` and `to:`. The other choice, positional arguments, would be refused.
9. **Named or positional on single-parameter calls (lines 22, 24).** I wrote positional arguments. The spec's `xs:` form is also valid, since a name is optional when there is only one parameter. Both produce the same result.
10. **Where `n - 1 - i` can go negative.** The inner bound `n - 1 - i` is never negative for this input. The outer loop stops at `n - 1`, so the inner bound is at least 0. If it were negative, the spec does not say whether `range` gives an empty range or aborts. For this input the case does not arise.

## confidence

I am fairly confident the checker accepts this program, roughly 85 percent. The code uses only the constructs the spec states clearly: `@=`, element re-binding, `range` with named arguments, `if`, `return` on every path, `for ... in`, and `print`. The rest of my confidence depends on the points the spec leaves open.

The line I am least sure of is line 3, `n: i64 = len(xs)`. The spec never gives the return type of `len`. If it is not `i64`, this line fails, and so does every `range` call that uses `n` or `len(xs)`, on lines 4, 5 and 16. The next least sure is line 8 and line 9, `ys[j] @ ys[j + 1]` and `ys[j + 1] @ t`. The spec's Place rule allows an index, but I have not seen an example of an element re-binding inside a loop, so the spec's wording is the only evidence.

## context

Nothing from outside this directory's files was read. I read `brief.md`, `spec.md`, `run.json` and `run.err`, all in this directory. `run.json` and `run.err` are empty. I wrote only `report.md`, and I ran nothing.

Information from the surrounding session did reach my context. It included the working directory and platform, the date and model information, and a git status snapshot that listed `run.err` and `run.json` as untracked files, along with the recent commit and account metadata. None of it is spec content. It did not change the program, but I am stating it here as the brief asks.
