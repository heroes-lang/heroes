## verdict

Refused, on two lines:

- **Line 20** `step = 2`: `step` is bound by `:=` on line 10, and `:=` binds once, forever. Only a `@=` cell can be re-bound with `=`.
- **Line 22** `last @= words[0]`: `last` is a cell that nothing re-binds. The specification refuses "a cell nothing re-binds".

Nothing else in `main.hero` is refused on the reading I took. The smallest fix is two token changes: line 10 `step := 1` becomes `step @= 1`, and line 22 `last @= words[0]` becomes `last := words[0]`. The corrected program prints `5`, `5`, `a` (one per line).

## lines

| Line | Class | Words of the specification relied on |
|---|---|---|
| 5 | *new name* | `function bump(@c: Counter, by: i64)`: the `@` marks parameter `c`. The grammar gives `Param = "@" ident ":" Type`, and section 9 says "Mutable parameters are marked `@` in the signature". The parameter itself is new in `bump`. Whether the caller's `c` changes is decided at the call sites (lines 19 and 21). See choice point 2. |
| 6 | *changes an existing name* | "`=` re-binds it, or a field or element inside one" (section 5). `c.hits` is a field of the `@` parameter `c`. |
| 9 | *new name* | "`:=` binds once, forever" (section 5). No earlier binding of `words`. |
| 10 | *new name* | "`:=` binds once, forever" (section 5). Because it is `:=`, `step` can never be re-bound, which is why line 20 is refused. |
| 11 | *new name* | "`@=` declares a mutable cell" (section 5). The annotated empty map is "`m: {str: i64} @= {}`" (section 10). |
| 12 | *new name* | "`@=` declares a mutable cell, type inferred too" (the comment on the `v @= 0` example in section 5). |
| 15 | *changes an existing name* | "`=` re-binds it, or a field or element inside one" (section 5), and "`m[k] = v` inserts or replaces" (section 10). `counts` is a `@=` cell. |
| 16 | *changes an existing name* | "`=` re-binds it" (section 5). `total` is a `@=` cell. |
| 18 | *new name* | "`@=` declares a mutable cell" (section 5). The record is built with named fields (section 9). |
| 19 | *changes an existing name* | "Mutable parameters are marked `@` in the signature and at the call site" (section 9). "the callee works on the caller's place itself" (section 9), so `c.hits` in `main` changes. |
| 20 | *changes an existing name* (refused) | "`:=` binds once, forever" and "`=` re-binds it" (section 5). `step` is `:=`, so `=` has no permitted target here. |
| 21 | *changes an existing name* | As line 19. |
| 22 | *new name* (refused as written) | "`@=` declares a mutable cell" (section 5). "a cell nothing re-binds" is refused in section 5, and `last` is never re-bound. |

## sentences

From section 5:

- "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."

From section 9:

- "Mutable parameters are marked `@` in the signature and at the call site:"
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- "Record construction is a call with field names, always mandatory:"

From section 10:

- "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"
- "an empty one needs an annotation"

From section 6 (the operations table):

- "`.default(v)` | extract or fall back"

From section 2:

- "A literal takes the type its context asks for" (the sentence continues "... otherwise `i64`.")

From section 1:

- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."

From section 8:

- "A function with a `->` must `return` on every path that reaches its end" (not applicable to `bump` or `main`, which have no `->`).

From section 11:

- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output, traced by hand:

- The loop over `["a", "b", "a", "c", "a"]` with `step` 1 gives `counts` = `a: 3`, `b: 1`, `c: 1`, and `total` = 5.
- `bump(@c, 3)` makes `c.hits` 3. `step` becomes 2.
- `bump(@c, 2)` makes `c.hits` 5. `last` is `"a"`.

So the program prints:

```
5
5
a
```

## choice_points

1. **Line 20: which fix.** I changed line 10 to `step @= 1`, which keeps line 20 as written and keeps its meaning. The other choice is to delete line 20 and write `bump(@c, 2)`, which also prints `5`, `5`, `a`, but it changes the program's shape more.
2. **Line 5: how to classify the `@` parameter.** I read it as *new name*, because the parameter `c` is introduced there. The other reading is *changes an existing name*, because the callee writes the caller's place. I classified the caller's change at lines 19 and 21 as *changes an existing name*.
3. **Whether an `@` argument counts as a re-binding of the cell.** Section 5 says "an `@` argument counting", which I read as: passing `c` as `@c` to `bump` counts as use and as writing `c`. So `c` on line 18 is accepted. The other reading would refuse line 18 as "a cell nothing re-binds" too. That would need a further change, such as an explicit `c = ...` in `main`, and the output would still be `5`, `5`, `a` if the value is unchanged.
4. **Line 22: which fix.** I changed `@=` to `:=`, since `last` is never written again. The other choice is to keep the cell and add a re-binding such as `last = words[0]` after it. It also prints `a`, but it adds a line the program does not need.
5. **Line 10: the cell's type.** `step @= 1` takes `i64` from the literal, since "otherwise `i64`" applies when the context gives no type. The other choice is `step: i64 @= 1`. Same output, more annotation.

## confidence

- **Most sure:** lines 20 and 22 are refused, and the two-change fix is accepted and prints `5`, `5`, `a`. The reasons are the explicit rules in section 5 that `:=` binds once and that a cell nothing re-binds is an error. I am about 90% confident of the verdict and the output.
- **Least sure:**
  - Line 5, whether the `@` parameter line is *new name* or *changes an existing name*. This is a judgement about wording, not a rule.
  - Whether an `@` argument alone counts as a re-binding for "a cell nothing re-binds" (choice point 3). If it does not, line 18 is also refused.
  - Whitespace. The file looks indented with 4 spaces, but I read it as text and cannot inspect the bytes. A single tab would be a compile error under section 1 and would change the verdict.

## context

- **Files read:** `brief.md`, `spec.md` (in full), and `main.hero`, all in this directory.
- **Also read, not used:** `run.json` and `run.err`, both in this directory. Both are empty. The brief lists `spec.md` and `main.hero` as its inputs, so I did not use these two.
- **Other context:** my context also contained the environment block (working directory, platform, date, model), a git status snapshot showing `run.json` and `run.err` as untracked and the commit "inputs", and the user's account metadata. None of this came from reading a file, and I did not use it in the analysis.
- **Tools:** I used only file reads and one file write to `report.md`. I did not run anything.
