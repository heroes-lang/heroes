# report

## program

```
function sorted_desc(xs: [i64]) -> [i64]
    res @= xs
    n $= res.len()
    i @= 0
    while i < n
        j @= 0
        while j + 1 < n - i
            if res[j] < res[j + 1]
                t $= res[j]
                res[j] = res[j + 1]
                res[j + 1] = t
            j = j + 1
        i = i + 1
    return res

function runs(xs: [i64]) -> i64
    if xs.len() == 0
        return 0
    count @= 1
    for i in range(from: 1, to: xs.len())
        if xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below count from the first line of this block (`function sorted_desc`) as line 1, blank lines included. So line 1 is the `sorted_desc` signature, line 16 the `runs` signature, and line 25 the `main` signature.

## sentences

Every quoted sentence is from `spec.md`. Where a sentence was shortened, the omitted part is marked with an ellipsis.

1. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs the indentation of every line; the program uses only spaces, at 4 per level.
2. "NEWLINE ends a statement, and a statement whose last part is a block ends with that block instead." Governs every statement line; each statement is one line, and the `while`, `if`, `for` and `function` lines end with their indented block.
3. "No braces, no semicolons; a condition needs no parentheses." Governs lines 5, 7, 8, 17, 21 (conditions written without parentheses) and the absence of `;` and braces throughout.
4. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs line 16 (`runs`) and line 25 (`main`) being written after `sorted_desc`, and `main` calling both functions defined above it.
5. "Signatures are always explicit; inference is local only." Governs lines 1, 16 and 25, each with an explicit parameter and return type (or none, for `main`).
6. "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs `res @=` (line 2), `n $=` (3), `i @=` (4), `j @=` (6), `t $=` (9), `count @=` (19); and the re-bindings `res[j] = ...` (10, 11), `j = j + 1` (12), `i = i + 1` (13), `count = count + 1` (22).
7. "A literal takes the type its context asks for ... otherwise `i64`." Governs literals `0` (4, 18), `1` (19, 12, 13), `1` in `j + 1` and `i - 1` (7, 8, 10, 11, 21), and the array and integer literals in `main` (26, 28). Each takes `i64` from its context.
8. "A leading zero is an error, never octal." Governs the literal `0` on lines 4 and 18. These are a single digit with no leading zero, so I read them as valid.
9. "All bindings are initialised." Governs every `@=` and `$=` line; each has an initial value.
10. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds ..." Governs `xs` (used on lines 2, 17 and 20), `res` (read at lines 3 to 14), `n`, `i`, `j`, `t`, `count` (each read in the program; the cells `i`, `j`, `count` are re-bound at lines 13, 12, 22).
11. "`while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs the loops on lines 5, 7 (`while`) and 20, 26 (`for`).
12. "`range(from: a, to: b) -> [i64]` exclude `to`." Governs line 20: `range(from: 1, to: xs.len())` yields indices 1 to `len - 1`, which is what `runs` needs.
13. "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs line 20: both `from` and `to` of `range` are `i64`, so the call names both arguments.
14. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `res.len()` (3), `xs.len()` (17, 20). Both are written as method-style calls on the array.
15. "Built-ins: ... `len` ..." Governs `len` being called through UFCS on lines 3, 17, 20. The sentence does not give `len`'s result type; see choice points.
16. "`==` is structural equality on any two values of one type, recursively" Governs `xs.len() == 0` (17).
17. "`< <= > >=`: a number only" Governs `<` on lines 5, 7, 8. The `!=` on line 21 is an equality test and is covered by sentence 16.
18. "`if cond` / `else if` / `else` take only `bool`" Governs the `if` conditions on lines 8, 17, 21: each is a comparison, so it is `bool`.
19. "Precedence, strongest first: ... `* / %` → `+ -` → ... comparisons → `&&` → `||`." Governs line 7 (`j + 1 < n - i`) and line 8, where `+` and `-` bind tighter than `<`. Each side of `<` contains only one `+` or `-`, so no left-to-right associativity question arises.
20. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs `print(x)` (27) and `print(runs(...))` (28), each printing an `i64`.
21. "A function with a `->` must `return` on every path that reaches its end" Governs `sorted_desc` (return at line 14, the only path) and `runs` (return at line 18 on the empty path, and at line 23 on the rest).
22. "A statement after a jump, in its block, is a compile error." Governs line 18 (`return 0`), which ends the `if` block with nothing after it in that block. Line 19 is in the outer block, after the `if`, so it is not in the same block.

## choice_points

1. **Algorithm for `sorted_desc`.** Choice: bubble sort on a mutable copy `res`, swapping when `res[j] < res[j + 1]`. Other choice: swapping when `res[j] > res[j + 1]` produces ascending order, not the descending order the task asks for. A different algorithm (insertion sort) would have needed more lines and no clear gain.
2. **Mutable copy versus `@` parameter.** Choice: `res @= xs` makes a local copy, so the signature stays `xs: [i64]`. Other choice: `@xs: [i64]` would mutate the caller's array in place. That changes the signature the task specifies and needs `@` at the call site in `main`, so I did not use it.
3. **Loop style.** Choice: `while` for both loops, which avoids naming `range` arguments and the bound arithmetic that `range` would need. Other choice: `for j in range(from: 0, to: n - i - 1)` would name both `range` arguments and would be harder to check, since its `n - i - 1` is a chain of two operators.
4. **Inner bound.** Choice: `j + 1 < n - i`, so each `+` and `-` appears on its own side of `<`. Other choice: `j < n - i - 1` is the same loop, but it chains two `-`, which depends on left-to-right associativity that the spec does not state. A bound of `j < n - 1` also sorts correctly, with more comparisons per pass and no out-of-range access.
5. **Type of `len`.** Choice: `n $= res.len()` and `xs.len() == 0` assume `len` returns `i64`, so that it compares with the `i64` loop counters. The spec does not state `len`'s result type. Other choice: if `len` returned a different integer type, lines 3, 5, 7, 17, 20 would need casts, and the checker would refuse the program.
6. **Empty input in `runs`.** Choice: return `0` when `xs` is empty, which matches "how many maximal groups" (no groups). Other choice: starting `count @= 1` without the check would return `1` for an empty array, which is wrong. The early return also keeps `range(from: 1, to: 0)` from being used with an empty array.
7. **Counting method in `runs`.** Choice: start `count` at 1 for the first group and add 1 at each index where `xs[i]` differs from `xs[i - 1]`. Other choice: start `count` at 0 and add 1 for each index where the value differs from the previous one, plus one more for the first element. Both give the same count; the choice only changes where the 1 comes from.
8. **Named arguments in `main`.** Choice: positional `sorted_desc([...])` and `runs([...])`, since each function has a single parameter and the spec makes names optional there. Other choice: `sorted_desc(xs: [...])`, which the spec also accepts, with the same result.
9. **Loop variable in `main`.** Choice: `for x in sorted_desc(...)`, the array form the spec gives. Other choice: index it with `range`, which would print the same values.

## confidence

I am fairly confident the checker accepts this program, but I cannot run it, so this is a judgement from reading the spec, not a test result. My estimate is about 75 percent that it passes first time.

Lines I am least sure of:

- **Line 3 (`n $= res.len()`) and line 20 (`range(from: 1, to: xs.len())`).** Both depend on `len` returning `i64`, which the spec leaves unstated. If it returns another integer type, the comparisons on lines 5, 7, 17 and the `range` call on line 20 would fail. This is the single largest risk.
- **Line 20 (`range(from: ..., to: ...)`).** Named arguments are mandatory here because both parameters are `i64`. I am reasonably sure of that from the spec, but if the checker reads the rule more widely, the call is still valid, since I name both.
- **Lines 2 and 10 to 11 (`res @= xs` and element writes `res[j] = ...`).** The spec allows element re-binding of a cell ("`=` re-binds it, or a field or element inside one"), but I have no example of an element write on a cell that comes from a parameter-derived copy. Low risk, but not checked against an example.

## context

Beyond the files in this directory (`brief.md`, `spec.md`, `run.json`, `run.err`, and `report.md`, which I wrote), the following reached my context:

- The harness and system context for this session: the environment description (platform, shell, working directory, date, model name) and a session git status snapshot with a note that identifies the account. None of it is from a file, and none of it changes the program or the report.
- `run.json` and `run.err` were read. Both are empty and contain nothing relevant to the task.

I read no file outside this directory and used no tool other than reading and writing files here, as the brief requires. I did not run or compile the program.
