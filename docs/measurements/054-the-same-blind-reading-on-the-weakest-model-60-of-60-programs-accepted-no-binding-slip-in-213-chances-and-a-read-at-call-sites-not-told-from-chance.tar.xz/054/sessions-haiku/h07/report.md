# Report

## program

```
record Item
    name: str
    qty: i64

# Adds n to the qty of the item called name, or appends a new item.
function restock(@items: [Item], name: str, n: i64)
    next: [Item] @= []
    found @= false
    for item in items
        if item.name == name
            found = true
            next = next.push(Item(name: item.name, qty: item.qty + n))
        else
            next = next.push(item)
    if !found
        next = next.push(Item(name: name, qty: n))
    items = next

# Subtracts n from the qty of the item called name when it holds at least n, else changes nothing.
function take(@items: [Item], name: str, n: i64) -> bool
    next: [Item] @= []
    taken @= false
    for item in items
        if item.name == name && item.qty >= n
            taken = true
            next = next.push(Item(name: item.name, qty: item.qty - n))
        else
            next = next.push(item)
    if taken
        items = next
    return taken

function main()
    items: [Item] @= []
    restock(@items, name: "apple", n: 3)
    restock(@items, name: "pear", n: 2)
    restock(@items, name: "apple", n: 4)
    a := take(@items, name: "apple", n: 5)
    b := take(@items, name: "pear", n: 9)
    print(a)
    print(b)
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output, traced by hand:

```
true
false
4
```

Trace: restock apple 3 gives [apple 3]; restock pear 2 gives [apple 3, pear 2]; restock apple 4 gives [apple 7, pear 2]. take apple 5 succeeds (7 >= 5), leaving apple 2. take pear 9 fails (2 < 9), so nothing changes. Sum is 2 + 2 = 4.

Program line numbers used below: 1 `record Item`, 2 `name: str`, 3 `qty: i64`, 5 comment, 6 `restock` signature, 7 `next: [Item] @= []`, 8 `found @= false`, 9 `for item in items`, 10 `if item.name == name`, 11 `found = true`, 12 `next = next.push(Item(name: item.name, qty: item.qty + n))`, 13 `else`, 14 `next = next.push(item)`, 15 `if !found`, 16 `next = next.push(Item(name: name, qty: n))`, 17 `items = next`, 19 comment, 20 `take` signature, 21 `next: [Item] @= []`, 22 `taken @= false`, 23 `for item in items`, 24 `if item.name == name && item.qty >= n`, 25 `taken = true`, 26 `next = next.push(Item(name: item.name, qty: item.qty - n))`, 27 `else`, 28 `next = next.push(item)`, 29 `if taken`, 30 `items = next`, 31 `return taken`, 33 `function main()`, 34 `items: [Item] @= []`, 35 to 37 the three `restock` calls, 38 `a := take(...)`, 39 `b := take(...)`, 40 `print(a)`, 41 `print(b)`, 42 `total @= 0`, 43 `for item in items`, 44 `total = total + item.qty`, 45 `print(total)`.

## sentences

Quoted from `spec.md`, with the program lines each one governs.

1. "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 7, 8, 21, 22, 34, 42 (the `@=` declarations) and lines 11, 25, 30, 17, 44 (the re-bindings).
2. "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs lines 12, 14, 16, 26, 28 (`next = next.push(...)`, where `next` is a plain name).
3. "A container literal separates elements by newline across lines and by comma on one, and an empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`." Governs lines 7, 21 and 34 (`[]` with the `[Item]` annotation).
4. "A literal takes the type its context asks for — `b: u8 := 255`, and `b + 1` is a `u8` — otherwise `i64`." Governs the literals `3`, `2`, `4`, `5`, `9`, `0` (lines 35 to 39, 42) and the typing of `total` and `found`-free `n` uses.
5. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`, and a variant's case `.num(v: 7)` or `.plus`." Governs lines 12, 16, 26 (`Item(name: ..., qty: ...)`).
6. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy". Governs lines 6, 20 (`@items` in the signatures) and 35 to 39 (`@items` at the call sites).
7. "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs lines 9, 23, 43 (the `item` loop variable copies) and the way `items = next` replaces the whole array.
8. "`if cond` / `else if` / `else` take only `bool` — there is no truthiness." Governs lines 10, 15, 24, 29 (each condition is a `bool`).
9. "boolean      && || !            (bool only; && and || short-circuit)" (section 7 table). Governs line 15 (`!found`) and line 24 (`&&`).
10. "`==` is structural equality on any two values of one type, recursively; a map's insertion order does not affect it." Governs lines 10 and 24 (`item.name == name`).
11. "`< <= > >=`: a number only" (section 7 table). Governs line 24 (`item.qty >= n`).
12. "arithmetic   + - * / %          (both sides one numeric type — never mixed)". Governs lines 12, 26 (`item.qty + n`, `item.qty - n`) and 44 (`total + item.qty`), all `i64` on both sides.
13. "`for x in xs`, over an array or a `range` (section 11)." Governs lines 9, 23, 43 (`for item in items`).
14. "A function with a `->` must `return` on every path that reaches its end, and `exit(code:)`, `assert false` and a `while true` with no `break` of its own end a path." Governs `take` (line 31 is the only path to its end).
15. "`()` nothing: what a function with no `->` returns". Governs `restock` (lines 6 to 17) and `main` (lines 33 to 45), which have no `->` and no `return`.
16. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." Governs every binding. `items` in `restock` and `take` is written through `items = next` (lines 17, 30). `next`, `found`, `taken`, `total`, `a`, `b` are all read.
17. "A line that computes a value must use it: bind it, or discard it on purpose with `_ := f(x)`, which a `()` line refuses: it stands alone." Governs lines 35 to 37 (`restock` returns `()`, so the bare call stands alone and is not a discarded value) and lines 38 to 39 (`a` and `b` are bound and then printed).
18. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 40, 41 and 45.
19. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs the whole program layout.
20. "Syntax is ASCII-only; comments and strings hold UTF-8 but no raw control character" Governs the whole program (no non-ASCII in code).
21. "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it; `##` is a section heading." Governs lines 5 and 19.
22. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs the order `Item`, `restock`, `take`, `main`: `main` uses both functions declared above it.
23. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." (Only the `use` part applies here, there is no `use`.) The loop variable `item` is reused in `take` and `main`, but these are separate functions with separate scopes, so nothing is shadowed (lines 9, 23, 43).
24. "Record construction ... `Point(x: 3, y: 4)`" also governs the field access `item.name` and `item.qty` (lines 10, 12, 24, 26, 44), which read fields of a record value.
25. "When two parameters in a signature share a type, named arguments are mandatory at the call site" (section 9). Does not apply to `restock` or `take`, because `name: str` and `n: i64` differ in type. Named arguments are used anyway (lines 35 to 39), which is allowed by `Arg = [ ident ":" ] [ "@" ] Expression`.
26. "Syntax is ASCII-only" also governs the string literals `"apple"` and `"pear"` (lines 35 to 39). Strings hold no escapes.

## choice_points

1. **Length of an array.** The spec does not state the return type of the `len` built-in. Comparing it with an `i64` `n` could be a mixed-type error ("both sides one numeric type — never mixed"). Choice: avoid `len` entirely and iterate with `for item in items` (lines 9, 23, 43). Other choice: index loop `while i < items.len()` with `items[i].qty = ...` in place. That would also give `true`, `false`, `4`, but it depends on `len`'s type, which the spec leaves open.
2. **Updating an element.** Choice: rebuild a new array in `next` and write it back with `items = next` (lines 7 to 17, 21 to 30). Other choice: mutate in place with `items[i].qty = items[i].qty + n`. Output is the same. The rebuild avoids both the `len` question and the index type question, but it copies the array on each call.
3. **Whether `take` writes back when it fails.** Choice: write back only when `taken` is `true` (line 29). Other choice: always write `items = next`. Output is the same here, because a failing `take` rebuilds the array with every item copied unchanged (line 28). The guard keeps the spec's wording, "otherwise it changes nothing", literally true even if the copy is not.
4. **Passing `@items` to `take` inside `print`.** Choice: bind the results first (`a := take(...)`, `b := take(...)`, lines 38 to 39) and then `print(a)`, `print(b)`. Other choice: `print(take(@items, name: "apple", n: 5))`. Only one `@` argument appears in that call, so the checker should accept it, and the output is the same.
5. **Named versus positional arguments.** Choice: `name:` and `n:` named at every call (lines 35 to 39), and `@items` positional, as in the spec's `advance(@l)`. Other choice: positional throughout, `restock(@items, "apple", 3)`. Named arguments are not mandatory here, since no two parameters share a type. Output is the same. The other form `items: @items` is allowed by the grammar but is not shown in the spec, so I did not use it.
6. **Variable names.** Choice: `next`, `found`, `taken`, `a`, `b`, `total`. I avoided `ok` because `ok(...)` is a built-in constructor for `T?` (section 6), and a name `ok` could be read as that. Other choice: `ok` for the flag. Output is the same if the checker accepts it, but I did not want the risk.
7. **Comments.** Choice: two comments above the two functions, each a single line. Other choice: no comments. Program behaviour is identical. Comments are checked only for character set and layout, and the spec allows them.
8. **Declaration order.** Choice: `record Item`, then `restock`, `take`, `main` (the spec says order never matters). Other choice: `main` first. Output is the same.
9. **Literal and cell types.** Choice: leave `total` and `found`/`taken` without annotation, relying on "type inferred" for `@=` and the `i64` default for literals. Other choice: `total: i64 @= 0`. Output is the same.
10. **Boolean test.** Choice: `if !found` (line 15) instead of `if found == false`. Both are `bool` and both should be accepted. Output is the same.

## confidence

About 85 percent that the checker accepts the program as written, and about 97 percent that, if accepted, it prints `true`, `false`, `4`.

Least sure line: **line 17 (`items = next`) and line 30 (`items = next`)**. The spec says `=` re-binds a mutable cell, or a field or element inside one, and says an `@` parameter is "the caller's place itself". It does not say in so many words that a whole `@` parameter may be re-bound with `=`. If the checker rejects that, the fix is to switch to the in-place form from choice 2, which I did not use because I could not verify the `len` type. The second least sure line is **line 12 and line 26** (`Item(name: item.name, qty: ...)` inside a `next.push(...)` call), because it nests a record construction inside a method call, which the spec does not show. That should be fine under the grammar, but it is not a shown example.

## context

Only the two files in this directory were read: `brief.md` and `spec.md`. I did not open `run.err`, `run.json`, or any other file, and I did not read files outside this directory. I used no tools besides reading these two files and writing `report.md`, as the brief requires.

Other material did reach my context, but it was not files in this directory. It was the system prompt, the environment block (which names the working directory and platform), and a git status snapshot that lists `run.err` and `run.json` as untracked. I did not act on any of it when writing the program or this report. The brief itself, the spec and the design choices above are the only inputs that shaped the program.
