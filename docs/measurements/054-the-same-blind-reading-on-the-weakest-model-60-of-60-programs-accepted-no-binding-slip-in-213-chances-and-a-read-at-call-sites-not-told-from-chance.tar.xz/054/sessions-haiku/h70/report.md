## program

```
# Heroes program: sorted_desc, runs and main.

function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n $= len(ys)
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if ys[j] < ys[j + 1]
                t $= ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
    return ys

function runs(xs: [i64]) -> i64
    count @= 0
    seen @= false
    prev @= 0
    for x in xs
        if !seen
            seen = true
            count = 1
        else if x != prev
            count = count + 1
        prev = x
    return count

function main()
    for v in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(v)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output: `9 6 5 4 3 2 1 1` on eight lines, then `4`.

## sentences

Line numbers refer to the program block above (line 1 is the comment).

1. "`#` comments to end of line, markdown inside." Governs line 1.
2. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 27-30.
3. "Every top-level line starts with its kind." Governs lines 3, 14 and 27 (each starts with `function`).
4. "Param = "@" ident ":" Type | ident ":" Type [ "lent" ] ." Governs the parameters `xs` on lines 3 and 14.
5. "Signatures are always explicit; inference is local only." Governs lines 3, 14 and 27 (every signature is written out, and `main` has no `->`).
6. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds" Governs every binding: `ys`, `n`, `i`, `j`, `t`, `count`, `seen`, `prev`, `x`, `v`. Each is read after it is bound, and each cell (`ys`, `count`, `seen`, `prev`) is re-bound.
7. "`$=` binds once, forever." Governs lines 5 (`n`) and 9 (`t`), which are never written again.
8. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 4 (`ys`), 10 and 11 (element re-binding of `ys`), 15-17 (`count`, `seen`, `prev`), and 20, 21, 23, 24 (re-binding of those cells).
9. "Binding = [ ":" Type ] ( "$=" | "@=" ) Expression NEWLINE ." Governs lines 4, 5, 9, 15, 16 and 17.
10. "Place = ident { "." ident | "[" Expression "]" } ." Governs the element re-bindings on lines 10 and 11.
11. "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `0`, `1` and `false` on lines 15-17, 20-21, 23 and the literals in the arrays on lines 28 and 30. Each becomes `i64` (or `bool` for `false`).
12. "`range(from: a, to: b) -> [i64]` exclude `to`." Governs lines 6 and 7 (the upper bounds `n` and `n - 1 - i` are excluded, so the largest index read is `n - 1`).
13. "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs lines 6 and 7, where both `from` and `to` are `i64`, so the named form `from:` and `to:` is used.
14. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 6, 7, 18 and 28.
15. "For = "for" ident "in" Expression Block ." Governs the same loops, each with one ident before `in`.
16. "Built-ins: `print(...)` ... `len` ..." together with "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs `len` on line 5, and `print` on lines 29 and 30 (each prints one `i64`, one value per line).
17. "Sum = Product { ( "+" | "-" ) Product } ." Governs line 7 (`n - 1 - i`) and line 23 (`count + 1`), which are left-associative sums of `i64`.
18. "Postfix = Primary { ... | "[" Expression "]" | "?" } ." Governs indexing `ys[j]`, `ys[j + 1]` on lines 8-11.
19. "`if cond` / `else if` / `else` take only `bool`" Governs the conditions on lines 8, 19 and 22: `ys[j] < ys[j + 1]` (bool), `!seen` (bool), `x != prev` (bool).
20. "comparison   == != < <= > >=    (`< <= > >=`: a number only)" Governs `<` on line 8 (on `i64`) and `!=` on line 22 (on `i64`).
21. "boolean      && || !            (bool only; && and || short-circuit)" Governs `!` on line 19, applied to a `bool` cell.
22. "If = "if" Expression Block { "else" "if" Expression Block } [ "else" Block ] ." Governs lines 19-23 (an `if`, then an `else if`, with no final `else`).
23. "`if` and `match` are expressions and may stand as statements" Governs lines 8 and 19, which stand as statements.
24. "A function with a `->` must `return` on every path that reaches its end" Governs line 12 (`sorted_desc` ends in `return ys`) and line 25 (`runs` ends in `return count`).
25. "Shadowing is a compile error" Governs the whole program: within each function, every name is bound once, and `i` and `j`, `x` and `v` are distinct names.
26. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line (the program uses 4 spaces per level only).

## choice_points

1. **Sort algorithm.** I chose bubble sort with a nested pair of bounded `for` loops (lines 6-11). The other choice, a `while` loop with a `swapped` flag that repeats passes until none swaps, would print the same eight values but has a different loop shape and needs an extra cell and `while` condition. Both satisfy the brief's "by repeatedly swapping two adjacent elements that are out of order".
2. **Swap direction.** I swap when `ys[j] < ys[j + 1]` (line 8), which puts the larger value first. The other choice, `>`, would give ascending order, which is wrong for this task.
3. **Copy versus `@` parameter.** The signature is `xs: [i64]` as given, so `sorted_desc` takes its argument by value. I copy it into the cell `ys @= xs` (line 4) and sort the copy. The other choice, `@xs`, would require a different signature. Since the spec says every value is an independent copy, the caller's array is unchanged either way, so the result is the same.
4. **Length source.** I used `n $= len(ys)` (line 5). The other choice is to avoid `len` by counting elements with a loop. I rejected that: an unused loop variable is a compile error, and the spec has no `_` loop form.
5. **Type of `len`.** The spec lists `len` among built-ins but never gives its return type. I assumed `i64`, so `n` is `i64` and `range(from: 0, to: n)` and `n - 1 - i` typecheck. The other choice, that `len` returns an unsigned type such as `u64`, would make `range(to: n)` and `n - 1 - i` type errors ("No implicit conversions, widths included"). This is the largest risk in the program.
6. **`runs` shape.** I used a `for x in xs` loop with a `seen` flag and a `prev` cell (lines 14-25) instead of an index loop with `len(xs)`. The other choice, an index loop, would also give 4 and would depend on `len` again. The `seen` flag handles the empty array (returns 0) and the first element without reading `prev` before it is set.
7. **Empty input for `runs`.** I return 0 for `[]` (count starts at 0, and no element means no group). The other choice, counting the first element unconditionally, would be wrong for an empty array; I avoided it.
8. **Named versus positional arguments in `main`.** `sorted_desc` and `runs` each have one parameter, so the naming rule does not apply and I passed the arrays positionally (lines 28 and 30). Naming them, `xs:` for `sorted_desc` and `xs:` for `runs`, would also be accepted and would produce the same output.
9. **Printing.** I print each element with its own `print(v)` call inside a `for` loop (lines 28-29), which gives one value per line as the brief asks. The other choice, `join` of the converted strings, would need `to_str` and a separator and is more code for the same output.
10. **Comment.** I kept a single `#` comment at line 1 (not attached to a declaration). It is optional and changes nothing.
11. **`else if` on a new line** (line 22) rather than a nested `if` under `else`. A nested `if` would also be accepted; I chose `else if` because the spec grammar lists it directly.

## confidence

About 85% that the checker accepts the program as written with no edits. The bulk of the risk is in the parts the spec does not pin down, not in the grammar.

Least sure line: **line 5** (`n $= len(ys)`), and by extension **line 7** (`range(from: 0, to: n - 1 - i)`), because `len`'s return type is never stated (see choice point 5). If `len` returns `i64`, both lines pass. If it returns an unsigned type, both fail.

Other lines I am confident in: the indentation (4 spaces throughout), the cells and their re-bindings (lines 4, 10, 11, 15-17, 20, 21, 23, 24), the `else if` chain (lines 19-23), and the returns at lines 12 and 25.

Smaller points: whether `i`, `j`, `t`, `x`, `v` could collide with a built-in name (I believe none do, but the spec does not list reserved words beyond the grammar); and whether the checker accepts a call in the `in` position of `for v in sorted_desc([...])` (I believe the grammar allows any `Expression` there).

## context

Yes, beyond this directory's files, but only harness and environment material:

- The session environment block, which gave the working directory path, the platform, the scratchpad location, the model identity, the date and a budget.
- The account and workspace context, which gave the user's email and a git status snapshot for the repository (branch `main`, untracked `run.err` and `run.json`, and a recent commit `b427fcc`). I did not use any of it in the program or in this report.

From this directory I read `brief.md` and `spec.md` (the two inputs the brief names), and also `run.json` and `run.err`. The brief names only `spec.md` as input; I read the other two because they sit in this directory, but both were empty and they had no effect on the program. I read no file outside this directory and ran nothing.
