## program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n $= to_i64(ys.len()).must()
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if ys[j] < ys[j + 1]
                tmp $= ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = tmp
            j = j + 1
        i = i + 1
    return ys

function runs(xs: [i64]) -> i64
    n $= to_i64(xs.len()).must()
    if n == 0
        return 0
    count @= 1
    k @= 1
    while k < n
        if xs[k] != xs[k - 1]
            count = count + 1
        k = k + 1
    return count

function main()
    out $= sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
    for x in out
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below refer to this block: 1 `sorted_desc`, 3 `n` in `sorted_desc`, 10 and 11 the swap, 16 `runs`, 17 `n` in `runs`, 28 `main`.

## sentences

1. Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()` (line 28).
2. Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line, and the `if` and `while` conditions (all lines).
3. Section 2: "A literal takes the type its context asks for ... otherwise `i64`." Governs `i @= 0`, `j @= 0`, `k @= 1`, `count @= 1`, `return 0`, `n == 0`, and the integer literals in the `main` call arguments.
4. Section 2: "Every base writes a value, so a literal must fit its type." Governs the literals `3, 1, 4, 1, 5, 9, 2, 6` and `1, 1, 2, 2, 2, 3, 1`, which all fit `i64`.
5. Section 3: "No implicit conversions, widths included: `1 + 2.0` is an error." Governs `n - 1 - i`, `i < n`, `j < n - 1 - i`, `k < n`, `n == 0`, which need `n`, `i`, `j`, `k` all of one type, `i64`. This is secured by the `to_i64(...).must()` wrapper on the two `n` bindings (lines 3 and 17).
6. Section 3: "`[T]` | dynamic array, indices from 0." Governs `ys[j]`, `ys[j + 1]`, `xs[k]`, `xs[k - 1]`.
7. Section 3: "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." Governs `ys @= xs` (line 2): `ys` is a copy, so the parameter `xs` stays unchanged, as parameters are immutable.
8. Section 4: "Every top-level line starts with its kind." Governs the three `function` lines (lines 1, 16 and 28).
9. Section 5: "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs `ys[j] = ys[j + 1]` and `ys[j + 1] = tmp` (lines 10 and 11, element re-binds of the cell `ys`), `j = j + 1`, `i = i + 1`, `k = k + 1`, `count = count + 1`.
10. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error." Governs every binding: in `sorted_desc`, `ys`, `n`, `i`, `j`, `tmp` are each read; in `runs`, `n`, `count`, `k` are each read; in `main`, `out` and `x` are each read. The parameters `xs` are read in each function.
11. Section 5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." This is why no name is reused across nested scopes. The name `xs` is a parameter of two separate functions, not of nested scopes; `n` and `x` are used in separate scopes. (Governs the whole program.)
12. Section 7: "`< <= > >=`: a number only" governs `ys[j] < ys[j + 1]` (the swap test), and `k < n`, `i < n`, `j < n - 1 - i`.
13. Section 7: "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -`" governs `n - 1 - i` (left to right within `+ -`) and `ys[j + 1]`.
14. Section 7: "`==` is structural equality on any two values of one type" and "`!=`" govern `n == 0` and `xs[k] != xs[k - 1]`.
15. Section 8: "`if` and `match` are expressions and may stand as statements" and "`if cond` / `else if` / `else` take only `bool`": there is no truthiness. Governs the `if` lines (`if ys[j] < ys[j + 1]`, `if n == 0`, `if xs[k] != xs[k - 1]`), each a `bool`.
16. Section 8: "A function with a `->` must `return` on every path that reaches its end." Governs `sorted_desc` (`return ys`, line 14) and `runs` (the early `return 0`, line 19, and the final `return count`, line 26).
17. Section 8: "A statement after a jump, in its block, is a compile error." Governs `return 0` (line 19) in `runs`: the jump is the only statement in its `if` block, and `count @= 1` follows the `if` block, not the jump, so the rule is respected.
18. Section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range`." Governs the three `while` loops and `for x in out` (line 30).
19. Section 9: "When two parameters in a signature share a type, named arguments are mandatory at the call site." Not triggered: each function has one parameter, so no named arguments are needed (governs the `sorted_desc(...)` and `runs(...)` calls).
20. Section 10: "A container literal separates elements by newline across lines and by comma on one" governs `[3, 1, 4, 1, 5, 9, 2, 6]` and `[1, 1, 2, 2, 2, 3, 1]`, written on one line with commas.
21. Section 10: "An out-of-bounds index or slice aborts." Governs the bounds of `ys[j + 1]` (since `j < n - 1 - i`, so `j + 1 < n`) and `xs[k - 1]` (since `k >= 1`).
22. Section 11: "`print(...)` ... takes the types this language renders as text: a number, `str` or `bool`." Governs `print(x)` (line 31) and `print(runs(...))` (line 32), both `i64`.
23. Section 11: "`print` writes its values with no separator and exactly one trailing newline." Governs the output: one number per line, then the `runs` result.
24. Section 11: "`len`" is listed among the built-ins, and `xs.len()` appears in the spec's own example as `xs.len() == 0`. Governs `ys.len()` and `xs.len()`.
25. Section 11: "`to_i8` … `to_u64` give a `T?`, because the number may not fit. `to_i64` takes a float too, truncating toward zero." Governs `to_i64(ys.len()).must()` and `to_i64(xs.len()).must()` (lines 3 and 17): the result is `i64?`, and `.must()` extracts it.
26. Section 6: "`.must()` | extract or abort" (table row). Governs the `.must()` in lines 3 and 17 (`n $= ...`).

## choice_points

1. **Length type.** The specification never states what `len` or `.len()` returns. I chose `to_i64(x.len()).must()` so that `n` is an `i64` whatever the built-in returns, and all counters are `i64` literals. The other choice, a bare `n $= ys.len()`, produces an `i64` only if `len` returns `i64`; if it returns another width, `i < n` and `n - 1 - i` are refused as mixed types. The cost of my choice is that `to_i64` on an `i64` must be accepted (the spec lists it as a conversion for integers, and says `to_i64` takes a float too).
2. **`xs.len()` vs `len(xs)`.** I used the method form, which the spec shows in its own example (`xs.len() == 0`). The other form, `len(xs)`, is the listed built-in name and would likely also be accepted; I did not choose it because the spec shows the method form as valid.
3. **Swap condition.** I swap when `ys[j] < ys[j + 1]`, which puts larger values first (descending). The other comparison, `>`, would produce ascending order, which is wrong for `sorted_desc`.
4. **Strict vs non-strict comparison.** `<` leaves equal neighbours in place. `<=` would also swap equal neighbours; the output values are identical, only the number of swaps differs. For the given input, both print the same lines.
5. **Shrinking inner bound.** The inner loop runs to `n - 1 - i`, since after each outer pass the largest remaining element is in place. The other choice, `n - 1` every time, produces the same output with more comparisons.
6. **Copy vs in-place on the parameter.** `xs` is a plain parameter, so it cannot be mutated. I copy it into the cell `ys @= xs` and sort the copy. The other choice would change the signature to an `@` parameter, which the brief does not allow.
7. **Loop form.** I used `while` loops with cells. The other choice, `for` over `range(from: 0, to: n)`, would be equivalent, but needs `n` as an `i64` as well and is more to get right without running the checker.
8. **Empty input for `runs`.** I return `0`, since an empty array has no groups. The other choice, returning `1` (as if an empty array were one group), would be unusual. The given test input is non-empty, so the printed output is unaffected.
9. **Printing the sorted result.** I loop with `for x in out` and `print(x)`, one per line. The other choice, `print(out)`, is not allowed: `print` takes numbers, `str` and `bool`, not arrays.
10. **Binding name.** I named the result `out` rather than `sorted`, since `sort` is a built-in and I did not want a name close to it.

## confidence

About 85 to 90 percent that the checker accepts the program as written. The logic is straightforward, and every line is within the grammar as I read it: one-line expressions, no brackets spanning lines, every function with `->` returns on all paths, and no unused bindings.

The line I am least sure of is line 3 of the program block, `n $= to_i64(ys.len()).must()` (and its twin on line 17). It depends on three things the specification states only indirectly: the return type of `len` or `.len()`, that `to_i64` accepts an `i64` argument, and that `.must()` applies to the `i64?` that `to_i64` gives. If any of these is wrong the checker rejects the program at that line. The next most uncertain line is the cell re-binding by element, `ys[j] = ys[j + 1]` (line 10 of the block), whose form the specification gives as a `Place` with an indexed element; I am fairly sure this is accepted.

## context

Nothing outside this directory reached my context. I read only `brief.md` and `spec.md` (the two files with content) in this directory, and also opened `run.json` and `run.err`, which are both empty and contain nothing relevant. I used no other tool and no knowledge from outside the specification, beyond general knowledge of programming. I did not run anything, as the brief specifies.
