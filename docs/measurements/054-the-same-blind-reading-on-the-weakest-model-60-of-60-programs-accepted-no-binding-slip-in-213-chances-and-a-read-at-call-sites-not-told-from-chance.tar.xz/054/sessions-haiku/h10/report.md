# Report

## program

```
# Sorts a copy of xs from largest to smallest by adjacent swaps.
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n := ys.len()
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if ys[j] < ys[j + 1]
                t := ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
            j = j + 1
        i = i + 1
    return ys

# Counts the maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    if xs.len() == 0
        return 0
    count @= 1
    i @= 1
    while i < xs.len()
        if xs[i] != xs[i - 1]
            count = count + 1
        i = i + 1
    return count

function main()
    for y in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(y)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output: `9 6 5 4 3 2 1 1` on separate lines, then `4`.

## sentences

Line numbers refer to the program above. Quotes are verbatim except where the spec uses an em dash or an arrow: those are shown as a comma, a semicolon, or the word "then" (quotes 4, 14, 15). The brief bans em dashes in this report, so the substitution is deliberate.

1. Section 1: "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 29.
2. Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line (3-15, 19-27, 30-32).
3. Section 1: "No braces, no semicolons; a condition needs no parentheses." Governs lines 6, 8, 9, 19, 23, 24 (conditions written without parentheses).
4. Section 2 (em dashes replaced): "A literal takes the type its context asks for, `b: u8 := 255`, and `b + 1` is a `u8`, otherwise `i64`." Governs lines 5, 21, 22 (`0`, `1` in bindings with no context, so `i64`) and 30 (`[3, 1, ...]` takes `[i64]` from the parameter).
5. Section 3: "`[T]` | dynamic array, indices from 0". Governs lines 2, 3, 18 (array parameters and indexing from 0).
6. Section 3: "No implicit conversions, widths included: `1 + 2.0` is an error." Governs lines 4, 8, 13, 14, 23, 25, 26 (all integer arithmetic and comparisons use `i64` operands only).
7. Section 3: "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs line 3 (`ys @= xs` copies, so `xs` is not changed).
8. Section 5: "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 3, 5, 7, 21, 22 (cells), 4, 10, 30 (bindings), 11, 12 (element writes), 13, 14, 25, 26 (re-binds).
9. Section 5: "Signatures are always explicit; inference is local only." Governs lines 2, 18, 29 (every signature is written in full).
10. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds" Governs line 3 (`ys` is re-bound by the element writes at 11 and 12), line 21 (`count` is re-bound at 25), line 22 (`i` is re-bound at 26), and every use of `xs`, `n`, `t`, `y`.
11. Section 5 grammar: "`Place     = ident { "." ident | "[" Expression "]" } .`" Governs lines 11 and 12 (`ys[j] = ...`, `ys[j + 1] = ...`).
12. Section 6 example: "function head(xs: [str]) -> str?" with "`return ok(xs[0])`". Governs lines 9, 10, 11, 12, 24 (an array index on a plain array yields the element type, so `ys[j]` and `xs[i]` are `i64`).
13. Section 7 table: "comparison   == != < <= > >=    (`< <= > >=`: a number only)". Governs lines 9 (`<`), 19 (`==`), 23 (`<`), 24 (`!=`).
14. Section 7 precedence (arrow replaced by "then"): "Precedence, strongest first: call, `.` and `::` then unary `-` `!` `~` then `* / %` then `+ -`" Governs lines 8 (`n - 1 - i`), 9 (`ys[j + 1]`), 24 (`xs[i - 1]`), 25, 26. Subtraction is left to right, so `n - 1 - i` is `(n - 1) - i`.
15. Section 8 (em dash replaced by a semicolon): "`if cond` / `else if` / `else` take only `bool`; there is no truthiness." Governs lines 9, 19, 24 (each condition is a comparison, so a `bool`).
16. Section 8: "A function with a `->` must `return` on every path that reaches its end" Governs lines 18-27 (the early `return 0` at 20 and the final `return count` at 27) and lines 2-15 (`return ys` at 15).
17. Section 8 grammar: "`While   = "while" Expression Block .`" Governs lines 6, 8, 23 (`while` loops).
18. Section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 6, 8, 23 (`while`) and 30 (`for` over an array).
19. Section 9: "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs lines 4, 19, 23 (`ys.len()`, `xs.len()` are `len(ys)`, `len(xs)`).
20. Section 11: "Built-ins: `print(...)` · `len` · `push` ..." Governs lines 4, 19, 23 (`len` is a built-in).
21. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 31 and 32 (one `i64` per call, one line each).
22. Section 4: "Declaration order never matters but a group's (section 13)" Governs lines 29-32 (`main` is written last, but it could be first).
23. Section 1: "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it" Governs lines 1, 17 (comments above `sorted_desc` and `runs`).

## choice_points

1. **Sorting algorithm.** I used bubble sort with a shrinking inner bound (`j < n - 1 - i`, line 8). The spec asks for repeated swaps of adjacent out-of-order elements, which bubble sort is. Alternative: full-length inner passes (`j < n - 1`). That also produces the correct output, but does redundant comparisons; it does not change the result.
2. **Where the sort works.** I copy `xs` into a mutable cell `ys @= xs` (line 3) and sort that. Alternative: make `xs` an `@` parameter and sort it in place. That would change the signature, which the brief fixes as `sorted_desc(xs: [i64])`, and would also make the caller's array change. Copying keeps the function a pure value transform.
3. **Swap form.** I used a temporary `t` (lines 10-12). The spec has no tuple or multiple assignment, so a temporary is the direct form. Alternative: an arithmetic swap, which is unnecessary here and risks overflow.
4. **Empty input to `runs`.** I return `0` (lines 19-20). The alternative, with no check, would return `1` for `[]`, because `count` starts at 1 and the loop does not run. It would also be wrong to read `xs[0]` there, so the check is needed for the access as well as for the answer. The brief does not cover empty input, so either answer is defensible; `0` is the one that matches "how many groups".
5. **Loop form.** I used `while` with index cells (lines 5-8, 22-23). Alternative: `for k in range(from: 0, to: n)`. Both are valid, and the spec allows both. I chose `while` because the inner bound depends on the outer index, which is clearer with a cell.
6. **Method form.** I wrote `ys.len()` and `xs.len()` (UFCS), not `len(ys)`. Both mean the same. I chose the method form because the spec's own example uses `xs.len() == 0` (section 6).
7. **Type annotations.** I left the cells and literals to inference (`i @= 0`, `count @= 1`) and did not write `: i64`. The spec says types are inferred locally, and the literal default is `i64`. Alternative: `i: i64 @= 0`. That would be equally valid and would only fail if the result type of `len` were not `i64` (see confidence).
8. **Loop bodies.** I declared `j @= 0` inside the outer loop (line 7), so each pass starts again at 0. Alternative: declare `j` once outside and reset it inside. Both are valid; the inside declaration keeps the names local.

## confidence

About 90% that the checker accepts the program as written.

The least certain line is line 4 (`n := ys.len()`), with line 19 (`xs.len() == 0`) and line 23 (`while i < xs.len()`) depending on the same fact. The spec lists `len` as a built-in but never says what it returns. If it returns `i64`, the program is fine. If it returned an unsigned type, comparing it with the `i64` cells `i` and `n` would be a mixed-type error, because the spec forbids implicit conversions. The spec's `xs.len() == 0` example suggests an integer result that accepts a bare literal, which is consistent with `i64` but does not prove it.

Lower risk, but still not stated outright: that indexing an array (`ys[j]`, `xs[i]`) yields the element type. The section 6 example, `ok(xs[0])` returning `str?` from a `[str]`, supports this.

No other line depends on an unstated rule that I can see. The comments, the signatures, the `while` and `if` forms, the mutable cells and the element writes all follow the grammar as written.

## context

Only the four files in this directory were read: `brief.md`, `spec.md`, `run.json` and `run.err`. `run.json` and `run.err` came back empty and told me nothing. I used no other tool and did not run anything. I also created a stray file, `report.md.tmp`, in this directory by mistake (a one-character placeholder); I have no tool to delete it, so it needs removing by hand.

Beyond those files, the session context already contained system-provided material: the working directory path, the platform and shell, the scratchpad path, the model and date information, the budget line, a git status snapshot (branch `main`, untracked `run.err` and `run.json`, and the last commit `6cbca37 inputs`), and the user's account email. None of this came from reading a file outside the directory, and I did not use any of it in the program or this report.
