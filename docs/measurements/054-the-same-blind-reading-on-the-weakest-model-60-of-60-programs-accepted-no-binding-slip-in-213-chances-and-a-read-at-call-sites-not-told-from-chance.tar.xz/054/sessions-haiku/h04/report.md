## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    out: [Item] @= []
    found @= false
    for item in items
        if item.name == name
            out @ out.push(Item(name: item.name, qty: item.qty + n))
            found @ true
        else
            out @ out.push(item)
    if !found
        out @ out.push(Item(name: name, qty: n))
    items @ out

function take(@items: [Item], name: str, n: i64) -> bool
    out: [Item] @= []
    found @= false
    for item in items
        if item.name == name && item.qty >= n
            out @ out.push(Item(name: item.name, qty: item.qty - n))
            found @ true
        else
            out @ out.push(item)
    if !found
        return false
    items @ out
    return true

function main()
    items: [Item] @= []
    restock(@items, name: "apple", n: 3)
    restock(@items, name: "pear", n: 2)
    restock(@items, name: "apple", n: 4)
    print(take(@items, name: "apple", n: 5))
    print(take(@items, name: "pear", n: 9))
    total @= 0
    for item in items
        total @ total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple 7 minus 5 leaves 2, pear stays 2, sum 4).

## sentences

Each sentence is quoted from spec.md, with the program lines it governs.

1. "The file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()`.
2. "Every top-level line starts with its kind." Governs `record Item`, `function restock`, `function take`, `function main`.
3. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line (the whole program is written with 4-space levels).
4. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`, and a variant's case `.num(v: 7)` or `.plus`." Governs every `Item(name: ..., qty: ...)` line in `restock` and `take`.
5. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`" Governs `function restock(@items: [Item], ...)`, `function take(@items: [Item], ...)`, and every `restock(@items, ...)` and `take(@items, ...)` call in `main`.
6. "`@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs `found @= false`, `total @= 0`, `items: [Item] @= []`, `out: [Item] @= []`, and the `found @ true`, `total @ ...`, `out @ ...` re-bindings.
7. "An empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`." Governs `out: [Item] @= []` (both functions) and `items: [Item] @= []` in `main`.
8. "`xs @ xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs `out @ out.push(...)` (`out` is a plain local name) and `items @ out` (the `@` parameter is rebound as a plain name).
9. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `out.push(...)`, which is the method-style form of `push(out, ...)`.
10. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs both `for item in items` loops in `restock` and `take` and the `for item in items` loop in `main`.
11. "`if cond` / `else if` / `else` take only `bool`; there is no truthiness." Governs `if item.name == name`, `if item.name == name && item.qty >= n`, and `if !found`.
12. "boolean `&&` `||` `!` (bool only; `&&` and `||` short-circuit)." Governs `!found` and the `&&` in `take`.
13. "`==` is structural equality on any two values of one type, recursively" Governs `item.name == name` (both `str`).
14. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs the three `print` lines in `main` (the `bool` results of `take`, and the `i64` total).
15. "A function with a `->` must `return` on every path that reaches its end" Governs `take`: the final `return true` covers the path past the loop, and `return false` is the early exit.
16. "A statement after a jump, in its block, is a compile error." Governs `take`: no statement follows `return false` inside its `if` block.
17. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13)" Governs: every binding is read (`out`, `found`, `total`, `item`), `name` and `n` are read in both functions, and `items` is written by `items @ out` in both functions.
18. "A literal takes the type its context asks for ... otherwise `i64`." Governs `found @= false` (bool), `total @= 0` (i64 by default, matching `item.qty`), and the `n: i64` arguments `3`, `2`, `4`, `5`, `9`.
19. "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs `out @ out.push(item)` (the element copied into `out`) and the discard of `out` when `take` returns `false` before `items @ out`.
20. "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -` → ... → comparisons → `&&` → `||`." Governs `item.qty + n`, `item.qty >= n`, and the `&&` in `take`, which need no parentheses.
21. "Outside brackets a line ends its statement: it may not end where the statement cannot, and the next line may not go on with it" Governs every statement in the program: each line is a complete statement and none continues onto the next.
22. "Declaration order never matters but a group's (section 13)." Governs the order of the declarations (`record Item` first, then the functions).

## choice_points

1. **Item rebuilt versus updated in place.** I chose to build a new array `out` in each `for` loop and then rebind `items @ out`. The other choice, an index loop with `while i < items.len()` and `items[i].qty @ ...`, would also be valid, but the spec does not state the return type of `len` (it could be an unsigned width, which would then need a conversion in `i < ...`). Avoiding `len` avoids that unstated type. Had I used the index loop, the program would depend on it.
2. **Rebinding an `@` parameter as a whole (`items @ out`).** The other choice, writing each element through `items[i]` or `items[i].qty @ ...`, depends only on indexed places, which the spec describes clearly. Whole-array rebinding of a parameter is not spelled out in the spec; I judged it to follow from "`@` re-binds it" and "the callee works on the caller's place itself".
3. **Named or positional arguments.** I wrote `restock(@items, name: "apple", n: 3)` with names on the value arguments. The other choice, `restock(@items, "apple", 3)`, is also valid because no two parameters share a type that would make names mandatory (`name: str`, `n: i64`). Positional calls would be accepted too, but I wanted the call sites to read clearly.
4. **Early exit in `take`.** I build `out` and check `found` before writing back, so the `false` path never touches `items`. The other choice, mutating `items` directly in the loop, would need a separate check before the first write so that a `false` result changes nothing; I avoided that by writing back only on success.
5. **Loop variable name.** I used `item` rather than `it` to avoid any doubt about `it` as a reserved word. The other choice (`it`) would produce the same behaviour; only a name clash would differ.
6. **No `use` or `test` block.** The other choice, adding a `test` block with `assert`, would not change behaviour, because test blocks are ignored by ordinary builds, but it would add lines the checker has to accept.
7. **Sum method.** I summed with a `for` loop and `total @= 0` instead of `fold`, `map` or `sort`. The other choice, `fold(0, add)`, would need a named top-level function `add`; the `for` loop needs fewer assumptions about built-in signatures.

## confidence

About 85% that the checker accepts the program as written and prints `true`, `false`, `4`.

The least certain line is `items @ out` (in `restock` and in `take`). The spec says `@` re-binds a mutable cell, and that a `@` parameter is worked on in place, but it does not state explicitly that a whole `@` parameter may be re-bound as a plain name. If that is refused, the fix is to write each element through `items[i]` instead.

The second least certain line is `out: [Item] @= []`. The annotation rule is explicit in the spec, so I expect it to be accepted; I list it only because the `: T @= []` form appears nowhere in the spec's examples.

## context

Nothing outside this directory's files reached my context as program input. I read only `brief.md` and `spec.md` in this directory and wrote `report.md`. I did not read `run.err` or `run.json`, which the environment's git snapshot lists as untracked files, and I did not run any tool other than file reads and writes. The environment description and the user's account details were supplied by the system and were not used in the program.
