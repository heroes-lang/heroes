## program

```
# Sort a list of numbers from largest to smallest by swapping adjacent pairs.
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n := len(ys)
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if ys[j] < ys[j + 1]
                t := ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
    return ys

# Count the maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    for i in range(from: 1, to: len(xs))
        if xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below count from the first line of the block above (the comment line is line 1).

## sentences

Spec sentences the program rests on, with the lines they govern.

- "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs line 3 (`ys @= xs`) and lines 9 to 10 (element writes `ys[j] = ...`), and line 20 (`count = count + 1`).
- "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs line 3: `xs` is a by-value parameter, so `ys` is a copy and the caller's array is untouched.
- "An unused binding or parameter is a compile error" (section 5). Governs every binding: `ys`, `n`, `t`, `count`, the loop variables `i`, `j`, `x`, and the parameter `xs` (all are read).
- "Shadowing is a compile error". Governs the names: no name is bound twice in one scope, and the loop variable `i` in `runs` and in `sorted_desc` lives in separate functions.
- "`:=` binds once, forever." Governs lines 4, 8, and the loop variables.
- "Signatures are always explicit; inference is local only." Governs lines 2, 14, 23: every signature is written out.
- "A literal takes the type its context asks for" and "otherwise `i64`." Governs the literals `0`, `1`, `3`, `1` etc. in `main`, `count @= 1` (line 17) and `return 0` (line 16).
- "`for x in xs`, over an array or a `range` (section 11)." Governs lines 5, 6, 18, 24.
- "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs lines 5, 6, 18: the loop runs over `0 .. n-1` and `1 .. len-1`, and the inner bound `n - 1 - i` keeps `j + 1` below `n`.
- "When two parameters in a signature share a type, named arguments are mandatory at the call site". Governs lines 5, 6, 18: `range` has two `i64` parameters, so `from:` and `to:` are written.
- "Built-ins: `print(...)` · `len` · `push`" (section 11). Governs lines 4, 15, 18, 19: `len` is a built-in. Its return type is not stated (see `confidence`).
- "`[T]` | dynamic array, indices from 0". Governs lines 7 to 10 and 19 (`ys[j]`, `xs[i]`, `xs[i - 1]`) and the index starting at 0.
- "An out-of-bounds index or slice aborts". Governs lines 7 to 10 and 19: every index is in range, because `j + 1 <= n - 1` and `i - 1 >= 0`.
- "return ok(xs[0])" (the section 6 example, showing that an array index yields its element type directly). Governs lines 7 to 10 and 19: `ys[j]` is an `i64`, not a `T?`.
- "`==` is structural equality on any two values of one type, recursively". Governs line 15 (`len(xs) == 0`).
- "(`< <= > >=`: a number only)" (section 7). Governs line 7 (`ys[j] < ys[j + 1]`).
- "both sides one numeric type" (section 7, arithmetic). Governs lines 6, 9, 10, 18, 20: all operands are `i64`.
- `Sum = Product { ( "+" | "-" ) Product } .` (section 7 grammar), with the precedence rule that `* / %` binds tighter than `+ -`. Governs line 6: `n - 1 - i` is `(n - 1) - i`, left to right.
- `Place = ident { "." ident | "[" Expression "]" } .` (section 5 grammar). Governs lines 9 and 10 (the assignment targets).
- `For = "for" ident "in" Expression Block .` (section 8 grammar). Governs lines 5, 6, 18, 24.
- "`if cond` / `else if` / `else` take only `bool`". Governs lines 7, 15, 19: each condition is a comparison, which yields `bool`.
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line; the program uses 4 spaces per level and no tabs.
- "Syntax is ASCII-only" (section 1). Governs the whole program: it is plain ASCII.
- "Declaration order never matters" (section 4). Governs `main` at line 23, which calls `sorted_desc` and `runs` written above it.
- "A function with a `->` must `return` on every path that reaches its end". Governs line 11 (`sorted_desc` ends with `return ys`) and line 21 (`runs` ends with `return count`). In `runs`, the early `return 0` at line 16 is the last statement of its block, so nothing follows a jump in that block.
- "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 25 and 26: each element prints on its own line, and the `i64` result of `runs` prints as a number.

## choice_points

1. Direction of the swap. I swap when the left element is smaller (`ys[j] < ys[j + 1]`), which leaves the largest first. The other choice (`>`) produces ascending order, which is wrong for this task.
2. Where the sorting happens. I copy the parameter into a mutable cell (`ys @= xs`, line 3). The other choice, marking the parameter `@xs`, makes the caller pass a place, and `sorted_desc([...])` with a literal would then be a compile error.
3. Bounds of the outer pass loop. I use `range(from: 0, to: n)`. The other choice, `to: n - 1`, gives the same output with one fewer pass.
4. Bounds of the inner loop. I use `to: n - 1 - i`, which skips the already-placed tail. The other choice, `to: n - 1`, gives the same output but does more comparisons.
5. Loop form. I use `for` over `range`. A `while` loop with an index, or a `while` loop with a "swapped" flag that stops early, gives the same output.
6. Handling the empty array in `runs`. I return `0` explicitly (lines 15 to 16). The other choice, starting `count` at `1` and looping from `1`, returns `1` for `[]`, which is wrong for the empty case but correct for the example given in the task.
7. Counting method in `runs`. I start at 1 and count a new group each time an element differs from the one before it (lines 17 to 20). The other choice, starting at 0 and counting a group start at every index where `i == 0` or the value differs, gives the same answer.
8. Type of `n`. I let it be inferred (`n := len(ys)`, line 4). The other choice, `n: i64 := len(ys)`, makes the mismatch show up at the binding rather than at the `range` calls. If `len` returned a type other than `i64`, both choices fail, and the explicit form fails earlier.
9. Argument style. I pass the single argument of `sorted_desc`, `runs` and the call sites positionally, because one parameter needs no name. The other choice, `sorted_desc(xs: [...])`, is also accepted. The `range` calls use names, which the rule for two same-typed parameters requires.
10. Printing the sorted result. I print each element in a loop (`print(x)`). The other choice, `join` into one `str` and print once, does not meet "each element of ... on its own line" as directly.
11. Comments. I added one comment above each function (the comment directly above a declaration documents it). Removing them changes nothing the checker reads.

## confidence

I am fairly confident the checker accepts the program on the first try: about 85 percent. I could not run it; this is a reading of the spec.

Least sure line: line 4, `n := len(ys)`. The spec lists `len` among the built-ins but does not state its return type. I assumed `i64`. If `len` returns another type, line 4, the `range(from: 0, to: n)` and `n - 1 - i` in line 5 and 6, and line 15 and 18 (`len(xs)` compared with and passed where an `i64` is needed) all fail. Line 19 and line 18 depend on the same assumption.

Other lines I checked with less doubt: the named arguments on `range` (lines 5, 6, 18), the `@=` cell with element writes (lines 3, 9, 10), and the `return` on every path (lines 11 and 21).

## context

Read only files in this directory: `brief.md`, `spec.md`, `run.json` and `run.err`. `run.json` and `run.err` exist and are empty, so they contributed nothing. No file outside this directory was read, and no tool other than file reading and writing was used.

The session also carried harness metadata into my context: the working directory and platform details, the current date, and a git status snapshot that lists `run.err` and `run.json` as untracked. I did not open any file from that metadata, and none of it affects the program.
