# Report: main.hero against spec.md

## verdict

Refused, on lines 20 and 22.

- **Line 20** `step = 2`: `step` was bound with `$=` on line 10. The spec says "`$=` binds once, forever", and only a `@=` cell can be re-bound with `=`. The checker refuses this re-binding.
- **Line 22** `last @= words[0]`: `last` is a cell that nothing re-binds. The spec says "a cell nothing re-binds" is a compile error. Line 25 only reads `last`, and a read is not a write.

Every other line passes: the `@c` argument on lines 19 and 21 counts as a write to `c`, `total` and `counts` are re-bound, `bump` writes its `@c` parameter through `c.hits`, and no name is unused.

Smallest accepted program: change `step $= 1` to `step @= 1` on line 10, and `last @= words[0]` to `last $= words[0]` on line 22. It prints:

```
5
5
a
```

(`c.hits` is 3 after the first `bump`, which reads `counts["a"]` = 3, then 5 after `bump(@c, 2)`. `total` is 5 because the loop runs once per word with `step` = 1. `last` is `"a"`.)

## lines

Lines of `main.hero` that contain `=` or `@` (the `$=` and `@=` operators count).

| Line | Source | Category | Words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (parameters `c` and `by`) | "Param = "@" ident ":" Type"; "Mutable parameters are marked `@` in the signature" |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (field `hits` of `c`) | "`=` re-binds it, or a field or element inside one" |
| 9 | `words $= [...]` | *new name* | "`$=` binds once, forever." |
| 10 | `step $= 1` | *new name* | "`$=` binds once, forever."; "otherwise `i64`." |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell"; "an empty one needs an annotation: ... `m: {str: i64} @= {}`" |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell" |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (element of `counts`) | "`=` re-binds it, or a field or element inside one"; "`m[k] = v` inserts or replaces" |
| 16 | `total = total + step` | *changes an existing name* | "`v = v + 1` re-binding"; "`=` re-binds it" |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell"; "Record construction is a call with field names" |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, through the `@` argument) | "an `@` argument counting" (section 5); "the callee works on the caller's place itself" (section 9) |
| 20 | `step = 2` | *changes an existing name* as written, and refused: `step` is `$=` | "`$=` binds once, forever."; "`=` re-binds it" (applies to cells only) |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`) | same as line 19 |
| 22 | `last @= words[0]` | *new name*, but refused: a cell nothing re-binds | "a cell nothing re-binds ... is a compile error"; "a read is a use and a write is not" |

## sentences

From `spec.md`, the sentences the verdict rests on:

- Section 5: "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- Section 5 grammar: "`Simple    = "_" Binding | Place "=" Expression NEWLINE`" (here `Place "=" Expression` is the re-binding form)
- Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"
- Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach,"
- Section 2: "A literal takes the type its context asks for … otherwise `i64`."
- Section 3: "`[T]` | dynamic array, indices from 0"
- Section 10: "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"
- Section 6 table: "`.default(v)` | extract or fall back"
- Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

```heroes
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a`, one per line.

## choice_points

1. **Fixing line 20.** I changed line 10 to `step @= 1`, so `step` is a cell that line 20 may re-bind.
   - Other choice: keep `step $= 1` and write line 20 as a new name, `step2 $= 2`, with line 21 as `bump(@c, step2)`. This also prints `5 5 a`.
   - I chose the first because it changes one line and keeps the name `step` for the same value.
2. **Fixing line 22.** I changed `@=` to `$=`, so `last` is an immutable binding and needs no re-binding.
   - Other choice: keep `@=` and add a re-binding, for example `last = words[4]` after line 21. This also prints `a`, since `words[4]` is `"a"`, but it adds a statement the program does not need.
3. **Which lines count as "holding `=` or `@`".** I counted every line with the characters `=` or `@`, including `$=`, `@=`, and `@` at a call site (lines 5, 19, 21). The other choice is to count only lines that bind or re-bind a name. That drops lines 19 and 21 from the table, and no verdict changes.
4. **Category of the `@` argument (lines 19 and 21).** I took it as *changes an existing name*, following "an `@` argument counting" and "the callee works on the caller's place itself". The other choice is *neither*, since no `=` appears on the line. The verdict does not depend on this, because `c` has to be written for line 22's fix to matter.
5. **Category of parameters (line 5).** I took parameters as *new name*, since they bring `c` and `by` into scope. The other choice is to treat them as neither, since they are not written with `=` or `@=`.
6. **Category of line 20.** I wrote *changes an existing name* because the line re-binds `step` as written, and the spec refuses that re-binding. The other choice is to call the line *neither*, since no binding is made. The verdict is the same either way.
7. **Type of `step`.** The literal `1` takes `i64` by default. Other types would require an annotation. No output changes.

## confidence

- **High** that the original program is refused on line 20. The spec says "`$=` binds once, forever", and line 20 re-binds `step`.
- **High** that line 22 is refused as written: "a cell nothing re-binds" is an error in the spec.
- **High** that the fixed program is accepted and prints `5`, `5`, `a`. I checked the arithmetic by hand, and every rule I used is quoted above.
- **Medium** on the exact category labels for lines 5, 19, 20 and 21. The spec does not settle them as cleanly as it settles the verdict, and I explain each choice in `choice_points`.
- **Least sure** of: whether the checker treats `counts[w] = ...` on line 15 as a re-binding of `counts`. The spec says "or a field or element inside one", so I think it does. If it did not, `counts` would also be an unre-bound cell and line 11 would be refused too. I could not run the checker to confirm.
- I could not run anything in this session, so every result above comes from reading the spec and the program.

## context

- Only the files in this directory were read as input: `brief.md`, `spec.md`, and `main.hero`.
- I also opened `run.json` and `run.err`, which are in this directory but are not inputs the brief names. Both are empty and had no effect on the report.
- My session context also contained environment details (the working directory, platform, and a git status snapshot that lists `run.err` and `run.json` as untracked). None of it came from the spec or the program, and I did not use it in the analysis.
- I did not read any file outside this directory and ran no tools other than reading and writing files here.
