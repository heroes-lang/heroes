# Report: Heroes program for sorted_desc, runs and main

## program

```
function sorted_desc(xs: [i64]) -> [i64]
    v @= xs
    n $= len(xs)
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if v[j] < v[j + 1]
                tmp $= v[j]
                v[j] = v[j + 1]
                v[j + 1] = tmp
            j = j + 1
        i = i + 1
    return v

function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    i @= 1
    while i < len(xs)
        if xs[i] != xs[i - 1]
            count = count + 1
        i = i + 1
    return count

function main()
    s $= sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
    for x in s
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output: `9 6 5 4 3 2 1 1` on eight lines, then `4`.

## sentences

Line numbers refer to the program block above.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 27-31 (`main` has no parameters, no `->`, and no `use` lines are needed).
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every block; the program uses only spaces, and the conditions on lines 5, 7, 8, 17, 21, 22 have no parentheses.
3. "Syntax is ASCII-only" (section 1). Governs the whole program; every character is ASCII.
4. "Signatures are always explicit; inference is local only." Governs lines 1, 16, 27: each function states its parameter and return types.
5. "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." Governs line 2 (`v @= xs` copies the parameter, so `xs` is not changed and need not be `@`).
6. "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 2, 4, 6, 12, 13 (cells `v`, `i`, `j`) and lines 10-11 (element writes `v[j] = ...`), 19-20, 23-24 (`count`, `i`).
7. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds" Governs lines 3 (`n` is read on lines 5 and 7), 9 (`tmp` is read on line 11), 19 and 23 (`count` is read on line 25), 20 and 24 (`i` is read on lines 21-22), 28 (`s` is read on line 29), and the parameters `xs` (lines 3, 17, 21 for `runs`) and `xs` (line 2 for `sorted_desc`).
8. "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `0`, `1`, `2`, `3`, `9`, and the arrays on lines 28 and 31, which take `[i64]` from the parameter types. Line 4, 6, 12, 13 literals become `i64`, matching `n` and `len(xs)`.
9. "Built-ins: `print(...)` · `len` · `push` ..." Governs lines 3, 17, 21 (`len` is a built-in taking `[i64]`).
10. "`if cond` / `else if` / `else` take only `bool` ... there is no truthiness." Governs lines 8, 17, 22 (each condition is a comparison, so it is `bool`).
11. "`<` ... `>=`: a number only" (section 7, comparison row). Governs lines 5, 7, 8, 21 (`<` on `i64`).
12. "`==` is structural equality on any two values of one type" and "`!=`" as listed in the comparison row. Governs lines 17 and 22 (`!=` and `==` on `i64`).
13. "Precedence, strongest first: call, `.` and `::` → unary ... → `* / %` → `+ -`" Governs lines 7 and 22 (`n - 1 - i` and `i - 1` bind before `<`).
14. "Overflow aborts at every width." Governs lines 7, 12, 13, 23, 24: all values stay within `i64` for the inputs in `main`.
15. "An out-of-bounds index or slice aborts" Governs lines 8, 10, 11 (`v[j + 1]` is in bounds since `j < n - 1 - i` keeps `j + 1 <= n - 1`), and line 22 (`xs[i]` and `xs[i - 1]` are in bounds because `i` starts at 1 and `i < len(xs)`).
16. "A function with a `->` must `return` on every path that reaches its end" Governs lines 14 (`sorted_desc` ends with `return v`) and 25 (`runs` ends with `return count`). Line 18 is the early exit for empty input; it is the last statement in its `if` block.
17. "A statement after a jump, in its block, is a compile error." Governs lines 18 (nothing follows `return 0` in its block) and 14.
18. "Loops: `while cond` and `for x in xs`, over an array or a `range`" Governs lines 5, 7, 21 (`while`) and 29 (`for x in s` over an array).
19. "`print` writes its values with no separator and exactly one trailing newline" Governs lines 30 and 31, so each element and the count appear on their own line.
20. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs the local names: no `use` exists, and no name is bound twice within one function. `i` appears in both `sorted_desc` and `runs`, in separate functions.
21. "Declaration order never matters but a group's" Governs the placement of `main` last (line 27).

## choice_points

1. **Algorithm for `sorted_desc`.** I chose bubble sort with the comparison `v[j] < v[j + 1]`, which swaps adjacent out-of-order pairs for descending order. The other choice, swapping when `v[j] > v[j + 1]`, gives ascending order (`1 1 2 3 4 5 6 9`). A selection sort would also satisfy the brief, but it needs an extra index and more cells, so I did not use it.
2. **Copy of the input.** I wrote `v @= xs` and left `xs` as a plain parameter. The other choice, marking `xs` as `@` (and passing `@xs` at the call), would let the function sort the caller's array in place. That would change the caller's array, which the brief does not ask for, so I did not choose it.
3. **Loop form.** I used `while` with explicit indices. The alternative `for i in range(from: 0, to: n)` also works, and is shorter, but `range` takes two `i64` parameters, so the call must name them (`from:`, `to:`). I chose `while` to keep the arguments simple.
4. **Empty input in `runs`.** I return `0` early when `len(xs) == 0`. The alternative starts `count` at 0 and guards the first comparison; it would give the same result. The early return keeps `xs[i - 1]` safe without extra logic.
5. **Type of `len`.** The spec lists `len` as a built-in but does not state its result type. I assumed `i64`, so that `n`, `i`, `j`, and the literal `0` compare and combine without mixing widths. If `len` returned another integer type, lines 3, 5, 7, 17, 21 would fail with a width mismatch. I could not check this in the spec.
6. **Naming.** I used `i` in both functions and `x` for the loop variable in `main`. The other choice, distinct names throughout, would produce the same output and avoid any doubt about the shadowing rule.
7. **Call style.** `sorted_desc([...])` and `runs([...])` pass their single argument by position. The spec makes named arguments mandatory only when two parameters share a type, so positional calls are accepted. Naming the argument (`xs: [...]`) would also be accepted.
8. **Temporary for the swap.** I used `tmp $= v[j]` as a `$=` binding, which is used on line 11. The alternative of writing the swap as a two-element expression does not exist in this language, so the temporary is required.
9. **No comments.** The program carries no `#` comments. Adding comments would not change the checker's result; they would only help a reader.

## confidence

I am about 85 percent sure the checker accepts the program on the first try. The rules used (indentation, `$=` and `@=`, element writes, `while`, `if` on `bool`, `return` on every path, `print`) are all stated plainly in the spec.

The line I am least sure of is line 3 (`n $= len(xs)`), with lines 17, 21 and 5/7 which depend on the same fact. The spec lists `len` as a built-in but never says its result type. If it is not `i64`, several comparisons and the subtraction on line 7 would fail. This is the one thing I could not settle from the spec.

The next least sure is line 14 and line 25, where the function must return on every path. I checked that both end with `return`, but the spec's rule about paths through a `while` with a condition (not `while true`) suggests the checker will see the trailing `return` as the only exit, which is what I intended.

I did not run the checker; I have no tool to do so.

## context

Everything I used came from this directory: `brief.md`, `spec.md`, and the two empty files `run.json` and `run.err`. I read `run.json` and `run.err` because they sit in this directory; both were empty, and they had no effect on the program.

Other material reached my context from the session, not from this directory: the system environment note (platform, shell, the scratchpad path, the model name and cutoff date), a git status snapshot showing the branch and two untracked files, and an account email. None of it informed the program, the choices, or the spec reading. I had no knowledge of Heroes beyond `spec.md`, and I used no other file or tool.
