# Report

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            if items[i].qty < n
                return false
            items[i].qty = items[i].qty - n
            return true
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output, traced by hand: `true`, `false`, `4` (apple 7 minus 5 leaves 2, pear stays 2, sum 4).

Line numbers used below: 1-3 `record Item`; 5-10 `restock`; 12-19 `take`; 21-31 `main`.

## sentences

1. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every block, lines 2-3, 6-10, 13-19, 22-31.
2. "No braces, no semicolons; a condition needs no parentheses." Governs lines 7 and 15.
3. "`Point(x: 3, y: 4)`": record construction is a call with field names, always mandatory. Governs lines 10 and 22.
4. "`function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`". Mutable parameters are marked `@` in the signature and at the call site. Governs lines 5, 12 (signatures) and 23-27 (calls).
5. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs lines 6, 10, 13 (`items.len()`, `items.push(...)`).
6. "`xs = xs.push(4)` grows in place when `xs` is a plain name". Governs line 10. `items` is a plain name here.
7. "`range(from: a, to: b) -> [i64]` exclude `to`." Governs lines 6 and 13.
8. "When two parameters in a signature share a type, named arguments are mandatory at the call site". `range` has two `i64` parameters, so `from:` and `to:` are required. Governs lines 6 and 13.
9. "`[T]` | dynamic array, indices from 0". Governs `items[i]` on lines 7, 8, 15, 17.
10. "`=` re-binds it, or a field or element inside one." Governs lines 8 and 17 (`items[i].qty = ...`).
11. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 22, 28, 30.
12. "An empty one needs an annotation: `xs: [i64] $= []`". Governs line 22.
13. "a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting". `items` is re-bound by the `@` arguments (lines 23-25). `total` is re-bound on line 30. The `@` parameter `items` is written on lines 8, 10 and 17.
14. "An unused binding or parameter is a compile error". Every binding and parameter is used: `i`, `item`, `n`, `name`, `total`, `items`.
15. "A function with a `->` must `return` on every path that reaches its end". Governs `take` (line 19 is the final `return false`).
16. "A statement after a jump, in its block, is a compile error." No statement follows a jump in its block (lines 9, 16, 18, 19).
17. "`if cond` / `else if` / `else` take only `bool`". Governs lines 7 and 15.
18. "`while cond` and `for x in xs`, over an array or a `range`". Governs lines 6, 13, 29.
19. "`return` [ Expression ]": bare `return` on line 9 (no `->`), `return false`/`return true` on lines 16, 18, 19.
20. "`==` is structural equality on any two values of one type". Governs line 7 (`str` against `str`).
21. "Integer operators `+ - *` ... `<`" are typed by the operands; `< <= > >=`: a number only. Governs lines 8, 15, 17, 30.
22. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 26, 27 (`bool`) and 31 (`i64`).
23. "A literal takes the type its context asks for ... otherwise `i64`." Governs the integer literals `0`, `3`, `2`, `4`, `5`, `9`, `0`.
24. "Declaration order never matters but a group's". Governs the whole file. `Item` is declared before use anyway.
25. "`function main()`, which takes nothing and produces nothing." Governs line 21.

## choice_points

1. **Search loop form.** Chose `for i in range(from: 0, to: items.len())` with index `items[i]` (lines 6, 13). Alternative: `for item in items` with a counter cell and an index write. That form mutates `items` while iterating it, which the spec does not clearly allow. Output is the same.
2. **Return type of `len`.** The spec never states it. I assumed `i64` so it can be passed as `to:` to `range`, which takes `i64`. If `len` returned an unsigned type, lines 6 and 13 would be a type error (no implicit conversion).
3. **Index type.** Assumed `items[i]` takes an `i64`, matching `range`. An unsigned index would fail the same way.
4. **Call syntax of `len` and `push`.** Chose UFCS (`items.len()`, `items.push(...)`), as the spec's own examples do. Alternative: `len(items)`, `push(items, ...)`. The spec gives only the UFCS form for `push`.
5. **Duplicate names in `restock`.** Chose first match wins, then return. Alternative: update every match. Output is the same because `restock` never creates duplicate names.
6. **`take` with a present but insufficient item.** Chose to check before subtracting and return `false` with no change (lines 15-16). Alternative: subtract, check, add back. The spec says "otherwise it changes nothing", so the first form matches it directly.
7. **`take` ending.** Chose an explicit `return false` after the loop (line 19), so every path returns. Alternative: put a `false` return in each branch.
8. **Named or positional arguments in calls.** Chose positional (`restock(@items, "apple", 3)`), because named arguments are mandatory only when two parameters share a type, and here `name: str` and `n: i64` differ. Alternative: `restock(@items, name: "apple", n: 3)`, which should also be accepted.
9. **Bare `return` in `restock`.** Chose `return` with no expression (line 9), since `restock` has no `->`.
10. **Sum method.** Chose an explicit loop with a `total` cell (lines 28-31). Alternative: `fold` with a named add function. The spec defines `fold` but has no `sum` built-in, so the loop is the simpler reading.
11. **Empty list annotation and binding kind.** Chose `items: [Item] @= []` (line 22), mutable because `restock` and `take` take it as `@`. Alternative: `$=`, which would not allow passing it as `@`.
12. **Literal types.** Chose `i64` for every literal, the spec default. No narrower type is needed.
13. **Comments and `use` lines.** Chose none. Neither affects the checker result.

## confidence

About 80% that the checker accepts the program as written.

Least sure line: **line 6 (and line 13), `range(from: 0, to: items.len())`**. The spec never states the return type of `len`, and this call depends on it being `i64`. Second least sure is **line 10, `items = items.push(Item(name: name, qty: n))`**. The spec's only `push` example is `xs = xs.push(4)` on a plain name, and `items` here is an `@` parameter, which the spec does not explicitly cover for `push`.

Most confident: lines 1-3 (record), lines 22-27 (`@` calls and `bool` printing), line 19 (final return), and lines 28-31 (sum loop).

## context

I read only files in this directory: `brief.md`, `spec.md`, and the two empty files `run.json` and `run.err`. Nothing outside this directory was read, and I ran no code.

The session also gave me its own environment description (working directory, platform, date, a git status snapshot, and an account identifier). None of it is in the language's files, and none of it was used for the program or this report.
