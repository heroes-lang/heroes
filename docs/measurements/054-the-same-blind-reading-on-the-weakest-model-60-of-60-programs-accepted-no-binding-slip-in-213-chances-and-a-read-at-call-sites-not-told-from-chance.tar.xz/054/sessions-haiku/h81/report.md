## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    for item in items
        if item.name == name
            items[i].qty = item.qty + n
            return
        i = i + 1
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    for item in items
        if item.name == name
            if item.qty < n
                return false
            items[i].qty = item.qty - n
            return true
        i = i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple 7 minus 5 is 2; pear stays 2; sum 4).

## sentences

Line numbers refer to the program above, counted from the `record Item` line as line 1 (blank lines counted).

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 25 (`function main()`).
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line (2-3, 6-12, 15-23, 26-35).
3. "Signatures are always explicit; inference is local only." Governs lines 5, 14, 25 (explicit parameter and return types); `i @= 0` (6, 15) and `total @= 0` (32) are local inference.
4. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 6, 11, 15, 22, 32, 34 (cell re-binding), 9, 20 (element field re-binding `items[i].qty = ...`), and 12 (`items = ...`).
5. "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `0` (6, 15, 32), `3`, `2`, `4`, `5`, `9` (27-31), and `1` in `i + 1` (11, 22), which are all `i64`.
6. "No implicit conversions, widths included: `1 + 2.0` is an error." Governs lines 9, 11, 18, 20, 22, 34 (all `i64`).
7. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`". Governs lines 5, 14 (signatures) and 12, 27-31 (call sites with `@items`).
8. "a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." Governs `items` (5, 14, 25: written at lines 9, 12, 20, or passed with `@`), `i` (6, 11, 15, 22: re-bound), and `total` (32, 34: re-bound).
9. "An unused binding or parameter is a compile error" Governs lines 5-6 and 14-15 (`name`, `n`, `items`, `i`, `item` all read) and 26-35 (`total`, `item`, `items` all read).
10. "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs line 12 (`items = items.push(...)`, where `items` is a plain name).
11. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs line 12 (`items.push(...)` is `push(items, ...)`).
12. "an empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`." Governs line 26 (`items: [Item] @= []`).
13. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`". Governs line 12 (`Item(name: name, qty: n)`) and the record declaration (1-3).
14. "`==` is structural equality on any two values of one type, recursively". Governs lines 8, 17 (`item.name == name`).
15. "`if cond` / `else if` / `else` take only `bool`: there is no truthiness." Governs lines 8, 17, 18 (each condition is a `bool` comparison).
16. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 7, 16, 33 (`for item in items`).
17. "A function with a `->` must `return` on every path that reaches its end, and `exit(code:)`, `assert false` and a `while true` with no `break` of its own end a path." Governs lines 14-23 (`take`): every path ends at `return false` (line 23) or at a `return` inside the loop.
18. "A statement after a jump, in its block, is a compile error." Governs lines 10, 19, 21, 23: each `return` is the last statement of its block. Lines 11 and 22 follow `if` statements that have no `else` and do not leave, so they are not after a jump.
19. "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs lines 5, 14 and calls 27-31: no two parameters in `restock` or `take` share a type (`[Item]`, `str`, `i64`), so positional arguments are allowed.
20. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 30, 31 (`bool` arguments) and 35 (`i64` argument).
21. "a `bool` prints `true` or `false`." Governs lines 30, 31 (expected output `true`, `false`).
22. "Syntax is ASCII-only." Governs the whole program (all ASCII).
23. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Not triggered: there is no `use`, and within each function every name is bound once (`items`, `i`, `item`, `total`), so no name is rebound through shadowing. Governs lines 5-35.
24. "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs the `for item in items` loops (7, 16, 33) and the writes inside them (9, 20). I read this as meaning the loop iterates over a copy, so writes to `items[i]` do not disturb the iteration. This is the reading I relied on; see confidence.
25. "`[T]` | dynamic array, indices from 0" Governs `items[i]` (9, 20) and the counter `i` starting at `0` (6, 15). The spec does not name the index type, so an `i64` index is assumed.

## choice_points

1. **How the loop finds the matching item.** I used a counter `i @= 0` incremented once per element with `for item in items`. The other choice was `for i in range(from: 0, to: len(items))`. That produces the same output, but it needs `len(items)` to return `i64`, which the spec never states (it only says `range` takes and returns `i64`). The counter avoids that dependency.
2. **How the matching item is updated.** I wrote `items[i].qty = item.qty + n` (a field write). The other choice, `items[i] = Item(name: name, qty: item.qty + n)`, gives the same output and rebuilds the record instead of writing one field.
3. **How the new item is appended.** I wrote `items = items.push(...)`, which rebinds the `@` parameter as a plain name, as the spec's push rule requires. The other choice, `items.push(...)` on its own, would discard the new array; the spec says a line that computes a value must use it, so that would be refused.
4. **Early exit in `restock`.** I used `return` inside the loop after updating. The other choice is a flag `found @= false`, set in the loop and tested after it with `if !found`. The output is the same, but the flag adds a cell that must be re-bound.
5. **Structure of `take`.** I used nested `if` blocks: return `false` when the qty is short, otherwise subtract and return `true`. The other choice is a combined test `if item.name == name && item.qty >= n`, falling through to `return false` otherwise. Output is the same because names are unique (restock never creates duplicates), so continuing the loop after a short match finds nothing else.
6. **Iteration over the array while writing it.** I iterated with `for item in items` and wrote `items[i]` inside the loop. The other choice is a `while i < len(items)` loop, which avoids iterating a value that the loop body changes. It would need the `len` return type discussed in choice 1.
7. **Printing the results.** I passed `take(...)` directly to `print`, which prints a `bool` as `true` or `false`. The other choice is an `if` that prints the words, which gives the same text.
8. **Summing.** I used a `total @=` cell and a `for` loop. The other choice is `fold`, but the spec gives no anonymous functions, so `fold` would need a named two-argument function with a `(function(acc, item) -> ...)` type.
9. **Index type.** I index with the `i64` cell `i`. The spec does not state the index type for `[T]`; the other choice would be a conversion such as `to_u64`, which would produce a `T?` and need unwrapping.

## confidence

About 80% that the checker accepts the program as written. The main uncertainties are:

- Lines 7 and 16 (`for item in items`) together with lines 9 and 20 (`items[i].qty = ...`): I assume the loop iterates over a copy, and that writing an element of the array being iterated is accepted. If the checker forbids mutating a collection under iteration, these lines fail.
- Lines 9 and 20 (`items[i]`): I assume an `i64` index is accepted for `[T]`. The spec does not name the index type.
- Line 12 (`items = items.push(...)`): the spec's push rule is written for `xs = xs.push(4)` with a plain name. I assume a `@` parameter counts as a plain name.

The line I am least sure of is line 9 (`items[i].qty = item.qty + n`), because it combines the iteration in line 7 with a write through an index. If the checker is strict about either, rewriting the loop as `for i in range(from: 0, to: len(items))` removes the iteration question but adds the `len` question.

## context

Nothing outside this directory reached my context. I read only files in this directory: `brief.md`, `spec.md`, and `run.json` and `run.err` (both empty). I ran no other tools and read no other files.

The harness supplied a system prompt, environment details (working directory, platform, shell, date), a git status snapshot, and user account metadata. These are not files from this directory, but they were in my context. None of them shaped the program, which comes only from `spec.md`.
