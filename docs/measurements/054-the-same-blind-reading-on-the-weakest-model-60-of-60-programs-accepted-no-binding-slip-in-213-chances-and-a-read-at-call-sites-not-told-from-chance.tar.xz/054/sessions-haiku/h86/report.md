## verdict

Refused. The checker refuses two lines of `main.hero`:

- Line 20, `step = 2`. `step` is bound with `$=` on line 10, and `$=` binds once, forever. Only a mutable cell (`@=`) can be re-bound with `=`.
- Line 22, `last @= words[0]`. `last` is a cell, and nothing re-binds it. Section 5 makes a cell that nothing re-binds a compile error.

Nothing else on the file's `=` or `@` lines is refused. The output below is for the fixed program in the `program` section, since the original is not accepted:

```
5
5
a
```

## lines

| line | new name | class | words of the specification relied on |
|---|---|---|---|
| 5 | `c` (parameter of `bump`) | *new name* | "Mutable parameters are marked `@` in the signature and at the call site" (section 9); `Param = "@" ident ":" Type` (section 4) |
| 6 | none; `c.hits` | *changes an existing name* | "`=` re-binds it, or a field or element inside one" (section 5) |
| 9 | `words` | *new name* | "`$=` binds once, forever." (section 5) |
| 10 | `step` | *new name* | "`$=` binds once, forever." (section 5) |
| 11 | `counts` | *new name* | "`@=` declares a mutable cell" (section 5) |
| 12 | `total` | *new name* | "`@=` declares a mutable cell" (section 5) |
| 15 | none; `counts[w]` | *changes an existing name* | "`=` re-binds it, or a field or element inside one" (section 5); "`m[k] = v` inserts or replaces" (section 10) |
| 16 | none; `total` | *changes an existing name* | "`=` re-binds it" (section 5) |
| 18 | `c` | *new name* | "`@=` declares a mutable cell" (section 5) |
| 19 | none; `@c` argument | *changes an existing name* | "an `@` argument counting; a read is a use and a write is not, except through an `@` parameter" (section 5); "the callee works on the caller's place itself" (section 9) |
| 20 | none; `step` | *changes an existing name* in form, but refused | "`$=` binds once, forever." (section 5); "`=` re-binds it" applies to a cell only (section 5) |
| 21 | none; `@c` argument | *changes an existing name* | same as line 19 |
| 22 | `last` | *new name* in form, but refused as a cell nothing re-binds | "`@=` declares a mutable cell" (section 5); "so is a cell nothing re-binds" (section 5) |

Lines 1 to 4, 7, 8, 13, 14, 17 and 23 to 25 hold neither `=` nor `@`, so they have no row. Line 1 is `record Counter`, line 14 is `for w in words`, and the rest are declarations or `print` calls without a binding.

## sentences

From section 5: "`$=` binds once, forever."

From section 5: "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."

From section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."

From section 5: "Signatures are always explicit; inference is local only."

From section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"

From section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."

From section 9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`"

From section 10: "`m[k] = v` inserts or replaces;"

From section 2: "A literal takes the type its context asks for" (so `step $= 1` is `i64`, and the literal `2` on line 20 takes that type too.)

From section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

Changes from the original: line 10 `step $= 1` becomes `step @= 1`, and line 22 `last @= words[0]` becomes `last $= words[0]`. Nothing else changes.

Printed output of this program: `5`, then `5`, then `a`. The loop adds `step` (1) five times, so `total` is 5 and `counts["a"]` is 3. The first `bump` adds 3 to `c.hits`, and the second adds 2, so `c.hits` is 5. `last` is `words[0]`, which is `"a"`.

## choice_points

1. **Line 10, `$=` or `@=` for `step`.** I chose `@=`, because line 20 (`step = 2`) plainly means that `step` changes before the second `bump`. The other choice is to keep `$=` and replace lines 20 and 21 with `bump(@c, 2)`. That prints the same three lines (`5`, `5`, `a`) but is a different program that no longer changes `step`. A third choice, `step2 $= 2` with `bump(@c, step2)`, also prints the same output but adds a name.
2. **Line 22, `$=` or `@=` for `last`.** I chose `$=`, because nothing re-binds `last`, so it does not need to be a cell. The other choice is to keep `@=` and add a re-binding such as `last = words[4]`. That also prints `a`, but it invents a statement the author did not write.
3. **Whether `bump(@c, ...)` counts as a re-binding of `c`.** The specification says an `@` argument counts, so I read the calls on lines 19 and 21 as writes that keep line 18's cell `c` alive. If they did not count, `c` would be a cell nothing re-binds, and line 18 would also be refused. The spec text supports my reading, so I made no change for it.
4. **Classification of lines 19, 20 and 21.** I classed the `@c` arguments on lines 19 and 21 as *changes an existing name*, because the callee writes the caller's place. A reader who looks only at the call line could class them *neither*, since the call itself binds nothing. I classed line 20 by its form, `Place "=" Expression`, and marked it as refused.
5. **Smallest fix.** I changed two lines, one token each. Deleting line 20 would change what the program means, so I did not take that route.

## confidence

I am highly confident of the verdict: line 20 is refused because `step` is a `$=` name, and line 22 is refused because `last` is a cell that is never re-bound. Both rules are stated explicitly in section 5. I am also confident of the printed output (`5`, `5`, `a`) of the fixed program, since I traced the arithmetic by hand.

I am least sure of two things. First, I read `main.hero` as rendered text and could not inspect its bytes, so an invisible character, trailing whitespace, or a tab in the indentation would not show up in my reading. I could not run the checker to confirm. Second, the classification of the `@c` arguments (choice point 4) is a judgment call rather than a rule the spec states outright.

## context

Only this directory's files were read: `brief.md`, `spec.md`, and `main.hero`, which the brief names as the inputs. I also opened `run.json` and `run.err`, which are in this directory but are not named as inputs. Both are empty, and they contributed nothing to the report.

Nothing from outside this directory was read. The harness supplied session metadata that reached my context: an environment block with the working directory, platform and date, a note about the user's account, and a git status snapshot. I did not use any of it in the verdict or the program.
