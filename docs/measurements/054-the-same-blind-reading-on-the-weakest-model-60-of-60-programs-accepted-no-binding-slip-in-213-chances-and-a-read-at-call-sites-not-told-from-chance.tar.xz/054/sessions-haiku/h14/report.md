## program

```
# Returns a copy of xs ordered from largest to smallest, by adjacent swaps.
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n: i64 := to_i64(len(ys)).must()
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if ys[j] < ys[j + 1]
                t := ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
            j = j + 1
        i = i + 1
    return ys

# Counts the maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    n: i64 := to_i64(len(xs)).must()
    if n == 0
        return 0
    count @= 1
    i @= 1
    while i < n
        if xs[i] != xs[i - 1]
            count = count + 1
        i = i + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

The line numbers below count from the first line of the block above, so line 1 is the first comment and line 33 is the last `print`. The block has 33 lines, with blank lines at 16 and 29.

## sentences

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs the whole file (lines 1-33) and `function main()` at line 30.
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line, for example lines 3-15, 19-28 and 31-33.
3. "No braces, no semicolons; a condition needs no parentheses." Governs the conditions without parentheses at lines 6, 8, 9, 20, 24 and 25.
4. "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it; `##` is a section heading." Governs the comments at lines 1 and 17, which sit directly above `sorted_desc` and `runs`.
5. "Signatures are always explicit; inference is local only." Governs the signatures at lines 2, 18 and 30, and the local bindings whose types are inferred (for example `ys` at line 3, `i` at line 5).
6. "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs `:=` at lines 4, 10 and 19. Governs `@=` at lines 3, 5, 7, 22 and 23. Governs `=` and element writes at lines 11 (`ys[j] = ...`), 12 (`ys[j + 1] = ...`), 13 (`j = j + 1`), 14 (`i = i + 1`), 26 (`count = count + 1`) and 27 (`i = i + 1`).
7. "A literal takes the type its context asks for ... otherwise `i64`." Governs the integer literals at lines 5, 7, 21, 22 and 23 (`0`, `0`, `0`, `1`, `1`) and the array literals at lines 31 and 33.
8. "No implicit conversions, widths included: `1 + 2.0` is an error." Governs lines 4 and 19, where the `len` result is converted to `i64` before it meets the `i64` arithmetic and comparisons at lines 6, 8, 20, 24 and 25.
9. "Built-ins: `print(...)` · `len` · `push` · ..." Governs `len` at lines 4 and 19 and `print` at lines 32 and 33.
10. "`to_i8` … `to_u64` give a `T?`, because the number may not fit. `to_i64` takes a float too, truncating toward zero." Governs `to_i64(len(...))` at lines 4 and 19, which gives an `i64?`.
11. "`.must()` | extract or abort" (section 6 table). Governs the `.must()` at lines 4 and 19, which extracts the `i64`.
12. "A `T?` is a `T` or an error" (section 6). Governs lines 4 and 19: the `i64?` from `to_i64` is handled by `.must()` before it is bound.
13. "`< <= > >=`: a number only" (section 7 operator table). Governs the `<` comparisons at lines 6, 8, 9 and 24.
14. "`==`" and "`!=`" are comparisons on one type in the section 7 operator table. Governs line 20 (`n == 0`) and line 25 (`xs[i] != xs[i - 1]`).
15. "`if cond` / `else if` / `else` take only `bool`" (section 8). Governs the `if` conditions at lines 9, 20 and 25, each of which is a `bool`.
16. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs the `while` loops at lines 6, 8 and 24, and the `for` loop at line 31.
17. "A function with a `->` must `return` on every path that reaches its end" (section 8). Governs the final `return` at lines 15 and 28, and the early `return 0` at line 21.
18. "A statement after a jump, in its block, is a compile error." Governs lines 20-22: `return 0` at line 21 ends the `if` block, and the next statement (line 22) is in the function block, after the `if` and not after the jump.
19. "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs line 3 (`ys @= xs`): `ys` is a copy, so the parameter `xs` is not changed.
20. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds" (section 5). Governs every binding. Each is read: `ys` (lines 4, 6, 9, 15), `n` (lines 6, 8, 20, 24), `i` (lines 6, 9, 14, 25), `j` (lines 8, 9, 10, 13), `t` (line 12), `count` (line 28), `x` (line 32). Each cell is re-bound: `ys` at lines 11 and 12, `i` at lines 14 and 27, `j` at line 13, `count` at line 26.
21. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs the local names. `i`, `j`, `n` and `t` are each declared once per function. The `j @= 0` at line 7 runs once per outer iteration, but it is one declaration in the source, so it does not shadow anything.
22. "`[T]` | dynamic array, indices from 0" (section 3 table). Governs the indexing at lines 9, 10, 11, 12 and 25 (`ys[j]`, `ys[j + 1]`, `xs[i]`, `xs[i - 1]`).
23. "An out-of-bounds index or slice aborts, and so does a slice that splits a character." Governs lines 9-12 and 25. The bounds hold because the inner loop runs while `j < n - 1 - i`, so `j + 1 <= n - 1`, and `i >= 1` in `runs`. No index is out of bounds, so the program does not abort.
24. "Declaration order never matters but a group's (section 13)." Governs lines 2, 18 and 30: `main` (line 30) calls `sorted_desc` and `runs`, which are declared before it, and neither function depends on the other.
25. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 32 and 33: one `i64` per line.

## choice_points

1. **Descending order by adjacent swaps.** I swap when the left element is smaller than its right neighbour (line 9, `ys[j] < ys[j + 1]`). The other choice, swapping when the left is larger (`>`), gives ascending output, which is the wrong answer for the task.
2. **Copy of the input in `sorted_desc`.** I bind `ys @= xs` (line 3), so the caller's array is untouched and the function returns a new array. The other choice, marking the parameter `@xs`, would change the caller's array in place. It would also need an `@` at the call site, which the required call `sorted_desc([...])` does not have.
3. **Width of `len`.** The spec lists `len` but does not state its result type. I convert it with `to_i64(...).must()` (lines 4 and 19), so the result is `i64` whatever the built-in returns. The other choice, `n: i64 := len(ys)`, is shorter and correct only if `len` returns `i64`. If it returns another integer width, that line is a compile error and the program is rejected.
4. **Empty input in `runs`.** For `xs` of length 0 I return `0` (lines 20-21). The other choice would fall through to `xs[0]`, which aborts. The specified example is not empty, so this choice does not change the output.
5. **Counting in `runs`.** I start `count` at `1` and compare from index 1 (lines 22-27). The other choice, starting at `0` and counting every element that differs from its predecessor, gives the same answer but needs a guard for index 0.
6. **Loop form.** I use `while` with explicit cells (lines 5-14 and 23-27). The other choice is `for j in range(from: 0, to: n - 1 - i)`, which the spec also allows because `range` takes expression bounds. Both give the same output. I chose `while` so the outer and inner counters are plain cells that the reader can see. The other choice, an early-exit flag when a pass makes no swap, also gives the same output and adds code.
7. **Swap form.** I swap through a temporary `t := ys[j]` (lines 10-12). The spec describes no tuple assignment, so the temporary is the direct form.
8. **Comments.** I included one comment above each function (lines 1 and 17). The other choice, no comments, gives the same checker result.
9. **Output of `main`.** I print each sorted element with `print(x)` on its own line, then the `runs` result with a separate `print` (lines 31-33). The other choice, joining the elements into one `str` and printing it once, would not give one element per line.

## confidence

About 90% that the checker accepts the program as written.

The least certain lines are 4 and 19, `n: i64 := to_i64(len(ys)).must()` and `n: i64 := to_i64(len(xs)).must()`. The spec does not give the result type of `len`. I am relying on `to_i64` accepting whatever integer `len` returns, and on `.must()` extracting the `i64?`. If either assumption is wrong, the checker rejects those lines. Lines 9-12 and 25 (indexing with an `i64` index) are the next least certain, because the spec does not state the index type. `i64` is the default integer type, so I expect those lines to pass.

## context

Only the files in this directory were used as inputs: `brief.md`, `spec.md`, `run.json` and `run.err`. The last two were empty, so they contributed nothing. I did not read any other file, and I used no tool other than reading and writing files here.

Outside the directory's files, the session's environment information reached my context. That includes the working directory path, platform, shell, scratchpad path, the current date, and a git status snapshot with the branch and recent commit message. I did not use any of it for the program or the report, and I did not read the repository or any file those paths point to.
