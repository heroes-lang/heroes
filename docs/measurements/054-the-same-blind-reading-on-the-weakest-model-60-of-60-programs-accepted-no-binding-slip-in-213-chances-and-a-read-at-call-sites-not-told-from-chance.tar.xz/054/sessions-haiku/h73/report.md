## program

```
# An inventory of named quantities.
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    while i < items.len()
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
        i = i + 1
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    while i < items.len()
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty = items[i].qty - n
                return true
            return false
        i = i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, name: "apple", n: 3)
    restock(@items, name: "pear", n: 2)
    restock(@items, name: "apple", n: 4)
    print(take(@items, name: "apple", n: 5))
    print(take(@items, name: "pear", n: 9))
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output, if the program runs as intended: `true`, `false`, `4` (apple is 7, take 5 leaves 2; pear is 2, which is not enough for 9 so it stays; 2 + 2 = 4).

## sentences

Each quotation is from `spec.md`; ellipses mark omitted words. The line numbers refer to the program above.

- §1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line (3-4, 7-13, 16-24, 27-36).
- §1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 26.
- §1: "`#` comments to end of line, markdown inside." Governs line 1.
- §2: "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `0` (lines 7, 16, 33), `1` (lines 12, 23), and `3`, `2`, `4`, `5`, `9` (lines 28-32), which take `i64` from the `n` parameter.
- §3: "`[T]` | dynamic array, indices from 0". Governs the parameter types `[Item]` on lines 6 and 15 and the annotation on line 27.
- §4: "Every top-level line starts with its kind." Governs lines 2, 6, 15, 26.
- §4: "Declaration order never matters but a group's (section 13)". Governs the order of lines 2, 6, 15, 26; the record is written first, though no line depends on it.
- §5: "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 7, 16, 33 (declarations), 10, 20 (field and element re-binds), and 12, 23, 35 (cell re-binds).
- §5: "All bindings are initialised. An unused binding or parameter is a compile error" Governs every binding and parameter: `i` (7, 16) is read by the loop condition; `items`, `name` and `n` are read in every function; `total` (33) and `item` (34) are read.
- §5: "Signatures are always explicit; inference is local only." Governs lines 6, 15 (both signatures are written in full) and line 26 (`main` takes and returns nothing, so its signature is only its name).
- §5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." The program has no `use`. The name `i` appears in two functions and `items` in `main`; each is a separate local, so none shadows another. `name` on line 13 is a field name in `Item(name: name, ...)`, not a binding.
- §6: not used.
- §7: "comparison `== != < <= > >=`" Governs lines 8, 17 (`<` on `i64`), 9, 18 (`==` on `str`), and 19 (`>=` on `i64`).
- §7: "`==` is structural equality on any two values of one type, recursively" Governs lines 9, 18 (`str == str`).
- §7: "arithmetic `+ - * / %` (both sides one numeric type ... never mixed)" Governs lines 10, 20, 35 (`i64` with `i64`) and 12, 23 (`i64 + i64`, where the literal `1` takes `i64` from `i`).
- §8: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 8, 17 (`while`) and 34 (`for`).
- §8: "A function with a `->` must `return` on every path that reaches its end" Governs `take`, lines 15-24: the loop may exit, so the trailing `return false` on line 24 covers that path, and every other path returns inside the loop.
- §8: "A statement after a jump, in its block, is a compile error." Governs lines 11 and 21-22: each jump is the last statement of its block (line 11 ends the if-block of line 9; line 21 ends the if-block of line 19; line 22 ends the if-block of line 18). Line 23 follows the `if` on line 18, and that `if` does not end on every branch, so line 23 is allowed.
- §9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs line 13 (`Item(name: name, qty: n)`).
- §9: "Mutable parameters are marked `@` in the signature and at the call site" Governs lines 6, 15 (signatures) and 13, 28-32 (call sites, with `@items` each time).
- §9: "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs lines 8, 13, 17 (`items.len()`, `items.push(...)`). UFCS does not apply to an `@` first parameter, and the receiver here is the array, not an `@` parameter.
- §9: "When two parameters in a signature share a type, named arguments are mandatory at the call site" does not force anything here: no two parameters of `restock` or `take` share a type. The named arguments are still legal; see choice points.
- §9: "the callee works on the caller's place itself, which no other `@` argument of the call may reach" Governs lines 28-32: each call has one `@` argument.
- §10: "an empty one needs an annotation: `xs: [i64] $= []`" Governs line 27, `items: [Item] @= []`.
- §10: "`xs = xs.push(4)` grows in place when `xs` is a plain name" Governs line 13, where `items` is a plain name.
- §10: "`s[i]` yields a `u8`" does not apply; array indexing yields the element itself (the §6 example reads `xs[0]` as the element type). Governs lines 9-10 and 18-20, which read and re-bind `items[i].name` and `items[i].qty`.
- §11: "Built-ins: `print(...)` · `len` · `push` ..." Governs `items.len()` (lines 8, 17) and `items.push(...)` (line 13).
- §11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 31, 32 (`bool`) and 36 (`i64`), each printing one line.
- §12: "`???` is a valid expression anywhere." Not used; the program has no holes.
- §13 (FFI): not used.

## choice_points

1. **Type of `len`.** The spec does not state the return type of `len`. I assumed `i64`, so that `i < items.len()` on lines 8 and 17 compares two `i64`. The other choice, a different integer type, makes `i < items.len()` a type error, since there is no implicit conversion. The fix in that case would be to type the cell `i` as that type on lines 7 and 16.
2. **Loop shape for the search.** I used `while` with an index cell `i`. The other choice, `for i in range(from: 0, to: items.len())`, also depends on the type of `len`, since `range` takes `i64` bounds. It would produce the same output.
3. **Index walk versus `find`.** The spec's `find` returns "the first it accepts, else `not_found`" but gives no signature, so I did not use it. Using it would mean guessing its return type and error form, which risks the first-try acceptance.
4. **Named arguments at call sites.** I wrote `name:` and `n:` at each call. The other choice, positional arguments (`restock(@items, "apple", 3)`), is also legal, since no two parameters share a type. Output is the same.
5. **Update in place versus rebuilding the item.** Lines 10 and 20 write `items[i].qty = ...`. The other choice, `items[i] = Item(name: ..., qty: ...)`, produces the same output. In place avoids rebuilding the record.
6. **Append form.** I wrote `items = items.push(...)`, the plain-name form the spec says grows in place. The other choice, `items.push(...)` as a standalone line, would discard the new array; I did not rely on that.
7. **Early return inside `restock`.** I used `return` on line 11 once the item is found. The other choice, an `if`/`else` with a flag, produces the same output but must respect the rule about statements after a jump.
8. **`take` on a found name with too little stock.** I return `false` at once (line 22) without searching further. The other choice, continuing the loop, gives the same result, because `restock` never creates duplicate names.
9. **Printing booleans.** I used `print(take(...))` directly, which the spec allows, since `bool` renders as `true` or `false`. The other choice, an `if` that prints a string literal, prints the same text.
10. **Sum.** I used `for item in items` with a cell `total`. The other choice, `fold`, is described in the spec only in words (its function names its arguments `acc` then `item`) with no signature, so I avoided it.
11. **Comment at top.** I wrote one `#` comment at line 1. The other choice, none, does not change what the checker accepts.
12. **Literal types.** All literals take `i64` from context (`qty`, `n`) or by default. A narrower type would fail, since no implicit conversion exists.

## confidence

About 85 percent that the checker accepts the program as written, and that it prints `true`, `false`, `4`. The largest uncertainty is that `len`'s return type is not stated, so I assumed `i64`. If `len` returns another integer type, lines 8 and 17 fail.

Least sure line: **line 8 (and the same comparison on line 17), `while i < items.len()`**. It depends on the unstated return type of `len`. The other lines rest on rules the spec states directly, which I checked against the statements and bindings in the program.

## context

Only files in this directory were used for the program: `brief.md`, `spec.md`, and the two files `run.json` and `run.err`. I read all four. The brief named only `spec.md` as input, so reading `run.json` and `run.err` went beyond the brief's stated input. Both files were empty, so they did not affect the program.

Nothing else reached my context as a source for the program. My session carried environment details (the working directory path, the platform, the date, and my model name) and a git status snapshot for the user's workspace. These are not from files in this directory, and I did not use them for the program. No tool other than reading and writing files in this directory was used.
