## program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n = ys.len()
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if ys[j] < ys[j + 1]
                t = ys[j]
                ys[j] @ ys[j + 1]
                ys[j + 1] @ t
    return ys

function runs(xs: [i64]) -> i64
    if xs.len() == 0
        return 0
    count @= 1
    for i in range(from: 1, to: xs.len())
        if xs[i] != xs[i - 1]
            count @ count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

## sentences

Line numbers refer to the program block above (line 1 is `function sorted_desc`).

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 21-24.
2. "Signatures are always explicit; inference is local only." Governs lines 1, 12, 21 (every signature is written out in full).
3. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs line 2 (`ys @= xs`), line 15 (`count @= 1`), lines 3 and 7 (`n = ...`, `t = ...`, immutable bindings), and lines 8, 9, 18 (re-bindings: element writes and `count @ ...`).
4. "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs line 2. The parameter `xs` has no `@` mark, so it cannot be written; `ys` is a copy that the sort can change.
5. "Place = ident { "." ident | "[" Expression "]" }" together with "Simple = "_" Binding | Place "@" Expression NEWLINE". Governs lines 8, 9 (`ys[j] @ ...`, `ys[j + 1] @ ...`) and line 18 (`count @ ...`).
6. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds". Governs every binding: `xs` (lines 1, 2, 12, 13, 16, 17 read it), `ys` (re-bound on lines 8, 9), `n` (lines 4, 5), `t` (lines 8, 9), `count` (re-bound on line 18), `i` and `j` (used on lines 5 and 6-9), `x` (line 23).
7. "`[T]` | dynamic array, indices from 0". Governs the index reads and writes on lines 6, 7, 8, 9, 17.
8. "An out-of-bounds index or slice aborts, and so does a slice that splits a character." Governs lines 6-9, where `j + 1` stays at most `n - 1` because `j` is at most `n - 2 - i`, and line 17, where `i - 1` is at least 0 because `i` starts at 1.
9. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 4, 5, 16 (`for ... in range(...)`) and line 22 (`for x in` over an array).
10. "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs lines 4, 5, 16. `range(from: 0, to: n)` gives 0 through `n - 1`, which is the set of passes and indices the sort needs.
11. "When two parameters in a signature share a type, named arguments are mandatory at the call site: `copy(from: a, to: b)`". Governs lines 4, 5, 16. Both `from` and `to` are `i64`, so the calls use the names `from:` and `to:`. Lines 13, 22 and 24 call one-parameter functions, so positional arguments are used there.
12. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs lines 3, 13, 16 (`ys.len()`, `xs.len()`), together with the built-in list "Built-ins: `print(...)` · `len` · ...".
13. The example in section 6 uses "`xs.len() == 0`". Governs line 13.
14. "`if cond` / `else if` / `else` take only `bool`, and there is no truthiness." Governs lines 6, 13, 17. Each condition is a comparison, so it is a `bool`.
15. "`==` ... `!=` ... (`< <= > >=`: a number only)." Governs line 6 (`<` on two `i64` values), line 13 (`==`), and line 17 (`!=`).
16. "A literal takes the type its context asks for ... otherwise `i64`." Governs line 15 (`count @= 1` is `i64`), lines 14 and 19 (the return type is `i64`), and the literal arrays on lines 22 and 24, which take `[i64]` from the parameter type.
17. "arithmetic   + - * / %          (both sides one numeric type, never mixed)". Governs lines 3, 5, 7, 16, 18 (`n - 1 - i`, `j + 1`, `i - 1`, `count + 1`). Every operand is an `i64`.
18. "A function with a `->` must `return` on every path that reaches its end". Governs lines 10 (the end of `sorted_desc`) and 19 (the end of `runs`), and line 14, which returns on the empty path.
19. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 23 and 24. Each call prints one `i64`, so each output is one line.
20. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every line of the program.
21. "Outside brackets a line ends its statement: it may not end where the statement cannot, and the next line may not go on with it". Governs every multi-line statement. No statement is broken across lines; each is one line.

## choice_points

1. **Sort shape.** I chose two fixed `for` passes (outer `i`, inner `j` from 0 to `n - 1 - i`). The other choice is a `while` loop that repeats until a cell records that no swap happened. That would also sort correctly, but it needs an extra mutable flag and an extra re-binding.
2. **Where the mutation happens.** I copy `xs` into a mutable cell `ys` (line 2) and sort that. The other choice is marking the parameter `@xs`, which would change the signature the task fixes and would also let the sort change the caller's array. The copy rule in the spec makes the copy safe.
3. **Swap by temporary.** I swap through `t` (lines 7-9). The spec has no tuples or multiple assignment, so a temporary is the only form I see. The other choice, writing `ys[j]` from `ys[j + 1]` without saving first, would lose one value and produce wrong output.
4. **Comparison direction.** The swap fires when `ys[j] < ys[j + 1]` (line 6), which moves larger values left and gives descending order. Using `>` instead would give ascending order, which is not what the task asks for.
5. **Loop form.** I used `for ... in range(...)` (lines 4, 5, 16). The other choice is a `while` loop with a manually updated index cell. The `for` form is shorter and has no extra cell.
6. **Named versus positional arguments.** `range` takes `from:` and `to:` by name (lines 4, 5, 16), which the spec requires because both parameters are `i64`. For one-parameter calls I used positional arguments (lines 13, 22, 24). Naming them too would also be legal, and I chose not to.
7. **Empty input in `runs`.** I return 0 early (lines 13-14). The other choice is to start `count` at 0 and treat the first element separately. Both give the same answer on non-empty input. My version starts `count` at 1 and only compares from index 1 on, so without the early return an empty array would give 1 instead of 0. The early return also keeps `xs[0]` from being read on an empty array, which would abort.
8. **Element type of an array index.** I read `ys[j]` and `xs[i]` as plain `i64` values (lines 6-9, 17). The spec gives `T?` (with `missing_key`) only for map indexing; it says nothing explicit about arrays. The other reading, that array indexing also yields `i64?`, would require `.must()` or `match` on every read and would change lines 6-9 and 17.
9. **Where the `t` binding sits.** I bind `t` inside the `if` body (line 7), so each run of that body makes a fresh binding. The other choice is to declare it once outside the loops as a cell with `@=`, which would need a re-binding and would be a different structure. I chose the immutable form because it is shorter and the spec says `=` is the default immutable binding.
10. **How `main` consumes the sort.** I iterate `sorted_desc([...])` directly in the `for` header (line 22). The other choice is to bind the result to a name first. Both are legal; I chose the direct form to keep the program short.

## confidence

I am about 85% confident the checker accepts this program on the first try. I could not run the checker, so this rests on reading `spec.md` alone.

The line I am least sure of is line 7, `t = ys[j]`. The spec says "`=` binds once, forever," and a checker could read a binding inside a loop body as a rebinding on each pass. I think the more likely reading is that each run of the block makes a fresh binding, but that is the rule I am least certain of. The next least certain is lines 6-9 and 17 (array element reads and writes), because the spec does not explicitly say that array indexing yields `T` rather than `T?`. If it yields `T?`, every such read fails to type-check.

## context

Only the files in this directory were read by me as program inputs: `brief.md`, `spec.md`, `run.err`, and `run.json`. `run.err` and `run.json` are both empty; I read them only because they are in the directory, and they gave me nothing to use.

Other things did reach my context, but they came from the session setup, not from any file I opened: the working-directory and platform information, the model information, and a git status snapshot (on branch `main`, with `run.err` and `run.json` untracked), plus account metadata. None of it bears on the language rules, and I did not use any of it in the program.

I did not read any file outside this directory, and I did not run any tool other than reading and writing files in this directory, as the brief requires.
