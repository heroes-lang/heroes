# Report

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i: i64 @= 0
    while i < items.len()
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
        i = i + 1
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i: i64 @= 0
    while i < items.len()
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty = items[i].qty - n
                return true
            return false
        i = i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    ok1 := take(@items, "apple", 5)
    print(ok1)
    ok2 := take(@items, "pear", 9)
    print(ok2)
    total: i64 @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4`, one per line. (apple 3+4=7, take 5 leaves 2; pear 2, take 9 fails; sum 2+2=4.)

## sentences

Line numbers are those of the program above.

1. "Signatures are always explicit; inference is local only." Governs lines 5, 14, 25 (every signature written in full).
2. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." Governs lines 6, 15, 26, 30, 32, 34 (each binding is read after it is made), the `@items` parameters on lines 5 and 14 (written on lines 9, 12, 19, 22), and `items` in `main` (written by the `@` arguments on lines 27-29 and 30, 32).
3. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 6, 9, 11, 15, 19, 22, 26, 34 (declarations and re-bindings of `i`, `items[i].qty`, `i`, `items[i].qty`, `i`, `items`, `total`), and line 36 (`total`).
4. "`:=` binds once, forever." Governs lines 30 and 32 (`ok1`, `ok2`).
5. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`". Governs lines 5, 14 (signatures) and 27-30, 32 (call sites).
6. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." (No `use` here.) Governs the names `name`, `n`, `items`, `i`, `item`, `total`, `ok1`, `ok2` in lines 5-37, none of which repeats a name in an enclosing scope.
7. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`." Governs line 12 `Item(name: name, qty: n)`.
8. "A container literal separates elements by newline across lines and by comma on one, and an empty one needs an annotation: `xs: [i64] := []` · `m: {str: i64} @= {}`." Governs line 26 (`items: [Item] @= []`).
9. "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs line 12 (`items = items.push(...)`, `items` a plain name).
10. "Built-ins: `print(...)` · `len` · `push` · …" Governs line 12 (`push`), lines 7 and 16 (`len`), lines 31, 33, 37 (`print`).
11. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs lines 7, 12, 16 (`items.len()`, `items.push(...)`) as method-style built-in calls.
12. "`[T]` | dynamic array, indices from 0" (section 3 table). Governs lines 8, 9, 17, 18, 19 (`items[i]`).
13. "`while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 7, 16 (`while`) and 35 (`for item in items`).
14. "`if cond` / `else if` / `else` take only `bool`" followed by "there is no truthiness." Governs lines 8, 17, 18 (conditions `items[i].name == name`, `items[i].qty >= n`).
15. "`==` is structural equality on any two values of one type, recursively". Governs lines 8 and 17 (`str` comparison of `name`).
16. "`< <= > >=`: a number only" (section 7 operator table). Governs lines 7, 16 (`i < items.len()`) and 18 (`>=`).
17. "arithmetic `+ - * / %`" followed by "(both sides one numeric type" and "never mixed)". Governs lines 9, 11, 19, 22, 36 (`i + 1`, `qty + n`, `qty - n`, `total + item.qty`).
18. "A function with a `->` must `return` on every path that reaches its end, and `exit(code:)`, `assert false` and a `while true` with no `break` of its own end a path." Governs lines 14-23 (`take` ends with `return false` on line 23).
19. "A statement after a jump, in its block, is a compile error." Governs line 10 (`return` is last in its block), lines 20-21 (`return true` is last in its block; `return false` on line 21 follows the inner `if`, which is not a jump), and line 23.
20. "`return` [Expression]" (section 5 grammar, `"return" [ Expression ] NEWLINE`). Governs line 10 (bare return in a function with no `->`), lines 20, 21, 23 (returns with `bool`).
21. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 31, 33, 37.
22. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line of the program.
23. "No braces, no semicolons; a condition needs no parentheses." Governs lines 7, 8, 16, 17, 18 (conditions written bare).
24. "Syntax is ASCII-only" Governs the whole program (all ASCII).
25. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs the placement of `restock` and `take` before `main` (lines 5, 14, 25).

## choice_points

1. **How to find the item.** Chose: an index loop with `i: i64 @= 0` and `while i < items.len()`, reading `items[i]` (lines 6-11, 15-22). Other choice: a `for` loop over `items` with a found flag. That cannot mutate the element in place, because `item` is an immutable binding, so the update would need a rebuilt list. Other choice 2: the built-in `find` or `map`. Its exact signature is not given in the spec, so I did not rely on it.
2. **Type of `len`.** The spec never gives the result type of `len` or `items.len()`. Chose: `i64`, so `i < items.len()` on lines 7 and 16 compares like with like. Other choice: `len` returns some other integer (e.g. `u64`). Then both comparisons are type errors ("never mixed"), and the program fails to compile. The fix would be a conversion, but the spec's rule for the `to_<type>` built-ins does not clearly say whether `to_i64` gives `i64?` or `i64`, so I did not use one.
3. **Type of an index.** The spec says indices start at 0 but does not state the index type. Chose: an `i64` counter used directly as the index (`items[i]`). Other choice: an index of another integer type, which would need a conversion or a different counter type.
4. **Growing the list.** Chose: `items = items.push(Item(name: name, qty: n))` on line 12, relying on the "plain name" in-place growth rule. Other choice: `items.push(...)` alone, which discards a value and is an error. Other choice 2: copying through a field or index, which copies the array and is slower but still correct.
5. **Changing a count in place.** Chose: `items[i].qty = items[i].qty + n` (line 9), a re-binding of an element's field inside a `@` parameter. Other choice: rebuilding the whole list, which is more code with no benefit here.
6. **Early exit versus flag.** Chose: `return` from inside the loop (lines 10, 20, 21). Other choice: a `found` flag and a `break`. The result is the same, with more lines.
7. **Declaring `items`.** Chose: `items: [Item] @= []` (line 26) with an explicit type, which the spec requires for an empty container. A mutable cell is needed because `items` is passed as `@items`. Other choice: `:=`, which would make `@items` a write to an immutable binding and is an error.
8. **Printing the take results.** Chose: bind each result to `ok1` and `ok2` (lines 30, 32) and print them. Other choice: `print(take(@items, ...))` directly. That is also legal, since the `@` argument is the only one in its call, but the named bindings make each line easy to check.
9. **Sum loop.** Chose: a `for item in items` loop with a `total @= 0` cell (lines 34-36). Other choice: a `while` loop over an index, which reuses the pattern from `restock` and `take`.
10. **Output of `bool`.** Chose: `print(ok1)` and `print(ok2)`, which print `true` and `false`. Other choice: `if` tests printing fixed strings; the output is identical.
11. **Name of the item field vs. the parameter.** Chose: the parameter `name` and the field `name` share a spelling, using `items[i].name == name` (line 8). Other choice: rename the parameter, for example `key`. Field access is `.name`, so there is no conflict either way.

## confidence

Overall: about 75% that the checker accepts the program on the first try, with the caveats below.

Least sure lines:
- **Lines 7 and 16** (`while i < items.len()`): the type returned by `len` is not in the spec. If it is not `i64`, both lines fail.
- **Line 12** (`items = items.push(...)`): relies on `push` growing in place for a `@` parameter that is a plain name. The spec states the rule for `xs` as a plain name, and `items` is one, but the spec does not say whether a `@` parameter counts the same way. If it does not, the program may still compile but copy the array; a compile error would come only if `push` through an `@` parameter is refused.
- **Line 8 and line 17** (`items[i].name == name`, `items[i]` indexing): depend on indexing with `i64` (choice point 3). Structural `==` on `str` is stated directly.

Lines I am most sure of: 5, 14, 25 (signatures), 26 (empty annotated list), 27-30 (`@` call sites), 31, 33, 37 (`print`).

I have not run the checker, and I cannot run anything here.

## context

Nothing outside this directory reached my context. I read only `brief.md` and `spec.md` in this directory, and I read `run.json` and `run.err`, which are also in this directory and are empty. I used no other tools besides reading and writing files here.
