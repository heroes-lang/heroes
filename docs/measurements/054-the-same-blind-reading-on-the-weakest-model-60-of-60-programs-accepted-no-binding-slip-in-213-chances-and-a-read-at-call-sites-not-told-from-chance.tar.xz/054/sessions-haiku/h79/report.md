## program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n = len(xs)
    i @= 0
    while i < n
        j @= 0
        while j < n - 1 - i
            if ys[j] < ys[j + 1]
                t = ys[j]
                ys[j] @ ys[j + 1]
                ys[j + 1] @ t
            j @ j + 1
        i @ i + 1
    return ys

function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    i @= 1
    while i < len(xs)
        if xs[i] != xs[i - 1]
            count @ count + 1
        i @ i + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

## sentences

Line numbers refer to the program above.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 27-30 (`main` takes no parameters, has no `->`, and returns nothing).
2. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs lines 27-30: `main` calls `sorted_desc` and `runs`, which are declared above it, and `runs` is declared after `sorted_desc`.
3. "Signatures are always explicit; inference is local only." Governs lines 1 and 16 (explicit parameter and return types) and line 2 (`ys` takes its type from `xs`, a local inference).
4. "Every value behaves as an independent copy: after `b = a`, mutating `b` never changes `a`." Governs line 2 (`ys @= xs`): `xs` is an immutable parameter and is never written; `ys` is the working copy.
5. "`=` binds once, forever." Governs lines 3 (`n`), 9 (`t`), and 22 (no `=` rebinding; only `@`). Line 9 is re-executed each loop iteration in a fresh block, which I take to be a new binding each time (see choice_points).
6. "`@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs lines 2, 4, 6, 19, 20 (cell declarations), 10 and 11 (element re-binding of `ys`), 12, 13, 23, 24 (cell re-binding).
7. "mutable cell, type inferred too" (from the section 5 example `v @= 0`). Governs lines 2, 4, 6, 19, 20 (the cells take `i64` from their literal or array).
8. "All bindings are initialised. An unused binding or parameter is a compile error" Governs every binding: `ys`, `n`, `i`, `j`, `t` (sorted_desc), `count`, `i` (runs), `x` (main). Each is read at least once.
9. "a read is a use and a write is not, except through an `@` parameter." Governs `ys` (line 8 reads it, lines 10-11 write it): a cell nothing reads would be unused, but `ys` is read on line 8 and returned on line 14. Governs `count` (read on line 25, written on line 23).
10. "a cell nothing re-binds" (the rule that every cell must be re-bound). Governs `i` (13 in sorted_desc, 24 in runs), `j` (12), `count` (23), and `ys` (10-11). Each is re-bound.
11. "Shadowing is a compile error" Governs the names inside each function: no name is declared twice in one scope. `i` appears in both `sorted_desc` and `runs`, but those are separate functions and neither is nested in the other.
12. "A literal takes the type its context asks for" and "otherwise `i64`." Governs lines 4 (`i @= 0`), 18 (`return 0`), 17 (`== 0`), 19 (`count @= 1`), 20 (`i @= 1`), 6 (`j @= 0`), and the integer literals in `ys[j + 1]`, `n - 1 - i`, `i - 1`, and the array literals on line 28 and 30.
13. "both sides one numeric type" and "never mixed" (section 7, arithmetic). Governs line 7 (`n - 1 - i`), line 12 (`j + 1`), line 13 (`i + 1`), line 23 (`count + 1`), line 24 (`i + 1`), and line 22 (`i - 1`). Every operand is `i64`.
14. "`< <= > >=`: a number only" Governs line 5 (`i < n`), line 7 (`j < n - 1 - i`), line 8 (`ys[j] < ys[j + 1]`), and line 21 (`i < len(xs)`).
15. "`==` is structural equality on any two values of one type" and "`!=`" (section 7, comparison). Governs line 17 (`len(xs) == 0`) and line 22 (`xs[i] != xs[i - 1]`).
16. "`if cond` / `else if` / `else` take only `bool`" Governs line 8 (`ys[j] < ys[j + 1]`), line 17 (`len(xs) == 0`), and line 22 (`xs[i] != xs[i - 1]`), which are all `bool`. The spec adds "there is no truthiness", so no integer is used as a condition.
17. "a condition needs no parentheses" and "No braces, no semicolons" (section 1). Governs lines 5, 7, 8, 17, 21, 22.
18. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 5 and 7 (`while` loops), 21 (`while`), and 28 (`for x in` over the array returned by `sorted_desc`).
19. "dynamic array, indices from 0" (section 3 table, `[T]`). Governs lines 8, 10, 11 (`ys[j]`, `ys[j + 1]`), and 22 (`xs[i]`, `xs[i - 1]`).
20. "An out-of-bounds index or slice aborts" (section 10). Governs lines 8 and 10-11: `j` runs over `0 .. n - 2 - i`, so `j + 1 <= n - 1`. Governs line 22: `i` starts at 1, so `i - 1 >= 0`.
21. "`len`" (section 11, Built-ins) Governs lines 3, 17, and 21. The spec does not state the return type of `len` (see choice_points).
22. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 29 and 30. `x` and the `i64` result of `runs` are numbers.
23. "Built-ins: `print(...)`" Governs lines 29 and 30.
24. "A function with a `->` must `return` on every path that reaches its end" Governs line 14 (`return ys` ends `sorted_desc`) and line 25 (`return count` ends `runs`). Line 18 is a `return` inside the `if` on line 17; the `if` does not end the path, and line 25 does.
25. "A statement after a jump, in its block, is a compile error." Governs lines 17-19: `return 0` on line 18 is the last statement in its block. Line 19 is outside that block.
26. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs the whole program. Every level is 4 spaces, and the program has no tabs.
27. "NEWLINE ends a statement" (section 1). Governs every line; no statement is continued across lines.
28. "Param = "@" ident ":" Type | ident ":" Type [ "lent" ]" (section 4 grammar). Governs line 1 and line 16: `xs: [i64]` is a read-only parameter.
29. "function ident [ Generics ] Params [ "->" Type ] Block" (section 4 grammar). Governs lines 1, 16, 27.
30. "A literal without the `f` is an error where its braces ..." Not applicable: the program has no string literals and no `{` or `}`.

## choice_points

1. **Type of `len`.** The spec lists `len` among built-ins but does not state its return type. I assumed `i64`, so that `n` (line 3) and `len(xs)` (lines 17, 21) compare and subtract against `i64` literals and cells. The other choice, `len` returning a `u64` or `int`-like type, would make lines 3, 5, 7, 17, 21 type errors without explicit conversion (`to_i64`, which returns `T?` and would need `.must()`), and the program would be rejected.
2. **Index type.** The spec does not say what type an array index must have. I used `i64` (`j`, `i` are `i64` cells). The other choice, requiring `u64` or another index type, would reject lines 8, 10, 11, 22.
3. **Sorting algorithm and loop form.** The brief asks for adjacent swaps, so I used a bubble sort with two nested `while` loops. The other choice, `for i in range(from: 0, to: n)`, would produce the same output, but it adds named-argument syntax and an `exclude to` range I did not need. With `while`, the bounds and the counter update are explicit, which is easier to check by hand.
4. **Copy of the parameter.** `xs` is an immutable parameter, so I copied it into the cell `ys @= xs` and sorted that copy. The other choice, sorting `xs` in place, is not possible: a parameter without `@` cannot be re-bound, and changing the signature to `@xs` would change the function type given in the brief.
5. **Swap condition.** I swap when `ys[j] < ys[j + 1]`, which puts larger values first (descending). The other choice, `<=`, also terminates and gives the same printed output, because equal integers are indistinguishable, but it does extra swaps.
6. **Empty input in `runs`.** The brief does not cover `[]`. I added the guard on line 17 and return `0`. The other choice, starting `count @= 1` with no guard, would return `1` for an empty array. The guard is needed to keep the `count @= 1` start correct and to avoid reading `xs[0]` in the loop, which would be fine here anyway, but the guard keeps the answer right for `[]`.
7. **Binding inside a loop (`t = ys[j]`, line 9).** `=` "binds once, forever", and line 9 runs once per inner iteration. I took each execution to create a fresh binding in a fresh block, which is how loop bodies normally work. The other reading, that a second execution of the same `=` is an error, would reject line 9. I used `t` because a cell `t @= ...` would be an unused-read-free but needless mutable binding. If the checker rejects this, `t` is the line to change.
8. **`for` versus `while` in `main`.** The brief asks for each element printed on its own line; `for x in` over the returned array does that. The other choice, indexing with a `while`, would print the same lines but needs a cell and a `len` call.
9. **Printing.** I used `print(x)` directly on `i64` values rather than `to_str`. The other choice, `print(to_str(x))`, prints the same text but is one more call than the spec requires, since `print` takes numbers.
10. **Use of the `lent` marker.** I did not use `lent` on `xs`. A `lent` parameter is for read-only borrows of `@`-style places; the plain `xs: [i64]` is a copy, which is the default and what the signature in the brief shows. The other choice, `xs: [i64] lent`, would be legal but changes nothing observable and adds a rule I would have to check.

## confidence

I am fairly sure the checker accepts this program, around 80 percent. The spec is complete enough to parse and type every line, but three points rest on the spec being silent rather than explicit:

- The return type of `len` (choice 1) and the required index type (choice 2). Both are very likely `i64`, but the spec does not say so in words.
- Whether a `=` binding inside a loop body is accepted on each iteration (choice 7).
- Whether `print(...)` as a bare statement is accepted as a `()`-valued line (the spec shows `print(n)` as an arm body, and `print(k, m[k].must())` as a loop body statement, so this is supported by examples).

The line I am least sure of is line 3 (`n = len(xs)`), with line 21 (`while i < len(xs)`) sharing the same risk. Both depend on `len` returning `i64`, which the spec leaves unstated. Lines 9 and 10 are next: they rely on the loop-body binding reading in choice 7 and on element re-binding `ys[j] @ ...` being allowed on a cell, which the grammar (`Place "@" Expression`, `Place = ident { "[" Expression "]" }`) supports.

I did not run the checker (I cannot run anything in this task), so this is a reading of the spec, not a test.

## context

Only the files in this directory reached my context: `brief.md`, `spec.md`, `run.json`, and `run.err`. `run.json` and `run.err` are both empty, so they contributed nothing to the program. I read no file outside this directory and used no other tool.

In addition, the session preamble reached my context: the working directory and scratchpad paths, the platform, the model and date, and a note that the repository's git status lists `run.err` and `run.json` as untracked files along with the user's account email and branch name. None of that was used in the program or this report.
