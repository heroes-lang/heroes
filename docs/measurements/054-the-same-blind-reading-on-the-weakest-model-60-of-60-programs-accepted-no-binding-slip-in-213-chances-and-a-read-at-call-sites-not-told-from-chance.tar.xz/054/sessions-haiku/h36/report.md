## program

```
# Sorts by adjacent swaps, largest first.
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n := ys.len()
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if ys[j] < ys[j + 1]
                t := ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
    return ys

# Counts maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    if xs.len() == 0
        return 0
    count @= 1
    for i in range(from: 1, to: xs.len())
        if xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below count from 1 at the `# Sorts` comment line of this block. The `function` lines are 2, 14 and 23.

## sentences

1. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." (spec section 1). Governs every indented line: 3 to 11, 15 to 21, 24 to 26.
2. "the file you compile holds `function main()`, which takes nothing and produces nothing." (spec section 1). Governs line 23.
3. "`:=` binds once, forever." (spec section 5). Governs lines 4, 8 (`:=` bindings) and the loop variables `i` and `j` on lines 5, 6, 18.
4. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." (spec section 5). Governs line 3 (`ys @= xs`), lines 9 and 10 (element re-binds of `ys`), line 17 (`count @= 1`), and line 20 (`count = count + 1`).
5. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds" (spec section 5). Governs `ys` (re-bound on lines 9 and 10), `t` (read on line 10), `count` (re-bound on line 20, read on line 21), `n` (read on line 5 and 6), and the parameter `xs` (read on lines 4, 15, 18, 19). Every binding and parameter is used.
6. "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." (spec section 3). Governs line 3. `xs` is not an `@` parameter, so it cannot be written; `ys` is the mutable copy.
7. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." (spec section 5). Governs the names. `i` (lines 5, 18) and `j` (line 6) are never bound twice in one scope, and `x` (line 24) and `n`, `t`, `ys`, `count` are each bound once in their function.
8. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." (spec section 9). Governs `ys.len()` on line 4 and `xs.len()` on lines 15 and 18.
9. "`len`" is listed among the built-ins (spec section 11), with no result type given. Governs lines 4, 15, 18. See `confidence`.
10. "When two parameters in a signature share a type, named arguments are mandatory at the call site" (spec section 9). Governs lines 5, 6, 18: `range` takes two `i64` parameters, so `from:` and `to:` are written.
11. "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." (spec section 11). Governs lines 5, 6, 18. The inner loop stops before `n - 1 - i`, so `ys[j + 1]` stays in bounds.
12. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." (spec section 8). Governs lines 5, 6, 18 and 24.
13. "`if cond` / `else if` / `else` take only `bool`" (spec section 8). Governs lines 7, 15, 19: each condition is a comparison, which yields `bool`.
14. "`< <= > >=`: a number only" (spec section 7, operator table). Governs line 7 (`ys[j] < ys[j + 1]`).
15. "both sides one numeric type" (spec section 7, arithmetic). Governs line 6 (`n - 1 - i`), lines 7, 9, 10 (`j + 1`), line 19 (`i - 1`), line 20 (`count + 1`). All operands are `i64`.
16. "`Sum = Product { ( "+" | "-" ) Product } .`" (spec section 7 grammar, production `Sum`). Governs line 6 (`n - 1 - i`): the production repeats `-`, so the expression is read left to right as `(n - 1) - i`.
17. "`[T]` | dynamic array, indices from 0" (spec section 3, type table). Governs `ys[j]` on lines 7 to 10, `xs[i]` and `xs[i - 1]` on line 19, and the `[i64]` types on lines 2 and 14.
18. "A literal takes the type its context asks for" (spec section 2). Governs the array literals on lines 24 and 26 (typed `[i64]` by the parameter), and the literals `0` on line 15, `1` on line 17.
19. "A function with a `->` must `return` on every path that reaches its end" (spec section 8). Governs lines 2 to 11 (ends with `return ys` on line 11) and lines 14 to 21 (`return 0` on line 16, `return count` on line 21).
20. "`print` writes its values with no separator and exactly one trailing newline" (spec section 11). Governs lines 25 and 26: each element on its own line, then the `runs` result on its own line.
21. "A container literal separates elements by newline across lines and by comma on one" (spec section 10). Governs lines 24 and 26: each literal is on one line, so its elements are comma-separated.
22. "`function` ident [ Generics ] Params [ "->" Type ] Block" (spec section 4, `Declaration`). Governs lines 2, 14, 23: `main` has no `->`, and the other two declare their return types.

## choice_points

1. **Length binding.** Chose `n := ys.len()` on line 4 and used `n` as the bound. The other choice, `xs.len()` in both loops, produces the same output and is also valid; it re-evaluates the length. Not a checker risk.
2. **Outer loop bound.** Chose `range(from: 0, to: n)` on line 5. The alternative, `range(from: 0, to: n - 1)`, produces the same sorted output with one fewer pass, and is also valid.
3. **Inner loop bound.** Chose `to: n - 1 - i` on line 6. The alternative `to: n` makes `j` reach `n - 1`, so `ys[j + 1]` reads `ys[n]`: an out-of-bounds index, which the spec says aborts. The alternative `to: n - 1` gives the same output with extra comparisons and is safe.
4. **Copy versus mutate.** Chose `ys @= xs` on line 3, a copy, because `xs` is a read-only parameter (no `@`) and cannot be written. The alternative, declaring `@xs`, would change the signature, which the task fixes. A third option, rebuilding the array with `push` in a loop, is valid but slower.
5. **Swap method.** Chose a temporary `t := ys[j]` on line 8 for the swap, since the spec shows no tuple assignment. The alternative, an arithmetic swap (`ys[j] = ys[j] + ys[j + 1]` and so on), would abort on overflow for large values, so the temporary is the safer choice.
6. **Empty input in `runs`.** Chose `return 0` on line 16 for an empty array, the natural count of groups. The alternative, aborting or returning `fail`, would change the signature to `i64?` or add an abort. The task's inputs are not empty, so `main` is unaffected.
7. **Range argument names.** Chose named arguments `range(from: ..., to: ...)`, because the spec makes them mandatory when two parameters share a type. The alternative, positional `range(0, n)`, would be refused by the checker.
8. **Loop form.** Chose `for ... in range(...)` over `while`. A `while` loop with manual counters is also valid and gives the same output.
9. **Method form for `len`.** Chose `xs.len()` (UFCS). The alternative `len(xs)` may also be valid, since the spec lists `len` as a built-in without a signature; it gives the same result if accepted.
10. **Printing the `runs` result.** Chose `print(runs(...))` on line 26 directly. The alternative, binding the result first, would add a binding that must be used, with no change in output.
11. **Descending comparison.** Chose to swap when `ys[j] < ys[j + 1]` on line 7, which moves the larger value forward. The alternative `>` would sort ascending, which the task does not want.

## confidence

Overall, about 85 percent that the checker accepts this program on the first try. I could not run it, so this rests on reading the spec.

Least sure line: **line 4**, `n := ys.len()`. The spec lists `len` among the built-ins but does not state its result type. Lines 5 and 6 (`range(from: 0, to: n)` and `n - 1 - i`) need `n` to be `i64` to match the `range` parameters and the `i64` operands of `-`. If `len` returns another integer width, the checker would refuse lines 4 to 6 and line 15. Line 15 has the same dependency: the literal `0` takes its type from the other side of `==`.

Second least sure: **line 9**, `ys[j] = ys[j + 1]`. The spec says `=` re-binds an element inside a cell, so `ys` counts as re-bound. I am fairly confident, but it depends on the checker treating an element write as a re-bind, as section 5 says.

The other lines follow directly from the quoted sentences.

## context

Nothing outside this directory reached my context. I read these files, all in this directory: `brief.md`, `spec.md`, `run.json` and `run.err`. The last two are empty. I used no knowledge of the Heroes language beyond `spec.md`, I did not use the built-in `sort`, and I did not read any other file. The session metadata (workspace path, git status, and the user's account identity) came from the environment, not from a file in this directory, and I did not use it for the program or the report.
