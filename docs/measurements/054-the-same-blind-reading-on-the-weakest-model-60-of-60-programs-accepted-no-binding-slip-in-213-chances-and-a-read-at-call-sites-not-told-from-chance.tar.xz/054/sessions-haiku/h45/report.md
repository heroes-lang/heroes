# verdict

Refused, on two lines:

- **Line 20** `step = 2`. `step` was bound on line 10 with `:=`, which "binds once, forever". Only a cell declared with `@=` can be re-bound with `=`.
- **Line 22** `last @= words[0]`. `last` is a cell, and nothing re-binds it. The spec makes "a cell nothing re-binds" a compile error.

Everything else on the lines that hold `=` or `@` is accepted as written.

Smallest change that is accepted and keeps the evident meaning: line 10 `step := 1` becomes `step @= 1`, and line 22 `last @= words[0]` becomes `last := words[0]`. The fixed program is under `program`. It prints:

```
5
5
a
```

# lines

Every line of `main.hero` that holds `=` or `@` (the `:=` lines contain `=` and are included).

| Line | Classification | Words of the specification relied on |
|---|---|---|
| 5 | *new name* | Section 9: "Mutable parameters are marked `@` in the signature and at the call site". The `@c` parameter introduces the name `c` in `bump`. The line itself writes nothing. |
| 6 | *changes an existing name* | Section 5: "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Here `=` re-binds the field `hits` inside the `@` parameter `c`. |
| 9 | *new name* | Section 5: "`:=` binds once, forever." `words` is a new immutable binding. |
| 10 | *new name* | Section 5: "`:=` binds once, forever." `step` is a new immutable binding. This is why line 20 is refused. |
| 11 | *new name* | Section 5: "`@=` declares a mutable cell". `counts` is a new cell, annotated as `{str: i64}`. |
| 12 | *new name* | Section 5: "`@=` declares a mutable cell". `total` is a new cell. |
| 15 | *changes an existing name* | Section 5: "`=` re-binds it, or a field or element inside one." Section 10: "`m[k] = v` inserts or replaces". The element write changes the cell `counts`. |
| 16 | *changes an existing name* | Section 5: "`=` re-binds it". `total` is a cell, so the re-binding is allowed. |
| 18 | *new name* | Section 5: "`@=` declares a mutable cell". `c` is a new cell. Section 9: "Record construction is a call with field names, always mandatory". |
| 19 | *changes an existing name* | Section 9: "Either way the callee works on the caller's place itself". The `@c` argument changes `c` through `bump`. Section 5: "an `@` argument counting" as a write. |
| 20 | *changes an existing name* (refused) | Section 5: "`:=` binds once, forever." together with "`=` re-binds it, or a field or element inside one." `step` is not a cell, so the re-binding is refused. |
| 21 | *changes an existing name* | Same as line 19. The `@c` argument changes `c` through `bump`. |
| 22 | *new name* (refused) | Section 5: "`@=` declares a mutable cell". Section 5: "a cell nothing re-binds" is a compile error. `last` is never re-bound. |

# sentences

Every sentence the verdict rests on, quoted from `spec.md`:

1. Section 5: "`:=` binds once, forever."
2. Section 5: "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
3. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
4. Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
5. Section 10: "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"
6. Section 9: "Record construction is a call with field names, always mandatory:"
7. Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."
8. Section 2, the sentence beginning "A literal takes the type its context asks for" and ending "otherwise `i64`." Used to type the literals `1`, `0` and `2` as `i64`.
9. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

# program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output of this program:

```
5
5
a
```

Trace: the loop adds 1 per word, so `counts["a"]` ends at 3 and `total` at 5. `bump` adds 3 to `c.hits`, then `step` is 2, so `bump` adds 2 more, giving 5. `last` is `"a"`.

# choice_points

1. **Repair for line 20.** I made `step` a cell (line 10 `@=`). The other choice is to keep `step` immutable and replace lines 20 and 21 with `bump(@c, 2)`. That also prints `5`, `5`, `a`, but it changes two lines and drops the name `step` that the program evidently uses.
2. **Repair for line 22.** I changed `@=` to `:=`. The other choice is to keep `last` as a cell and add a re-binding such as `last = words[0]` after the loop. That prints the same output but adds a line.
3. **Unused record field `label`.** Line 2 declares `label` and nothing reads it. The spec only forbids unused bindings and parameters, and a field is neither, so I accepted it. If the checker treated fields as bindings, line 2 would be refused. The output would not change.
4. **Classification of line 5 (`@c` parameter).** I chose *new name*, since the parameter introduces `c` in `bump`. The other choice is *neither*, since the line writes nothing. The verdict is unaffected.
5. **Classification of lines 19 and 21 (`@` arguments).** I chose *changes an existing name*, following "an `@` argument counting" and "the callee works on the caller's place itself". The other choice is *neither*, since neither line contains `=`. The verdict is unaffected.
6. **Classification of line 20 (refused).** I chose *changes an existing name*, because that is what the line evidently tries to do. The other choice is *neither*, because the checker refuses it and nothing changes. The verdict is unaffected.
7. **Lines containing `:=`.** I counted them as lines holding `=`. If only `=` and `@=` counted, lines 9 and 10 would drop out. Their classification as *new name* would not change.

# confidence

- **High (about 90 percent)** that the checker refuses lines 20 and 22 and accepts the rest. Both refusals follow directly from quoted sentences in section 5, and the rest of the program follows the same rules.
- **Least sure** of: (a) whether the checker treats an unread record field as an error (section 3 of the choice points); (b) whether lines are indented with exactly 4 spaces and no tabs. I cannot verify the whitespace by reading, and a tab would be a compile error on any line; (c) the exact classification of the `@` lines, where the brief's categories fit loosely.
- I cannot run the checker, so this is a reading of the spec, not a test.

# context

- Read in this directory: `brief.md`, `spec.md`, `main.hero`, plus `run.json` and `run.err`. The last two are empty and were not used.
- No file outside this directory was read.
- The session's environment information (working directory, platform, date, model) and a git status snapshot (branch `main`, untracked `run.err` and `run.json`, one prior commit) were in my context. Neither affected the verdict. A user identity reminder was also present and was not used.
