## verdict

Refused. The checker would reject `main.hero` on two lines:

- **Line 20** `step = 2`: `step` was bound with `:=` on line 10, which binds once and never changes. `=` re-binds only a mutable cell.
- **Line 22** `last @= words[0]`: `last` is a mutable cell that nothing re-binds. A cell nothing re-binds is a compile error. (`last` is only read on line 25.)

Everything else in the file is accepted as written.

Smallest changes that make it accepted (both keep the evident meaning):

- Line 10: `step := 1` becomes `step @= 1`, so the later `step = 2` re-binds a cell.
- Line 22: `last @= words[0]` becomes `last := words[0]`, since it is never changed.

The corrected program prints:

```
5
5
a
```

Trace: the loop gives `counts["a"] = 3`, `counts["b"] = 1`, `counts["c"] = 1` and `total = 5`. `bump(@c, 3)` sets `c.hits` to 3, `step` becomes 2, and `bump(@c, 2)` sets `c.hits` to 5. `last` is `"a"`.

## lines

Every line of `main.hero` that holds `=` or `@` (note that `:=` contains `=`):

| line | source | class | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (`c` and `by` are parameters; `@` marks `c` as mutable) | "Param = "@" ident ":" Type" (section 4); "Mutable parameters are marked `@` in the signature and at the call site" (section 9) |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (`c`, through its `@` parameter) | `=` re-binds "a field or element inside" a cell (section 5); "a write is not [a use], except through an `@` parameter" (section 5); "the callee works on the caller's place itself" (section 9) |
| 9 | `words := [...]` | *new name* | ":= binds once, forever" (section 5); "Binding = [ ":" Type ] ( ":=" \| "@=" ) Expression NEWLINE" (section 5) |
| 10 | `step := 1` | *new name* | ":= binds once, forever" (section 5) |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell" (section 5); the empty map is annotated, as section 10 requires |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell" (section 5) |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (`counts`, one element of it) | "`=` re-binds it, or a field or element inside one" (section 5); "`m[k] = v` inserts or replaces" (section 10); Place = ident { "." ident \| "[" Expression "]" } (section 5) |
| 16 | `total = total + step` | *changes an existing name* (`total`) | "`@=` declares a mutable cell, and `=` re-binds it" (section 5) |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell" (section 5) |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, through the `@` argument; no `=` on the line) | "Mutable parameters are marked `@` in the signature and at the call site" (section 9); "Either way the callee works on the caller's place itself" (section 9) |
| 20 | `step = 2` | *changes an existing name* in intent, and **refused**: `step` is immutable | "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it" (section 5) |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, through the `@` argument) | same as line 19 |
| 22 | `last @= words[0]` | *new name*, but a cell nothing re-binds, which is **refused** | "so is a cell nothing re-binds" (section 5) |

## sentences

Quoted from `spec.md`:

1. Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing."
2. Section 5: "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
3. Section 5: "Signatures are always explicit; inference is local only."
4. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
5. Section 5 grammar: "Simple    = "_" Binding | Place "=" Expression NEWLINE"
6. Section 5 grammar: "Place     = ident { "." ident | "[" Expression "]" } ."
7. Section 9: "Mutable parameters are marked `@` in the signature and at the call site:"
8. Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
9. Section 10: "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"
10. Section 6 table: "`.default(v)` | extract or fall back"
11. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
12. Section 7: "`+` ... (both sides one numeric type)": the `+` row of the operator table, which needs both operands of one numeric type. Both `counts[w].default(0)` and `step` are `i64`, so the sum is accepted.

Sentences 1, 2, 4 and 6 are the ones the verdict rests on. Sentence 5 says `=` is a statement form on any place, so the parser accepts line 20; sentence 2 is what refuses it. Sentence 4 is what refuses line 22.

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

Prints `5`, `5`, `a`, one per line.

## choice_points

1. **Fix for line 20.** I made `step` a cell (line 10 becomes `step @= 1`). The other choice: keep `step := 1` and replace lines 20 and 21 with `bump(@c, 2)`. That also prints `5`, `5`, `a`, but it drops the name `step` and hard-codes the value, so it no longer shows what the program evidently means.
2. **Fix for line 22.** I made `last` immutable (`last := words[0]`). The other choice: keep it a cell and add a re-binding such as `last = words[4]`. That would print `a` too, but it invents a second assignment the program never had.
3. **Line 5 classification.** I called it *new name*, because `c` and `by` are parameters that come into existence there. The other reading is *neither*, because the line only declares a mutability mark and writes nothing. The verdict does not depend on this.
4. **Lines 19 and 21 classification.** I called them *changes an existing name*, because the callee writes `c` through the `@` argument. The other reading is *neither*, since no `=` appears on the line. The verdict does not depend on this.
5. **Line 20 classification.** I called it *changes an existing name* in intent, although the checker refuses it. The other reading is *neither* (no change happens, since it is rejected). The verdict does not depend on this.
6. **Literal typing.** I took `1`, `2` and `0` as `i64`, the default with no other context. `step` and `counts` values are therefore `i64` throughout. If a literal were typed another way the program would be refused for a different reason; this does not arise here.

## confidence

- **High** that the program is refused, and that the two refused lines are 20 and 22. Both rest on explicit sentences in section 5.
- **High** that the corrected program is accepted and prints `5`, `5`, `a`. I traced it by hand.
- **Lower** on the classification of lines 5, 19 and 21, which depends on how one reads "changes an existing name" for a call-site `@` argument. The spec does not give an explicit word for it, only "a write is not [a use], except through an `@` parameter" and "the callee works on the caller's place itself".
- **Not verified**: I cannot run the checker (the brief forbids running anything), so "accepted" and "refused" are readings of the specification, not compiler output. The spec also says the checker is the authority on details I did not check, such as exact error wording.

## context

Only the files in this directory were read as program input: `brief.md`, `spec.md`, `main.hero`. I also opened `run.json` and `run.err`, which sit in this directory but are not named in the brief. Both came back empty and played no part in the answer. I wrote only `report.md`.

Outside this directory, the session's system context reached me: an environment block (platform, shell, paths, model information, date), a git status snapshot for the parent repository, and account metadata. None of it is used in the analysis. I used no tool beyond reading and writing files here.
