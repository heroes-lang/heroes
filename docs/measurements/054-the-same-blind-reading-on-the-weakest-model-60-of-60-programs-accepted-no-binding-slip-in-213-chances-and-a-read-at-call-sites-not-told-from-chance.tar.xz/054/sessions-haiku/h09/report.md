# Report: main.hero against spec.md

## verdict

Refused. Two lines break the checker's rules as written:

- Line 20, `step = 2`: `step` is bound by `:=` on line 10, and a `:=` name binds once, forever. Only a cell (`@=`) can be re-bound with `=`.
- Line 22, `last @= words[0]`: `last` is declared as a mutable cell but nothing ever re-binds it, which the spec makes a compile error.

Nothing else in the file is refused by the rules I checked (see `sentences`).

Smallest fix (two single-token edits, both on lines the program evidently means to be bindings of those kinds):

- Line 10: `step := 1` becomes `step @= 1`, so that line 20 may re-bind it.
- Line 22: `last @= words[0]` becomes `last := words[0]`, since nothing re-binds it.

The submitted program prints:

```
5
5
a
```

Trace: the loop counts `a` 3 times, `b` once, `c` once, so `counts["a"]` is 3 and `total` is 5. `bump` adds 3 to `hits`, then `step` becomes 2 and `bump` adds 2, so `c.hits` is 5. `last` is `"a"`.

## lines

Every line of `main.hero` holding `=` or `@` (note: `:=` and `@=` contain `=`, so they are included).

| Line | Source | Kind | Words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (`c`, the parameter, local to `bump`) | Section 4: `Param = "@" ident ":" Type`; section 9: "Mutable parameters are marked `@` in the signature and at the call site" |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (`c`, a field of it) | Section 5: "`=` re-binds it, or a field or element inside one." |
| 9 | `words := [...]` | *new name* (`words`) | Section 5: "`:=` binds once, forever." |
| 10 | `step := 1` | *new name* (`step`) | Section 5: "`:=` binds once, forever." |
| 11 | `counts: {str: i64} @= {}` | *new name* (`counts`) | Section 5: "`@=` declares a mutable cell" |
| 12 | `total @= 0` | *new name* (`total`) | Section 5: "`@=` declares a mutable cell" |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (`counts`, an element of it) | Section 5: "`=` re-binds it, or a field or element inside one."; section 10: "`m[k] = v` inserts or replaces" |
| 16 | `total = total + step` | *changes an existing name* (`total`) | Section 5: "`=` re-binds it, or a field or element inside one."; `total` is a cell from line 12 |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* (`c`, in `main`) | Section 5: "`@=` declares a mutable cell" |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, through the `@` argument) | Section 9: "the callee works on the caller's place itself"; section 5: "an `@` argument counting" as a write |
| 20 | `step = 2` | *changes an existing name* in intent, but **refused**: `step` is a `:=` name | Section 5: "`:=` binds once, forever." and "`=` re-binds it" (only a cell) |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, through the `@` argument) | Section 9 and section 5 as on line 19 |
| 22 | `last @= words[0]` | *new name* (`last`), and **refused**: no later re-binding | Section 5: "a cell nothing re-binds ... is a compile error" |

## sentences

Quoted from `spec.md`, every sentence the verdict rests on:

- Section 5: "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- Section 5: "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy: `function peek(l: Lex lent)` … `peek(l)`. Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- Section 10: "`m[k] = v` inserts or replaces;"
- Section 7 (operators): "`+` (both sides one numeric type — never mixed)" as it appears in the arithmetic row, which `counts[w].default(0) + step` and `total + step` satisfy since both are `i64`.
- Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

The fix rests on the same sentences plus: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." (see `choice_points`, not a failure here).

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output of this program:

```
5
5
a
```

## choice_points

1. **Fixing line 20.** I changed line 10 to `step @= 1` so the program's evident meaning (`step` becomes 2 partway through) holds. The other choice: keep `step := 1` and replace line 20 with a `bump(@c, 2)` call, dropping the re-binding. That also prints `5 5 a` but changes the program's shape and removes the variable the author evidently wanted. I rejected it as not "the smallest change".
2. **Fixing line 22.** I changed `@=` to `:=`, since `last` is never re-bound. The other choice: keep the cell and add a re-binding of `last` somewhere, which would invent behaviour the program does not have. Rejected.
3. **Classifying line 5 (`@c` parameter).** I called it *new name*, since a parameter brings `c` into existence inside `bump`. The other reading treats it as *neither*, since it binds nothing in the body of `main`. Outcome for the verdict: none.
4. **Classifying line 19 and 21 (`@` arguments).** I called them *changes an existing name*: the spec says the callee "works on the caller's place itself", so `c.hits` changes. The other reading, *neither* (a call writes nothing new), would not alter any verdict, but I think it is wrong for `@`.
5. **Shadowing.** The spec sentence "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." can be read as covering all shadowing or only `use` names. It makes no difference here: `c` in `bump` and `c` in `main` are in separate functions, not nested, and the program has no `use`.
6. **Missing key.** `counts["a"]` and `counts[w]` return `i64?`; I used `.default(0)`, the spec's "extract or fall back". Both readings agree that a missing key yields 0, and no key is missing in this run.

## confidence

- High (about 95%) that the file as written is refused, on lines 20 and 22, for the reasons quoted. These are the sentences a checker would most plainly apply.
- High (about 95%) that the two-edit program is accepted and prints `5`, `5`, `a`, given the arithmetic in the trace.
- Least sure of: the *new name* / *neither* split for the parameter on line 5, and whether the spec intends a shadowing rule wider than `use` names. Neither changes the verdict.
- I cannot run the checker, so "accepted" and "refused" are my reading of the spec, not compiler output.

## context

- Read in this directory: `brief.md`, `spec.md`, `main.hero`, `run.json` and `run.err`. The last two are in this directory and were empty. I read them because they were there, but I did not use them, and nothing in them affected this report.
- Outside this directory: nothing from my own reads. The session's system context reached me. It included the working directory and environment details, a scratchpad path, the model identity and date, and a git status snapshot listing `run.err` and `run.json` as untracked files. I did not use any of it in the analysis.
- No tool other than file reading and writing was used. Nothing was run.
