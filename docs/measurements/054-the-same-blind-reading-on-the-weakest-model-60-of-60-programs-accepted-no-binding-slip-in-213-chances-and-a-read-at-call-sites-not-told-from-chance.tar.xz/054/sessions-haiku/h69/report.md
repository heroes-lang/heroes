# Report

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    while i < items.len()
        if items[i].name == name
            items[i].qty @ items[i].qty + n
            return
        i @ i + 1
    items @ items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    while i < items.len()
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty @ items[i].qty - n
                return true
            return false
        i @ i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    took_apple = take(@items, "apple", 5)
    print(took_apple)
    took_pear = take(@items, "pear", 9)
    print(took_pear)
    total @= 0
    for item in items
        total @ total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4`. Apple goes 3, then 7, then takes 5 down to 2. Pear is 2, and taking 9 fails. The sum is 2 + 2 = 4.

## sentences

Line numbers refer to the program block above, counted from its first line (`record Item` is line 1).

1. Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line (2 to 3, 6 to 12, 15 to 23, 26 to 37).
2. Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()` (line 25).
3. Section 4: "Every top-level line starts with its kind." Governs `record` (line 1), `function restock` (line 5), `function take` (line 14), `function main` (line 25).
4. Section 4: "`Fields = INDENT { ident ":" Type NEWLINE } DEDENT .`" Governs the field lines `name: str` and `qty: i64` (lines 2 to 3).
5. Section 2: "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `0`, `1`, `2`, `3`, `4`, `5`, `9` and the `i64` parameter `n`.
6. Section 3: "No implicit conversions, widths included: `1 + 2.0` is an error." Governs the arithmetic and comparisons; every operand is `i64` (`items[i].qty`, `n`, `total`, `i`) or `str`.
7. Section 3 table: "`[T]` | dynamic array, indices from 0". Governs `items: [Item]` (lines 5, 14, 26) and `items[i]` (lines 8, 9, 17, 18, 19).
8. Section 3 table: "`bool` | `true` / `false`". Governs the `bool` return of `take` (line 14) and the `true` / `false` returns (lines 20, 21, 23).
9. Section 5: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs `i @= 0` (lines 6, 15), `i @ i + 1` (lines 11, 22), `items[i].qty @ ...` (lines 9, 19), `items @ items.push(...)` (line 12), `items: [Item] @= []` (line 26), `total @= 0` (line 34), `total @ ...` (line 36).
10. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." Governs every binding (`i`, `took_apple`, `took_pear`, `total`, `item`) and the `@` parameter `items` in `restock` and `take`, which are written at lines 9 and 12, and 19. See choice point 6 for `items` in `main`.
11. Section 5: "Signatures are always explicit; inference is local only." Governs the signatures (lines 5, 14, 25).
12. Section 5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs the names: the parameter `name` (lines 5, 8, 12) does not clash with the field `name` (a field is not a binding), and `item` and `items` are distinct.
13. Section 7: "`==` is structural equality on any two values of one type, recursively". Governs `items[i].name == name` (lines 8, 17).
14. Section 7: "`< <= > >=`: a number only" Governs `i < items.len()` (lines 7, 16) and `items[i].qty >= n` (line 18).
15. Section 8: "`if cond` / `else if` / `else` take only `bool`, and there is no truthiness." Governs the `if` conditions (lines 8, 17, 18). Each is a `bool` comparison.
16. Section 8: "`while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs `while` (lines 7, 16) and `for item in items` (line 35).
17. Section 8: "A statement after a jump, in its block, is a compile error." Governs `return` (line 10), `return true` (line 20), `return false` (line 21): each is the last statement in its block.
18. Section 8: "A function with a `->` must `return` on every path that reaches its end, and `exit(code:)`, `assert false` and a `while true` with no `break` of its own end a path." Governs `take`: the final `return false` (line 23) covers the path where the loop ends.
19. Section 9: "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `items.len()` (lines 7, 16) and `items.push(...)` (line 12).
20. Section 9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`". Governs `Item(name: name, qty: n)` (line 12).
21. Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`". Governs `@items: [Item]` in the signatures (lines 5, 14) and `@items` at the call sites (lines 27, 28, 29, 30, 32).
22. Section 9: "When two parameters in a signature share a type, named arguments are mandatory at the call site". Governs the calls to `restock` and `take`: `restock` has `str` and `i64` and `take` has `str` and `i64`, and no two parameters share a type, so positional arguments are allowed.
23. Section 10: "an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`." Governs `items: [Item] @= []` (line 26).
24. Section 10: "`xs @ xs.push(4)` grows in place when `xs` is a plain name" Governs `items @ items.push(Item(name: name, qty: n))` (line 12): `items` is a plain parameter name.
25. Section 10: "An out-of-bounds index or slice aborts". `items[i]` is read only inside `while i < items.len()` (lines 7 to 9, 16 to 19), so no out-of-bounds index occurs.
26. Section 11: "`print(...)` · `len` · `push`" and "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs `print(took_apple)` (line 31), `print(took_pear)` (line 33) and `print(total)` (line 37).
27. Section 11: "a `bool` prints `true` or `false`." Governs the first two output lines.
28. Section 1: "Syntax is ASCII-only". The program is ASCII.

## choice_points

1. **Index loop instead of `for` for the mutation in `restock` and `take`.** Chose: `i @= 0` with `while i < items.len()` and `items[i].qty @ ...` (lines 6 to 9, 15 to 19). The other choice, `for item in items`, cannot write an element in place, since `item` is an immutable binding. The program would have to rebuild the array instead. The output would be the same, but the program would be longer and need an extra array binding.
2. **Early `return` in `restock` when the name is found.** Chose: `return` at line 10. The other choice is a flag cell (`found @= false`) that is set and tested before the append at line 12. The output is identical; the flag version has more lines and an extra binding that must be used.
3. **Appending with `push`.** Chose: `items @ items.push(Item(name: name, qty: n))` (line 12), which section 10 says grows in place for a plain name. The other choice, `items[items.len()] @ Item(...)`, would index one past the end and abort.
4. **Positional arguments at the call sites.** Chose: `restock(@items, "apple", 3)`. The other choice is named arguments, `restock(@items, name: "apple", n: 3)`. Both are accepted; the named form is mandatory only when two parameters share a type, which they do not. The output is the same.
5. **Literal types.** Chose: the default `i64` for every literal and for `total` and `i` (section 2). The other choice is a narrower width. Section 3 forbids implicit conversion, and `qty` is `i64`, so any other width would produce a mixed-type error at lines 9, 19 and 36.
6. **Whether passing `items` as an `@` argument counts as re-binding the cell in `main`.** Section 5 says a cell nothing re-binds is a compile error, and `main` never writes `items @ ...` directly; it only passes `items` as `@items`. Chose: leave `items` as written, reading section 5's "an `@` argument counting" as making the `@` argument count as a use and a write of the cell. The other reading makes the checker reject `items: [Item] @= []` in `main` with a "cell nothing re-binds" error. The brief's signatures leave no way to satisfy that reading without changing the program's structure.
7. **Type of `items.len()`.** The spec never gives the return type of `len`. Chose: `i64`, so `i < items.len()` compares two `i64` values, as section 7 requires for operands of one type. The other choice, an unsigned result, makes lines 7 and 16 a mixed-type comparison that the checker rejects. The default for an unannotated integer is `i64` (section 2).
8. **Temporary binding for each `take` result.** Chose: `took_apple = take(...)` and then `print(took_apple)`. The other choice, `print(take(@items, "apple", 5))`, should also be accepted. The temporary keeps the `@` argument out of `print`'s argument list.
9. **Loop variable name `item`.** Chose `item`. The spec does not reserve `it`, so `it` would also work.
10. **Two `return false` statements in `take`.** Chose: one inside the name-matched branch (quantity too low, line 21) and one after the loop (no such name, line 23). The other choice is one `return false` after the loop plus a flag. Both give the same result. The chosen form satisfies section 8's rule that every path reaching the end returns.

## confidence

Roughly 75 percent that the checker accepts the program on the first try.

Least sure line: line 7 and line 16, `while i < items.len()`. The spec does not state the return type of `len` (choice point 7). If it is not `i64`, both lines are rejected. The next least sure is line 26, `items: [Item] @= []`, which depends on the reading in choice point 6.

The rest follows the spec's explicit rules for records, `@` parameters, `while` loops, `push`, and `print` with `bool` values. I am fairly sure of those.

## context

Nothing other than the files in this directory reached my context. I read `brief.md` and `spec.md` in this directory, and I read `run.json` and `run.err`, which are both empty. I used no tool beyond reading and writing files here, and I read no other file. One side effect: while checking the file I accidentally created `report.md.tmp` in this directory. It is empty and was not part of the brief. I have no tool to delete it, so it needs to be removed by hand.
