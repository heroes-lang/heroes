# Report: main.hero

## verdict

Refused. Two lines are refused:

- **Line 20** `step = 2`. `step` was bound on line 10 with `:=`, which binds once, forever. Only a `@=` cell can be re-bound with `=`.
- **Line 22** `last @= words[0]`. `last` is a `@=` cell, and nothing ever re-binds it. A cell nothing re-binds is a compile error.

Smallest change that is accepted and still means what it evidently means (a counter that ends at 5, then prints the first word):

- Line 10: `step := 1` becomes `step @= 1`.
- Line 22: `last @= words[0]` becomes `last := words[0]`.

The submitted program prints:

```
5
5
a
```

Trace: the loop over `["a", "b", "a", "c", "a"]` with `step` = 1 gives `counts["a"] = 3` and `total = 5`. `bump(@c, 3)` sets `c.hits` to 3. Then `step` = 2, and `bump(@c, 2)` sets `c.hits` to 5. `last` is `"a"`.

Lines 1 to 19 and 21 to 25 are accepted by the checker as far as I can tell, apart from the two refusals above. Line 21 `bump(@c, step)` is accepted once `step` is a cell.

## lines

Every line of `main.hero` that holds `=` or `@` (13 lines).

| line | classification | words of the specification relied on |
|---|---|---|
| 5 `function bump(@c: Counter, by: i64)` | *new name* (parameter `c`) | §9: "Mutable parameters are marked `@` in the signature and at the call site:". §5 treats a parameter as a name (`_` "names anything you do not use: ... a parameter"). |
| 6 `c.hits = c.hits + by` | *changes an existing name* (field `hits` of the cell `c`) | §5: "`=` re-binds it, or a field or element inside one." The write is legal through an `@` parameter: "a write is not [a use], except through an `@` parameter." |
| 9 `words := [...]` | *new name* | §5: "`:=` binds once, forever." |
| 10 `step := 1` | *new name* | §5: "`:=` binds once, forever." This is the line that makes line 20 refused. |
| 11 `counts: {str: i64} @= {}` | *new name* | §5: "`@=` declares a mutable cell". The annotation is required: §10 "an empty one needs an annotation". |
| 12 `total @= 0` | *new name* | §5: "`@=` declares a mutable cell". |
| 15 `counts[w] = counts[w].default(0) + step` | *changes an existing name* (element of the cell `counts`) | §5: "`=` re-binds it, or a field or element inside one." §10: "`m[k] = v` inserts or replaces;" |
| 16 `total = total + step` | *changes an existing name* (cell `total`) | §5: "`@=` declares a mutable cell, and `=` re-binds it". |
| 18 `c @= Counter(label: "a", hits: 0)` | *new name* | §5: "`@=` declares a mutable cell". §9: "Record construction is a call with field names, always mandatory:". |
| 19 `bump(@c, counts["a"].default(0))` | *neither* | §9: "Mutable parameters are marked `@` ... at the call site". "Either way the callee works on the caller's place itself". The line does not bind a name, and it contains no write of its own. The write happens on line 6. |
| 20 `step = 2` | *changes an existing name* in intent, but refused: `step` is a `:=` name | §5: "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it". On this line alone the `=` cannot be checked against its declaration; the refusal comes from line 10. |
| 21 `bump(@c, step)` | *neither* | Same reading as line 19. `step` is passed by value (no `@`). |
| 22 `last @= words[0]` | *new name*, refused: a cell nothing re-binds | §5: "`@=` declares a mutable cell". §5: "and so is a cell nothing re-binds". |

## sentences

Quoted from `spec.md`, the sentences the verdict rests on:

1. §5: "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
2. §5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
3. §9: "Mutable parameters are marked `@` in the signature and at the call site:"
4. §9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
5. §10: "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"
6. §10: "and an empty one needs an annotation"
7. §2: "A literal takes the type its context asks for [...] otherwise `i64`."
8. §7: "(both sides one numeric type ... never mixed)"
9. §9: "Record construction is a call with field names, always mandatory:"
10. §11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
11. §6 table: "`.default(v)` | extract or fall back"
12. §1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."
13. §3 table: "`()` | nothing: what a function with no `->` returns"

Sentences 1 and 2 decide the two refusals. Sentence 2 also makes line 22 an error by itself. Sentences 3 and 4 let line 6 write through `c` and make line 19 and 21 legal. Sentences 5, 7, 8, 9, 10 and 11 decide that the rest is well-typed and that the output is as stated. Sentence 12 confirms the indentation.

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a`, one per line.

## choice_points

1. **How to make `step` re-bindable (line 10 versus line 20).** I chose `step @= 1` on line 10, which keeps line 20 as written. The other choice is to delete line 20 and write `bump(@c, 2)` on line 21. That is also accepted and prints the same output, but it changes the program's text and drops the `step = 2` the author wrote.
2. **How to make `last` accepted (line 22).** I chose `last := words[0]`, which is the smallest edit and means the same thing. The other choice is to keep `@=` and add a re-binding such as `last = words[0]` later in `main`. That is also accepted, prints the same output, and adds code the program does not need.
3. **Whether passing a cell as an `@` argument counts as re-binding it.** The phrase "an `@` argument counting" in §5 I read as: an `@` argument counts as a write to the cell. That makes `c` (line 18) legal, since `bump(@c, ...)` writes it. The other reading treats the `@` argument as only a use. Then `c` is a cell nothing re-binds, and line 18 is refused too. I could not find a smaller fix under that reading that keeps `bump` as written.
4. **Whether `@` on a call line is a change or neither (lines 19 and 21).** I classified these as *neither*, because the line itself binds nothing and writes nothing. The write happens inside `bump`, on line 6. A reader who counts the caller's `c` as changed by the call would mark these as *changes an existing name*. The verdict does not depend on this choice.
5. **Whether an unread record field is an error (`label`).** §5 makes unused bindings and parameters errors. It says nothing about record fields, and `label` is set on line 18 and never read. I took it as accepted. If the checker rejects unread fields, the fix would be to read `label` somewhere or drop it, and the printed output would not change.
6. **Type of `total`, `step`, and the literals.** No type was written, so `i64` applies (§2: "otherwise `i64`"). This is forced by the text, not a choice, but it is where the output's integer width comes from.

## confidence

- **High** that line 20 is refused. Sentence 1 is explicit that `:=` binds once and only a cell is re-bound with `=`, and line 10 is a `:=`.
- **High** that line 22 is refused. Sentence 2 names "a cell nothing re-binds" as a compile error, and nothing in `main` re-binds `last`.
- **High** that the rest is accepted, with two caveats: choice point 3 (the `@` argument reading) and choice point 5 (unread fields).
- **High** that the printed output of the submitted program is `5`, `5`, `a`. The trace is short and every operation is an `i64` add or a map read with a default.
- **Least sure of**: the classification of lines 19 and 21 as *neither* (choice point 4), and the reading of "an `@` argument counting" (choice point 3). Those are the two places where the spec's wording is open to more than one reading.

## context

Only the two files in this directory were read: `brief.md` and `spec.md`, then `main.hero`. I did not open `run.err`, `run.json`, or any file outside this directory. No other tool was used besides reading and writing files here.

Session metadata came with the conversation, including the working directory, the date, the model name, a user email, and a git status listing `run.err` and `run.json` as untracked. None of it was used in the verdict or the output. The git status is a snapshot, and I did not check it against the files.
