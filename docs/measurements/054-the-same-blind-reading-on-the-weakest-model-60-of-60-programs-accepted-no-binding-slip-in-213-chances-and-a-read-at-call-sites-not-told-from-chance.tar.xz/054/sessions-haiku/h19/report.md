## verdict

Refused, on two lines:

- **Line 20** (`step @ 2`): `step` was bound with `=` on line 10, and `=` binds once. Only a mutable cell can be re-bound with `@`.
- **Line 22** (`last @= words[0]`): `last` is a mutable cell that nothing re-binds. A cell nothing re-binds is a compile error.

Smallest change that keeps the evident meaning:

- Line 10: `step = 1` becomes `step @= 1`, so that line 20 re-binds a cell.
- Line 22: `last @= words[0]` becomes `last = words[0]`, since `last` is never meant to change.

The corrected program prints:

```
5
5
a
```

Trace: the loop sets `counts` to `a`=3, `b`=1, `c`=1 and `total` to 5. `bump(@c, 3)` makes `c.hits` 3. `step` becomes 2, and `bump(@c, 2)` makes `c.hits` 5. `last` is `"a"`.

## lines

| Line | Kind | Words of the specification relied on |
|---|---|---|
| 5 `function bump(@c: Counter, by: i64)` | *new name* (parameter `c`) | "Param = "@" ident ":" Type"; "Mutable parameters are marked `@` in the signature" |
| 6 `c.hits @ c.hits + by` | *changes an existing name* (field of `c`) | "`@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." |
| 9 `words = [...]` | *new name* | "`x = 5` ... # immutable binding, type inferred"; "`=` binds once, forever." |
| 10 `step = 1` | *new name* | same as line 9 |
| 11 `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell"; "an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`" |
| 12 `total @= 0` | *new name* | "`@=` declares a mutable cell" |
| 15 `counts[w] @ counts[w].default(0) + step` | *changes an existing name* (element of `counts`) | "`@` re-binds it, or a field or element inside one."; "`m[k] @ v` inserts or replaces" |
| 16 `total @ total + step` | *changes an existing name* | "`@` re-binds it" |
| 18 `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell"; "Record construction is a call with field names" |
| 19 `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, through the call) | "Mutable parameters are marked `@` ... at the call site"; "the callee works on the caller's place itself" |
| 20 `step @ 2` | *changes an existing name*, but refused | "`=` binds once, forever."; "`@` re-binds it" (applies only to a `@=` cell) |
| 21 `bump(@c, step)` | *changes an existing name* (`c`, through the call) | same as line 19 |
| 22 `last @= words[0]` | *new name*, but refused (a cell nothing re-binds) | "`@=` declares a mutable cell"; "and so is a cell nothing re-binds" |

## sentences

Quoted from `spec.md`:

- §1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing."
- §2: "A literal takes the type its context asks for ... otherwise `i64`."
- §4 grammar: "Param    = "@" ident ":" Type | ident ":" Type [ "lent" ] ."
- §5: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
- §5: "Signatures are always explicit; inference is local only."
- §5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- §5 example comment: "x = 5 ... # immutable binding, type inferred"
- §6 table: "`.default(v)` | extract or fall back"
- §7: "arithmetic   + - * / %" with the requirement "both sides one numeric type"
- §9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` ... `advance(@l)`"
- §9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- §9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`"
- §8: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)."
- §10: "`m[k] @ v` inserts or replaces;"
- §10: "`m[k]` is a `V?` with code `missing_key`"
- §11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a`, one per line.

## choice_points

1. **Fixing line 20.** I made `step` a cell (line 10 becomes `step @= 1`). The other choice is to keep `step = 1` and delete line 20. The program then passes 1 on line 21, so it prints `4`, `5`, `a`. I chose the cell because line 20 shows the author meant `step` to change.
2. **Fixing line 22.** I made `last` immutable (`last = words[0]`). Keeping `@=` requires adding a re-binding line that the author never wrote, which would invent behaviour. The output is `5`, `5`, `a`.
3. **Classifying line 5** (`@c` in a signature). I called it *new name*, since the parameter `c` comes into scope in `bump`. The other reading is *neither*, treating the `@` as a mark and not a binding. This does not affect the verdict.
4. **Classifying the call-site `@c` on lines 19 and 21.** I called them *changes an existing name*, because `bump` writes the caller's `c`. The other reading is *neither*, treating the `@` as argument syntax. This does not affect the verdict.
5. **The record field `label`.** It is set on line 18 and never read. The specification speaks of unused bindings and parameters but says nothing about unused fields. I treated it as accepted. If unused fields were an error, the refusal would fall on line 2, which has no `=` or `@`. I did not change it.
6. **Literal types.** `step`, `total`, `hits` and the map values are `i64` by the default in §2. Nothing in the program needed another type, so this choice is fixed by the specification.

## confidence

- **High** that lines 20 and 22 are refused. Both follow from explicit sentences in §5, and I checked the rest of the program against the same rules without finding another refusal.
- **High** on the output `5`, `5`, `a` for the corrected program. It follows from §2, §7, §9, §10 and §11 and a hand trace.
- **Least sure** of two things. First, whether an unused record field is accepted, since the specification is silent (choice 5). Second, the classification of lines 5, 19 and 21, where the brief's three categories fit the `@` marks awkwardly (choices 3 and 4).

## context

Nothing beyond this directory's files was read. I read `brief.md`, `spec.md` and `main.hero` in this directory, and wrote `report.md` here. I did not open any other file.

The session's environment header and a git status snapshot were present in my context. The snapshot lists two untracked files, `run.err` and `run.json`, which I did not open and which play no part in this answer. I used no tool other than reading and writing files here.
