# report

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            if items[i].qty < n
                return false
            items[i].qty = items[i].qty - n
            return true
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    print(take(@items, "apple", 5))
    print(take(@items, "pear", 9))
    total @= 0
    for entry in items
        total = total + entry.qty
    print(total)
```

Expected output: `true`, `false`, `4` (apple 7 minus 5 leaves 2; pear 2 stays; sum 4), one per line.

## sentences

Line numbers refer to the program above (the fenced block, first line `record Item` is line 1).

1. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs lines 8, 10, 17, 22, 28, 30 (`items[i].qty = ...`, `items = items.push(...)`, `total = ...`, and the cell declarations).
2. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`". Governs lines 5, 12 (the `@items` parameters) and 23 to 27 (the `@items` arguments).
3. "a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." Governs line 22 (`items` is re-bound/written through `@items` arguments on lines 23 to 27), line 28 (`total` re-bound on line 30), and lines 5 and 12 (`@items` is written on lines 8, 10, 17).
4. "An unused binding or parameter is a compile error" and "`_` names anything you do not use". Governs lines 5, 12 (`name` and `n` are read on lines 7, 8, 10, 14, 15, 17, 18) and line 29 (`entry` is read on line 30). No `_` is needed because nothing is unused.
5. "`:=` binds once, forever." Governs the loop variables `i` (lines 6, 13) and `entry` (line 29), which are never re-bound; line 29 therefore reads `entry.qty` and does not assign to it.
6. "`xs: [i64] := []` · `m: {str: i64} @= {}`" (an empty container needs an annotation). Governs line 22: `items: [Item] @= []`.
7. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `items.len()` on lines 6 and 13.
8. "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs line 10, `items = items.push(...)`. `items` is a plain name (the `@` parameter), so it grows in place.
9. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`". Governs line 10, `Item(name: name, qty: n)`.
10. "`range(from: a, to: b) -> [i64]` exclude `to`." Governs lines 6 and 13: indices 0 to len-1, and `items.len()` is never out of bounds.
11. "When two parameters in a signature share a type, named arguments are mandatory at the call site". Governs lines 6 and 13: `range` has two `i64` parameters, so `from:` and `to:` are written. (The signatures of `restock` and `take` have `str`, `i64` parameters, so no named argument is required at their call sites on lines 23 to 27.)
12. "`for x in xs`, over an array or a `range` (section 11)." Governs lines 6, 13 (over `range`) and 29 (over the array `items`).
13. "`if cond` / `else if` / `else` take only `bool` — there is no truthiness." Governs lines 7, 14, 15: each condition is a `bool` comparison.
14. "`<` `<=` `>` `>=`: a number only" and "`==` is structural equality on any two values of one type". Governs line 15 (`<` on `i64`) and lines 7, 14 (`==` on `str`).
15. "A function with a `->` must `return` on every path that reaches its end". Governs `take` (lines 12 to 19): the path through the loop reaches `return false` on line 19.
16. "A statement after a jump, in its block, is a compile error." Governs lines 9, 16, 18: each `return` is the last statement of its own block, and the statements after them (lines 10, 17, 19) sit in the enclosing block.
17. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 26, 27 (`bool`) and 31 (`i64`).
18. "A literal takes the type its context asks for … otherwise `i64`." Governs lines 22, 23 to 25, 28 (`0`, `3`, `2`, `4`, `5`, `9`, `0`): all `i64`, matching `qty: i64` and `n: i64`.
19. "Syntax is ASCII-only" and "exactly 4 spaces per level; a tab is a compile error." Governs every indented line (the program uses only spaces).
20. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 21.
21. "Declaration order never matters but a group's." Governs the placement of `record Item` before its use on lines 5 and 12.
22. "Shadowing is a compile error" (section 5). Governs all names: `items`, `name`, `n`, `i`, `total`, `entry` are not reused in one scope, and no local shares a name with a top-level function (`restock`, `take`, `main`) or with `Item`.
23. "Overflow aborts at every width." Governs lines 8, 17, 30: no value approaches `i64` limits, so no abort.
24. "An out-of-bounds index or slice aborts" (section 10). Governs lines 7, 8, 14, 15, 17: each index `i` runs over `0 .. items.len()-1`.

## choice_points

1. **Index loop versus `for entry in items` for the update in `restock` and `take`.** I chose `for i in range(...)` with `items[i].qty = ...` (lines 6 to 8, 13 to 17). The other choice, `for entry in items` with `entry.qty = ...`, produces a compile error, because `entry` is an immutable `:=`-style binding and `=` may only re-bind a cell or a field inside one. The `for entry` form is only correct for read-only loops such as the sum on line 29.
2. **Appending with `items = items.push(...)` (line 10) versus a bare `items.push(...)`.** I chose the re-binding form. A bare `items.push(...)` computes a `[Item]` value that is never used, which is a compile error under the rule that a line computing a value must use it. The other choice, `push` as a free call such as `push(items, ...)`, is the same built-in, but I kept the form the spec's own example uses (`xs = xs.push(4)`).
3. **Early exit from the loop in `restock` (`return` on line 9) versus a `found` cell.** I chose `return` inside the loop, which leaves `restock` with no value and avoids a flag. The other choice, a `found @= false` cell, would produce the same items but needs one more cell and one more `if` at the end.
4. **Bool-result `take` printed directly (lines 26, 27) versus bound to a name first.** I chose `print(take(...))`. The other choice, `ok := take(...)` followed by `print(ok)`, produces identical output. Either way the value is used.
5. **Sum by a `total @= 0` cell and a `for` loop (lines 28 to 31) versus a built-in `fold`.** I chose the loop, because `fold` takes a named function and the spec has no anonymous functions, so a `fold` would need a separate top-level helper. The other choice produces the same output (`4`).
6. **Integer type of the `total` cell.** I left it to inference (`total @= 0`), so it is `i64` because the literal defaults to `i64` and `entry.qty` is `i64`. The other choice, a typed `u8` or `i32` cell, would produce a compile error on `total + entry.qty` (no mixing of widths), or a different result type for `print`, so I kept `i64`.
7. **Range bounds via `items.len()` evaluated in the `for` header.** I chose `items.len()` (UFCS form). The other choice, `len(items)`, is the same call. Both are evaluated once before the loop, which is safe because the loop does not change the length in `take` and `restock` exits before a push.
8. **Empty list annotation `items: [Item] @= []` (line 22) versus `items @= []` with the type on the empty literal.** I chose the explicit annotation, which the spec requires for empty containers. The other choice produces a "no type context" error.
9. **Comments.** I wrote no comments. The other choice (adding `#` comments above the declarations) is allowed, and would not change what the checker accepts.

## confidence

About 85% that the checker accepts the program as written on the first try.

Least certain line: **line 10, `items = items.push(Item(name: name, qty: n))`**. The spec says `xs = xs.push(4)` grows in place when `xs` is a plain name, but `items` here is an `@` parameter rather than a local cell, and I am reading "`=` re-binds it" as covering re-binding of an `@` parameter. If the checker refuses a re-binding of an `@` parameter, the fix is to write the `restock` body without the re-bind, which the spec does not offer directly, so this is the main risk.

Second least certain: **line 22, `items: [Item] @= []`**, and the fact that `items` is only ever written through `@items` arguments (lines 23 to 27). I read "an `@` argument counting" as counting as a write to the cell, which satisfies "a cell nothing re-binds". If the checker does not count it, line 22 would be an unused-cell error.

Lines 8, 17, 30 and the loop headers on lines 6, 13 are well covered by the spec text and are the least risky.

## context

Only the two files in this directory reached my context: `brief.md` and `spec.md`, both read in full. I did not read `run.err` or `run.json`, which appear as untracked in the git snapshot shown with the session. Session metadata (the working directory, platform, and the git status snapshot) also reached my context, but it contained no language material. I did not search for or open any file outside this directory, and I ran no tools besides reading and writing files here.
