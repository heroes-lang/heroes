## program

```heroes
function sorted_desc(xs: [i64]) -> [i64]
    ys: [i64] @= xs
    n $= len(xs)
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if ys[j] < ys[j + 1]
                t $= ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
    return ys

function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    for i in range(from: 1, to: len(xs))
        if xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    xs: [i64] $= [3, 1, 4, 1, 5, 9, 2, 6]
    result $= sorted_desc(xs)
    for v in result
        print(v)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers used below count from the top of this block (line 1 is `function sorted_desc`, line 26 is the last `print`).

## sentences

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 21 to 26: `main` has no `->` and no return.
2. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every line; all indentation is 4-space multiples.
3. "No braces, no semicolons; a condition needs no parentheses." Governs the conditions on lines 6, 13 and 17, and the loop headers on lines 4, 5 and 16.
4. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs the order of the three functions (lines 1, 12, 21); `main` calls the two above it, but the order is not relied on.
5. "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs line 2 (`ys @=`), line 3 and 7 (`$=`), lines 8 and 9 (`ys[j] =`, `ys[j + 1] =`), line 15 (`count @=`), line 18 (`count =`), and lines 22 and 23 (`$=`).
6. "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." Governs line 2: `ys` is a copy of `xs`, so the sorting in lines 4 to 9 does not change the caller's array.
7. "All bindings are initialised." Governs lines 2, 3, 7, 15, 22 and 23: each binding has its value on the same line.
8. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), ..." Governs line 2 (`ys` is re-bound on lines 8 and 9), line 15 (`count` is re-bound on line 18), and the parameter `xs` on lines 1 and 12 (both read). Lines 3, 7, 22 and 23 are also used.
9. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs the loop variables `i` (lines 4, 16), `j` (line 5) and `v` (line 24): each name is bound once in its function, and `i` is reused only in separate functions.
10. "A literal takes the type its context asks for ... otherwise `i64`." Governs the literals `0` and `1` (lines 14, 15, 16), `1`, `2` and `3` in the list (line 22 and line 26); with no other context they are `i64`, which matches the signatures.
11. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs the loops on lines 4, 5, 16 and 24.
12. "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs the bounds on lines 4, 5 and 16. Line 4 gives indices 0 to n-1, and line 5 gives j from 0 to n-2-i, so `j + 1` never passes `n - 1`. Line 16 gives 1 to len-1.
13. "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs the `range` calls on lines 4, 5 and 16, whose `from` and `to` are both `i64`; the names are written in each.
14. "`[T]` | dynamic array, indices from 0" Governs the array parameters on lines 1, 12, 21, and the index expressions on lines 6, 7, 8, 9 and 17.
15. "An out-of-bounds index or slice aborts, and so does a slice that splits a character." Governs the index expressions on lines 6 to 9 and 17. All indices lie in range by the bounds in sentence 12.
16. "`if cond` / `else if` / `else` take only `bool`" Governs the `if` conditions on lines 6, 13 and 17: each is a comparison, so each is `bool`.
17. "`< <= > >=`: a number only" (from the operator table) Governs the `<` on line 6. The `==` on lines 13 and 17 and the `!=` on line 17 are the same kind of comparison on `i64`.
18. "A function with a `->` must `return` on every path that reaches its end" Governs `sorted_desc` (line 10 returns `ys`) and `runs` (line 14 returns 0 on the empty path, line 19 returns `count`).
19. "Built-ins: `print(...)` · `len` · `push` ..." Governs `len` on lines 3, 13 and 16, and `print` on lines 25 and 26.
20. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 25 and 26: each prints one `i64`, so each output is one number on its own line.
21. "`Arg = [ ident \":\" ] [ \"@\" ] Expression .`" (section 9 grammar) Governs the positional calls `sorted_desc(xs)` on line 23, `runs([...])` on line 26, and `len(xs)` on lines 3, 13 and 16, which pass arguments without names. Named arguments appear only where sentence 13 requires them.
22. "Binding = [ \":\" Type ] ( \"$=\" | \"@=\" ) Expression NEWLINE ." (section 5 grammar) Governs the annotated bindings on lines 2 and 22 and the unannotated ones on lines 3, 7, 15, 23.

## choice_points

1. **Where the sorted result lives.** I copy `xs` into a mutable cell `ys` and sort that. The alternative is to take `xs` as `@xs`, which would change the signature the brief fixes and would alter the caller's array. Another alternative is building a new array with `push`; the brief asks for adjacent swaps, so that was not used.
2. **Algorithm.** Bubble sort with adjacent swaps, as the brief asks. A selection sort would also produce the same output, but it does not use the adjacent swap the brief describes.
3. **Inner loop bound.** `n - 1 - i` with an exclusive `to`. The alternative, an inclusive bound `n - 1 - i` written as `to: n - i`, would reach `ys[j + 1]` at index `n`, which aborts. Another alternative is `while` loops; I used `for` over `range` because that is the form the spec gives.
4. **Descending order.** A swap happens when `ys[j] < ys[j + 1]`, which moves the larger value left. The alternative `ys[j] > ys[j + 1]` produces ascending order.
5. **Named arguments on `range`.** I wrote `from:` and `to:`. The spec makes them mandatory here, so the alternative (positional) would be refused.
6. **`len(xs)` versus `xs.len()`.** I used the function form. The spec says `x.f(y)` is sugar for `f(x, y)`, so the two give the same value; the function form was chosen to avoid relying on method-call sugar.
7. **Empty input in `runs`.** I guard with `if len(xs) == 0` and return 0. The alternative is to rely on `range(from: 1, to: 0)` being empty; the spec does not say what a reversed range does, so I did not rely on it. The guard also keeps the loop from running at all for empty input.
8. **Counting method in `runs`.** `count` starts at 1 for a non-empty array and goes up by one at each change between neighbours. The alternative counts equal neighbours and adds one; the result is the same, but it needs an extra branch for the case of length 1.
9. **Annotation on `xs` in `main`.** I wrote `xs: [i64] $= [...]`. The alternative `xs $= [...]` gives the same type because the literals default to `i64`; the annotation makes the type explicit, as the spec's style does.
10. **Printing.** One `print` call per element, as the brief asks. The alternative `print(join(...))` would need text conversion of each element and would print one line, not one per element.
11. **Declaration order.** `sorted_desc` and `runs` come before `main`. Any order is accepted, so the alternative has no effect.
12. **Temporary for the swap.** I used a named binding `t` in the `if` block. The spec has no tuple swap, so the alternative is a different three-line form, which I did not use.

## confidence

I am about 85 percent sure the checker accepts this program on the first try.

The line I am least sure of is line 6 (`if ys[j] < ys[j + 1]`), with line 17 (`if xs[i] != xs[i - 1]`) about the same. Both assume that indexing a `[T]` yields a plain `T`. The spec states that `m[k]` is a `V?` and that `s[i]` is a `u8`, and that an out-of-bounds index aborts, which implies a plain element. It does not state the array case in a sentence of its own, so this is an inference from the rules rather than a quoted rule. If array indexing were optional, both comparisons would be refused.

A smaller doubt sits on line 5 (`for j in range(from: 0, to: n - 1 - i)`). The spec says `range` takes `from` and `to` and excludes `to`, which covers it, but it does not say whether `range` may be called with the arguments as named expressions of this form. I think it does.

## context

Only these files and sources reached my context:

- `brief.md` and `spec.md` in this directory. I read both in full.
- `run.json` and `run.err` in this directory. Both were read and reported empty, so they gave me nothing.
- The harness's environment block for this session (the working-directory path, platform, shell, date, and model details). This is not a file in this directory, but it did reach my context.
- A git status snapshot listing `run.err` and `run.json` as untracked, plus a user account note. These came from the harness, not from a file in the directory. I did not use either of them in the program or the report.

I read no file outside this directory and used no tool other than reading and writing files here.
