## verdict

Refused, on lines 20 and 22 of `main.hero`.

- **Line 20** `step = 2` re-binds `step`, which line 10 bound with `$=`. A `$=` name binds once, forever, so `=` on it is a compile error.
- **Line 22** `last @= words[0]` declares a mutable cell that nothing re-binds (`last` is only read, on line 25). A cell nothing re-binds is a compile error.

Every other line passes the checks I could make from the specification.

Smallest change that is accepted (two lines, both needed):

- Line 10: `step $= 1` becomes `step @= 1`, so `step = 2` on line 20 is a re-binding of a cell.
- Line 22: `last @= words[0]` becomes `last $= words[0]`, an immutable binding that nothing needs to re-bind.

The accepted program prints:

```
5
5
a
```

Trace: `counts` ends with a=3, b=1, c=1, and `total` ends at 5. The first `bump` adds `counts["a"]` = 3 to `c.hits`. `step` is then 2, so the second `bump` adds 2, giving `c.hits` = 5. `last` is "a".

## lines

| line | source | class | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (parameter `c`) | "Param = "@" ident ":" Type" (section 4); "Mutable parameters are marked `@` in the signature" (section 9) |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (field of `c`) | "`=` re-binds it, or a field or element inside one" (section 5); "Simple = Place "=" Expression NEWLINE" (section 5) |
| 9 | `words $= [...]` | *new name* | "`$=` binds once, forever" (section 5); "x $= 5 # immutable binding, type inferred" (section 5) |
| 10 | `step $= 1` | *new name* | same as line 9 |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell" (section 5); "m: {str: i64} @= {}" (section 10) |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell, type inferred too" (section 5) |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (element of `counts`) | "`=` re-binds it, or a field or element inside one" (section 5); "`m[k] = v` inserts or replaces" (section 10) |
| 16 | `total = total + step` | *changes an existing name* | "`=` re-binds it" (section 5); "v = v + 1 # re-binding" (section 5) |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell" (section 5); "Record construction is a call with field names" (section 9) |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, through the `@` argument) | "an `@` argument counting" (section 5); "the callee works on the caller's place itself" (section 9); "Mutable parameters are marked `@` ... at the call site" (section 9) |
| 20 | `step = 2` | *changes an existing name*, and **refused** (`step` is `$=`) | "`$=` binds once, forever." and "`=` re-binds it" (section 5) |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, through the `@` argument) | same as line 19 |
| 22 | `last @= words[0]` | *new name*, and **refused** (cell nothing re-binds) | "`@=` declares a mutable cell" (section 5); "a cell nothing re-binds" (section 5) |

## sentences

Quoted from `spec.md`, each one the verdict or a line class rests on:

1. Section 5: "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
2. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
3. Section 5 (code): "v @= 0             # mutable cell, type inferred too" and "v = v + 1          # re-binding".
4. Section 5: "Signatures are always explicit; inference is local only."
5. Section 5 grammar: "Simple    = ... | Place "=" Expression NEWLINE ..." and "Place     = ident { "." ident | "[" Expression "]" } ."
6. Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`;"
7. Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
8. Section 9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`, and a variant's case `.num(v: 7)` or `.plus`."
9. Section 10: "`m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces;"
10. Section 6 table: "`.default(v)` | extract or fall back"
11. Section 2: "A literal takes the type its context asks for — `b: u8 $= 255`, and `b + 1` is a `u8` — otherwise `i64`."
12. Section 7: "arithmetic   + - * / %          (both sides one numeric type — never mixed)"
13. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

Sentences 1 and 2 carry the verdict. Sentence 2 also keeps `c` and `counts` alive: `c` is written by the `@` arguments on lines 19 and 21, and `counts` by the element writes on line 15.

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a`, one per line.

## choice_points

1. **How to fix line 20.** I made `step` a cell (`step @= 1`), which keeps the evident meaning (the step changes to 2 before the second `bump`). The other choice, an immutable `step2 $= 2` with `bump(@c, step2)`, also prints `5 5 a`, but it changes more text and is less close to the author's intent.
2. **How to fix line 22.** I made `last` immutable (`last $= words[0]`), because nothing re-binds it. The other choice, keeping `@=` and adding a re-binding, has no evident purpose in the program. Removing the `@` leaves the output unchanged.
3. **Record fields as bindings.** I did not treat `label` (line 2) as an unused binding, because the specification's "unused binding or parameter" rule does not name fields. If fields counted, line 2 would be refused too, since `label` is never read. The smallest fix would then be to read it or drop it, and the printed output would not change.
4. **Classifying `@` argument lines (19, 21).** I classed them as *changes an existing name*, because the specification says an `@` argument counts (sentence 2) and the callee works on the caller's place (sentence 7). The other choice, *neither*, would treat the mark as a mere reference. I think the first is the right reading, since an `@` parameter nothing writes is refused.
5. **Classifying the parameter line (5).** I classed `c` as a *new name*. The other choice, *neither*, would treat the parameter as a signature rather than a binding. Either way the verdict is unchanged.
6. **Element writes (line 15).** I classed `counts[w] = ...` as *changes an existing name*, reading "a field or element inside one" as covering a map element. The other choice would be to treat it as a new key rather than a change, which the specification does not support: `m[k] = v` "inserts or replaces" the same place.

## confidence

- **High** that lines 20 and 22 are refused. Both rest on sentences 1 and 2 with no ambiguity I can find.
- **High** that the fixed program is accepted, given the two fixes and the checks I walked through.
- **High** on the printed output `5 5 a`. I traced it by hand; `print` format is from section 11.
- **Lower** on choice 3 (record fields) and on the classification of the `@`-argument lines 19 and 21. Those depend on how the checker reads sections 5 and 9, which the specification states only in passing.
- I could not run the checker, so all of this is a reading of the specification.

## context

Beyond the directory's files, the following reached my context:

- The system-supplied environment block (platform, shell, date, model name, and the scratchpad path).
- A git status snapshot describing the wider repository (branch `main`, untracked `run.err` and `run.json`, one recent commit), and the user's account email. I did not use the email, and I did not read anything in the repository outside this directory.

Files I read, all inside this directory: `brief.md`, `spec.md`, `main.hero`, and `run.json` and `run.err`. The last two are empty, so they contributed nothing. I ran no tools other than reading and writing files here.
