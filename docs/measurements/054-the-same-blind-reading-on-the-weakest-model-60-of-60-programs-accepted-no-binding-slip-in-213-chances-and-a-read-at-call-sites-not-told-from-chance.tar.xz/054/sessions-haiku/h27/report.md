## verdict

Refused. Two lines are refused:

- **Line 20**, `step @ 2`: `step` was bound on line 10 with `=`, which "binds once, forever". The `@` re-binding form needs a cell, and `step` is not one.
- **Line 22**, `last @= words[0]`: `last` is declared as a mutable cell but nothing re-binds it. The spec makes "a cell nothing re-binds" a compile error. The later read on line 25 does not count as a re-binding.

Every other line is accepted by my reading. Line 6 and line 19 are fine because `c` is an `@` parameter that is written, and an `@` argument counts as a use.

Smallest change that is accepted and keeps the evident meaning (`step` grows to 2 before the second `bump`, `last` is the first word):

- line 10: `step = 1` becomes `step @= 1`
- line 22: `last @= words[0]` becomes `last = words[0]`

The fixed program prints:

```
5
5
a
```

(`c.hits` is 3 after the first `bump` and 5 after the second; `total` is 5; `last` is `"a"`.)

## lines

| line | classification | words of the specification relied on |
|---|---|---|
| 5 | *new name* | `Param = "@" ident ":" Type`: the `@` parameter `c` is a binding of `bump`. Section 9: "Mutable parameters are marked `@` in the signature and at the call site". |
| 6 | *changes an existing name* | Section 5: "`@` re-binds it, or a field or element inside one." Production `Simple = Place "@" Expression NEWLINE`, with `Place = ident { "." ident ... }` giving `c.hits`. |
| 9 | *new name* | Section 5: "`=` binds once, forever." Production `Binding = [ ":" Type ] ( "=" \| "@=" ) Expression NEWLINE`. |
| 10 | *new name* | Section 5: "`=` binds once, forever." This makes `step` immutable, which causes the refusal on line 20. |
| 11 | *new name* | Section 5: "`@=` declares a mutable cell". Section 10: an empty container needs an annotation, `m: {str: i64} @= {}`, which the line uses. |
| 12 | *new name* | Section 5: "`@=` declares a mutable cell". |
| 15 | *changes an existing name* | Section 10: "`m[k] @ v` inserts or replaces". Section 5: "`@` re-binds it, or a field or element inside one." This re-binds the cell `counts`, which the rule about re-binding a cell counts. |
| 16 | *changes an existing name* | Section 5: "`@` re-binds it" (`total` is the cell from line 12). |
| 18 | *new name* | Section 5: "`@=` declares a mutable cell". Section 9: "Record construction is a call with field names, always mandatory". |
| 19 | *changes an existing name* | Section 9: "Mutable parameters are marked `@` in the signature and at the call site ... Either way the callee works on the caller's place itself". Section 5: "an `@` argument counting" as a write. The call changes `c`. See choice point 2. |
| 20 | *changes an existing name* (refused) | Section 5: "`=` binds once, forever." and "`@` re-binds it" (a cell). The name `step` is a `=` binding, so the re-binding is refused. |
| 21 | *changes an existing name* | Same as line 19. The call passes `step` by value and writes `c` through `@c`. |
| 22 | *new name* (refused as written) | Section 5: "a cell nothing re-binds ... is a compile error". No later line re-binds `last`. |

## sentences

Quoted from `spec.md`, each sentence the verdict rests on:

1. Section 5, after the example: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
2. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
3. Section 5 grammar: `Simple    = "_" Binding | Place "@" Expression NEWLINE`, and `Binding   = [ ":" Type ] ( "=" | "@=" ) Expression NEWLINE .`
4. Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy: `function peek(l: Lex lent)` … `peek(l)`."
5. Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
6. Section 10: "`m[k]` is a `V?` with code `missing_key`; `m[k] @ v` inserts or replaces;"
7. Section 9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`, and a variant's case `.num(v: 7)` or `.plus`."
8. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a`, one per line.

## choice_points

1. **Which binding to change for the two refusals.** I made `step` a cell (line 10: `@=`) and `last` immutable (line 22: `=`). This keeps line 20's intent (the second `bump` sees 2) and line 22's intent (a name that is never re-bound). The other choice, keeping `step = 1` and turning line 20 into a new binding, is refused: a second `=` on the same name is a rebinding. Another option is to rename line 20's target (`step2 = 2`, `bump(@c, step2)`); that is also accepted and prints the same `5`, `5`, `a`, but it departs from the evident intent of one `step` that changes.
2. **Call-site `@` (lines 19 and 21).** I classed these as *changes an existing name*, because `c.hits` does change and the spec says the callee "works on the caller's place itself". Read strictly on the line alone, the `@` there is an argument marker and not the `Place "@" Expression` re-binding form, so one could class them as *neither*. The verdict does not depend on this choice.
3. **Line 5 (`@c` in the signature).** I classed the `@` parameter as *new name*, since it brings `c` into the scope of `bump`. One could argue a parameter is not a `=` or `@` binding in the sense of the brief. The verdict does not depend on it.
4. **Element re-binding counts as re-binding the cell (line 15).** I read "`@` re-binds it, or a field or element inside one" as making `counts[w] @ ...` a re-binding of `counts`. The other reading would make `counts` a cell nothing re-binds (line 11 refused). The spec wording favours my reading.
5. **Literal types.** `step`, `total`, `counts` values and `hits` default to `i64` by section 2, since no context asks otherwise. The other choice (none available here) would only matter if a literal needed another width.

## confidence

- **High** that the original program is refused, and that the refusals are on lines 20 and 22 (the rules quoted in `sentences` 1 and 2 are explicit).
- **High** that the fixed program is accepted and prints `5`, `5`, `a` (I traced each statement by hand).
- **Medium** on the line-by-line classification for lines 19 and 21 and for line 5 (see choice points 2 and 3).
- **Not checked**: I could not run the checker, and the reading tool does not let me confirm byte-level details such as tab characters or trailing whitespace in `main.hero`. The indentation I read is four spaces per level, which is what the spec requires. If a tab is present, the program is also refused, on the line with the tab.

## context

- I read `brief.md`, `spec.md` and `main.hero`, the files the brief names as inputs. I also read `run.json` and `run.err`, which are in this directory but are not inputs the brief names. Both were empty, and I did not use them in the verdict.
- The session's system context (an environment description, a git status snapshot, and account metadata) was present in my context. None of it bears on the program, and I did not use it.
- I did not read any file outside this directory, used no tool other than reading and writing files here, and did not run anything.
