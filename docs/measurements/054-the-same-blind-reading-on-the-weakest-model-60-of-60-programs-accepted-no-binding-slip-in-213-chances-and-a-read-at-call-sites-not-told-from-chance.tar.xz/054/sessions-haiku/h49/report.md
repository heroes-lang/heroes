## verdict

Refused. Two lines fail:

- **Line 20** `step = 2`: `step` is bound by `:=` on line 10, which "binds once, forever". Only a cell can be re-bound with `=`, so this line is refused.
- **Line 22** `last @= words[0]`: `last` is a cell that nothing re-binds. Section 5 makes "a cell nothing re-binds" a compile error. The later read on line 25 is a use, and a use does not count as a re-binding.

Smallest fix, keeping the evident meaning (the program accumulates `step` and then uses a fixed `last`):

- Line 10: `step := 1` becomes `step @= 1`, so that line 20 can re-bind it.
- Line 22: `last @= words[0]` becomes `last := words[0]`, since it is never re-bound.

The fixed program prints:

```
5
5
a
```

`c.hits` is 3 after line 19 (`counts["a"]` is 3) and 5 after line 21 (adding `step` = 2). `total` is 5 (five iterations, each adding `step` = 1). `last` is `"a"`.

## lines

| line | kind | words of the specification relied on |
|---|---|---|
| 5 | *new name* | `Param = "@" ident ":" Type`; "Mutable parameters are marked `@` in the signature". The signature binds `c` for `bump`. |
| 6 | *changes an existing name* | "`=` re-binds it, or a field or element inside one" (`c.hits` is a field of the `@` parameter `c`); "the callee works on the caller's place itself" |
| 9 | *new name* | "`:=` binds once, forever" (`words`) |
| 10 | *new name* | "`:=` binds once, forever" (`step`). With the fix, "`@=` declares a mutable cell" instead. |
| 11 | *new name* | "`@=` declares a mutable cell" (`counts`) |
| 12 | *new name* | "`@=` declares a mutable cell" (`total`) |
| 15 | *changes an existing name* | "`=` re-binds it, or a field or element inside one" (`counts[w]` is an element of the cell `counts`); "`m[k] = v` inserts or replaces" |
| 16 | *changes an existing name* | "`=` re-binds it" (`total` is a cell, declared on line 12) |
| 18 | *new name* | "`@=` declares a mutable cell" (`c`); "Record construction is a call with field names, always mandatory" |
| 19 | *changes an existing name* | "Mutable parameters are marked `@` in the signature and at the call site"; "the callee works on the caller's place itself"; "an `@` argument counting" (section 5) |
| 20 | *changes an existing name* (attempted, refused) | "`:=` binds once, forever"; "`=` re-binds it" applies only to a cell, and `step` is a `:=` binding |
| 21 | *changes an existing name* | the same words as line 19 (`c` through the `@` argument) |
| 22 | *new name* (refused: never re-bound) | "`@=` declares a mutable cell"; "a cell nothing re-binds" is a compile error |

## sentences

From section 5 (Bindings):

> `:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one.

> All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter.

From section 9 (Functions and calls):

> Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy: `function peek(l: Lex lent)` … `peek(l)`. Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument.

> Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`, and a variant's case `.num(v: 7)` or `.plus`.

From section 2 (Literals), with the two em dashes replaced by `[...]`:

> A literal takes the type its context asks for [...] otherwise `i64`.

From section 10 (Strings, arrays, maps):

> `m[k]` is a `V?` with code `missing_key`; `m[k] = v` inserts or replaces.

From section 6 (Failure), the table row:

> `.default(v)` | extract or fall back

From section 11 (Built-ins):

> `print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`.

From section 1 (Files and layout):

> One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing.

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a`, one per line.

## choice_points

1. **Fix for line 20.** I made `step` a cell (line 10 `step @= 1`), which keeps the reassignment the program evidently intends. The other choice is to delete line 20 and write `bump(@c, 2)` on line 21, with `step` left as `:=`. That also prints `5`, `5`, `a`, because `step` is not read after the loop except through line 21.
2. **Fix for line 22.** I changed the binding to `last := words[0]`. The other choices are to keep the cell and re-bind it once (for example `last = words[0]` after line 22), or to drop `last` and print `words[0]`. All of these print `a`, and I chose the one-token change.
3. **Classification of line 5.** I read the `@c` parameter as a *new name*, since the signature binds `c`. The other reading is *neither*, because the parameter declaration only marks a binding that the call site must supply. The verdict does not depend on this.
4. **Whether an `@` argument counts as a write to a cell.** The specification says "an `@` argument counting", so `bump(@c, ...)` on lines 19 and 21 counts as a re-binding of `c` and line 18 is accepted. If it did not count, line 18 would be refused as well. I followed the text.

## confidence

- **High** on the verdict (lines 20 and 22 refused) and on the output of the fixed program (`5`, `5`, `a`). Both follow directly from the quoted sentences and from a hand trace of the loop.
- **High** on the classification of lines 6, 9 to 12, 15, 16, 18, 19, 21 and 22.
- **Least sure** of line 5 (new name versus neither, see choice point 3) and of how a checker would classify line 20, which is refused, so "changes an existing name" describes what it attempts rather than an accepted change.

## context

Files read: `brief.md`, `spec.md` and `main.hero` (the inputs), plus `run.json` and `run.err`. Both of the last two are in this directory but are not among the inputs the brief names. Both are empty, and neither affected the verdict.

Outside this directory, my context also contained the session's environment block: the working directory path, the scratchpad path, the platform and shell, the model identity, the date, the git status snapshot and the user's account email. I did not use any of it for this report, and no other tool was used.
