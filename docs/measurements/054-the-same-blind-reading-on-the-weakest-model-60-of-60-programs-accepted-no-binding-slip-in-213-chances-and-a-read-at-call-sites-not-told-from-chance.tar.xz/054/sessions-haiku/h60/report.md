# Report

## program

```
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n := len(ys)
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if ys[j] < ys[j + 1]
                t := ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
    return ys

function runs(xs: [i64]) -> i64
    if len(xs) == 0
        return 0
    count @= 1
    for i in range(from: 1, to: len(xs))
        if xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    xs := sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
    for x in xs
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

## sentences

1. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line of the program (the bodies of all three functions, and the nested loop and `if` blocks).

2. "Syntax is ASCII-only; comments and strings hold UTF-8 but no raw control character ..." Governs the whole file. The program is pure ASCII and has no comments and no string literals, so the rule is met trivially.

3. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs `function main()` (no parameters, no `->`).

4. "Every top-level line starts with its kind." Governs the three `function` lines.

5. "Signatures are always explicit; inference is local only." Governs `function sorted_desc(xs: [i64]) -> [i64]` and `function runs(xs: [i64]) -> i64`.

6. "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs `ys @= xs` (the cell), `ys[j] = ys[j + 1]` and `ys[j + 1] = t` (element re-bindings of the cell `ys`), and `count = count + 1` (re-binding of the cell `count`). Also governs `n := len(ys)`, `t := ys[j]`, and `xs := sorted_desc(...)` as immutable bindings.

7. "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." Governs `ys @= xs`: `ys` is a copy, so the parameter `xs` is never changed, and no `@` parameter is needed.

8. "All bindings are initialised. An unused binding or parameter is a compile error ..." Governs the uses: parameter `xs` (read in `ys @= xs`, and in `runs` in `len(xs)` and `xs[i]`), `n` (in both `range` bounds), `t` (read in the swap), `count` (read in `return count`), and `ys` (returned), plus `xs` in `main` (iterated).

9. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Checked, not relied on: the program has no `use`, and the names `i`, `j`, `t`, `n`, `ys`, `count`, `x`, `xs` are each introduced once per function without repeating a name already in scope.

10. "`[T]` | dynamic array, indices from 0" (section 3 table). Governs `ys[j]`, `ys[j + 1]`, `xs[i]`, `xs[i - 1]`: zero-based indexing, with `j + 1 <= n - 1` and `i - 1 >= 0` in every access.

11. "An out-of-bounds index or slice aborts, and so does a slice that splits a character." Governs the index accesses above. Each is in bounds, so no abort occurs. Lines: `if ys[j] < ys[j + 1]`, `t := ys[j]`, `ys[j] = ys[j + 1]`, `ys[j + 1] = t`, `if xs[i] != xs[i - 1]`.

12. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs `for i in range(...)`, `for j in range(...)`, `for x in xs`, and `for i in range(from: 1, to: len(xs))`.

13. "`range(from: a, to: b) -> [i64]` exclude `to`." Governs every `range(...)` line. `range(from: 0, to: n)` visits 0 through n-1. `range(from: 0, to: n - 1 - i)` visits j = 0 through n - 2 - i, so `j + 1` stays at most n - 1 - i.

14. "When two parameters in a signature share a type, named arguments are mandatory at the call site ..." Governs the `range(from: ..., to: ...)` calls, which name both `i64` arguments as the rule requires. Not triggered by `sorted_desc(...)` and `runs(...)`, which have one parameter each, so positional arguments are legal there.

15. "`if cond` / `else if` / `else` take only `bool`, there is no truthiness." Governs `if ys[j] < ys[j + 1]`, `if len(xs) == 0`, and `if xs[i] != xs[i - 1]`: each condition is a `bool`.

16. "`< <= > >=`: a number only" (section 7, comparison row). Governs `ys[j] < ys[j + 1]`: both sides are `i64`.

17. "A function with a `->` must `return` on every path that reaches its end, and ..." Governs `sorted_desc` (ends with `return ys`) and `runs` (the `return 0` path inside the `if`, and the final `return count`).

18. "A literal takes the type its context asks for ... otherwise `i64`." Governs the integer literals. `0` and `1` in `runs` and the array literals take their types from context, which here is `i64` or `[i64]`. `== 0` in `runs` takes the type of `len(xs)`, which is the open point in choice 8.

19. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs `print(x)` (an `i64`) and `print(runs(...))` (an `i64`). `print` does not take an array, which is why `main` loops over `xs` and prints each element.

20. "Built-ins: `print(...)` · `len` · `push` ..." Governs `len(ys)` and `len(xs)`. The spec names `len` but does not state its return type (see choice 8).

21. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs the order of the functions: `main` calls `sorted_desc` and `runs`, which are defined above it.

## choice_points

1. **Sorting method.** I chose bubble sort: repeated swaps of adjacent elements where `ys[j] < ys[j + 1]`, which is what the brief asks for. The other choice, insertion sort, produces the same final output, `9 6 5 4 3 2 1 1`, but a different sequence of swaps.

2. **Working copy.** I chose `ys @= xs` and sort the copy, because the parameter `xs` is immutable and the copy rule makes `ys` independent. The other choice, marking the parameter `@xs: [i64]`, would change the signature the brief fixes, and it would change the caller's array. The printed output is the same either way.

3. **Inner loop bound.** I chose `range(from: 0, to: n - 1 - i)`, which skips the already-placed largest elements at the end. The other choice, `range(from: 0, to: n - 1)`, produces the same output and is still abort-free (j + 1 stays at most n - 1), only with extra comparisons.

4. **Outer loop count.** I chose `range(from: 0, to: n)`, which runs n passes. The other choice, `range(from: 0, to: n - 1)`, produces the same result, since n - 1 passes are enough to sort n elements. It is also safe for n = 0 and n = 1, because the inner range is then empty.

5. **Empty input in `runs`.** I chose an early `return 0` for an empty array, since a count started at 1 would wrongly give 1 for an empty array. The other choice, starting `count @= 0` and counting a group whenever `i == 0` or a neighbour differs, gives the same results on every input, at the cost of a test inside the loop.

6. **Argument style.** I chose positional arguments for `sorted_desc` and `runs`, which have one parameter each, and named arguments for `range`, which the rule requires. The other choice, naming `xs:` in the calls to the one-parameter functions, is also legal and gives the same output.

7. **Loop form.** I chose `for` over `range` and over the array, not `while`. A `while` loop with an index cell gives the same output and the same bounds reasoning.

8. **Type of `len`.** The spec does not state what `len` returns. I assumed `i64`, so that `n - 1 - i`, `range(from: 0, to: n)`, and `range(from: 1, to: len(xs))` type-check against the `i64` parameters of `range` with no conversion. If `len` returns an unsigned type such as `u64`, the lines that mix it with `i64` fail: `n - 1 - i` (where `i` comes from `range`), `range(from: 0, to: n)`, `range(from: 1, to: len(xs))`, and `range(from: 0, to: n - 1 - i)`. The checker would reject the program, since there are no implicit conversions. Repairing that would need `to_i64(len(ys))`, which returns a `T?`, so the program would also need `.must()`, which the spec allows.

## confidence

About 85% that the checker accepts the program as written, assuming `len` returns `i64`. The spec does not state the return type of `len`, and that is almost the whole of the uncertainty.

The least certain line is `n := len(ys)`, together with `for i in range(from: 1, to: len(xs))` in `runs`, because both depend on the type of `len`. The next least certain is the element re-binding `ys[j] = ys[j + 1]`. Sentence 6 reads as clearly allowing it, but it is the one place a stricter checker could differ from my reading.

If the program runs, it should print `9`, `6`, `5`, `4`, `3`, `2`, `1`, `1`, then `4` (the runs of `[1, 1, 2, 2, 2, 3, 1]` are `1 1`, `2 2 2`, `3`, `1`). I did not run it. I could not run anything in this session.

## context

Nothing from outside this directory reached my context as a file. I read only `brief.md` and `spec.md` in this directory, and I wrote only `report.md` here. The surrounding session metadata (the environment description, the git status snapshot, and the user's account details) was present in my context as system information, not as files. That metadata played no part in the program's design.
