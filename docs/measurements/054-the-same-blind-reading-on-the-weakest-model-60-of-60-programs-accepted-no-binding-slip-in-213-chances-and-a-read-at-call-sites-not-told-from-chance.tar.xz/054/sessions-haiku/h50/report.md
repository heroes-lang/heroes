# Report

## program

The program below is the one I would submit. Line numbers in the `sentences` section count from the first line of this block (`record Item` is line 1), blank lines included.

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    for i in range(from: 0, to: items.len())
        if items[i].name == name
            if items[i].qty < n
                return false
            items[i].qty = items[i].qty - n
            return true
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    took_apple := take(@items, "apple", 5)
    print(took_apple)
    took_pear := take(@items, "pear", 9)
    print(took_pear)
    total @= 0
    for item in items
        total = total + item.qty
    print(total)
```

Expected output: `true`, then `false`, then `4` (apple 3+4=7, take 5 leaves 2; pear 2, take 9 fails; sum 2+2=4).

## sentences

Quotes are from `spec.md`. Lines are program lines as numbered above.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 21.
2. "Every top-level line starts with its kind." Governs lines 1, 5, 12, 21.
3. "Declaration order never matters but a group's (section 13)" Governs lines 1 to 33 (the record precedes its uses; the order is not required).
4. "Fields = INDENT { ident ":" Type NEWLINE } DEDENT ." (grammar, section 4) Governs lines 1 to 3.
5. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs line 10.
6. "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs line 22 (`@=`), lines 26 and 28 (`:=`), lines 8, 10, 17 (`=` into a field or element, and the `@` parameter), line 30 (`@=`), line 32 (`=`).
7. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting" Governs line 22 (`items` is re-bound by the `@` arguments on lines 23 to 28), lines 8 and 10 (`items` written in `restock`), lines 17 (`items` written in `take`), and every parameter and binding: `name` and `n` (lines 7, 8, 10, 14, 15, 17), `took_apple` and `took_pear` (lines 26 to 28), `total` and `item` (lines 31 to 33).
8. "Mutable parameters are marked `@` in the signature and at the call site" Governs lines 5, 12 (signatures), and lines 23 to 28 (call sites).
9. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs line 6 (`items.len()`), line 10 (`items.push(...)`), line 13 (`items.len()`).
10. "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs line 10. `items` is a plain name (a parameter is a name).
11. "An empty one needs an annotation: `xs: [i64] := []`" Governs line 22 (`items: [Item] @= []`).
12. "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs lines 6 and 13 (the loop covers indices 0 to len-1).
13. "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs lines 6 and 13 (`from:` and `to:` are both `i64`, so both are named).
14. "A literal takes the type its context asks for ... otherwise `i64`." Governs line 6 and 13 (`from: 0`), lines 23 to 25 and 26, 28 (the arguments `3`, `2`, `4`, `5`, `9`), line 30 (`total @= 0`).
15. "No implicit conversions, widths included" Governs lines 6 and 13 (`items.len()` must be `i64` to be passed to `to:`), line 10 (`n` is `i64` as the `qty` field is), line 32 (`item.qty` and `total` are both `i64`).
16. "Built-ins: `print(...)` · `len` · `push`" Governs lines 6, 13 (`len`), line 10 (`push`), lines 27, 29, 33 (`print`).
17. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 27, 29, 33.
18. "a `bool` prints `true` or `false`." Governs lines 27 and 29.
19. "Loops: `while cond` and `for x in xs`, over an array or a `range`" Governs lines 6, 13 (`for i in range(...)`), line 31 (`for item in items`).
20. "`==` is structural equality on any two values of one type, recursively" Governs lines 7 and 14 (`str` comparison).
21. "`< <= > >=`: a number only" Governs line 15 (`items[i].qty < n`, both `i64`).
22. "`if cond` / `else if` / `else` take only `bool`" Governs lines 7, 14, 15.
23. "No braces, no semicolons; a condition needs no parentheses." Governs lines 7, 14, 15 (conditions written bare).
24. "A function with a `->` must `return` on every path that reaches its end" Governs lines 12 to 19, in particular line 19 (`return false`), which is the path that reaches the end of `take`.
25. "A statement after a jump, in its block, is a compile error." Governs lines 9 (last statement of its block), 16 (only statement of its block), 18 (last statement of its block). No statement follows a jump in any block.
26. "A line that computes a value must use it: bind it" Governs lines 26 and 28 (`took_apple`, `took_pear` are bound and then used by `print`).
27. "Simple = ... | "return" [ Expression ] NEWLINE ." (grammar, section 5) Governs lines 9, 16, 18, 19 (`return` with and without an expression; `restock` has no `->`, so its bare `return` is valid).
28. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs the names used: `i` (lines 6 and 13, in two separate functions, neither nested in the other), `item` (line 31, distinct from `items`), and no name is bound twice in one scope.
29. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line (2 to 33). The program uses no tabs.
30. "Syntax is ASCII-only" Governs the whole program; it contains only ASCII characters.

## choice_points

1. **Iterate by index (`for i in range(from: 0, to: items.len())`) versus `for item in items`.** I chose the index loop in `restock` and `take`, because they must write `items[i].qty` through the `@` parameter. The `for item in items` form only reads. The other choice (a `for item in items` loop) would not compile the update, or would need a second array rebuilt with `map`, which is more code and more risk.
2. **Return type of `len`.** The spec does not state it. I assumed `i64`, since `range` takes `i64` and there is no implicit conversion. The other choice (a non-`i64` integer type) would make `range(from: 0, to: items.len())` a type error, and the checker would reject the program.
3. **Writing an element through an `@` parameter (`items[i].qty = ...`) versus rebuilding the array.** I chose the in-place write, because the spec says an `@` parameter works on the caller's place itself. The other choice (build a new array and return it) would need a return value, which changes the signatures the brief fixes.
4. **Assigning `items = items.push(...)` to the `@` parameter versus `items.push` into a separate local.** I chose re-binding the parameter, since `=` re-binds a mutable cell and the spec says `xs = xs.push(4)` grows in place for a plain name. The other choice (a local copy) would not change the caller's list, so `main` would see no appended item.
5. **Positional versus named arguments for `restock` and `take`.** The two parameters `name: str` and `n: i64` have different types, so naming is optional. I chose positional calls. The other choice (`restock(@items, name: "apple", n: 3)`) would compile to the same program; it only changes readability.
6. **Passing the `@` argument inside `print(...)` versus binding the result first.** I bound each `take` result to a name and then printed it, to avoid nesting an `@` argument inside another call's argument list. The other choice (`print(take(@items, "apple", 5))`) would most likely also compile, but I did not rely on it.
7. **Early `return` inside the loop in `restock` versus a found flag.** I used an early `return`, so `items.push` runs only when no item matched. The other choice (a `found @= false` flag with a post-loop `if`) would also be correct but adds a cell that must be re-bound and used.
8. **Sum by a `for` loop versus `fold`.** The spec gives `fold` but not its exact signature beyond "its function names them `acc` then `item`". I chose the loop, which needs only `for`, `total @= 0` and re-binding. The other choice (`fold`) would be shorter but depends on details the spec does not fully state.
9. **Loop variable name `item`.** Any unused name would do. `item` is distinct from `items` and from the built-in names.
10. **`take` when the item exists but holds less than `n`.** The spec says "otherwise it changes nothing and returns `false`", so I return `false` before any subtraction. The other choice (subtract then check) would break the "changes nothing" rule.
11. **Using `items: [Item] @= []` (a mutable cell) rather than `items: [Item] := []`.** The cell must be mutable because it is passed as an `@` argument. The other choice (`:=`) would be refused, since an `@` argument needs a mutable place.

## confidence

I am fairly confident (roughly 80 percent) that the checker accepts the program on the first try. The main uncertainty is the return type of `len` (choice point 2), which the spec does not state.

The line I am least sure of is line 6 (and the same pattern on line 13): `for i in range(from: 0, to: items.len())`. It depends on `len` returning `i64` (choice point 2) and on `range` taking named arguments as written. The lines that write through the `@` parameter (lines 8, 10, 17) and the `@` call sites (lines 23 to 28) rest on clear spec text and are less risky.

## context

Nothing other than this directory's files reached my context, as far as I can tell. I read `brief.md`, `spec.md` (in full), `run.json` and `run.err` (both empty; the Read tool reported them as existing with empty contents). I did not read any file outside this directory and used no other tool.

Separately, the session supplied environment and git status information (working directory, platform, the git branch, and a list of untracked files). That information came from the harness, not from a file I read, and I did not use it to write the program.
