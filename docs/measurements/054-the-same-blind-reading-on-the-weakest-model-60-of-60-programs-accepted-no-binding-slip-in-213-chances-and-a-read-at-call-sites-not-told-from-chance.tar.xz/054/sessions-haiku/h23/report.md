# program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    while i < items.len()
        if items[i].name == name
            items[i].qty = items[i].qty + n
            return
        i = i + 1
    items = items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    while i < items.len()
        if items[i].name == name
            if items[i].qty >= n
                items[i].qty = items[i].qty - n
                return true
            return false
        i = i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    took_apple $= take(@items, "apple", 5)
    took_pear $= take(@items, "pear", 9)
    print(took_apple)
    print(took_pear)
    total @= 0
    for entry in items
        total = total + entry.qty
    print(total)
```

Expected output: `true`, `false`, `4`.

# sentences

Each sentence is quoted from spec.md, with the program lines it governs.

1. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line (record fields, function bodies, loop and if bodies).
2. "Every top-level line starts with its kind." Governs `record Item`, `function restock`, `function take`, `function main`.
3. "`function main()`, which takes nothing and produces nothing." Governs `function main()` (no parameters, no `->`).
4. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs `Item(name: name, qty: n)`.
5. "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `items.len()`, `items.push(...)`, and `items.push(Item(...))`.
6. "Mutable parameters are marked `@` in the signature and at the call site" Governs `@items` in the signatures of `restock` and `take`, and every `@items` call-site argument in `main`.
7. "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs `i @= 0`, `total @= 0`, `items: [Item] @= []`, `i = i + 1`, `total = total + entry.qty`, `items[i].qty = ...`, `items = items.push(...)`.
8. "`$=` binds once, forever." Governs `took_apple $= ...` and `took_pear $= ...`.
9. "Signatures are always explicit; inference is local only." Governs the typed parameters and `-> bool`; `i @= 0` and `total @= 0` infer `i64` from the literal.
10. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." Governs: every parameter and binding is read (`name`, `n`, `i`, `took_apple`, `took_pear`, `entry`); `items` in `main` is re-bound by the `@items` arguments and by `items = items.push(...)` in `restock`; `items` in `restock` and `take` are written; `total` is re-bound in the loop.
11. "A statement after a jump, in its block, is a compile error." Governs the `return` at the end of the `if` block in `restock`, and `return true` and `return false` in `take`.
12. "A function with a `->` must `return` on every path that reaches its end" Governs `return false` at the end of `take`, which is reached after the `while` loop exits.
13. "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness." Govern `if items[i].name == name` and `if items[i].qty >= n`.
14. "`while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs `while i < items.len()` and `for entry in items`.
15. "`==` is structural equality on any two values of one type, recursively" Governs `items[i].name == name` (str compared with str).
16. "No implicit conversions, widths included: `1 + 2.0` is an error." Governs `i < items.len()` and `items[i].qty >= n` (both sides must be one type, here `i64`), and `total + entry.qty` (`i64` + `i64`).
17. "Overflow aborts at every width." Governs the additions and subtractions in `restock`, `take`, and the sum in `main`; the values are small, so no abort occurs.
18. "`xs = xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs `items = items.push(Item(name: name, qty: n))`: `items` is the plain `@` parameter name.
19. "An out-of-bounds index or slice aborts" Governs `items[i]` in both loops; `i` is always below `items.len()` because of the `while` condition.
20. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Checked only: the program has no `use`, and within each function no name is bound twice (`i` appears once per function, in separate functions).
21. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs `print(took_apple)`, `print(took_pear)`, `print(total)`.
22. "Built-ins: `print(...)` · `len` · `push`" Governs `items.len()` and `items.push(...)` as built-ins.

# choice_points

1. **Find-or-append method.** Chosen: a `while` loop over an index `i`, with an early `return` once the name is found, then an append after the loop. Other choice: a `for` loop with a `found` bool cell and an append guarded by `if not found`. Output is the same; the flag version has no early exit and needs one more cell.
2. **Updating the found item.** Chosen: `items[i].qty = items[i].qty + n` in place through the `@` parameter. Other choice: rebuild the array with `map` (`items = items.map(...)`). Same result, but it copies the whole array on each call.
3. **Type of `len()`.** The spec does not state the return type of `len`. I assumed `i64`, so `i @= 0` (also `i64`) compares with it without conversion. If `len()` returned `u64` (as `repeat`'s `n` does), `i < items.len()` would be an error under "No implicit conversions", and the program would need a conversion or a different loop bound. This is the largest uncertainty.
4. **Passing `@items` as the re-binding of `items` in `main`.** I read "an `@` argument counting" to mean that `restock(@items, ...)` and `take(@items, ...)` count as writes to the cell, so the cell `items` in `main` is not "nothing re-binds". The other reading would make `main` fail, since `items` is never assigned by a plain `=` in `main`. To avoid depending on this, `main` could add a plain re-binding, but the spec does not show a form for that, so I did not add one.
5. **Results of `take`.** Chosen: bind each to a name with `$=` and print the name. Other choice: `print(take(@items, "apple", 5))`. Same output; the binding form avoids nesting an `@` argument inside another call.
6. **Sum loop.** Chosen: `for entry in items` with a `total @=` cell. Other choice: an index `while` loop, as in the helpers. Same output; the `for` form is shorter and has no index.
7. **Loop variable name.** Chosen: `entry`. Any unused name would work; I avoided `it` only for readability.
8. **Order of checks in `take`.** Chosen: `items[i].qty >= n` is tested before subtracting, so a failed take writes nothing and returns `false`, as the brief requires. Other choice: subtract first and check afterward, which would need undoing the write on failure.
9. **Literal typing.** Chosen: `i @= 0` and `total @= 0` default to `i64` from the literal. Other choice: an explicit annotation `i: i64 @= 0`. The spec allows both; the annotation is more explicit but has the same meaning.

# confidence

I am fairly confident the checker accepts the program, roughly 75 to 80 percent, given that I cannot run it. The least certain line is `    while i < items.len()` (both in `restock` and `take`), because the spec does not state the return type of `len`; if it is not `i64`, this line is refused by the "No implicit conversions" sentence. The second least certain is the `items` re-binding in `main` (choice point 4), which depends on how "an `@` argument counting" is read. The other lines are covered by explicit sentences: the record, `@` marks at call sites, the `return` on every path in `take`, and the `if`/`while` `bool` and `i64` rules.

# context

Nothing other than this directory's files reached my context. I read `brief.md`, `spec.md` (in full), `run.json`, and `run.err`. The last two are empty files in this directory and gave no information. I used no tool other than reading these files and writing `report.md`, as the brief requires, and I did not read any file outside this directory. My knowledge of Heroes comes only from `spec.md`.
