## program

```
# Sorts by repeated adjacent swaps, largest first; no built-in sort.
function sorted_desc(xs: [i64]) -> [i64]
    ys @= xs
    n $= len(ys)
    swapped @= true
    i @= 0
    while swapped
        swapped = false
        i = 0
        while i < n - 1
            if ys[i] < ys[i + 1]
                t $= ys[i]
                ys[i] = ys[i + 1]
                ys[i + 1] = t
                swapped = true
            i = i + 1
    return ys

# Counts the maximal runs of equal adjacent elements.
function runs(xs: [i64]) -> i64
    count @= 0
    seen @= false
    prev @= 0
    for x in xs
        if !seen || x != prev
            count = count + 1
        seen = true
        prev = x
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below refer to this block (line 1 is the first comment line).

## sentences

Each quoted sentence is from `spec.md`, followed by the program lines it governs.

1. "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs line 4 (`n $=` binds once), lines 3, 5, 6, 21, 22, 23 (cells declared with `@=`), and lines 8, 9, 13, 14, 15, 16, 26, 27, 28 (re-bindings, including the element writes on lines 13 and 14).
2. "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds ... a read is a use and a write is not, except through an `@` parameter." Governs line 3 (`ys` is re-bound by element writes and read on line 17), line 5 (`swapped` read on line 7), line 6 (`i` read on line 10), line 12 (`t` read on line 14), line 21 (`count` read on line 29), line 22 (`seen` read on line 25), line 23 (`prev` read on line 25), and the parameters `xs` on lines 2 and 20.
3. "Signatures are always explicit; inference is local only." Governs lines 2, 20 and 31.
4. "`function main()`, which takes nothing and produces nothing." Governs line 31.
5. "`[T]` | dynamic array, indices from 0" (section 3 table). Governs lines 3, 11, 13, 14 and 25 (array indexing and the `[i64]` parameters).
6. "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." Governs line 3 (`ys @= xs` copies the parameter).
7. "Built-ins: `print(...)` · `len` · `push` · ..." Governs line 4 (`len(ys)`).
8. "No implicit conversions, widths included: `1 + 2.0` is an error." Governs line 10 (`i < n - 1`, where `i` and `n` must be one integer type) and line 4 (the result of `len` must fit that same type).
9. "A literal takes the type its context asks for ... otherwise `i64`." Governs lines 5, 6, 9, 21, 23, 26, 32 and 34 (integer literals default to `i64`, and the array literals take `[i64]` from their parameter).
10. "`< <= > >=`: a number only" (section 7 operator table). Governs lines 10 and 11.
11. "boolean `&& || !` (bool only; && and || short-circuit)" (section 7 operator table). Governs lines 25 (`!seen || x != prev`) and 7 (`while swapped`).
12. "Precedence, strongest first: call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -` → ... → comparisons → `&&` → `||`." Governs line 10 (`n - 1` binds before `<`), line 11 (`ys[i + 1]` and `+` bind before `<`), and line 25 (`!seen` binds before `||`, and `!=` binds before `||`).
13. "`if cond` / `else if` / `else` take only `bool`" and "there is no truthiness." Governs lines 11 and 25.
14. "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 7, 10, 24 and 32.
15. "A function with a `->` must `return` on every path that reaches its end." Governs lines 17 and 29 (each function ends with `return`).
16. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 33 and 34.
17. "A container literal separates elements by newline across lines and by comma on one" Governs lines 32 and 34 (single-line array literals separated by commas).
18. "An out-of-bounds index or slice aborts" Governs lines 11, 13 and 14 (`i + 1` stays at most `n - 1`, which is `len(ys) - 1`, so no index is out of bounds).
19. "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs lines 2, 20 and 31 (`main` also calls functions declared above it, so order is safe either way).
20. "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs lines 24 and 32 (`x` is bound in two different functions and never twice in one function).
21. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error. No braces, no semicolons; a condition needs no parentheses." Governs every indented line of the program, and the conditions on lines 7, 10, 11, 24 and 25.
22. "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it" Governs lines 1 and 19 (both sit directly above a declaration).
23. "Syntax is ASCII-only; comments and strings hold UTF-8 but no raw control character" Governs every line: the program is ASCII only.

## choice_points

1. **Bubble sort structure in `sorted_desc`.** I chose a `swapped` flag with an outer `while swapped` and an inner `while i < n - 1` (lines 5 to 16). The other choice, a fixed outer loop of `n - 1` passes, gives the same output, since an extra pass changes nothing, but it needs a second counter.
2. **Swap test uses strict `<` (line 11).** Equal elements are never swapped, so equal values keep their order. The other choice, `<=`, reports a swap on every pass once two equal neighbours exist, so the outer loop never ends. The output with `<` is `9 6 5 4 3 2 1 1`.
3. **Swapping through a temporary `t` (lines 12 to 14).** The spec has no tuple assignment, so a temporary is the way to swap. I know of no other single-statement form that the spec allows.
4. **Copy into `ys` rather than mutating the parameter (line 3).** Parameters are read-only unless marked `@`. The other choice, an `@xs` parameter, would change the caller's array in place and would require `@` at every call site. The printed output would be the same, but the call sites would differ.
5. **Result type of `len` (line 4).** The spec does not state the result type of `len`. I assumed `i64`, to match the spec's other integer-valued built-ins such as `range -> [i64]`. If `len` returned `u64` or another width, line 10 (`i < n - 1`) and line 4 would be type errors, since there is no implicit conversion. This is the choice with the most risk.
6. **`runs` without `len` (lines 21 to 29).** I iterate with `for x in xs` and track `seen` and `prev`. The other choice, an index loop from 1 using `len` (`i < len(xs)`, `xs[i] != xs[i - 1]`), gives the same counts, but it depends on the unstated type of `len` from choice point 5, so I avoided it. Both give 0 on an empty array and 4 for `[1, 1, 2, 2, 2, 3, 1]`.
7. **`seen` flag versus a sentinel in `runs` (lines 22 and 25).** A sentinel such as `prev @= -1` would remove the flag, but an input that contains the sentinel value would then be miscounted. I chose the flag. The other choice gives the right answer on every `i64` input only if the sentinel is one the input cannot hold, which an `i64` array can always contain, so the flag is the correct option.
8. **`for` versus `while` in `main` (line 32).** I used `for` over the returned array. The other choice, `while` with an index, depends on `len` again, which is the unstated type from choice point 5.
9. **Comments (lines 1 and 19).** Comments are optional. Dropping them leaves the output unchanged.
10. **Declaration order.** I put `sorted_desc` and `runs` before `main`. The spec says order does not matter, so the other order also works.

## confidence

I am fairly confident the checker accepts this program on the first try, roughly 85 to 90 percent. The spec is clear on the constructs used: `$=`, `@=`, `=`, `while`, `for`, `if`, `return`, `print`, the `i64` default for literals, and the operator precedence. Each function ends with a `return` on every path, and every binding is used.

The line I am least sure of is line 4, `n $= len(ys)`. The spec lists `len` as a built-in but does not give its result type. If `len` yields a type other than `i64`, lines 4 and 10 fail. Line 10 is the next least certain line, for the same reason.

Smaller points of doubt, none of which I expect to fail: the spec does not say whether a `while` body may re-declare or re-assign a cell declared outside it (line 9 assigns `i` declared on line 6), and I read the rules on re-binding as allowing it. The spec also does not say how a comment immediately before the first `function` at the top of the file is handled, but it says a comment directly above a declaration documents it.

## context

Only files in this directory reached my reasoning as project input: `brief.md`, `spec.md`, `run.json` and `run.err`. Both `run.json` and `run.err` are empty; the read tool returned an empty-file warning for each. I did not open any file outside this directory and used no tool other than reading and writing files here.

The harness also supplied session metadata that is not project content: the working directory path, the platform, the scratchpad path, a git status snapshot (branch `main`, untracked `run.err` and `run.json`, last commit `inputs`), and the account email address. None of it describes the language or the program, and I did not use it in the program or in this report.
