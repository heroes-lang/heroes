## verdict

Refused, on line 20 (`step = 2`) and line 22 (`last @= words[0]`).

- Line 20: `step = 2` re-binds `step`, which line 10 declares with `$=`. Only a mutable cell can be re-bound, so the checker refuses it.
- Line 22: `last @= words[0]` declares a mutable cell that nothing re-binds, which the spec makes a compile error.

Both refusals are one-token fixes. Changing line 10 to `step @= 1` and line 22 to `last $= words[0]` gives a program the checker accepts. It prints:

```
5
5
a
```

## lines

| Line | Text | Classification | Words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (`c`, an `@` parameter of `bump`) | "Mutable parameters are marked `@` in the signature and at the call site" (section 9) |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (`c`, through its field `hits`) | "`=` re-binds it, or a field or element inside one" (section 5) |
| 9 | `words $= ["a", "b", "a", "c", "a"]` | *new name* (`words`) | "`$=` binds once, forever" (section 5) |
| 10 | `step $= 1` | *new name* (`step`, immutable) | "`$=` binds once, forever" (section 5) |
| 11 | `counts: {str: i64} @= {}` | *new name* (`counts`, a mutable cell) | "`@=` declares a mutable cell" (section 5) |
| 12 | `total @= 0` | *new name* (`total`, a mutable cell) | "`@=` declares a mutable cell" (section 5) |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (an element of `counts`) | "`=` re-binds it, or a field or element inside one" (section 5); "`m[k] = v` inserts or replaces" (section 10) |
| 16 | `total = total + step` | *changes an existing name* (`total`) | "`=` re-binds it" (section 5) |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* (`c`, a mutable cell) | "`@=` declares a mutable cell" (section 5); "Record construction is a call with field names" (section 9) |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, written through the `@` argument) | "Either way the callee works on the caller's place itself" (section 9); "a write is not, except through an `@` parameter" (section 5) |
| 20 | `step = 2` | *changes an existing name*, and refused: `step` is not a cell | "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it" (section 5) |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, through the `@` argument) | "Either way the callee works on the caller's place itself" (section 9); "a write is not, except through an `@` parameter" (section 5) |
| 22 | `last @= words[0]` | *new name* (`last`), refused: a cell nothing re-binds | "and so is a cell nothing re-binds" (section 5) |

## sentences

Quoted from `spec.md`, each sentence the verdict rests on:

- Section 5: "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`; a read-only one is marked `lent`, in the signature alone, where one with neither mark would be a copy: `function peek(l: Lex lent)` … `peek(l)`. Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- Section 9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`, and a variant's case `.num(v: 7)` or `.plus`."
- Section 2: "A literal takes the type its context asks for — `b: u8 $= 255`, and `b + 1` is a `u8` — otherwise `i64`."
- Section 10: "`m[k] = v` inserts or replaces;"
- Section 6 (table row): "`.default(v)` | extract or fall back"

Verdict-relevant reading of line 22: the spec sentence "and so is a cell nothing re-binds" applies because `last` is declared with `@=` and no later line assigns to it.

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words $= ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last $= words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output of this program, traced by hand:

```
5
5
a
```

Trace: the loop adds 1 to `total` five times, so `total` is 5, and `counts["a"]` is 3. `bump` with 3 gives `c.hits` 3. `step` becomes 2, and `bump` with 2 gives `c.hits` 5. `last` is `"a"`.

## choice_points

1. **Line 20 (`step = 2`).** I made `step` a cell on line 10 (`step @= 1`). The other choice was to delete the re-binding and pass `2` directly: `bump(@c, 2)`. That also prints `5`, `5`, `a`, because the loop still uses 1. It differs only in that `step` is no longer a name the program reads after line 20, so the one-token fix keeps the author's evident intent of a changing step more closely.
2. **Line 22 (`last @= words[0]`).** I made `last` immutable (`last $= words[0]`). The other choice was to keep the cell and add a re-binding later. That would also print `a`, but it would need an extra line the program does not otherwise need.
3. **Field `label` on `Counter`.** It is set on line 18 and never read. I treated a record field as not a binding, so the unused-binding rule does not apply to it, and I did not refuse the program for it. The other reading would refuse line 2 as an unused field, which would be a third refusal. The spec's unused-binding sentence names bindings and parameters, not fields, so I did not add a fix for it.
4. **Lines 5, 19, 21 (`@` arguments and parameter).** I read the `@` on `bump`'s parameter and at its call sites as a write to the caller's `c`. The other reading (that `c.hits = ...` through an `@` parameter is not a write) would make `c` a cell that nothing re-binds, which would be a fourth refusal on line 18. The spec's section 5 sentence supports my reading.
5. **Output format.** I took `print` of an `i64` to write the digits with one trailing newline, as section 11 states, and assumed no separator between values in a single call (none occurs here).

## confidence

High that the program as written is refused, and that lines 20 and 22 are the refusals. The first is a direct reading of "`$=` binds once, forever" against `step = 2`. The second is the cell rule quoted above.

High on the printed output for the fixed program, since it is a short hand trace with no floats and no overflow.

Less sure of two things:

- Line 5's classification as *new name*. The brief asks for a yes/no on whether the line brings a name into existence, and a parameter is a name in `bump`'s scope, but the spec's wording on parameters is less direct than on bindings.
- Whether the checker also rejects the unused field `label`. The spec does not say, so I went with the reading in choice point 3.

I could not run the checker, so these are readings of the spec, not observed results.

## context

I read only files in this directory, as the brief requires: `brief.md`, `spec.md`, and `main.hero`. I also read `run.json` and `run.err`, which are in this directory but are not listed as inputs. Both are empty and contributed nothing to this report.

The system prompt for this session also contained environment details (working directory path, platform, shell, a git status snapshot naming `run.err` and `run.json`, and the user's account email). None of it came from a file I read, and none of it bears on the verdict. I did not use any tool beyond reading and writing files in this directory, and I ran nothing.
