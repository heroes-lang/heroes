## verdict

Refused, on lines 20 and 22 of `main.hero`.

- **Line 20** (`step @ 2`): `step` is bound by `=` on line 10, which binds once and never again. `@` re-binds only a mutable cell, so this line has no legal meaning.
- **Line 22** (`last @= words[0]`): this declares a mutable cell that nothing re-binds. The only later use is `print(last)`, which is a read, and a read does not count as a write.

Nothing else in the program is refused by the rules I checked.

The smallest change that keeps the evident meaning (`step` goes from 1 to 2 part way through, and `last` is the first word) is two edits:

- line 10: `step = 1` becomes `step @= 1`
- line 22: `last @= words[0]` becomes `last = words[0]`

The fixed program prints:

```
5
5
a
```

Trace: the loop makes `counts` `{a: 3, b: 1, c: 1}` and `total` 5. `bump(@c, counts["a"].default(0))` adds 3 to `c.hits`, giving 3. `step` is then 2, and `bump(@c, step)` adds 2, giving 5. `last` is `"a"`.

The unmodified program prints nothing, because the checker refuses it.

## lines

| Line | Kind | Words of the specification relied on |
|---|---|---|
| 5 | *new name* | `@c` in `function bump(@c: Counter, by: i64)` is a parameter, so it brings `c` into existence inside `bump`. Section 4 (`Param = "@" ident ":" Type`), section 9 ("Mutable parameters are marked `@` in the signature and at the call site"). |
| 6 | *changes an existing name* | `c.hits @ c.hits + by`: section 5 ("`@` re-binds it, or a field or element inside one"). |
| 9 | *new name* | `words = [...]`: section 5 code block (`x = 5 # immutable binding`) and "`=` binds once, forever." |
| 10 | *new name* | `step = 1`: same as line 9. |
| 11 | *new name* | `counts: {str: i64} @= {}`: section 5 ("`@=` declares a mutable cell"). |
| 12 | *new name* | `total @= 0`: section 5 ("`@=` declares a mutable cell"). |
| 15 | *changes an existing name* | `counts[w] @ ...`: section 5 ("`@` re-binds it, or a field or element inside one"). |
| 16 | *changes an existing name* | `total @ total + step`: section 5 ("`@` re-binds it"). |
| 18 | *new name* | `c @= Counter(label: "a", hits: 0)`: section 5 ("`@=` declares a mutable cell"). |
| 19 | *changes an existing name* | `bump(@c, ...)`: section 9 ("the callee works on the caller's place itself"). Section 5 ("an `@` argument counting" as a write). |
| 20 | *changes an existing name* | `step @ 2`: section 5 ("`=` binds once, forever." and "`@` re-binds it"). The line names an `=` binding, so it is refused. It is classified as a change because that is what the line tries to do. |
| 21 | *changes an existing name* | `bump(@c, step)`: same as line 19. |
| 22 | *new name* | `last @= words[0]`: section 5 ("`@=` declares a mutable cell"). The cell is never re-bound, which section 5 forbids. |

## sentences

From section 5:

- "`=` binds once, forever."
- "`@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
- "All bindings are initialised."
- "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- Code block: `x = 5 # immutable binding, type inferred` and `v @= 0 # mutable cell, type inferred too`.

From section 5's grammar:

- `Simple = "_" Binding | Place "@" Expression NEWLINE`

From section 9:

- "Mutable parameters are marked `@` in the signature and at the call site:"
- "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach,"

From section 2:

- "A literal takes the type its context asks for ... otherwise `i64`."

From section 11:

- "`print` writes its values with no separator and exactly one trailing newline"

Note on the grammar: `Simple` alone would parse `step @ 2`. The refusal on line 20 therefore comes from combining section 5's "`=` binds once, forever" with "`@` re-binds it" (a mutable cell), not from the grammar.

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a`, one per line.

## choice_points

1. **Fixing line 20.** I changed line 10 to `step @= 1`, so that `step` is a cell that line 20 may re-bind. The other choice is to change line 10 to `step = 1` and delete line 20 (or change line 21 to `bump(@c, 2)`). That also prints `5`, `5`, `a`, so the output does not depend on this choice. I chose the version that keeps the mid-program change of `step`, which is the evident intent.
2. **Fixing line 22.** I dropped the `@` so that `last` is an immutable binding. The other choice is to keep the cell and add a later re-binding. That would change the output (for example, `last @ words[1]` would print `b`). Deleting `last` and printing `words[0]` directly would print the same `a`. I chose the smallest edit.
3. **Strictness of the cell rule.** I read "a read is a use and a write is not" as meaning `print(last)` does not stop line 22 from being refused. The other reading, that a read counts as satisfying the cell rule, would accept line 22 as written. I chose the literal reading.
4. **Whether line 20 is refused.** I read "`=` binds once, forever" together with "`@` re-binds it" as forbidding `@` on an `=` name. The other reading, that `@` could re-bind any name, would accept line 20 and print `5`, `5`, `a` for the original program. I chose refusal because the spec ties `@` to cells.
5. **Classification of line 5.** I classified the `@c` parameter as *new name*, since it brings `c` into existence in `bump`. The other classification would be *changes an existing name*, reading the `@` as tying `c` to the caller's cell. I chose *new name*.
6. **Classification of lines 19 and 21.** I classified the call-site `@c` as *changes an existing name*, because the callee writes the caller's place. The other classification would be *neither*, reading the `@` as a marker only. I chose *changes an existing name*, following section 9.
7. **Integer type of `step`.** Both `1` and `2` take `i64` from `bump`'s `by: i64` or by default. No other type is possible, so this is not a real choice.

## confidence

- **High** that the program as written is refused on lines 20 and 22. Line 22 follows from the explicit "cell nothing re-binds" rule. Line 20 follows from "`=` binds once, forever" and "`@` re-binds it".
- **High** on the output of the fixed program, `5`, `5`, `a`, because I traced it by hand. I did not run it.
- **Least sure** of: whether the checker treats `@` on an `=` name as a refusal, as opposed to an error with some other wording. This rests on my reading of section 5. Also least sure of the line 5, 19 and 21 classifications, since the spec's phrasing "the callee works on the caller's place itself" supports my reading but does not spell out the category.

## context

Only the files in this directory reached my context: `brief.md`, `spec.md` and `main.hero`. I read all three in full. I opened no other file and used no tool other than reading and writing files here. I did not run anything.
