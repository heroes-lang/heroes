## program

```
# Sorts xs from largest to smallest by swapping adjacent out-of-order pairs.
function sorted_desc(xs: [i64]) -> [i64]
    n: i64 $= xs.len()
    v @= xs
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if v[j] < v[j + 1]
                t $= v[j]
                v[j] = v[j + 1]
                v[j + 1] = t
    return v

# Counts the maximal groups of equal adjacent elements.
function runs(xs: [i64]) -> i64
    n: i64 $= xs.len()
    if n == 0
        return 0
    count @= 1
    for i in range(from: 1, to: n)
        if xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    for x in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(x)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Expected output: `9 6 5 4 3 2 1 1` on eight lines, then `4`. I have not run it; the checker is not available to me.

## sentences

Line numbers refer to the program above.

1. Spec section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line (4 to 10, 15 to 22, 25 to 27).
2. Spec section 1: "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it" Governs lines 1 and 13.
3. Spec section 1: "Syntax is ASCII-only" Governs the whole program, which is ASCII.
4. Spec section 1: "the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 24 to 27.
5. Spec section 2: "A literal takes the type its context asks for ... otherwise `i64`." Governs the integer literals: `0` and `1` in the ranges on lines 5, 6 and 19, `0` on line 16, `1` on line 18, `1` on lines 6, 20 and 21, and the list literals on lines 25 and 27.
6. Spec section 3: "Every value behaves as an independent copy: after `b $= a`, mutating `b` never changes `a`." Governs line 4, so sorting `v` leaves the caller's `xs` unchanged.
7. Spec section 4: "Declaration order never matters but a group's (section 13); mutual recursion needs no forward declarations." Governs lines 2, 14 and 24: `main` calls functions declared above it, and the order would not matter either way.
8. Spec section 5: "`$=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one." Governs line 4 (`v @=`), lines 9 and 10 (element re-binding of `v`), line 18 (`count @=`) and line 21 (`count =`).
9. Spec section 5: "v @= 0 # mutable cell, type inferred too" Governs line 4 (`v @= xs`) and line 18 (`count @= 1`).
10. Spec section 5: "An unused binding or parameter is a compile error, and so is a cell nothing re-binds" Governs: `xs` used on lines 3 and 4 (in `sorted_desc`) and on lines 15 and 20 (in `runs`); `n` used on lines 3, 5 and 6 and on lines 15, 16 and 19; `v` re-bound on lines 9 and 10 and returned on line 11; `t` used on line 10; `count` re-bound on line 21 and returned on line 22; `i` and `j` used in the loop bounds and the indexing; `x` used on line 26.
11. Spec section 5: "Shadowing is a compile error" Governs lines 5 and 6 (`i` and `j` each bound once in `sorted_desc`) and line 19 (`i` in `runs`, a separate function scope).
12. Spec section 5 grammar: "Binding = [ ":" Type ] ( "$=" | "@=" ) Expression NEWLINE" Governs the annotated bindings `n: i64 $= xs.len()` on lines 3 and 15.
13. Spec section 7: "both sides one numeric type" (from the arithmetic row) Governs line 6 (`n - 1 - i`), lines 9 and 10 (`v[j + 1]`), line 20 (`i - 1`) and line 21 (`count + 1`).
14. Spec section 7 precedence: "call, `.` and `::` → unary `-` `!` `~` → `* / %` → `+ -`" Governs line 6 (`n - 1 - i` parses as `(n - 1) - i`) and line 20 (`xs[i - 1]`).
15. Spec section 7 comparison: "`==` is structural equality on any two values of one type" and "`< <= > >=`: a number only" Governs line 7 (`<` on `i64` values), line 16 (`==`) and line 20 (`!=`).
16. Spec section 8: "`if cond` / `else if` / `else` take only `bool`" Governs line 7 (`v[j] < v[j + 1]` is `bool`), line 16 (`n == 0`) and line 20 (`xs[i] != xs[i - 1]`).
17. Spec section 8: "`if` and `match` are expressions and may stand as statements" Governs the `if` statements on lines 7, 16 and 20.
18. Spec section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 5, 6, 19 and 25.
19. Spec section 8 grammar: "For = "for" ident "in" Expression Block ." Governs the four `for` lines (5, 6, 19, 25).
20. Spec section 8: "A function with a `->` must `return` on every path that reaches its end" Governs line 11 (end of `sorted_desc`), line 22 (end of `runs`), and line 17 (early return when `n` is 0, so that the path through line 19 reaches line 22 only when `n` is not 0).
21. Spec section 8: "A statement after a jump, in its block, is a compile error." Governs lines 17 and 18: `return 0` is the last statement of its block, and `count @= 1` sits outside that block.
22. Spec section 9 (UFCS): "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs `xs.len()` on lines 3 and 15; `len` is called as `xs.len()`.
23. Spec section 9 (named arguments): "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs the `range(from: ..., to: ...)` calls on lines 5, 6 and 19, since `from` and `to` share `i64`.
24. Spec section 11: "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`." Governs lines 5 and 6 (`i` runs `0` to `n - 1`, and `j` runs to `n - 2 - i`) and line 19 (`i` runs `1` to `n - 1`).
25. Spec section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 26 and 27.
26. Spec section 10: "An out-of-bounds index or slice aborts" Governs lines 7, 9 and 10 (`v[j]` and `v[j + 1]` with `j` at most `n - 2`) and line 20 (`xs[i]` and `xs[i - 1]` with `i` from 1 to `n - 1`), so no index goes out of bounds.
27. Spec section 1 and section 4 grammar: "Param = "@" ident ":" Type | ident ":" Type [ "lent" ]" Governs the signatures on lines 2 and 14, which use neither `@` nor `lent`, so `xs` is a plain parameter that the body copies rather than mutates.

## choice_points

1. **Type of `len` (lines 3 and 15).** The spec never states the result type of `len` or `xs.len()`. I chose `n: i64 $= xs.len()`, assuming it yields `i64`. Other choice: leave `n` unannotated. If `len` yields a type other than `i64`, the annotated version is refused with a type mismatch (no implicit conversions), and the unannotated version is refused at `range(from: 0, to: n)` and at `n - 1 - i`, since `range` takes `i64`.
2. **Copy of the input (line 4).** I wrote `v @= xs` to get a mutable working copy, because `xs` is not an `@` parameter. Other choice: none is available with the required signature. Using `xs` directly would fail, since a plain parameter cannot be re-bound.
3. **Loop shape of the sort (lines 5 to 10).** I chose two nested `for` loops with a shrinking inner bound. Other choice: a `while` loop with a "swapped" flag cell. Output is the same; the flag version would stop early on sorted input.
4. **Direction of the swap (line 7).** I swap when the left element is smaller (`<`), which yields descending order. Other choice: `>` swaps when the left is larger, producing ascending order (`1 1 2 3 4 5 6 9`), which does not meet the task.
5. **Equal neighbours (line 7).** I use strict `<`, so equal elements are never swapped. Other choice: `<=`. For integers the printed output is identical; only the number of swaps differs.
6. **Inner bound (line 6).** I used `n - 1 - i`, so each pass skips the already-placed tail. Other choice: `n - 1` on every pass. Output is identical; the work is larger.
7. **Empty input in `runs` (lines 16 and 17).** I return `0` early. Other choice: start `count` at `0` and add one for index `0` (or use `||` to short-circuit the index read). Both give `0` for empty input and the same count otherwise.
8. **Starting index of `runs` (line 19).** I start at `1` and compare with `i - 1`. Other choice: start at `0` with a special case for the first element. Results are the same.
9. **Call form of `len` (lines 3 and 15).** I used `xs.len()` (UFCS), the form the spec's own example uses. Other choice: the call form `len(xs)`, which the spec's sugar rule makes equivalent.
10. **Reuse of `i` in both functions (lines 5 and 19).** Allowed because each function has its own scope. Other choice: distinct names, which would not change behaviour.
11. **Comments (lines 1 and 13).** I included one comment above each helper function. Other choice: no comments; the checker does not need them.
12. **Index type (lines 7, 9, 10, 20).** The spec does not say which integer type an array index must have. I index with `i64` values, the type of the loop variables. Other choice: a different integer type would need explicit conversions, which the spec does not describe.

## confidence

I am about 80 percent sure the checker accepts this program on the first try. I could not run it, and I have only the spec to go on.

The line I am least sure of is line 3 (and its twin, line 15): `n: i64 $= xs.len()`. The spec never says what `len` returns, so the annotation may be wrong. Every other line rests on a sentence I quote above.

## context

Nothing outside this directory's files reached my context as document content. I read `brief.md`, `spec.md`, `run.json` and `run.err`, all in this directory. `run.json` and `run.err` are both empty.

The session's environment information also reached my context: the working directory path, the platform and shell, the scratchpad path, a git status snapshot (branch and recent commit names), and a user identity note. None of that is content from the spec or the brief, and I did not use it in the program. I used no other tool and ran nothing.
