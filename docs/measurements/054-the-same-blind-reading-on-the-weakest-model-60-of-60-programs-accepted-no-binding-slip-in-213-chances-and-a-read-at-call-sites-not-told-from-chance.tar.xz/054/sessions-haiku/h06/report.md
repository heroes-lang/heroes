## program

```
# One item of stock: a name and how many are held.
record Item
    name: str
    qty: i64

# Adds n to the item called name, or appends a new item with qty n.
function restock(@items: [Item], name: str, n: i64)
    i @= 0
    while i < items.len()
        if items[i].name == name
            items[i].qty @ items[i].qty + n
            return
        i @ i + 1
    items @ items.push(Item(name: name, qty: n))

# Subtracts n from the item called name when it holds at least n.
function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    while i < items.len()
        if items[i].name == name
            if items[i].qty < n
                return false
            items[i].qty @ items[i].qty - n
            return true
        i @ i + 1
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    taken = take(@items, "apple", 5)
    print(taken)
    pear_taken = take(@items, "pear", 9)
    print(pear_taken)
    total @= 0
    for item in items
        total @ total + item.qty
    print(total)
```

Expected output, by hand: `true`, `false`, `4`. Apple goes to 7, then 5 is taken leaving 2. Pear stays at 2, so taking 9 fails. The sum is 2 + 2 = 4.

## sentences

Line numbers refer to the program above, counting the first line of the block as line 1.

1. "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 28 to 40, the `main` function.
2. "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`, and a variant's case `.num(v: 7)` or `.plus`." Governs line 14, `Item(name: name, qty: n)`.
3. "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`" Governs line 7 (`@items` in the signature), line 17 (`@items` in the signature), and lines 30 to 33 and 35 (`@items` at each call site).
4. "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs lines 8, 18, 29, 37 (the `@=` cells) and lines 11, 14, 23, 25, 39 (the `@` re-bindings, including the element re-bindings `items[i].qty @` on lines 11 and 23 and the `items @` re-binding of the parameter on line 14).
5. "An empty one needs an annotation: `xs: [i64] = []`" Governs line 29, `items: [Item] @= []`, which is annotated as `[Item]`.
6. "`xs @ xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array" Governs line 14, `items @ items.push(...)`, where `items` is a plain name.
7. "Built-ins: `print(...)` · `len` · `push` ..." together with the example "`xs.len() == 0`" in section 6. Governs lines 9 and 19, `items.len()`.
8. "A literal takes the type its context asks for ... otherwise `i64`." Governs lines 8, 18, 37 (the `0` values, which take `i64` by default), and lines 30 to 33 and 35 (the `3`, `5`, `2`, `4`, `9` arguments, which take `i64` from the parameter types).
9. "`< <= > >=`: a number only" Governs lines 9, 19 and 21.
10. "`==` is structural equality on any two values of one type, recursively" Governs lines 10 and 20, the `str` comparisons `items[i].name == name`.
11. "`if cond` / `else if` / `else` take only `bool`" followed by "there is no truthiness." Governs lines 10, 20 and 21, each `if` condition, which is a `bool` expression.
12. "No braces, no semicolons; a condition needs no parentheses." Governs lines 9, 10, 19, 20 and 21, which use the condition without parentheses.
13. "Loops: `while cond` and `for x in xs`, over an array or a `range`" Governs lines 9 and 19 (`while`) and lines 38 and 39 (`for item in items`).
14. "A function with a `->` must `return` on every path that reaches its end" Governs lines 17 to 26, `take`, which ends with `return false` on line 26 and has no path that falls out of the end.
15. "A statement after a jump, in its block, is a compile error." Governs lines 11 to 12 and 23 to 24, where each `return` is the last statement of its block.
16. "Overflow aborts at every width." Governs lines 11, 14, 23 and 39, the `+` and `-` arithmetic on `i64` values.
17. "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 34, 36 and 40.
18. "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting" Governs lines 7 and 17 (`@items` is written), lines 8, 18 and 37 (the cells are re-bound), and lines 7, 17, 33, 35, 14 and 26 (every parameter and binding is read or passed).
19. "Shadowing is a compile error" Governs the file as a whole: `items` in `main` and in the two `@items` parameters do not nest, and no name is bound twice in one scope.
20. "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every indented line of the program.
21. "Declaration order never matters but a group's" Governs the order of `record Item`, `restock`, `take` and `main`.
22. "Signatures are always explicit; inference is local only." Governs lines 7, 17 and 28, the signatures, which spell out parameter and return types (`main` takes and returns nothing).
23. "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it" Governs lines 1, 6 and 16, which are comments above a declaration.

## choice_points

1. **Iteration over `items`.** I used an index cell `i` and a `while` loop. The other choice is a `for` loop over `items`, but its loop variable is a copy, so it cannot update an element in place. Doing the update through a `for` loop would need a rebuilt array, for example `items @ items.map(...)` with top-level helper functions. That would work but is longer and adds more lines the checker must accept.
2. **Stop on finding the name.** `restock` returns early with a bare `return` when it finds the name. The other choice is a `found @= false` flag, set in the loop and tested after it with `if found == false`. Both produce the same output. The flag form adds a cell that must be re-bound and read.
3. **Argument form at call sites.** I passed arguments by position: `restock(@items, "apple", 3)`. The other choice is named arguments: `restock(@items, name: "apple", n: 3)`. The spec only makes names mandatory when two parameters share a type, which is not the case here, so both should compile. The output is the same.
4. **Result names in `main`.** I bound each `take` result to a name (`taken`, `pear_taken`) before printing. The other choice is `print(take(@items, "apple", 5))`, which nests an `@` argument inside a call. Both compile. I bound the results to keep the `@` argument out of the `print` call.
5. **Type of counters and totals.** I left `i` and `total` unannotated (`@= 0`), so they take `i64` by default. The other choice is `i: i64 @= 0`, which says the same thing explicitly. The spec's inference rule gives the same type, so either works.
6. **Annotation on the empty list.** I wrote `items: [Item] @= []`, because the spec requires an annotation for an empty container. The other choice, `items @= []`, is refused by that rule.
7. **Summing the quantities.** I used a `for` loop with a cell `total`. The other choice is `fold`, which needs a top-level function with the right signature. The loop is simpler here.
8. **Missing name and short quantity in `take`.** Both return `false` and change nothing. The other choice would be to distinguish them, but the brief asks only for `false`. In `take`, the quantity check comes before any write, so a `false` result leaves the list unchanged. The other order, subtracting first and then checking, would break the "changes nothing" rule.
9. **Comments.** I included comments, all in ASCII with no em dashes. The other choice is to leave them out. Comments do not change the program, so this has no effect on the checker.

## confidence

About 85% that the checker accepts the program as written, with no edits. I am not certain of the following:

- The least certain line is line 9 (and its copy on line 19), `while i < items.len()`. The spec lists `len` as a built-in and shows `xs.len() == 0` in section 6, but it never states what type `len` returns. My comparison assumes `len` returns a type that compares with `i64`. If `len` returns another integer type, the comparison would be rejected.
- Line 11 and line 23 write through an index into an `@` parameter (`items[i].qty @ ...`). Section 5 says `@` re-binds "a field or element inside one", so I believe this is allowed, but I have not seen an example with an `@` parameter.
- Line 14 re-binds the `@` parameter with `items @ items.push(...)`. The spec says this grows in place when the name is plain, and `items` is a plain parameter name here, so I believe it is valid.

## context

I read four files in this directory: `brief.md`, `spec.md`, `run.json` and `run.err`. The last two are empty. I did not read any file outside this directory and used no other tool. The session context included environment and git information provided by the harness, such as the working directory, the platform, and a git status listing. I did not use any of it in the program or this report.
