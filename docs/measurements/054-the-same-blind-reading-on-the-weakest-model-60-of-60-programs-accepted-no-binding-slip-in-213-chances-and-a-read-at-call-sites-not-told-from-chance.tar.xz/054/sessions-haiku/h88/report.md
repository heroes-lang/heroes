## verdict

Refused, on two lines:

- **Line 20** (`step = 2`). `step` is bound by `:=` on line 10, and `:=` binds once, forever. Only a mutable cell (`@=`) may be re-bound with `=`.
- **Line 22** (`last @= words[0]`). `last` is a mutable cell that nothing re-binds. Line 25 only reads it, and a read is not a write, so the cell is a compile error.

Everything else in the file is accepted as far as the specification reads. Smallest accepted change (see `program`): line 10 `step := 1` becomes `step @= 1`, and line 22 `last @= words[0]` becomes `last := words[0]`. The corrected program prints:

```
5
5
a
```

Trace: `counts` ends with `a` = 3, `b` = 1, `c` = 1. The loop adds `step` (1) five times, so `total` = 5. `bump(@c, 3)` gives `c.hits` = 3, and `bump(@c, 2)` gives 5. `last` is `"a"`.

## lines

| line | source | classification | words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* (parameter `c`, in `bump`'s scope) | Section 4 `Param = "@" ident ":" Type`; section 9 "Mutable parameters are marked `@` in the signature" |
| 6 | `c.hits = c.hits + by` | *changes an existing name* (field `c.hits`) | Section 5 "`=` re-binds it, or a field or element inside one"; section 5 `Place = ident { "." ident ...}` |
| 9 | `words := ["a", "b", "a", "c", "a"]` | *new name* | Section 5 "`:=` binds once, forever" |
| 10 | `step := 1` | *new name* | Section 5 "`:=` binds once, forever" |
| 11 | `counts: {str: i64} @= {}` | *new name* | Section 5 "`@=` declares a mutable cell" |
| 12 | `total @= 0` | *new name* | Section 5 "`@=` declares a mutable cell" |
| 15 | `counts[w] = counts[w].default(0) + step` | *changes an existing name* (element of cell `counts`) | Section 5 "`=` re-binds it, or a field or element inside one"; section 10 "`m[k] = v` inserts or replaces" |
| 16 | `total = total + step` | *changes an existing name* (cell `total`) | Section 5 "`=` re-binds it" |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | Section 5 "`@=` declares a mutable cell" |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* (`c`, through the `@` argument) | Section 9 "the callee works on the caller's place itself"; section 5 "an `@` argument counting" (toward a cell being re-bound) |
| 20 | `step = 2` | *changes an existing name* in intent (`step`), and refused: `step` is a `:=` name | Section 5 "`:=` binds once, forever" and "`=` re-binds it" (only a cell) |
| 21 | `bump(@c, step)` | *changes an existing name* (`c`, through the `@` argument) | Section 9 "the callee works on the caller's place itself" |
| 22 | `last @= words[0]` | *new name* (but refused: nothing re-binds `last`) | Section 5 "`@=` declares a mutable cell"; section 5 "a cell nothing re-binds ... is a compile error; a read is a use and a write is not" |

## sentences

Sentences the verdict rests on, quoted from `spec.md`:

- Section 5: "`:=` binds once, forever. `@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
- Section 5 grammar: "Binding = [ ":" Type ] ( ":=" | "@=" ) Expression NEWLINE ."
- Section 5 grammar: "Simple = "_" Binding | Place "=" Expression NEWLINE"
- Section 5 grammar: "Place = ident { "." ident | "[" Expression "]" } ."
- Section 5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it."
- Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`"
- Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
- Section 4 grammar: "Param = "@" ident ":" Type | ident ":" Type [ "lent" ] ."
- Section 2: "A literal takes the type its context asks for ... otherwise `i64`."
- Section 10: "`m[k] = v` inserts or replaces"
- Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
- Section 6: "`.default(v)` extract or fall back" (table row; used on lines 15 and 19 and accepted)
- Section 1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."

## program

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits = c.hits + by

function main()
    words := ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] = counts[w].default(0) + step
        total = total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step = 2
    bump(@c, step)
    last := words[0]
    print(c.hits)
    print(total)
    print(last)
```

Output: `5`, `5`, `a`, one per line.

## choice_points

1. **Fixing line 20.** I made `step` a cell by changing line 10 to `step @= 1`, so the original `step = 2` and `bump(@c, step)` keep their meaning. The other choice was to keep line 10 and rename the second value: `step2 := 2` on line 20 and `bump(@c, step2)` on line 21. That is also accepted and prints the same `5`, `5`, `a`. It changes the text more, so I did not choose it.
2. **Fixing line 22.** I changed `last @= words[0]` to `last := words[0]`, since `last` is never re-bound. The other choice was to keep the cell and add a re-binding (for example `last = last`), which is artificial. Deleting the cell and printing `words[0]` directly would also print `a`, but it changes more lines.
3. **Classifying line 19 and line 21.** I classed the `@` argument as *changes an existing name*, because the callee writes the caller's place and section 5 counts an `@` argument as a re-binding. The other reading would be *neither*, since no `=` appears on the line. I think *changes* is correct.
4. **Classifying line 5.** I classed the `@c` parameter as *new name*, since it brings `c` into `bump`'s scope. The other reading would be *neither*, because the parameter is an alias for the caller's place. I think *new name* is the closer fit to section 4.
5. **Classifying line 20.** I classed it as *changes an existing name*, because that is what the line tries to do. The checker refuses it, so the change never happens. The other reading would be *neither*.
6. **Where the refusal is reported.** I assumed the checker reports the line-20 refusal on line 20 and the line-22 refusal on line 22. A checker could report the line-22 problem at its declaration (line 22 is the declaration, so this agrees). I did not consider any other site.

## confidence

- High (about 90%) that the program is refused on lines 20 and 22. Those two refusals follow directly from the quoted sentences of section 5, with no reading of unclear text needed.
- High that the corrected program is accepted and prints `5`, `5`, `a`. I checked each name for an unused binding, a re-binding, and an `@` argument.
- Less sure (about 75%) about the category labels for lines 5, 19, 20 and 21. The spec does not define "changes an existing name" or "new name" as terms; I applied them using section 5 and section 9.
- Least sure about the layout check: I read the file as plain spaces with 4-space indentation, but I cannot verify the absence of tab characters beyond what the file view shows.
- I have not run anything, so the output is derived from the specification, not from a built binary.

## context

Only three files reached my context from this directory: `brief.md`, `spec.md` and `main.hero`. I read all three in full, and I read no other file and used no tool beyond reading and writing files in this directory.

The session's environment notes reached my context but were not files I opened. They mention a git status listing `run.err` and `run.json` as untracked, and they give a scratchpad path. I did not read either file, and neither affected the verdict.
