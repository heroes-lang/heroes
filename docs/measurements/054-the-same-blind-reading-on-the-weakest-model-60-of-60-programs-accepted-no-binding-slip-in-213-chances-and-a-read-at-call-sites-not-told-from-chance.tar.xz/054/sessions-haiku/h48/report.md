# Report

## program

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    updated: [Item] @= []
    found @= false
    for it in items
        if it.name == name
            updated @ updated.push(Item(name: name, qty: it.qty + n))
            found @ true
        else
            updated @ updated.push(it)
    if !found
        updated @ updated.push(Item(name: name, qty: n))
    items @ updated

function take(@items: [Item], name: str, n: i64) -> bool
    updated: [Item] @= []
    hit @= false
    for it in items
        if it.name == name && it.qty >= n
            updated @ updated.push(Item(name: name, qty: it.qty - n))
            hit @ true
        else
            updated @ updated.push(it)
    if hit
        items @ updated
    return hit

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    apple_ok = take(@items, "apple", 5)
    pear_ok = take(@items, "pear", 9)
    print(apple_ok)
    print(pear_ok)
    total @= 0
    for it in items
        total @ total + it.qty
    print(total)
```

Expected output, if the program runs as the specification reads: `true`, `false`, `4`.
(apple 3+4 = 7, take 5 leaves 2; pear 2, take 9 fails and leaves 2; sum 2+2 = 4.)

Line numbers used below refer to the block above, counted from its first line.

## sentences

Governing lines are given after each quoted sentence.

1. §1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs lines 31-43 (`main`, no `->`, no return).
2. §1: "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error." Governs every line; all indentation is 4 spaces per level (function bodies 4, `if`/`for` bodies 8, nested `if` bodies 12).
3. §4: "Declaration = "constant" ident ":" Type Block | "function" ident [ Generics ] Params [ "->" Type ] Block | "record" ident Fields" (grammar). Governs lines 1-3 (`record Item` with its `Fields`), 5, 18, 31.
4. §5: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs the cells `updated`, `found`, `hit`, `total` and `items` (lines 6, 7, 19, 20, 32, 40), and their re-bindings (lines 10, 11, 13, 15, 16, 23, 24, 26, 28, 42).
5. §5: "Signatures are always explicit; inference is local only." Governs the signatures on lines 5 and 18 (`@items: [Item]`, `name: str`, `n: i64`, `-> bool`) and the inferred types of cells `found`, `hit`, `total` (lines 7, 20, 40), which are `bool`, `bool`, `i64` from their initialisers.
6. §5: "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter." Governs lines 6-7, 19-20, 32, 40 (each cell is read: `updated` at lines 10-16 and 23-28, `found` at line 14, `hit` at line 27, `total` at lines 42-43, `apple_ok` and `pear_ok` at lines 38-39), and the `@` parameters `items` in `restock` and `take` (written at lines 16 and 28) and the `@` arguments in `main` (lines 33-37).
7. §5: "A line that computes a value must use it: bind it, or discard it on purpose with `_ = f(x)`, which a `()` line refuses: it stands alone." Governs lines 33-35: `restock` returns `()`, so each call stands alone with no `_ =`.
8. §5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs the loop variable `it` (lines 8, 21, 41): I read this sentence as limited to names bound by `use`; the program has no `use`, and each `it` is in a separate function, so no name is taken twice in one scope.
9. §9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`" Governs lines 5 and 18 (`@items` in the signature) and lines 33-37 (`@items` at each call site).
10. §9: "When two parameters in a signature share a type, named arguments are mandatory at the call site" Governs lines 33-37: the parameters `name: str` and `n: i64` do not share a type, so positional arguments are allowed.
11. §9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`" Governs lines 10, 15 and 23 (`Item(name: name, qty: ...)`).
12. §9: "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs lines 10, 13, 15, 23, 26 (`updated.push(...)`, `items.` not used; `push` is a built-in on `updated`), 16 and 28 (`items @ updated`) are plain assignments, not UFCS.
13. §10: "`xs @ xs.push(4)` grows in place when `xs` is a plain name; reached through a field or an index it copies the whole array, so lend the array itself to an `@` parameter or hoist it into a name." Governs lines 10, 13, 15, 23, 26: each `updated @ updated.push(...)` is on a plain name. Lines 16 and 28 write `items`, which is a plain name (an `@` parameter).
14. §10: "an empty one needs an annotation: `xs: [i64] = []` · `m: {str: i64} @= {}`." Governs lines 6, 19, 32: each empty list has an annotation `[Item] @= []`.
15. §7: "`==` is structural equality on any two values of one type, recursively" Governs lines 9 and 22 (`it.name == name`, both `str`).
16. §7: "comparison `< <= > >=`: a number only" Governs line 22 (`it.qty >= n`, both `i64`).
17. §7: "boolean && || !  (bool only; && and || short-circuit)" Governs line 14 (`!found`, `found` is `bool`) and line 22 (`&&`, both operands `bool`).
18. §7: "both sides one numeric type" Governs lines 10 and 23 (`it.qty + n`, `it.qty - n`, both `i64`) and line 42 (`total + it.qty`, both `i64`).
19. §8: "`if cond` / `else if` / `else` take only `bool`" Governs lines 9, 14, 22 and 27 (conditions `it.name == name`, `!found`, `it.name == name && it.qty >= n`, `hit`); each is `bool`.
20. §8: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)." Governs lines 8, 21 and 41 (`for it in items`, `items` an array).
21. §8: "A function with a `->` must `return` on every path that reaches its end" Governs lines 18-29: `take` ends with `return hit` on line 29, which is the only path to its end.
22. §2: "A literal takes the type its context asks for ... otherwise `i64`." Governs line 40 (`total @= 0` is `i64`) and the literals `3`, `2`, `4`, `5`, `9` on lines 33-37 (their context is the `i64` parameter `n`).
23. §3: "No implicit conversions, widths included" Governs lines 10, 22, 23 and 42: every operand is `i64` or `str`, so no conversion is needed.
24. §11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." Governs lines 38, 39 and 43.
25. §11: "a `bool` prints `true` or `false`." Governs lines 38 and 39.
26. §12 (not in the program): "`test` blocks run only when asked for" No tests are written; the checker sees only `main`, `restock` and `take`.

## choice_points

1. **Finding an item.** I rebuild the list (`updated`, lines 6-16 and 19-29) by looping over `items` and pushing each item into a new array, then write it back. The other choice was an index loop, `while i < len(items)` with `items[i].qty @ ...` (`Place` allows `[Expression]`). That choice would also compile if `len` returns `i64`, but the specification gives `len` no return type (section 11 lists it bare), so `i < len(items)` could fail on a width mismatch. I avoided that risk.
2. **Writing back.** `items @ updated` (lines 16, 28) replaces the whole array. The other choice was in-place element writes, `items[i].qty @ items[i].qty + n` (after finding `i`). The output is the same; only cost and the `len` question differ.
3. **Write-back guard in `take`.** Line 27 writes back only `if hit`. The other choice, always writing `items @ updated`, gives the same result because `updated` equals `items` when nothing matches. I kept the guard so that a failed take visibly changes nothing.
4. **Loop source.** I iterate `for it in items` and build `updated` separately, so `items` is not written while it is being iterated. The other choice was to write `items` inside the loop, which is riskier under the rule that the callee works on the caller's place itself.
5. **Argument style.** `restock(@items, "apple", 3)` is positional. The other choice, `restock(@items, name: "apple", n: 3)`, is also valid because named arguments are optional here (the mandatory rule does not apply). Same output.
6. **Printing the take results.** I bind `apple_ok` and `pear_ok` first, instead of `print(take(@items, "apple", 5))`. The other choice puts an `@` argument inside another call's arguments, which the text does not clearly allow. Same output.
7. **Sum type.** `total @= 0` is inferred `i64` (the default). The other choice, `total: i64 @= 0`, is identical; I left the default.
8. **Naming of flags.** I use `found` for `restock` and `hit` for `take`, so the two functions do not share a name. The other choice (any other name) changes nothing.
9. **Reading of `@` parameter writes.** In `take`, `items` is written only on one path (line 28). I read that as "written" for the rule about unused `@` parameters. The other reading (a parameter is written only if written on every path) would make line 28 an error, but the text does not say so.

## confidence

About 85% that the checker accepts the program as written, given the specification alone. I could not run the checker.

Least sure line: 16 and 28, `items @ updated`. The specification says `@` re-binds a cell, a field, or an element, and that an `@` parameter must be written or ended. It does not say in so many words that a whole `@` parameter may be re-bound by `@`. I read it as a cell, which is how `items` is used in `main` too (line 32).

Other lines of some doubt: line 27-28 (the conditional write to `items`, see choice point 9), and line 8/21/41 (`for` over an `@` parameter), which the text permits but does not show with an `@` parameter.

## context

Only the files of this directory reached my context: `brief.md`, `spec.md`, and `run.json` and `run.err`, which are both empty. I read no file outside this directory and used no tool other than reading and writing files here. I used no outside sources and did not consult any other documentation of Heroes.
