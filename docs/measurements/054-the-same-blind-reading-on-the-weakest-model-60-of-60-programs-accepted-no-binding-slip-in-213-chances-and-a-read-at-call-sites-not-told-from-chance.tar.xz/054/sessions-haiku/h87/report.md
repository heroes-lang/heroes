## program

Line numbers below count from the first line of this block as line 1.

```
record Item
    name: str
    qty: i64

function restock(@items: [Item], name: str, n: i64)
    i @= 0
    found @= false
    for item in items
        if !found
            if item.name == name
                found @ true
            else
                i @ i + 1
    if found
        items[i].qty @ items[i].qty + n
    else
        items @ items.push(Item(name: name, qty: n))

function take(@items: [Item], name: str, n: i64) -> bool
    i @= 0
    found @= false
    for item in items
        if !found
            if item.name == name
                found @ true
            else
                i @ i + 1
    if found && items[i].qty >= n
        items[i].qty @ items[i].qty - n
        return true
    return false

function main()
    items: [Item] @= []
    restock(@items, "apple", 3)
    restock(@items, "pear", 2)
    restock(@items, "apple", 4)
    first = take(@items, "apple", 5)
    second = take(@items, "pear", 9)
    print(first)
    print(second)
    total @= 0
    for item in items
        total @ total + item.qty
    print(total)
```

Expected output: `true`, `false`, `4`, one per line.

## sentences

Quotations are from `spec.md`. Where a quotation is a fragment, `...` marks the omitted part.

- Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing." Governs line 33 (`function main()`).
- Section 2: "A literal takes the type its context asks for ... otherwise `i64`." Governs lines 6, 7, 20, 21, 34, 42 (the literals `0`, `false`, `3`, `2`, `4`, `5`, `9`, `[]`). `i`, `total`, `n` and `qty` come out as `i64`.
- Section 2: "One `i64` is `0x1f` `0o37` `0b11111` or `31`, with `_` between any two digits. A leading zero is an error, never octal." Governs the literal `0` on lines 6, 20 and 42. I read a lone `0` as having no leading zero. See choice_points.
- Section 4: "Every top-level line starts with its kind." Governs lines 1, 5, 19 and 33.
- Section 4 `Declaration` grammar: `function ident Params [ "->" Type ] Block` and `record ident Fields`. Governs lines 1-3 (record `Item`), 5 and 19 (signatures with and without `->`), and 33 (`main`).
- Section 5: "`@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one." Governs lines 6, 7, 11, 13, 15, 17, 20, 21, 25, 27, 29, 34, 42 and 44. Lines 15 and 29 re-bind a field of an element (`items[i].qty`). Lines 17 and 44 re-bind a whole cell.
- Section 5: "All bindings are initialised." Governs lines 6, 7, 20, 21, 34 and 42. Each cell is given `0`, `false` or `[]` when declared.
- Section 5: "An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends ... a read is a use and a write is not, except through an `@` parameter." Governs lines 6 and 7 (`i`, `found`, both read and re-bound), lines 5 and 19 (`items` is written by line 17 and by line 29), lines 38 and 39 (`first` and `second` are read by lines 40 and 41), line 42 (`total` is read on line 44 and line 45), and lines 8 and 22 (`item` is read).
- Section 5: "Shadowing is a compile error: a `use` binds its name for the whole file, so nothing else in the file may take it." Governs lines 8, 22 and 43 (the loop variable `item` is bound in three separate scopes, none nested inside another that binds it). There are no `use` lines.
- Section 7: "`&&` and `||` short-circuit" (table row: "bool only; && and || short-circuit"). Governs line 9 (`!found`), line 28 (`found && items[i].qty >= n`) and the loop guard in the design. Line 28 relies on this: `items[i]` is evaluated only when `found` is true.
- Section 7: precedence "unary `-` `!` `~`" binds tighter than "`* / %`", and comparisons bind tighter than "`&&`". Governs line 28, where `>=` and `&&` combine as `(found) && (items[i].qty >= n)`, and line 9, where `!found` is a unary `!`.
- Section 7 (table row `==`): "`==` is structural equality on any two values of one type, recursively". Governs lines 10 and 24 (`item.name == name`, both `str`).
- Section 7: "`+` ... (both sides one numeric type ...)" (arithmetic row). Governs lines 15, 17 (`items[i].qty + n`, `i + 1`), 29, 44. All operands are `i64`.
- Section 8: "`if` and `match` are expressions and may stand as statements" and "`if cond` / `else if` / `else` take only `bool`". Governs the `if` and `else` pairs on lines 9-13, 14-17, 23-27 and 28-31. Each condition is `bool`: `!found`, `item.name == name`, `found`, `found && items[i].qty >= n`.
- Section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range`." Governs lines 8, 22 and 43 (`for item in items`, where `items` is an array parameter or cell).
- Section 8: "A function with a `->` must `return` on every path that reaches its end." Governs lines 19-31 (`take`): the path through line 30 returns `true`, and line 31 returns `false` on every other path.
- Section 8: "A statement after a jump, in its block, is a compile error." Governs lines 29-31. `return true` on line 30 is the last statement of its block, and `return false` on line 31 is not in the same block.
- Section 9: "Record construction is a call with field names, always mandatory: `Point(x: 3, y: 4)`." Governs line 17 (`Item(name: name, qty: n)`).
- Section 9: "When two parameters in a signature share a type, named arguments are mandatory at the call site." Does not apply here: the parameters of `restock` and `take` are `[Item]`, `str` and `i64`, with no repeated type. Governs lines 5, 19 and 35-39 (positional calls are accepted).
- Section 9: "Mutable parameters are marked `@` in the signature and at the call site." Governs lines 5 and 19 (`@items` in the signature) and lines 35-39 (`@items` at each call site).
- Section 9: "`x.f(y)` is sugar for `f(x, y)` (UFCS)." Governs line 17 (`items.push(...)`, read as `push(items, ...)`).
- Section 10: "an empty one needs an annotation: `xs: [i64] = []`". Governs line 34 (`items: [Item] @= []`).
- Section 10: "`xs @ xs.push(4)` grows in place when `xs` is a plain name". Governs line 17. `items` is a plain name (a parameter), so the append is done in place.
- Section 10: "An out-of-bounds index or slice aborts". Governs lines 15 and 28-29. Both index `items[i]` are reached only when `found` is true, and `i` was set by the loop to the position of the matching element, so the index is in bounds.
- Section 11: "Built-ins: `print(...)` · `len` · `push` ...". Governs `print` on lines 40, 41 and 45, and `push` on line 17.
- Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`." and "a `bool` prints `true` or `false`." Governs lines 40 and 41, which print the two `bool` results. Line 45 prints an `i64`.

## choice_points

1. **Finding the item: loop with a counter vs `find`.** I chose a `for` loop that keeps an index `i` and a flag `found`. `find` takes a predicate function, and the language has no closures or anonymous functions. A named top-level predicate cannot see `name`, so it cannot test for the item. I also did not use `while i < len(items)`, because the spec does not state the return type of `len`. A type mismatch against the `i64` counter would be an error, so I avoided the call.
2. **Iteration over the array vs an index loop.** I iterate with `for item in items` and count an index, then write through `items[i]` after the loop. Other choice: an index-based `while` with `len`, which has the `len` typing problem above. Writing `items[i]` inside the `for` body would also be less clear, and the spec does not say what `for` iterates over if the array changes during the loop. The loop I wrote never mutates `items` while it runs.
3. **Append: `items @ items.push(...)` vs `push(@items, ...)`.** The spec gives the in-place form `xs @ xs.push(4)` and states that it grows in place for a plain name. It does not show a `push` that takes `@`. I used the documented form. Other choice: `push(@items, ...)`, which the spec does not describe, so the checker might reject it.
4. **Early return vs flag in `restock`.** I used a `found` flag and one `if found` after the loop. Other choice: `return` inside the loop, since `restock` has no `->` and a bare `return` is allowed. The output is the same either way.
5. **`take` return path.** I wrote the success branch as an `if` with `return true`, then a final `return false`. Other choice: `if !found || items[i].qty < n` followed by `return false` and a final `return true`. The `&&` guard short-circuits, so `items[i]` is read only when `found` is true. The other order would read `items[i]` when `found` is false and `i` is past the end. That is an abort, so it would fail at run time.
6. **Summing.** I used a `for` loop with a `total` cell. Other choice: `fold` with a named two-parameter function (`acc`, `item`). That is possible, but the spec does not give `fold`'s exact signature, so the loop is the safer form. The output is the same either way.
7. **Loop variable name.** I used `item`. Other choice: `it`, `row` or `x`. None of them is reserved in the spec, and none changes behaviour.
8. **Literal typing.** Every literal is left to default to `i64`. The other choice, annotating `n: i64` or writing `: i64` on each cell, produces the same type and only adds noise.
9. **Literal `0` and the leading-zero rule.** I read `0` alone as the integer zero, not as a leading-zero literal. The other reading would make `0` an error and would require writing it another way, which the spec does not describe. This is the most significant interpretive choice in the program.
10. **Sum timing.** The sum is computed after both `take` calls, so it is 4. The other choice, summing before the takes, would give 9 (apple 7, pear 2). The brief says to print the sum of every item's `qty`, which I read as the state at the end.
11. **Field name `name` and parameter `name`.** The record field and the parameter share a name. I kept both, because field access `item.name` does not bind a name, so this does not trigger the shadowing rule. Other choice: rename the parameter, for example to `key`. The output would not change.

## confidence

About 85 percent that the checker accepts the program as written.

The line I am least sure of is line 17, `items @ items.push(Item(name: name, qty: n))`. The spec gives the in-place form only for a literal argument (`xs @ xs.push(4)`). I have assumed that a record construction as the argument is accepted the same way. The next least certain lines are line 8, `for item in items` over an `@` parameter, and line 9, which relies on `!` applied to a bool cell. Line 6, which uses the literal `0`, depends on the leading-zero reading in choice point 9.

## context

Nothing from outside this directory reached my context. The only files I read are the four in this directory: `brief.md`, `spec.md`, `run.json` and `run.err`. `run.json` and `run.err` came back empty, and I did not use them. I did not use any tool apart from reading those files and writing `report.md`. My context also contains the session's system and environment text (working directory, platform, date, model name and account details), which is not from a file in this directory and was not used in the program.
