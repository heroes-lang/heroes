## program

```heroes
# Sorts a copy of xs from largest to smallest by swapping adjacent out-of-order elements.
function sorted_desc(xs: [i64]) -> [i64]
    n: i64 := xs.len()
    ys @= xs
    for i in range(from: 0, to: n)
        for j in range(from: 0, to: n - 1 - i)
            if ys[j] < ys[j + 1]
                t := ys[j]
                ys[j] = ys[j + 1]
                ys[j + 1] = t
    return ys

# Counts the maximal groups of equal adjacent elements of xs.
function runs(xs: [i64]) -> i64
    if xs.len() == 0
        return 0
    count @= 1
    for i in range(from: 1, to: xs.len())
        if xs[i] != xs[i - 1]
            count = count + 1
    return count

function main()
    for v in sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])
        print(v)
    print(runs([1, 1, 2, 2, 2, 3, 1]))
```

Line numbers below refer to this block.

## sentences

Section 1, governs lines 23-26 (`main`):
- "the file you compile holds `function main()`, which takes nothing and produces nothing."

Section 1, governs lines 2, 14, 23 (indentation of every block):
- "Indentation is significant and rigid: exactly 4 spaces per level; a tab is a compile error."

Section 1, governs lines 1 and 13 (comments above declarations):
- "`#` comments to end of line, markdown inside. A comment directly above a declaration documents it"

Section 4, governs lines 2, 14, 23 (top-level declarations):
- "Every top-level line starts with its kind."
- "Declaration order never matters" (lines 23-26 call functions declared above them; the order is also valid the other way round)

Section 2, governs lines 16, 17, 26 (integer literals take the context type, else `i64`):
- "A literal takes the type its context asks for"

Section 3, governs lines 3, 15, 18 (`len` and the `i64` comparisons must agree in type):
- "No implicit conversions, widths included"

Section 3, governs lines 2, 3, 4, 7-10, 19-20 (array type and indexing):
- "`[T]` | dynamic array, indices from 0"

Section 5, governs line 4 (`ys @= xs`, a mutable cell):
- "`@=` declares a mutable cell, and `=` re-binds it, or a field or element inside one."
- "Every value behaves as an independent copy: after `b := a`, mutating `b` never changes `a`." (the copy keeps the caller's `xs` unchanged)

Section 5, governs lines 3, 8 (`:=` bindings):
- "`:=` binds once, forever."

Section 5, governs lines 2, 3, 14 (explicit signatures):
- "Signatures are always explicit; inference is local only."

Section 5, governs lines 4, 17 (cells that are re-bound, and parameters and bindings that are used):
- "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds"

Section 5 grammar, governs lines 9, 10 (element assignment):
- "`Place     = ident { "." ident | "[" Expression "]" } .`"

Section 7 operator table, governs lines 7, 19 (comparisons on numbers):
- "`< <= > >=`: a number only"
- The comparison row `==  !=  <  <=  >  >=` governs line 19 (`!=`).

Section 7, governs lines 6, 7, 8, 9, 10, 15, 19, 20 (arithmetic and index arithmetic cannot abort in these loops):
- "Overflow aborts at every width."

Section 8, governs lines 7, 15, 19 (conditions are `bool`):
- "`if cond` / `else if` / `else` take only `bool`"

Section 8, governs lines 7, 15, 19 (`if` as a statement):
- "`if` and `match` are expressions and may stand as statements"

Section 8, governs lines 11 and 21 (every path ends in a `return`):
- "A function with a `->` must `return` on every path that reaches its end"

Section 8, governs lines 5, 6, 18, 24 (loops over a `range` or an array):
- "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)."

Section 9, governs lines 15, 18 (UFCS, so `xs.len()` is `len(xs)`):
- "`x.f(y)` is sugar for `f(x, y)` (UFCS)."

Section 9, governs lines 5, 6, 18 (named arguments are mandatory when two parameters share a type):
- "When two parameters in a signature share a type, named arguments are mandatory at the call site"

Section 9, governs line 4 (no `@` mark is used, so the parameter is not mutated):
- "Mutable parameters are marked `@` in the signature and at the call site"

Section 11, governs lines 5, 6, 18 (`range` takes `from:` and `to:`, and excludes `to`):
- "`slice` and `range(from: a, to: b) -> [i64]` exclude `to`."

Section 11, governs lines 3, 15, 18 (`len` is a built-in; its result type is not stated, see choice points):
- "Built-ins: `print(...)` · `len` · `push`"

Section 11, governs lines 25, 26 (`print` of an `i64`):
- "`print` writes its values with no"
- "exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."

Section 4, governs lines 23-26 (`main` takes and returns nothing, and no `->` is written):
- "`function main()`, which takes nothing and produces nothing."

## choice_points

1. Sort algorithm and loop form (lines 5-10). Choice: nested `for` over `range`, with an inner bound `n - 1 - i` and a strict `<` test. Other choices: a `while` loop with `@=` counters, or `<=` as the test. The output is the same for `i64` values because equal elements are interchangeable. With `<=` the program would swap equal neighbours, which is wasted work but still terminates.

2. Swap form (lines 8-10). Choice: a temporary `t := ys[j]`. The spec has no tuple or multiple-assignment form, so the temporary is the only option that the grammar allows.

3. Mutating the input (lines 2-4). Choice: copy into a mutable cell `ys @= xs` and return it. Other choice: mark the parameter `@xs` and sort it in place. That would make the call site write `sorted_desc(@xs)`, and the caller's array would be changed, which the task does not ask for. The literal argument in `main` could not be passed as `@` anyway.

4. Type of `n` (line 3). Choice: annotate `n: i64` so the checker compares it with `i64`. Other choice: `n := xs.len()` with no annotation. The spec never states what `len` returns. If it is `i64`, both choices work. If it is another integer type, both fail, and the annotated form fails at the binding, which is the clearer place. The annotation is my reading of the spec, not something it requires.

5. Empty input to `runs` (lines 15-16). Choice: an early `return 0` when `xs.len() == 0`. Other choice: start `count @= 1` without the guard. That would read `xs[0]` on an empty array in the loop range, but the loop range would be empty, so the result would be 1 for `[]`, which is wrong. Without the guard the function would give the wrong answer for empty input, and it would not abort.

6. Range with `to` below `from`. Choice: never create one. The outer bound is `n` (at least 0), the inner bound is `n - 1 - i` with `i < n`, so it is at least 0, and `runs` uses `from: 1` only after the empty check. The spec does not say what `range` does when `to < from`, so I avoided that case.

7. Looping over `runs` from index 1 (line 18). Choice: `from: 1` with `xs[i - 1]`. Other choice: `from: 0` with a `count` that starts at 0 and a separate first-element check. The results are the same.

8. Iterating over the sort result in `main` (line 24). Choice: `for v in sorted_desc(...)`. Other choice: bind the result with `r := sorted_desc(...)` and then loop over `r`. Both are valid under section 5.

9. Call style (lines 24, 26). Choice: positional arguments, since the signature has one parameter and named arguments are only mandatory when two parameters share a type. Other choice: `sorted_desc(xs: [...])` and `runs(xs: [...])`, which the spec also allows.

10. Comments (lines 1, 13). Choice: one `#` line above each function, since the spec says a comment directly above a declaration documents it. Other choice: no comments. Output does not change.

## confidence

About 85% that the checker accepts the program as written, with no edits.

The line I am least sure of is line 3, `n: i64 := xs.len()`. The spec lists `len` as a built-in but never states its return type, and the annotation `i64` depends on that type. Line 6 (`for j in range(from: 0, to: n - 1 - i)`) is the next least certain, because the spec describes `range` only by its signature and says nothing about a negative or empty range; the program never produces `to < from`, but the checker might reason about it differently.

The remaining lines follow the spec's wording directly: the `@=` cell and its element re-bindings (lines 4, 9, 10, 17, 20), the early return and the final return (lines 15-16 and 21), named `range` arguments (lines 6 and 18), and `print` of `i64` (lines 25-26).

I cannot run the checker, so the confidence is from reading the spec only.

## context

Nothing outside this directory's files reached my context as file content. I read only `brief.md`, `spec.md`, `run.json` and `run.err`, all in this directory. `run.json` and `run.err` are empty. I wrote only `report.md` here.

Session metadata (the working directory and platform, a git status snapshot, the user's account identifier, the date and the model details) was present in my context from the environment. I did not use any of it for the program or this report.
