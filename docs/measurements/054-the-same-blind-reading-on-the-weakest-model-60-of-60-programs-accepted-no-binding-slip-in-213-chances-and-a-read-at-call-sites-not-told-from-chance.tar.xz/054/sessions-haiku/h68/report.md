# Report: main.hero against spec.md

## verdict

Refused. The checker would refuse `main.hero` as written, on two lines:

- **Line 20** `step @ 2`: `step` was bound on line 10 with `=`, which "binds once, forever". `@` re-binds only a mutable cell, so this re-binding of an immutable name is refused.
- **Line 22** `last @= words[0]`: `last` is a mutable cell that nothing re-binds. The spec makes "a cell nothing re-binds" a compile error. Line 25 only reads `last`, and a read is not a write.

Nothing else in the file is refused. Every other name is used, and `counts`, `total` and `c` are each re-bound by an `@` write or an `@` argument. The program prints nothing, because it does not compile.

The smallest accepted program changes two lines, 10 and 22 (see `program`). It prints:

```
5
5
a
```

## lines

Classification is for each line as written in `main.hero`.

| Line | Source | Class | Words of the specification relied on |
|---|---|---|---|
| 5 | `function bump(@c: Counter, by: i64)` | *new name* | "Param = "@" ident ":" Type" (section 4). The `@` marks `c` as a mutable parameter, so `c` comes into existence in `bump`. The write happens on line 6. |
| 6 | `c.hits @ c.hits + by` | *changes an existing name* | "`@` re-binds it, or a field or element inside one." (section 5). `c` is the `@` parameter, so the write reaches the caller's place. |
| 9 | `words = ["a", "b", "a", "c", "a"]` | *new name* | "`=` binds once, forever." (section 5). |
| 10 | `step = 1` | *new name* | "`=` binds once, forever." (section 5). This is the line that makes line 20 refused. |
| 11 | `counts: {str: i64} @= {}` | *new name* | "`@=` declares a mutable cell" (section 5). The annotation is needed because the map is empty (section 10). |
| 12 | `total @= 0` | *new name* | "`@=` declares a mutable cell" (section 5). |
| 15 | `counts[w] @ counts[w].default(0) + step` | *changes an existing name* | "`@` re-binds it, or a field or element inside one." (section 5). "`m[k] @ v` inserts or replaces;" (section 10). |
| 16 | `total @ total + step` | *changes an existing name* | "`@` re-binds it, or a field or element inside one." (section 5). |
| 18 | `c @= Counter(label: "a", hits: 0)` | *new name* | "`@=` declares a mutable cell" (section 5). |
| 19 | `bump(@c, counts["a"].default(0))` | *changes an existing name* | "Mutable parameters are marked `@` in the signature and at the call site" (section 9). "Either way the callee works on the caller's place itself" (section 9). The `@` on the argument is a write to `c`. |
| 20 | `step @ 2` | *changes an existing name* (in intent; refused as written) | "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it" (section 5). `step` was bound with `=` on line 10, so there is no cell to re-bind. |
| 21 | `bump(@c, step)` | *changes an existing name* | "Mutable parameters are marked `@` in the signature and at the call site" (section 9). |
| 22 | `last @= words[0]` | *new name* | "`@=` declares a mutable cell" (section 5). It is then refused, because "a cell nothing re-binds" is a compile error (section 5). |

Lines 1 to 4, 7 to 8, 13 to 14, 17, 23 to 26 hold no `=` or `@` and are not in the table. Line 5 and line 19 and 21 hold an `@` that marks a parameter or argument, not a binding of their own; I classified them by the name they affect (see `choice_points`).

## sentences

Every sentence the verdict rests on, quoted from `spec.md`:

1. Section 5: "`=` binds once, forever. `@=` declares a mutable cell, and `@` re-binds it, or a field or element inside one."
2. Section 5: "All bindings are initialised. An unused binding or parameter is a compile error, and so is a cell nothing re-binds or an `@` parameter nothing writes or ends (section 13), an `@` argument counting; a read is a use and a write is not, except through an `@` parameter."
3. Section 5: "Signatures are always explicit; inference is local only."
4. Section 5 grammar: "Place     = ident { "." ident | "[" Expression "]" } ."
5. Section 1: "One file is one module; the file you compile holds `function main()`, which takes nothing and produces nothing."
6. Section 2: "A literal takes the type its context asks for [...] otherwise `i64`."
7. Section 9: "Mutable parameters are marked `@` in the signature and at the call site: `function advance(@l: Lex)` … `advance(@l)`;"
8. Section 9: "Either way the callee works on the caller's place itself, which no other `@` argument of the call may reach, nor, for `lent`, one nested in another argument."
9. Section 10: "`m[k]` is a `V?` with code `missing_key`; `m[k] @ v` inserts or replaces;"
10. Section 6 table: "`.default(v)` | extract or fall back"
11. Section 3 table: "`[T]` | dynamic array, indices from 0"
12. Section 10: "An out-of-bounds index or slice aborts, and so does a slice that splits a character."
13. Section 7: "(both sides one numeric type [...])"
14. Section 11: "`print` writes its values with no separator and exactly one trailing newline, and takes the types this language renders as text: a number, `str` or `bool`."
15. Section 8: "Loops: `while cond` and `for x in xs`, over an array or a `range` (section 11)."

## program

The program I would submit. Changes from `main.hero`: line 10 is `step @= 1` (was `step = 1`), and line 22 is `last = words[0]` (was `last @= words[0]`).

```
record Counter
    label: str
    hits: i64

function bump(@c: Counter, by: i64)
    c.hits @ c.hits + by

function main()
    words = ["a", "b", "a", "c", "a"]
    step @= 1
    counts: {str: i64} @= {}
    total @= 0

    for w in words
        counts[w] @ counts[w].default(0) + step
        total @ total + step

    c @= Counter(label: "a", hits: 0)
    bump(@c, counts["a"].default(0))
    step @ 2
    bump(@c, step)
    last = words[0]
    print(c.hits)
    print(total)
    print(last)
```

Trace of the accepted program:

- The loop over `["a", "b", "a", "c", "a"]` with `step` = 1 gives `counts["a"]` = 3 and `total` = 5.
- `bump(@c, 3)` sets `c.hits` to 3.
- `step` becomes 2, and `bump(@c, 2)` sets `c.hits` to 5.
- `last` is `"a"`.

Output: `5`, `5`, `a`, one per line.

## choice_points

1. **Fixing line 20.** I made `step` a cell (`step @= 1` on line 10), so the re-binding on line 20 is legal. The other choice was to delete line 20 and write `bump(@c, 2)` on line 21, keeping `step = 1`. That also prints `5`, `5`, `a`, but it no longer says that `step` changes. I chose the edit that keeps the program's evident intent of a changing `step`.
2. **Fixing line 22.** I changed `@=` to `=`, because `last` is never re-bound. The other choice was to keep the cell and make it re-bound, for example `last @ words[4]` after the loop. That also prints `a`, since `words[4]` is `"a"`. I chose the smaller change, which keeps the value and drops the unneeded mutability. The program does not say whether `last` was meant to be the last word, so I kept `words[0]` as written.
3. **Line 5, the `@` parameter.** I classed it as *new name*, because the signature brings `c` into existence in `bump`. The other reading is *neither*, since the line binds nothing and only marks how `c` is passed. Both readings give the same verdict.
4. **Lines 19 and 21, the `@` argument.** I classed these as *changes an existing name* (the caller's `c`), because the callee writes through the argument. The other reading would count the argument as a use only. The spec's rule "an `@` argument counting" as a write settles it for the cell `c`, so I am confident in this one.
5. **Line 15, element write.** I classed `counts[w] @ ...` as *changes an existing name*, because the spec says `@` re-binds "a field or element inside one" and this is an element of the map cell `counts`. The other reading would treat the map as new. It would not change the verdict, but it would change the table row.
6. **Type of `words[0]`.** I took it to be `str`, not `str?`. The spec says an out-of-bounds index "aborts", not that it fails, so array indexing yields `T`. If it were `str?`, line 22 and line 25 would be refused in another way. The spec does not state this rule for arrays in a single sentence.
7. **Type of literals.** `step @ 2` and `total @ total + step` take `i64` by default and by the type of `step`, as section 2 says.

## confidence

- **High (about 90%)** that the checker refuses lines 20 and 22 and accepts everything else. Both refusals rest on sentences 1 and 2, which are explicit.
- **High** that the two-line fix is accepted and prints `5`, `5`, `a`. I traced the arithmetic by hand.
- **Lower** on the classification of the `@` parameter on line 5 (choice 3) and on whether an `@`-marked element write on a map counts as a change to the cell (choice 5). These are classifications, not checker outcomes.
- **Least sure** of the type of `words[0]` (choice 6). The spec does not state the array index type in one sentence. If it is wrong, the fixed program is refused on line 22 or line 25.
- I have not run the checker. The reading is from the specification only.

## context

Only the three files in this directory were read: `brief.md`, `spec.md` and `main.hero`. I did not read any file outside this directory, and I used no other tool.

Other material was in my session context and did not come from files I read. It was the environment block (working directory, platform, model and date), a git status snapshot of the user's repository, and account metadata. None of it was used to decide the verdict, and none of it is quoted here.
