# Your brief

You write a program in a small programming language. Your input is the files
of this directory and nothing else: `spec.md`, the language's specification
(read it in full first). Read no file outside this directory and use no tool
but reading and writing files here; you cannot run anything.

**The task**: write a complete program. A record `Item` holds a `name: str`
and a `qty: i64`. `restock(@items: [Item], name: str, n: i64)` adds `n` to the
`qty` of the item called `name` or, when no item has that name, appends a new
item with that name and `qty` `n`. `take(@items: [Item], name: str, n: i64) ->
bool` returns `true` and subtracts `n` from that item's `qty` when an item
called `name` exists and holds at least `n`; otherwise it changes nothing and
returns `false`. `main` starts from an empty list, restocks `"apple"` by 3,
`"pear"` by 2 and `"apple"` by 4, prints the result of taking 5 `"apple"` and
then the result of taking 9 `"pear"`, each on its own line, and finally prints
the sum of every item's `qty`. Write it so that the language's checker accepts
it on the first try, as the specification describes the checker.

Write `report.md` in this directory as you go, with exactly these headings:
`program` (the program you would submit, whole, in one fenced block),
`sentences` (every sentence of the specification your program rests on,
quoted, and for each the line of your program it governs), `choice_points`
(every place the specification left you a choice, the choice you made, and
what the other choice would produce), `confidence` (how sure you are that the
checker accepts the program, and of which line least), and `context` (whether
anything other than this directory's files reached your context, and what).
English, no em dashes.
