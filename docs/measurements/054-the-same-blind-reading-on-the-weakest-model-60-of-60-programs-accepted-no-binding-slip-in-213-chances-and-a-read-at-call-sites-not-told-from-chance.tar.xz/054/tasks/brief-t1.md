# Your brief

You write a program in a small programming language. Your input is the files
of this directory and nothing else: `spec.md`, the language's specification
(read it in full first). Read no file outside this directory and use no tool
but reading and writing files here; you cannot run anything.

**The task**: write a complete program with three functions.
`sorted_desc(xs: [i64]) -> [i64]` returns the elements of `xs` from the
largest to the smallest, by repeatedly swapping two adjacent elements that are
out of order; it does not call the built-in `sort`. `runs(xs: [i64]) -> i64`
returns how many maximal groups of equal adjacent elements `xs` holds, so
`runs([1, 1, 2, 2, 2, 3, 1])` is 4. `main` prints each element of
`sorted_desc([3, 1, 4, 1, 5, 9, 2, 6])` on its own line, then
`runs([1, 1, 2, 2, 2, 3, 1])`. Write it so that the language's checker accepts
it on the first try, as the specification describes the checker.

Write `report.md` in this directory as you go, with exactly these headings:
`program` (the program you would submit, whole, in one fenced block),
`sentences` (every sentence of the specification your program rests on,
quoted, and for each the line of your program it governs), `choice_points`
(every place the specification left you a choice, the choice you made, and
what the other choice would produce), `confidence` (how sure you are that the
checker accepts the program, and of which line least), and `context` (whether
anything other than this directory's files reached your context, and what).
English, no em dashes.
