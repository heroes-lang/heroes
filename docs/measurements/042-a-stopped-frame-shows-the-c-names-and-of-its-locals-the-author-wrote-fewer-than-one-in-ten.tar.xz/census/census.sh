# The census of a stopped frame's locals, as docs/measurements/042 gives it.
set -e
H=./heroes
D=build/census
L="lldb --no-lldbinit --no-use-colors --batch"
# The names `frame variable` printed at its top level, one per local.
names() { sed -n '/^(lldb) frame variable/,/^(lldb) [^f]/p' "$1" | grep -E '^\([^)]*\) [A-Za-z_][A-Za-z0-9_]* = ' | sed -E 's/^\([^)]*\) ([A-Za-z_][A-Za-z0-9_]*) = .*/\1/'; }
# A function's slots in the IR, one a line, the `$` kept.
slots() { grep -A1 "^function $2" "$1" | sed -n 2p | sed 's/^    slots  //; s/ · /\n/g' | sed -E 's/^([^:]+):.*/\1/'; }
split() {
    total=$(names "$1" | wc -l | tr -d ' ')
    temps=$(names "$1" | grep -cE '^t[0-9]+$' || true)
    params=$(names "$1" | grep -cE '^p?h[0-9]+_' | tr -d ' ')
    synthetic=$(slots "$2" "$3" | grep -c '^\$' || true)
    author=$(slots "$2" "$3" | grep -vc '^\$' || true)
    echo "$4: $total locals = $temps t<N> + $synthetic \$-synthetic + $author author-written slots + $((params - synthetic - author)) parameters"
    # The join: the slot names lldb printed, past the parameters, are the IR's with the `$` dropped.
    names "$1" | grep -vE '^t[0-9]+$' | sed -E 's/^p?h[0-9]+_//' | tail -n "+$((params - synthetic - author + 1))" > $D/c-slots.txt
    slots "$2" "$3" | sed 's/^\$//' | diff - $D/c-slots.txt > /dev/null && echo "   joined: every slot lldb named is the IR's, index for index"
}
mkdir -p $D
$H build tests/golden/run/adversarial-aggregate-overwrite.hero -O0 -o $D/agg > /dev/null
$L -o "breakpoint set --file adversarial-aggregate-overwrite.hero --line 71" -o run -o "frame variable" $D/agg > $D/agg.txt
$H build tests/golden/run/adversarial-aggregate-overwrite.hero --dump-ir > $D/agg.ir
$H build examples/interpreter/main.hero -O0 -o $D/interp > /dev/null
$L -o "breakpoint set --file syn/expr.hero --line 66" -o run -o "frame variable" $D/interp -- examples/interpreter/scripts/tour.script > $D/compared.txt
rm -rf $D/interp-copy && mkdir -p $D/interp-copy && cp -R examples/interpreter/lex examples/interpreter/syn examples/interpreter/util examples/interpreter/run $D/interp-copy/
{ cat examples/interpreter/syn/expr.hero; printf '\nfunction main()\n    print(0)\n'; } > $D/interp-copy/exprroot.hero
$H build $D/interp-copy/exprroot.hero --dump-ir > $D/compared.ir
$H build $D/shapes.hero --dump-ir > $D/shapes.ir
split $D/agg.txt $D/agg.ir 'main()' "(a) adversarial-aggregate-overwrite main, stopped at :71"
split $D/compared.txt $D/compared.ir 'compared' "(b) syn/expr.hero compared, stopped at :66"
split $D/shapes-out.txt $D/shapes.ir 'main()' "(c) the shapes program's main, stopped at :30"
