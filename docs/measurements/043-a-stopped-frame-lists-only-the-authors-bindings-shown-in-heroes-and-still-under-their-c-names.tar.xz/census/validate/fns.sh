names() { sed -n '/^(lldb) frame variable/,/^(lldb) [^f]/p' "$1" | grep -E '^\([^)]*\) [A-Za-z_][A-Za-z0-9_]* = ' | sed -E 's/^\([^)]*\) ([A-Za-z_][A-Za-z0-9_]*) = .*/\1/'; }
slots() { grep -A1 "^function $2" "$1" | sed -n 2p | sed 's/^    slots  //; s/ · /\n/g' | sed -E 's/^([^:]+):.*/\1/'; }
params_of() { grep -m1 "^function $2" "$1" | sed -E 's/^function [^(]*\((.*)\).*/\1/' | awk -F', ' '{ print ($0 == "" ? 0 : NF) }'; }
fvlines() { sed -n '/^(lldb) frame variable/,/^(lldb) [^f]/p' "$1" | grep -vc '^(lldb) ' || true; }
split() {
    P=$(params_of "$2" "$3")
    total=$(names "$1" | wc -l | tr -d ' ')
    temps=$(names "$1" | grep -cE '^t[0-9]+$' || true)
    irslots=$(slots "$2" "$3" | wc -l | tr -d ' ')
    irsyn=$(slots "$2" "$3" | grep -c '^\$' || true)
    irauthor=$(slots "$2" "$3" | grep -vc '^\$' || true)
    names "$1" | grep -vE '^t[0-9]+$' > $D/listed.txt || true
    slots "$2" "$3" > $D/irslots.txt
    # one line per listed non-temporary: its kind, its index, its name
    awk -v P="$P" 'NR == FNR { ir[FNR - 1] = $0; next }
        { if (match($0, /^p?h[0-9]+_/) == 0) { print "unjoined", $0; next }
          pre = substr($0, 1, RLENGTH); nm = substr($0, RLENGTH + 1)
          k = pre; gsub(/[^0-9]/, "", k); k += 0
          if (k < P) { print "parameter", k, nm; next }
          e = ir[k - P]; bare = e; sub(/^\$/, "", bare)
          if (bare != nm) { print "mismatch", k, nm, e; next }
          print (e ~ /^\$/ ? "synthetic" : "author"), k, nm }' $D/irslots.txt $D/listed.txt > $D/joined-$5.txt
    par=$(grep -c '^parameter ' $D/joined-$5.txt || true)
    syn=$(grep -c '^synthetic ' $D/joined-$5.txt || true)
    aut=$(grep -c '^author ' $D/joined-$5.txt || true)
    bad=$(grep -cE '^(unjoined|mismatch) ' $D/joined-$5.txt || true)
    echo "$4: $total locals = $temps t<N> + $syn \$-synthetic + $aut author-written slots + $par parameters; frame variable printed $(fvlines "$1") lines"
    echo "   the IR: $P parameters, $irslots slots ($irsyn \$-synthetic, $irauthor the author's); $bad listed names failed the join by index"
}
