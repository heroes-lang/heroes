# Measurement 043's sessions beside census.sh, run from the worktree's root
# after it. Every output named in the measurement is written here.
set -e
H=./heroes
D=build/census
F=build/heroes_lldb.py      # editors/lldb/heroes_lldb.py at 9f025f019, copied
L="lldb --no-lldbinit --no-use-colors --batch"
fvlines() { sed -n '/^(lldb) frame variable/,/^(lldb) [^f]/p' "$1" | grep -vc '^(lldb) ' || true; }

# 042 section 2's session with the formatter imported (census.sh ran it without).
$L -o "command script import $F" -o "breakpoint set --file shapes.hero --line 30" -o run -o "frame variable" \
   -o "command source -e false $D/p.txt" $D/shapes > $D/shapes-fmt-out.txt 2> $D/shapes-fmt-err.txt

# Frames (a) and (b) with the formatter imported (census.sh built both binaries).
$L -o "command script import $F" -o "breakpoint set --file adversarial-aggregate-overwrite.hero --line 71" \
   -o run -o "frame variable" $D/agg > $D/agg-fmt.txt 2> $D/agg-fmt-err.txt
$L -o "command script import $F" -o "breakpoint set --file syn/expr.hero --line 66" -o run -o "frame variable" \
   $D/interp -- examples/interpreter/scripts/tour.script > $D/compared-fmt.txt 2> $D/compared-fmt-err.txt
for f in agg compared shapes-out agg-fmt compared-fmt shapes-fmt-out; do
    t=$D/$f.txt; [ -f "$t" ] || t=$D/$f; echo "$f: frame variable printed $(fvlines $t) lines"
done > $D/fvlines.txt

# What each frame's prologue declares in the emitted C, and how many it marks.
$H build $D/shapes.hero --emit-c > $D/shapes.c 2> $D/shapes-emit-err.txt
$H build tests/golden/run/adversarial-aggregate-overwrite.hero --emit-c > $D/agg.c 2> $D/agg-emit-err.txt
$H build examples/interpreter/main.hero --emit-c > $D/interp.c 2> $D/interp-emit-err.txt
prologue() { awk -v pat="$2" 'found && !/^#line/ { print; exit } index($0, pat) && /\) \{$/ { found = 1 }' "$1"; }
count() {
    prologue "$1" "$2" | sed 's/goto bb0;//' | tr ';' '\n' | sed 's/^ *//' | grep -v '^$' > $D/prologue-$3.txt
    tot=$(wc -l < $D/prologue-$3.txt | tr -d ' ')
    nod=$(grep -c '^HERO_NODEBUG ' $D/prologue-$3.txt || true)
    temps=$(grep -cE ' t[0-9]+( =.*)?$' $D/prologue-$3.txt || true)
    echo "$3: $tot declared in the prologue, $nod marked HERO_NODEBUG ($temps of them t<N>), $((tot - nod)) unmarked: $(grep -v '^HERO_NODEBUG ' $D/prologue-$3.txt | sed -E 's/ = .*//; s/.* \**//' | tr '\n' ' ')"
}
{ count $D/agg.c 'h_adversarialaggregateoverwrite_main(void)' agg
  count $D/interp.c 'h_synexpr_compared(h_syncursor_Cursor' compared
  count $D/shapes.c 'h_shapes_main(void)' shapes; } > $D/prologue-counts.txt

# The census's join by index, asked of 042's own transcripts and IR (restored
# from its .tar.xz to build/before042/census): it must give 042's numbers.
B=build/before042/census
V=$D/validate
mkdir -p $V
sed -n '/^names()/p;/^slots()/p;/^params_of()/p;/^fvlines()/p' $D/census.sh > $V/fns.sh
sed -n '/^split() {/,/^}/p' $D/census.sh >> $V/fns.sh
sh -c ". $V/fns.sh; D=$V; split $B/agg.txt $B/agg.ir 'main()' '(a) 042' agg; split $B/compared.txt $B/compared.ir 'compared' '(b) 042' compared; split $B/shapes-out.txt $B/shapes.ir 'main()' '(c) 042' shapes" > $D/validate-out.txt
for f in agg compared shapes; do
    cmp -s $B/$f.ir $D/$f.ir && echo "$f.ir: byte-identical to 042's" || echo "$f.ir: differs from 042's"
done >> $D/validate-out.txt

# Without the formatter, the ten bindings and the twenty p answers against 042's.
fv() { sed -n '/^(lldb) frame variable/,/^(lldb) [^f]/p' "$1" | grep -v '^(lldb) ' | sed -E 's/0x[0-9a-f]{16}/<addr>/g'; }
fv $B/shapes-out.txt | awk '/^\(/ { keep = ($0 ~ / h[0-9]_/) } keep' > $D/fv-042-ten.txt
fv $D/shapes-out.txt | awk '/^\(/ { keep = ($0 ~ / h[0-9]_/) } keep' > $D/fv-043-ten.txt
ps_() { sed -n '/^(lldb) command source/,$p' "$1" | sed -E 's/0x[0-9a-f]{16}/<addr>/g; s#[^ ]*/build/census/p.txt#<p.txt>#'; }
ps_ $B/shapes-out.txt > $D/p-042.txt
ps_ $D/shapes-out.txt > $D/p-043.txt
{ cmp -s $D/fv-042-ten.txt $D/fv-043-ten.txt && echo "the ten bindings without the formatter: identical to 042's but for addresses" || echo "the ten bindings: differ"
  cmp -s $D/p-042.txt $D/p-043.txt && echo "the twenty p answers without the formatter: identical to 042's but for addresses and the path" || echo "the p answers: differ"
  echo "with the formatter: $(grep -c 'error: use of undeclared identifier' $D/shapes-fmt-out.txt) answer 'use of undeclared identifier', $(grep -c 'has unknown type' $D/shapes-fmt-out.txt) 'has unknown type'"
} > $D/compare-042.txt

# What lldb takes `name` to be (042 section 7 left it unrun).
printf '%s\n' 'image lookup -r -s ^_?name$' 'image lookup -r -n ^name$' 'target variable name' 'image lookup -t name' 'expr -- (void *)&name' > $D/name-probe-cmds.txt
$L -o "breakpoint set --file shapes.hero --line 30" -o run -o "command source -e false $D/name-probe-cmds.txt" $D/shapes > $D/name-probe.txt 2>&1

# Xcode's lldb-dap through panel 213's seat's client, copied unchanged to $D/dap.py,
# with the extension's initCommands (editors/vscode/extension.js, withFormatter).
python3 -I $D/dap.py "$(xcrun --find lldb-dap)" "$PWD/$D/shapes" "$PWD/$D/shapes.hero" 30 \
    "command script import \"$PWD/$F\"" > $D/dap-shapes.txt 2> $D/dap-shapes-err.txt
