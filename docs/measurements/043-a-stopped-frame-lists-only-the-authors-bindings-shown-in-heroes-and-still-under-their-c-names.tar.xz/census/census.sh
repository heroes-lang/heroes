# The census of a stopped frame's locals, docs/measurements/042 section 5 re-run
# for measurement 043 at c6f4d0157 (M-typed-inspection step 4). Run from the
# worktree's root. Same builds, same breakpoints, same lldb invocation as 042;
# `names` and `slots` are 042's word for word. What changes is the join: 042
# joined the slots lldb printed to the IR's slots line in ORDER, which held
# because every slot was printed; step 4 hides the invented ones, so here a
# printed slot `h<k>_<name>` (or `ph<k>_<name>`) is joined BY ITS INDEX k: k
# below the parameter count is a parameter, else the IR's slots-line entry
# k - params, whose name must equal <name> once its `$` is dropped.
set -e
H=./heroes
D=build/census
L="lldb --no-lldbinit --no-use-colors --batch"
# The names `frame variable` printed at its top level, one per local (042's).
names() { sed -n '/^(lldb) frame variable/,/^(lldb) [^f]/p' "$1" | grep -E '^\([^)]*\) [A-Za-z_][A-Za-z0-9_]* = ' | sed -E 's/^\([^)]*\) ([A-Za-z_][A-Za-z0-9_]*) = .*/\1/'; }
# A function's slots in the IR, one a line, the `$` kept (042's).
slots() { grep -A1 "^function $2" "$1" | sed -n 2p | sed 's/^    slots  //; s/ · /\n/g' | sed -E 's/^([^:]+):.*/\1/'; }
# A function's parameter count, from the IR's header line.
params_of() { grep -m1 "^function $2" "$1" | sed -E 's/^function [^(]*\((.*)\).*/\1/' | awk -F', ' '{ print ($0 == "" ? 0 : NF) }'; }
# The lines `frame variable` printed (the method that reads 042's 339, 595, 853).
fvlines() { sed -n '/^(lldb) frame variable/,/^(lldb) [^f]/p' "$1" | grep -vc '^(lldb) ' || true; }
split() {
    P=$(params_of "$2" "$3")
    total=$(names "$1" | wc -l | tr -d ' ')
    temps=$(names "$1" | grep -cE '^t[0-9]+$' || true)
    irslots=$(slots "$2" "$3" | wc -l | tr -d ' ')
    irsyn=$(slots "$2" "$3" | grep -c '^\$' || true)
    irauthor=$(slots "$2" "$3" | grep -vc '^\$' || true)
    names "$1" | grep -vE '^t[0-9]+$' > $D/listed.txt || true
    slots "$2" "$3" > $D/irslots.txt
    # one line per listed non-temporary: its kind, its index, its name
    awk -v P="$P" 'NR == FNR { ir[FNR - 1] = $0; next }
        { if (match($0, /^p?h[0-9]+_/) == 0) { print "unjoined", $0; next }
          pre = substr($0, 1, RLENGTH); nm = substr($0, RLENGTH + 1)
          k = pre; gsub(/[^0-9]/, "", k); k += 0
          if (k < P) { print "parameter", k, nm; next }
          e = ir[k - P]; bare = e; sub(/^\$/, "", bare)
          if (bare != nm) { print "mismatch", k, nm, e; next }
          print (e ~ /^\$/ ? "synthetic" : "author"), k, nm }' $D/irslots.txt $D/listed.txt > $D/joined-$5.txt
    par=$(grep -c '^parameter ' $D/joined-$5.txt || true)
    syn=$(grep -c '^synthetic ' $D/joined-$5.txt || true)
    aut=$(grep -c '^author ' $D/joined-$5.txt || true)
    bad=$(grep -cE '^(unjoined|mismatch) ' $D/joined-$5.txt || true)
    echo "$4: $total locals = $temps t<N> + $syn \$-synthetic + $aut author-written slots + $par parameters; frame variable printed $(fvlines "$1") lines"
    echo "   the IR: $P parameters, $irslots slots ($irsyn \$-synthetic, $irauthor the author's); $bad listed names failed the join by index"
}
mkdir -p $D
# 042 section 2's program and session (shapes.hero and p.txt copied from 042's archive).
$H build $D/shapes.hero -O0 -o $D/shapes > $D/shapes-build.txt 2>&1
$D/shapes > $D/shapes-run.txt
$L -o "breakpoint set --file shapes.hero --line 30" -o run -o "frame variable" \
   -o "command source -e false $D/p.txt" $D/shapes > $D/shapes-out.txt 2> $D/shapes-err.txt
$H build tests/golden/run/adversarial-aggregate-overwrite.hero -O0 -o $D/agg > /dev/null
$L -o "breakpoint set --file adversarial-aggregate-overwrite.hero --line 71" -o run -o "frame variable" $D/agg > $D/agg.txt
$H build tests/golden/run/adversarial-aggregate-overwrite.hero --dump-ir > $D/agg.ir
$H build examples/interpreter/main.hero -O0 -o $D/interp > /dev/null
$L -o "breakpoint set --file syn/expr.hero --line 66" -o run -o "frame variable" $D/interp -- examples/interpreter/scripts/tour.script > $D/compared.txt
rm -rf $D/interp-copy && mkdir -p $D/interp-copy && cp -R examples/interpreter/lex examples/interpreter/syn examples/interpreter/util examples/interpreter/run $D/interp-copy/
{ cat examples/interpreter/syn/expr.hero; printf '\nfunction main()\n    print(0)\n'; } > $D/interp-copy/exprroot.hero
$H build $D/interp-copy/exprroot.hero --dump-ir > $D/compared.ir
$H build $D/shapes.hero --dump-ir > $D/shapes.ir
split $D/agg.txt $D/agg.ir 'main()' "(a) adversarial-aggregate-overwrite main, stopped at :71" agg
split $D/compared.txt $D/compared.ir 'compared' "(b) syn/expr.hero compared, stopped at :66" compared
split $D/shapes-out.txt $D/shapes.ir 'main()' "(c) the shapes program's main, stopped at :30" shapes
