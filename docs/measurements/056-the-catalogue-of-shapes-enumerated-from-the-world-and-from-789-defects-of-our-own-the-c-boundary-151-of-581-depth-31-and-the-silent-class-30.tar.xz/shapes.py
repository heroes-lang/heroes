import json, re, io, collections, sys
d = json.load(io.open("defects.json"))
comp_areas = {"area:emit","area:check","area:compiler","area:parse","area:runtime","area:resolve","area:print","area:ir","area:seed","area:mutate","area:probe","area:module","area:cli"}
def area(i):
    a = [l["name"] for l in i["labels"] if l["name"].startswith("area:")]; return a[0] if a else "area:none"
def cls(i):
    c = [l["name"] for l in i["labels"] if l["name"].startswith("class:")]; return c[0] if c else "class:none"
S = collections.OrderedDict([
 ("fall", r"segfault|signal 11|(?<!Defect )\b(139|134)\b|stack (overflow|exhaust)|internal error|hero_unreachable|\bunreachable\b(?!_)|crash|infinite loop|never (ends|returns)|runs? for ever|hangs?\b"),
 ("silent", r"exit 0|wrong (value|answer|number|result|bytes|output)|prints? the wrong|silently|in silence|\bsilent\b"),
 ("accepts", r"accept(s|ed)?\b|is not refused|not refused|never refused|compiles? what|builds? what|passes? (a|the) wrong|unsound"),
 ("refuses", r"refuse[sd]? (a |the )?(correct|valid|legal)|rejects? (a |the )?(correct|valid)|correct program|false (refusal|positive)"),
 ("disagree", r"check (accepts|passes).*build|build (refuses|fails).*check|--emit-c|emitted C .*(does not|cannot|fails to) (compile|build|link)|clang (refuses|rejects|warns)"),
 ("fmt", r"\bfmt\b|format(ter|ted|ting)?\b|canonical|re-?print|round-?trip"),
 ("determinism", r"determinis|byte-?identical|second emission|differs? (between|across) (two )?(runs|emissions)"),
 ("cboundary", r"\bextern\b|\bheaders?\b|\bstructs?\b|callback|\bcstr\b|\blen[dt]s?\b|\blease[sd]?\b|end_lease|\bhandles?\b|\bFFI\b|\bC (type|struct|function|array|string|side|library|object)|counted_by|\bpartial\b|\bunions?\b|padding|\bABI\b|\bowned\b|\bconsumes\b|\bacquires\b|\bborrows\b|\btransfers\b|\bretains\b"),
 ("depth", r"nest(ed|ing)|\bdeep(ly)?\b|\bdepth\b|recurs|hundreds|thousands|many (levels|arguments|fields|cases)|\b[0-9],?[0-9]{3,} (levels|cases|fields|arms|elements|deep)|stack (overflow|exhaust)"),
 ("integers", r"overflow|\b[iu](8|16|32|64)\b|\bwidth\b|\bsign(ed|edness)?\b|\bshifts?\b|divi(de|sion)|modulo|\bliterals?\b|\bhex\b|octal"),
 ("floats", r"\bf32\b|\bf64\b|float|\bnan\b|\binf\b|rounding"),
 ("strings", r"utf-?8|escape|interpolat|\bf\"|\bslices?\b|\bchars?\b|\bbytes?\b|\bstrings?\b|\bstr\b"),
 ("generics", r"generic|type parameter|\binfer|instantiat"),
 ("match", r"\bmatch\b|\bvariants?\b|exhaustiv|\barms?\b|payload|catch-all|\bpatterns?\b"),
 ("places", r"\b@\b|@=|\bcells?\b|\blent\b|alias|\bcop(y|ies)\b|rebound|rebind|\bplaces?\b|mutable|in place"),
 ("failure", r"\bT\?|fallible|\bfail\b|\bok\(|\.must|\.default|\bcodes?:|\berror codes?\b|propagat|is_err"),
 ("diagnostics", r"message|diagnostic|\bfix(es)?\b|\bcertain\b|\bguess\b|position|\bcolumn\b|excerpt|\bnotes?\b|\btold\b|\bsays\b|wording|worded"),
 ("platforms", r"windows|linux|arm64|x86|msvc|clang-cl|\blld\b|darwin|macos|\bgcc\b|ubuntu|\bCI\b|\blegs?\b"),
 ("instruments", r"harness|\bsuites?\b|golden|census|\bprobe\b|\bhooks?\b|issues?\.hero|\bnet\b|\bseed\b|fixpoint|stage 2|\bmeasure\b|instrument|\bfloors?\b"),
])
R = {k: re.compile(p, re.I) for k, p in S.items()}
comp = [i for i in d if area(i) in comp_areas]
out = {"all": {}, "comp": {}, "lists": {}}
for k in S:
    out["all"][k] = sum(1 for i in d if R[k].search(i["title"]))
    out["comp"][k] = sum(1 for i in comp if R[k].search(i["title"]))
out["unmatched_all"] = sum(1 for i in d if not any(R[k].search(i["title"]) for k in S))
def show(name, pool):
    hits = [i for i in pool if R[name].search(i["title"])]
    print("\n== %s in compiler areas: %d  by area %s  by class %s" % (name, len(hits), dict(collections.Counter(area(i) for i in hits).most_common()), dict(collections.Counter(cls(i) for i in hits).most_common())))
    return hits
falls = show("fall", comp); silent = show("silent", comp); cb = show("cboundary", comp); dp = show("depth", comp)
for name, pool in (("fall", falls), ("silent", silent)):
    print("-- %s titles, with the words that matched:" % name)
    for i in pool: print("   %5d %-28s %s" % (i["number"], "|".join(sorted(set(m.group(0).lower() for m in R[name].finditer(i["title"])))), i["title"][:95]))
print("\nfalls at the C boundary:", sum(1 for i in falls if R["cboundary"].search(i["title"])), " depth:", sum(1 for i in falls if R["depth"].search(i["title"])), " neither:", sum(1 for i in falls if not R["cboundary"].search(i["title"]) and not R["depth"].search(i["title"])))
print("silent at the C boundary:", sum(1 for i in silent if R["cboundary"].search(i["title"])), " depth:", sum(1 for i in silent if R["depth"].search(i["title"])), " neither:", sum(1 for i in silent if not R["cboundary"].search(i["title"]) and not R["depth"].search(i["title"])))
ie = [i for i in falls if re.search("internal error", i["title"], re.I)]
hdr = [i for i in ie if re.search(r"header|bound|binding|group|macro|pragma|link|C (object|struct|function)|extern|cstr|lend", i["title"], re.I)]
print("falls saying internal error:", len(ie), " of them on a header, a binding or the link:", len(hdr))
early = [i for i in d if re.match(r"Defect 0(0[1-9]|1[0-9]|2[0-5])\b", i["title"])]
print("defects 001-025:", len(early), " C boundary:", sum(1 for i in early if R["cboundary"].search(i["title"])), " depth:", sum(1 for i in early if R["depth"].search(i["title"])), " fall:", sum(1 for i in early if R["fall"].search(i["title"])), " silent:", sum(1 for i in early if R["silent"].search(i["title"])))
print("\nALL 789:", out["all"]); print("COMPILER AREAS 581:", out["comp"]); print("unmatched over 789:", out["unmatched_all"])
json.dump({"patterns": S, "all": out["all"], "compiler_areas": out["comp"], "unmatched_all": out["unmatched_all"]}, io.open("shapes.json", "w"), indent=1)
